﻿using HHI.Data.Diagnostics;
using Oracle.DataAccess.Client;
using System;

namespace HHI.ShipBuilding.Data.QueryLog
{
    public class OracleFileLogProvider : HHI.Data.Diagnostics.FileLogProvider
    {
        // TODO : [공통팀] 파일 로그에 추가적인 정보를 로그로 남기는 경우 아래에 항목을 추가한다.
        static OracleFileLogProvider()
        {
            FileLogProvider.PropertyNames.Add("MENU_ID");
            FileLogProvider.PropertyNames.Add("MENU_TITLE");
        }

        protected override string GetParameterValueString(System.Data.Common.DbParameter parameter)
        {
            OracleParameter oracleParam = parameter as OracleParameter;
            if (oracleParam != null)
            {
                switch (oracleParam.OracleDbType)
                {
                    case OracleDbType.Date:
                        return String.Format("'{0:yyyy-MM-dd}'", oracleParam.Value);

                    case OracleDbType.TimeStamp:
                        return String.Format("'{0:yyyy-MM-dd HH:mm:ss}'", oracleParam.Value);
                }
            }

            return base.GetParameterValueString(parameter);
        }
    }
}
