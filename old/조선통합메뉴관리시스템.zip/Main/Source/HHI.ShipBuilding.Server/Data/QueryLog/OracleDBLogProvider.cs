﻿using HHI.Data.Diagnostics;

namespace HHI.ShipBuilding.Data.QueryLog
{
    public class OracleDBLogProvider : QueryLogProviderBase
    {
        public override void WriteLog(QueryLogInfo logInfo)
        {
            using (DbLogDac dac = new DbLogDac())
            {
                dac.SaveQueryLog(logInfo);
            }
        }
    }
}
