﻿using HHI.Data.Diagnostics;
using HHI.Data.Odp;
using HHI.ShipBuilding.Transactions;
//using Oracle.DataAccess.Client;/******************odp.net 직접 참조하지 말것....******************************************/
using System;
using System.Data;

namespace HHI.ShipBuilding.Data.QueryLog
{
    //@@@ 별도 트랜잭션 처리하는 코드가 추가되어야 한다.
    internal class DbLogDac : ShipBuildingDacBase
    {
        public void SaveQueryLog(QueryLogInfo logInfo)
        {
            //string queryString = logInfo.Command.CommandText;
            //string exceptionMessage = String.Empty;
            //int IS_SUCCESS = 1;
            //if (logInfo.Exception != null)
            //{
            //    IS_SUCCESS = 0;
            //    exceptionMessage = logInfo.Exception.ToString();
            //}

            //string QXML_ID = (logInfo.QueryXmlInfo == null ? "QXML_ID_NOT_FOUND" : logInfo.QueryXmlInfo.Substring(logInfo.QueryXmlInfo.LastIndexOf(',') + 2));
            //string STATEMENT = logInfo.Command.CommandText;
            //string USER_ID = logInfo.UserInfo.UserID;

            //string I_COMMAND_TYPE = logInfo.Command.CommandType.ToString();

            //string query = @"PK_QUERY_LOG.LOG_WRITE_NEW";

            //OdpParamCollection parameters = new OdpParamCollection();
            //parameters.Add("ISYSTEM_CODE", OracleDbType.Varchar2, logInfo.UserInfo["SYSTEM_CODE"]);
            //parameters.Add("IUSER_IP_GUID", OracleDbType.Varchar2, USER_ID + "@" + logInfo.UserInfo["WCF_INVOKE_GUID"]);
            //parameters.Add("IDB_TYPE", OracleDbType.Varchar2, "ORACLE");
            //parameters.Add("ISQL_TYPE", OracleDbType.Varchar2, (logInfo.Command.CommandType == CommandType.StoredProcedure ? (STATEMENT.IndexOf('.') > -1 ? "PACKAGE" : "PROCEDURE") : "SQL"));
            //parameters.Add("IQXML_ID", OracleDbType.Varchar2, QXML_ID);
            //parameters.Add("ISTATEMENT", OracleDbType.Clob, STATEMENT);
            //parameters.Add("IUSER_ID", OracleDbType.Varchar2, USER_ID);
            //parameters.Add("ISESSION_ID", OracleDbType.Varchar2, logInfo.UserInfo["LOGIN_GUID"]);
            //parameters.Add("IIS_SUCCESS", OracleDbType.Int32, IS_SUCCESS);
            //parameters.Add("IERROR_MSG", OracleDbType.Clob, exceptionMessage);
            //parameters.Add("IELAPSED_TIME", OracleDbType.Double, logInfo.ExecutionTime);


            ////쿼리 파라미터값은 로그에 저장안함
            ///*
            //ArrayList cPARAMETER_NAME = new ArrayList();
            //ArrayList cPARAMETER_VALUE = new ArrayList();

            //foreach (DbParameter param in logInfo.Command.Parameters)
            //{
            //    if (param.Direction == System.Data.ParameterDirection.Input || param.Direction == System.Data.ParameterDirection.InputOutput)
            //    {
            //        if (param.Value is byte[])
            //        {
            //            cPARAMETER_NAME.Add(param.ParameterName);
            //            cPARAMETER_VALUE.Add("byte [] size = " + (param.Value as byte[]).Length);
            //        }
            //        else if (param.Value is Array)
            //        {
            //            foreach (object o in (param.Value as Array))
            //            {
            //                cPARAMETER_NAME.Add(param.ParameterName);
            //                cPARAMETER_VALUE.Add(o.ToString());
            //            }
            //        }
            //        else
            //        {
            //            cPARAMETER_NAME.Add(param.ParameterName);
            //            cPARAMETER_VALUE.Add(param.Value.ToString());
            //        }
            //    }
            //}

            //OracleParameter PARAMETER_NAME = parameters.Add("cPARAMETER_NAME", OracleDbType.Varchar2);
            //PARAMETER_NAME.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            //PARAMETER_NAME.Size = cPARAMETER_NAME.Count;

            //if (cPARAMETER_NAME.Count == 0)
            //    PARAMETER_NAME.Value = new string[] { "" };
            //else
            //    PARAMETER_NAME.Value = cPARAMETER_NAME.ToArray();


            //OracleParameter PARAMETER_VALUE = parameters.Add("cPARAMETER_VALUE", OracleDbType.Varchar2);
            //PARAMETER_VALUE.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            //PARAMETER_VALUE.Size = cPARAMETER_NAME.Count;

            //if (cPARAMETER_NAME.Count == 0)
            //    PARAMETER_VALUE.Value = new string[] { "" };
            //else
            //    PARAMETER_VALUE.Value = cPARAMETER_VALUE.ToArray();
            //*/

            //HHI.Data.DbAccess dbAccess = QueryLogDbAccess;

            //dbAccess.EnabledQueryLogging = false;
            //dbAccess.ExecuteSpNonQuery(query, parameters);
        }
    }
}
