﻿using HHI.Data.DMF;
using System;

namespace HHI.ShipBuilding.Transactions
{
    public class CustomTypeConverter : TypeConverter
    {
        public override object ConvertToResultObject(object value, Type destinationType)
        {
            if (value is DBNull)
            {
                if (destinationType == typeof(String))
                {
                    return "DBNull";
                }
                else if (destinationType == typeof(DateTime))
                {
                    return DateTime.MinValue;
                }
                else if (destinationType == typeof(int))
                {
                    return -1;
                }
                else
                {
                    return null;
                }
            }

            return value;
        }
    }
}
