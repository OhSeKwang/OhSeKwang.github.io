﻿using HHI.Data;
using HHI.Data.DMF;
using HHI.ShipBuilding.Security;
using HHI.Transactions;
using System;

namespace HHI.ShipBuilding.Transactions
{
    public class ShipBuildingDacBase : DACBase
    {
        static ShipBuildingDacBase()
        {
            HHI.Data.Diagnostics.FileLogProvider.PropertyNames.Add("MENU_ID");
            HHI.Data.Diagnostics.FileLogProvider.PropertyNames.Add("MENU_TITLE");
            HHI.Data.Diagnostics.FileLogProvider.PropertyNames.Add("USER_IP");
        }

        /// <summary>
        /// 오라클 HiproSCM 디비계정에 쿼리로그를 남길 DbAccess 객체를 반환한다
        /// </summary>
        protected DbAccess QueryLogDbAccess
        {
            get
            {
                DbAccess dbAccess = DatabaseFactory.CreateDatabase(this._dataSource);
                dbAccess.CommandTimeout = 0;
                return dbAccess;
            }
        }

        /// <summary>
        /// DbAccess 객체를 반환한다.
        /// </summary>
        public new DbAccess DbAccess
        {
            get
            {
                base.DbAccess.CommandTimeout = 0;
                return base.DbAccess;
            }
        }

        // 데이터베이스 객체를 생성한다.
        protected override DbAccess CreateDbInstance()
        {
            if (string.IsNullOrWhiteSpace(this._dataSource))
                throw new HHIException("데이터소스가 정의되지 않았습니다");

            DbAccess dbAccess = DatabaseFactory.CreateDatabase(this._dataSource);
            dbAccess.CommandTimeout = 0;
            return dbAccess;
        }

        // 예외 발생시 파일 로그에 예외 정보를 기록한다.
        protected override void OnError(Exception ex)
        {
            ExceptionHandler(ex);
        }

        protected DataMapper _Mapper;
        protected string _configName = string.Empty;
        protected string _dataSource = string.Empty;

        protected string _O_APP_CODE = "ORT_YN";
        protected string _O_APP_MSG = "ORT_CODE";

        protected DataMapper Mapper
        {
            get
            {
                if (_Mapper == null)
                {

                    _Mapper = new DataMapper(base.DbAccess, _configName);
                }

                return _Mapper;
            }
        }


        protected bool GetParseSuccessCode(string parseString)
        {
            switch (parseString.ToLower())
            {
                case "y":
                    return true;
                case "s":
                    return true;
                case "true":
                    return true;
                case "t":
                    return true;
                default:
                    return false;
            }
        }
    }
}
