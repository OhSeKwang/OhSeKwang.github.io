﻿using HHI.Data.DMF;
using Oracle.DataAccess.Types;
using System;

namespace HHI.ShipBuilding.Transactions
{
    public class OdpTypeConverter : TypeConverter
    {
        public override object ConvertToParameterObject(object value)
        {
            if (value is OracleString)
            {
                if (((OracleString)value).IsNull)
                    return string.Empty;
                else
                    return ((OracleString)value).Value;
            }
            else if (value is OracleString[])
            {
                string[] result = new string[(value as OracleString[]).Length];
                int i = 0;
                foreach (OracleString item in (value as OracleString[]))
                {
                    if (item.IsNull)
                        result[i] = string.Empty;
                    else
                        result[i] = item.Value;

                    i++;
                }
                return result;
            }
            else if (value is OracleDecimal)
            {
                if (((OracleDecimal)value).IsNull)
                    return 0;
                else
                    return ((OracleDecimal)value).ToInt32();
            }
            else if (value is OracleDecimal[])
            {
                double[] result = new double[(value as OracleDecimal[]).Length];
                int i = 0;
                foreach (OracleDecimal item in (value as OracleDecimal[]))
                {
                    if (item.IsNull)
                        result[i] = 0;
                    else
                        result[i] = item.ToDouble();

                    i++;
                }
                return result;
            }
            else if (value is OracleDate)
            {
                if (((OracleDate)value).IsNull)
                    return DBNull.Value;
                else
                    return ((OracleDate)value).Value;
            }
            else if (value is OracleDate[])
            {
                DateTime[] result = new DateTime[(value as OracleDate[]).Length];
                int i = 0;
                foreach (OracleDate item in (value as OracleDate[]))
                {
                    if (!item.IsNull)
                        result[i] = item.Value;

                    i++;
                }
                return result;
            }
            else if (value is decimal)
            {
                return Convert.ToInt32(value);
            }
            /* Parameter Output으로 전달되는 OracleBlob를 byte[] 로 변환 */
            else if (value is OracleBlob)
            {
                OracleBlob blob = value as OracleBlob;
                return (byte[])blob.Value;
            }
            /* Parameter Output으로 전달되는 OracleClob를 string으로 변환 */
            else if (value is OracleClob)
            {
                OracleClob clob = value as OracleClob;
                return (string)clob.Value;
            }
            else
            {
                return value.ToString();
            }
        }

        public override object ConvertToParameterObject(object value, Type parameterType)
        {
            if (value is OracleString)
            {
                if (((OracleString)value).IsNull)
                    return string.Empty;
                else
                    return ((OracleString)value).Value;
            }
            else if (value is OracleDecimal)
            {
                if (((OracleDecimal)value).IsNull)
                    return 0;
                else
                    return ((OracleDecimal)value).ToInt32();
            }
            else if (value is decimal)
            {
                return Convert.ToInt32(value);
            }
            /* Parameter Output으로 전달되는 OracleBlob를 byte[] 로 변환 */
            else if (value is OracleBlob)
            {
                OracleBlob blob = value as OracleBlob;
                return (byte[])blob.Value;
            }
            /* Parameter Output으로 전달되는 OracleClob를 string으로 변환 */
            else if (value is OracleClob)
            {
                OracleClob clob = value as OracleClob;
                return (string)clob.Value;
            }

            return value;
        }

        public override object ConvertToResultObject(object value, Type destinationType)
        {
            if (value is DBNull)
            {
                if (destinationType == typeof(String))
                {
                    return "DBNull";
                }
                else if (destinationType == typeof(DateTime))
                {
                    return DateTime.MinValue;
                }
                else if (destinationType == typeof(int))
                {
                    return -1;
                }
                else
                {
                    return null;
                }
            }

            return ConvertToParameterObject(value);
        }
    }
}
