﻿using HHI.ShipBuilding.Security;
using HHI.Transactions;
using System;

namespace HHI.ShipBuilding.Transactions
{
    [Transaction(TransactionOption = TransactionOption.Supported, IsolationLevel = TransactionIsolationLevel.ReadCommitted)]
    [AutoComplete(true)]
    public class ShipBuildingBizBase : BIZBase
    {
        // 사용자 정보 객체를 반환한다.
        protected new StdUserInfoContext UserInfo
        {
            get { return (StdUserInfoContext)base.UserInfo; }
        }

        // 예외 발생시 파일 로그에 예외 정보를 기록한다.
        protected override void OnError(Exception ex)
        {
            ExceptionHandler(ex);
        }
    }
}
