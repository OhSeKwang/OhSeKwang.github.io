﻿using HHI.Configuration;
using HHI.ServiceModel;
using HHI.ShipBuilding.Biz;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.Security;
using HHI.ShipBuilding.WcfService.SC;
using HHI.ShipBuilding.WcfService.SystemChannel;
using System.Collections;
using System.Data;

namespace HHI.ShipBuilding.ServiceModel
{
    /// <summary>
    /// ShipBuilding Wcf Service Base 클래스
    /// </summary>
    public class ShipBuildingServiceBase : ServiceBase, IShipBuilding
    {
        #region 공통 프로퍼티

        /// <summary>
        /// 지정한 데이터소스에 대한 맵핑된 매퍼명을 반환한다.
        /// </summary>
        /// <param name="dataSource"></param>
        /// <returns></returns>
        private string GetDataMapperName(string dataSource)
        {
            string dataMapperName = AppSectionFactory.AppSection[dataSource];

            if (string.IsNullOrWhiteSpace(dataMapperName))
                throw new HHIException("지정한 데이터소스[" + dataSource + "]에 Server_Configuration.xml 에서 맵핑된 데이터매퍼명을 찾을 수 없습니다.");

            return dataMapperName;
        }

        /// <summary>
        /// 클라이언트IP 주소를 반환한다
        /// </summary>
        /// <returns></returns>
        protected string UserId
        {
            get
            {
                string userId = string.Empty;

                if (StdUserInfoContext.Current != null)
                {
                    userId = StdUserInfoContext.Current.UserID;
                }

                return userId;
            }
        }

        /// <summary>
        /// 클라이언트IP 주소를 반환한다
        /// </summary>
        /// <returns></returns>
        protected string IpAddress
        {
            get
            {
                string ipAddress = string.Empty;

                if (StdUserInfoContext.Current != null)
                {
                    ipAddress = StdUserInfoContext.Current["IP_ADDRESS"];
                }

                return ipAddress;
            }
        }

        /// <summary>
        /// 클라이언트 컴퓨터명을 반환한다
        /// </summary>
        /// <returns></returns>
        protected string ClientComputerName
        {
            get
            {
                string computerName = string.Empty;

                if (StdUserInfoContext.Current != null)
                {
                    computerName = StdUserInfoContext.Current["COMPUTER_NAME"];
                }

                return computerName;
            }
        }

        #endregion

        #region IShipBuilding 인터페이스 구현

        public DataSet ExecuteMultiDataSetByHashtable(string dataSources, string[] queryId, Hashtable[] paramObject)
        {
            string dataMapperName = GetDataMapperName(DbDataSourcePrefix.DefaultDataSource.ToString());

            using (ShipBuildingBiz biz = new ShipBuildingBiz(false))
            {
                return biz.MultiExecuteDataSet(dataMapperName, dataSources, queryId, paramObject, UserId, IpAddress, ClientComputerName);
            }
        }

        public DataSet ExecuteMultiDataSetByNoneParameter(string dataSources, string[] queryId)
        {
            string dataMapperName = GetDataMapperName(DbDataSourcePrefix.DefaultDataSource.ToString());

            using (ShipBuildingBiz biz = new ShipBuildingBiz(false))
            {
                return biz.MultiExecuteDataSet(dataMapperName, dataSources, queryId, UserId, IpAddress, ClientComputerName);
            }
        }

        public DataResultSets ExecuteMultiNonQueryByHashtable(string dataSources, bool isTransaction, string[] queryId, Hashtable[] paramObject)
        {
            return ExecuteMultiNonQuery(dataSources, isTransaction, queryId, paramObject);
        }

        public DataResultSets ExecuteMultiNonQueryByWcfParamDataList(string dataSources, bool isTransaction, string[] queryId, DataPack[] paramObject)
        {
            DataCollection[] paramObjectCon = new DataCollection[paramObject.Length];
            DataResultSets result;
            if (paramObject != null)
            {
                for (int i = 0; i < paramObject.Length; i++)
                {
                    paramObject[i].DataList.ItemCount = paramObject[i].ArrayItemCount;
                    paramObjectCon[i] = paramObject[i].DataList;
                }

                result = ExecuteMultiNonQuery(dataSources, isTransaction, queryId, paramObjectCon);
            }
            else
            {
                result = ExecuteMultiNonQuery(dataSources, isTransaction, queryId, null);
            }
            //쿼리아이디 지정
            for (int i = 0; i < result.dataResultSetList.Length; i++)
            {
                result.dataResultSetList[i].ScalarQueryID = queryId[i];
            }

            return result;
        }

        public DataSet ExecuteMultiDbDataSetByHashtable(string[] dataSources, string[] queryId, Hashtable[] paramObject)
        {
            string[] mapperNames = new string[dataSources.Length];
            for (int i = 0; i < dataSources.Length; i++)
            {
                mapperNames[i] = GetDataMapperName(dataSources[i]);
            }
            using (ShipBuildingBiz biz = new ShipBuildingBiz(false))
            {
                return biz.MultiExecuteDataSet(dataSources, mapperNames, queryId, paramObject, UserId, IpAddress, ClientComputerName);
            }
        }

        public DataSet ExecuteMultiDbDataSetByNoneParameter(string[] dataSources, string[] queryId)
        {
            string[] mapperNames = new string[dataSources.Length];
            for (int i = 0; i < dataSources.Length; i++)
            {
                mapperNames[i] = GetDataMapperName(dataSources[i]);
            }
            using (ShipBuildingBiz biz = new ShipBuildingBiz(false))
            {
                return biz.MultiExecuteDataSet(dataSources, mapperNames, queryId, UserId, IpAddress, ClientComputerName);
            }
        }

        private DataResultSets ExecuteMultiDbNonQuery(string[] dataSources, bool isTransaction, string[] queryId, object[] paramObject)
        {
            string[] mapperNames = new string[dataSources.Length];
            for (int i = 0; i < dataSources.Length; i++)
            {
                mapperNames[i] = GetDataMapperName(dataSources[i]);
            }
            DataResultSets result;
            using (ShipBuildingBiz biz = new ShipBuildingBiz(isTransaction))
            {
                result = biz.ExecuteMultiNonQuery(dataSources, mapperNames, queryId, paramObject, UserId, IpAddress, ClientComputerName);
            }
            //쿼리아이디 지정
            for (int i = 0; i < result.dataResultSetList.Length; i++)
            {
                result.dataResultSetList[i].ScalarQueryID = queryId[i];
            }

            return result;
        }

        public DataResultSets ExecuteMultiDbNonQueryByHashtable(string[] dataSources, bool isTransaction, string[] queryId, Hashtable[] paramObject)
        {
            return ExecuteMultiDbNonQuery(dataSources, isTransaction, queryId, paramObject);
        }

        public DataResultSets ExecuteMultiDbNonQueryByWcfParamDataList(string[] dataSources, bool isTransaction, string[] queryId, DataPack[] paramObject)
        {
            return ExecuteMultiDbNonQuery(dataSources, isTransaction, queryId, paramObject);
        }

        public DataResultSet ExecuteDataSetByHashtable(string dataSources, bool isTransaction, string queryId, Hashtable paramObject)
        {
            return ExecuteDataSet(dataSources, isTransaction, queryId, paramObject);
        }

        public DataResultSet ExecuteDataSetByWcfParamDataList(string dataSources, bool isTransaction, string queryId, DataPack paramObject)
        {
            if (paramObject != null)
            {
                paramObject.DataList.ItemCount = paramObject.ArrayItemCount;

                return ExecuteDataSet(dataSources, isTransaction, queryId, paramObject.DataList);
            }
            else
            {
                return ExecuteDataSet(dataSources, isTransaction, queryId, null);
            }
        }

        public DataResultSet ExecuteNonQueryByHashtable(string dataSources, bool isTransaction, string queryId, Hashtable paramObject)
        {
            return ExecuteNonQuery(dataSources, isTransaction, queryId, paramObject);
        }

        public DataResultSet ExecuteNonQueryByWcfParamDataList(string dataSources, bool isTransaction, string queryId, DataPack paramObject)
        {
            if (paramObject != null)
            {
                paramObject.DataList.ItemCount = paramObject.ArrayItemCount;

                return ExecuteNonQuery(dataSources, isTransaction, queryId, paramObject.DataList);
            }
            else
            {
                return ExecuteNonQuery(dataSources, isTransaction, queryId, null);
            }
        }

        public void Dispose()
        {
            
        }

        #endregion

        #region DataResultSet 반환 Common 메소드

        /// <summary>
        /// 지정한 쿼리아이디를 다중 실행한다
        /// </summary>
        /// <param name="isTransaction">트랜잭션여부</param>
        /// <param name="queryId">쿼리아이디</param>
        /// <param name="paramObject">파라미터</param>
        /// <param name="userId">사용자 아이디</param>
        /// <param name="ipAddress">클라이언트 아이피</param>
        /// <param name="computer_name">클라언트 컴퓨터명</param>
        /// <returns>영향을 받은 행수</returns>
        private DataResultSets ExecuteMultiNonQuery(string dataSources, bool isTransaction, string[] queryId, object[] paramObject)
        {
            string dataMapperName = GetDataMapperName(DbDataSourcePrefix.DefaultDataSource.ToString());

            DataResultSets result;
            using (ShipBuildingBiz biz = new ShipBuildingBiz(isTransaction))
            {
                result = biz.ExecuteMultiNonQuery(dataMapperName, dataSources, queryId, paramObject, UserId, IpAddress, ClientComputerName);
            }
            //쿼리아이디 지정
            for (int i = 0; i < result.dataResultSetList.Length; i++)
            {
                result.dataResultSetList[i].ScalarQueryID = queryId[i];
            }

            return result;
        }

        /// <summary>
        /// 지정한 쿼리아이디를 실행한다
        /// </summary>
        /// <param name="isTransaction">트랜잭션여부</param>
        /// <param name="queryId">쿼리아이디</param>
        /// <param name="paramObject">파라미터</param>
        /// <returns>영향을 받은 행수</returns>
        private DataResultSet ExecuteNonQuery(string dataSources, bool isTransaction, string queryId, object paramObject)
        {
            string dataMapperName = GetDataMapperName(DbDataSourcePrefix.DefaultDataSource.ToString());

            DataResultSet result;
            using (ShipBuildingBiz biz = new ShipBuildingBiz(isTransaction))
            {
                result = biz.ExecuteNonQuery(dataMapperName, dataSources, queryId, paramObject, UserId, IpAddress, ClientComputerName);

                result.ScalarQueryID = queryId;
            }

            return result;
        }

        /// <summary>
        /// 지정한 쿼리아이디를 실행한다
        /// </summary>
        /// <param name="isTransaction">트랜잭션여부</param>
        /// <param name="queryId">쿼리아이디</param>
        /// <param name="paramObject">파라미터</param>
        /// <returns>실행결과</returns>
        private DataResultSet ExecuteDataSet(string dataSources, bool isTransaction, string queryId, object paramObject)
        {
            string dataMapperName = GetDataMapperName(DbDataSourcePrefix.DefaultDataSource.ToString());

            DataResultSet resultSet = null;
            using (ShipBuildingBiz biz = new ShipBuildingBiz(isTransaction))
            {
                resultSet = biz.ExecuteDataSet(dataMapperName, dataSources, queryId, paramObject, UserId, IpAddress, ClientComputerName);

                resultSet.ScalarQueryID = queryId;
            }
            return resultSet;
        }

        #endregion
    }
}
