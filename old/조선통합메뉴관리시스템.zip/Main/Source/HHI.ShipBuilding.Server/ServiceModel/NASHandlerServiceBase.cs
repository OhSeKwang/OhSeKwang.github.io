﻿using System;
using System.IO;
using System.Collections;
using System.Data;

using HHI.Configuration;
using HHI.ServiceModel;

using HHI.ShipBuilding.Biz;
using HHI.ShipBuilding.WcfService.SC;
using HHI.ShipBuilding.WcfService.SystemChannel;
using System.Security.Principal;

namespace HHI.ShipBuilding.ServiceModel
{
    /// <summary>
    /// BIZWORK Wcf Service Base 클래스
    /// </summary>
    public class NASHandlerServiceBase : ServiceBase, INASHandler
    {
        //public BIZWORKServiceBase()
        //    : base(false)
        //{

        //}

        #region NAS 폴더 생성 - NASFolderCreateAPI
        /// <summary>
        /// NAS 폴더 생성
        /// </summary>
        /// <param name="strFolderPath"></param>
        /// <returns></returns>
        public bool NASFolderCreateAPI(string strNASInfo, string strFolderPath)
        {
            bool bResult = true;

            /* NAS 장비에 직접 파일 쓰기....*/
            WindowsImpersonationContext ctx = null;
            IntPtr token = IntPtr.Zero;

            try
            {
                //strFolderPath = AppSectionFactory.AppSection[string.Format("{0}_NASPATH", strNASInfo)] + strFolderPath;
                //string strNASId = AppSectionFactory.AppSection[string.Format("{0}_NASID", strNASInfo)];
                //string strNASPw = AppSectionFactory.AppSection[string.Format("{0}_NASPW", strNASInfo)];

                string strNASId = string.Empty;
                string strNASPw = string.Empty;

                GetNASAccountInfo(strNASInfo, ref strFolderPath, ref strNASId, ref strNASPw);

                token = SecurityAPI.LogonNAS(strNASId, strNASPw, strNASInfo);
                ctx = WindowsIdentity.Impersonate(token);

                if (!Directory.Exists(strFolderPath))
                {
                    Directory.CreateDirectory(strFolderPath);
                }
            }
            catch (Exception ex)
            {
                bResult = false;
                throw ex;
            }
            finally
            {
                if (ctx != null)
                {
                    ctx.Undo();
                }

                if (token != IntPtr.Zero)
                {
                    SecurityAPI.CloseHandle(token);
                }
            }

            return bResult;
        }
        #endregion NAS 폴더 생성 - NASFolderCreateAPI

        #region NAS 폴더 삭제 - NASFolderDeleteAPI
        /// <summary>
        /// NAS 폴더 삭제
        /// </summary>
        /// <param name="strFolderPath"></param>
        /// <returns></returns>
        public bool NASFolderDeleteAPI(string strNASInfo, string strFolderPath)
        {
            bool bResult = true;

            /* NAS 장비에 직접 파일 쓰기....*/
            WindowsImpersonationContext ctx = null;
            IntPtr token = IntPtr.Zero;

            try
            {
                //strFolderPath = AppSectionFactory.AppSection[string.Format("{0}_NASPATH", strNASInfo)] + strFolderPath;
                //string strNASId = AppSectionFactory.AppSection[string.Format("{0}_NASID", strNASInfo)];
                //string strNASPw = AppSectionFactory.AppSection[string.Format("{0}_NASPW", strNASInfo)];

                string strNASId = string.Empty;
                string strNASPw = string.Empty;

                GetNASAccountInfo(strNASInfo, ref strFolderPath, ref strNASId, ref strNASPw);

                token = SecurityAPI.LogonNAS(strNASId, strNASPw, strNASInfo);
                ctx = WindowsIdentity.Impersonate(token);

                if (!Directory.Exists(strFolderPath))
                {
                    Directory.Delete(strFolderPath, true);
                }
            }
            catch (Exception ex)
            {
                bResult = false;
                throw ex;
            }
            finally
            {
                if (ctx != null)
                {
                    ctx.Undo();
                }

                if (token != IntPtr.Zero)
                {
                    SecurityAPI.CloseHandle(token);
                }
            }

            return bResult;
        }
        #endregion NAS 폴더 삭제 - NASFolderDeleteAPI

        #region NAS 파일 존재 확인 - NASFileChecked
        /// <summary>
        /// NAS 파일 존재 확인
        /// </summary>
        /// <param name="strFilePathFull"></param>
        /// <returns></returns>
        public bool NASFileChecked(string strNASInfo, string strFilePathFull)
        {
            bool bResult = true;

            /* NAS 장비에 직접 파일 쓰기....*/
            WindowsImpersonationContext ctx = null;
            IntPtr token = IntPtr.Zero;

            try
            {
                //strFilePathFull = AppSectionFactory.AppSection[string.Format("{0}_NASPATH", strNASInfo)] + strFilePathFull;
                //string strNASId = AppSectionFactory.AppSection[string.Format("{0}_NASID", strNASInfo)];
                //string strNASPw = AppSectionFactory.AppSection[string.Format("{0}_NASPW", strNASInfo)];

                string strNASId = string.Empty;
                string strNASPw = string.Empty;

                GetNASAccountInfo(strNASInfo, ref strFilePathFull, ref strNASId, ref strNASPw);

                token = SecurityAPI.LogonNAS(strNASId, strNASPw, strNASInfo);
                ctx = WindowsIdentity.Impersonate(token);

                bResult = File.Exists(strFilePathFull);
            }
            catch (Exception ex)
            {
                bResult = false;
                throw ex;
            }
            finally
            {
                if (ctx != null)
                {
                    ctx.Undo();
                }

                if (token != IntPtr.Zero)
                {
                    SecurityAPI.CloseHandle(token);
                }
            }

            return bResult;
        }
        #endregion NAS 파일 존재 확인 - NASFileChecked

        #region 첨부 파일 업로드 - FileUpLoadAPI
        /// <summary>
        /// 첨부 파일 업로드
        /// </summary>
        /// <param name="strFileSubUrl"></param>
        /// <param name="strFileName"></param>
        /// <param name="byteFile"></param>
        /// <returns></returns>
        public bool FileUpLoadAPI(string strNASInfo, string strFileSubUrl, string strFileName, byte[] byteFile)
        {
            bool bResult = true;

            /* NAS 장비에 직접 파일 쓰기....*/
            WindowsImpersonationContext ctx = null;
            IntPtr token = IntPtr.Zero;

            try
            {
                //strFileSubUrl = AppSectionFactory.AppSection[string.Format("{0}_NASPATH", strNASInfo)] + strFileSubUrl;
                //string strNASId = AppSectionFactory.AppSection[string.Format("{0}_NASID", strNASInfo)];
                //string strNASPw = AppSectionFactory.AppSection[string.Format("{0}_NASPW", strNASInfo)];

                string strNASId = string.Empty;
                string strNASPw = string.Empty;

                GetNASAccountInfo(strNASInfo, ref strFileSubUrl, ref strNASId, ref strNASPw);

                token = SecurityAPI.LogonNAS(strNASId, strNASPw, strNASInfo);
                ctx = WindowsIdentity.Impersonate(token);

                if (!Directory.Exists(strFileSubUrl))
                {
                    Directory.CreateDirectory(strFileSubUrl);
                }

                File.WriteAllBytes(strFileSubUrl + @"\" + strFileName, byteFile);
            }
            catch (Exception ex)
            {
                bResult = false;
                throw ex;
            }
            finally
            {
                if (ctx != null)
                {
                    ctx.Undo();
                }

                if (token != IntPtr.Zero)
                {
                    SecurityAPI.CloseHandle(token);
                }
            }

            return bResult;
        }
        #endregion 첨부 파일 업로드 - FileUpLoadAPI

        #region 첨부 파일 다운로드 - FileDownLoadAPI
        /// <summary>
        /// 첨부 파일 다운로드
        /// </summary>
        /// <param name="strFileSubUrl"></param>
        /// <param name="strServerFileFullName"></param>
        /// <returns></returns>
        public byte[] FileDownLoadAPI(string strNASInfo, string strServerFileFullName)
        {
            byte[] byteResult = null;

            /* NAS 장비에 직접 파일 쓰기....*/
            WindowsImpersonationContext ctx = null;
            IntPtr token = IntPtr.Zero;

            try
            {
                //strServerFileFullName = AppSectionFactory.AppSection[string.Format("{0}_NASPATH", strNASInfo)] + strServerFileFullName;
                //string strNASId = AppSectionFactory.AppSection[string.Format("{0}_NASID", strNASInfo)];
                //string strNASPw = AppSectionFactory.AppSection[string.Format("{0}_NASPW", strNASInfo)];

                string strNASId = string.Empty;
                string strNASPw = string.Empty;

                GetNASAccountInfo(strNASInfo, ref strServerFileFullName, ref strNASId, ref strNASPw);

                token = SecurityAPI.LogonNAS(strNASId, strNASPw, strNASInfo);
                ctx = WindowsIdentity.Impersonate(token);

                byteResult = File.ReadAllBytes(strServerFileFullName);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (ctx != null)
                {
                    ctx.Undo();
                }

                if (token != IntPtr.Zero)
                {
                    SecurityAPI.CloseHandle(token);
                }
            }

            return byteResult;
        }
        #endregion 첨부 파일 다운로드 - FileDownLoadAPI

        #region 첨부 파일 삭제 - FileDeleteAPI
        public bool FileDeleteAPI(string strNASInfo, string strFileSubUrl, string strFileName)
        {
            bool bResult = true;

            /* NAS 장비에 직접 파일 쓰기....*/
            WindowsImpersonationContext ctx = null;
            IntPtr token = IntPtr.Zero;

            try
            {
                // NAS Login
                //strFileSubUrl = AppSectionFactory.AppSection[string.Format("{0}_NASPATH", strNASInfo)] + strFileSubUrl;
                //string strNASId = AppSectionFactory.AppSection[string.Format("{0}_NASID", strNASInfo)];
                //string strNASPw = AppSectionFactory.AppSection[string.Format("{0}_NASPW", strNASInfo)];

                string strNASId = string.Empty;
                string strNASPw = string.Empty;

                GetNASAccountInfo(strNASInfo, ref strFileSubUrl, ref strNASId, ref strNASPw);

                token = SecurityAPI.LogonNAS(strNASId, strNASPw, strNASInfo);
                ctx = WindowsIdentity.Impersonate(token);

                if (Directory.Exists(strFileSubUrl))
                {
                    File.Delete(strFileSubUrl + @"\" + strFileName);
                }
            }
            catch (Exception ex)
            {
                bResult = false;
                throw ex;
            }
            finally
            {
                if (ctx != null)
                {
                    ctx.Undo();
                }

                if (token != IntPtr.Zero)
                {
                    SecurityAPI.CloseHandle(token);
                }
            }

            return bResult;
        }
        #endregion

        #region NAS 폴더 정보 - NASGetDirectorys
        /// <summary>
        /// NAS 폴더 정보
        /// </summary>
        /// <param name="strNASInfo"></param>
        /// <param name="strPath"></param>
        /// <returns></returns>
        public string[] NASGetDirectorys(string strNASInfo, string strPath)
        {
            string[] arrDir = null;

            /* NAS 장비에 직접 파일 쓰기....*/
            WindowsImpersonationContext ctx = null;
            IntPtr token = IntPtr.Zero;

            try
            {
                ////strDirPath = AppSectionFactory.AppSection[string.Format("{0}_NASPATH", strNASInfo)] + strDirPath;
                //string strNASId = AppSectionFactory.AppSection[string.Format("{0}_NASID", strNASInfo)];
                //string strNASPw = AppSectionFactory.AppSection[string.Format("{0}_NASPW", strNASInfo)];

                string strTemp = string.Empty;
                string strNASId = string.Empty;
                string strNASPw = string.Empty;

                GetNASAccountInfo(strNASInfo, ref strTemp, ref strNASId, ref strNASPw);

                token = SecurityAPI.LogonNAS(strNASId, strNASPw, strNASInfo);
                ctx = WindowsIdentity.Impersonate(token);

                arrDir = Directory.GetDirectories(strPath);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (ctx != null)
                {
                    ctx.Undo();
                }

                if (token != IntPtr.Zero)
                {
                    SecurityAPI.CloseHandle(token);
                }
            }

            return arrDir;
        }
        #endregion NAS 폴더 정보 - NASGetDirectorys

        #region NAS 파일 정보 - NASGetFiles
        /// <summary>
        /// NAS 파일 정보
        /// </summary>
        /// <param name="strNASInfo"></param>
        /// <param name="strPath"></param>
        /// <returns></returns>
        public string[] NASGetFiles(string strNASInfo, string strPath)
        {
            string[] arrFiles = null;

            /* NAS 장비에 직접 파일 쓰기....*/
            WindowsImpersonationContext ctx = null;
            IntPtr token = IntPtr.Zero;

            try
            {
                ////strDirPath = AppSectionFactory.AppSection[string.Format("{0}_NASPATH", strNASInfo)] + strDirPath;
                //string strNASId = AppSectionFactory.AppSection[string.Format("{0}_NASID", strNASInfo)];
                //string strNASPw = AppSectionFactory.AppSection[string.Format("{0}_NASPW", strNASInfo)];

                string strTemp = string.Empty;
                string strNASId = string.Empty;
                string strNASPw = string.Empty;

                GetNASAccountInfo(strNASInfo, ref strTemp, ref strNASId, ref strNASPw);

                token = SecurityAPI.LogonNAS(strNASId, strNASPw, strNASInfo);
                ctx = WindowsIdentity.Impersonate(token);

                arrFiles = Directory.GetFiles(strPath);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (ctx != null)
                {
                    ctx.Undo();
                }

                if (token != IntPtr.Zero)
                {
                    SecurityAPI.CloseHandle(token);
                }
            }

            return arrFiles;
        }
        #endregion NAS 파일 정보 - NASGetFiles

        #region NAS 파일 정보 - NASGetFileInfo
        /// <summary>
        /// NAS 파일 정보
        /// </summary>
        /// <param name="strNASInfo"></param>
        /// <param name="strPath"></param>
        /// <returns></returns>
        public Hashtable NASGetFileInfo(string strNASInfo, string strPath)
        {
            Hashtable hsFileInfo = null;

            /* NAS 장비에 직접 파일 쓰기....*/
            WindowsImpersonationContext ctx = null;
            IntPtr token = IntPtr.Zero;

            try
            {
                ////strDirPath = AppSectionFactory.AppSection[string.Format("{0}_NASPATH", strNASInfo)] + strDirPath;
                //string strNASId = AppSectionFactory.AppSection[string.Format("{0}_NASID", strNASInfo)];
                //string strNASPw = AppSectionFactory.AppSection[string.Format("{0}_NASPW", strNASInfo)];

                string strTemp = string.Empty;
                string strNASId = string.Empty;
                string strNASPw = string.Empty;

                GetNASAccountInfo(strNASInfo, ref strTemp, ref strNASId, ref strNASPw);

                token = SecurityAPI.LogonNAS(strNASId, strNASPw, strNASInfo);
                ctx = WindowsIdentity.Impersonate(token);

                FileInfo fileInfo = new FileInfo(strPath);
                if (fileInfo.Exists)
                {
                    hsFileInfo = new Hashtable();
                    hsFileInfo.Add("LENGTH", fileInfo.Length);
                    hsFileInfo.Add("LASTWRITETIME", fileInfo.LastWriteTime);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (ctx != null)
                {
                    ctx.Undo();
                }

                if (token != IntPtr.Zero)
                {
                    SecurityAPI.CloseHandle(token);
                }
            }

            return hsFileInfo;
        }
        #endregion NAS 파일 정보 - NASGetFileInfo

        #region NAS 파일 정보 - NASGetFileInfo
        /// <summary>
        /// NAS 폴더 정보
        /// </summary>
        /// <param name="strNASInfo"></param>
        /// <param name="strPath"></param>
        /// <returns></returns>
        public Hashtable NASGetDirectoryInfo(string strNASInfo, string strPath)
        {
            Hashtable hsDirectoryInfo = null;

            /* NAS 장비에 직접 파일 쓰기....*/
            WindowsImpersonationContext ctx = null;
            IntPtr token = IntPtr.Zero;

            try
            {
                ////strDirPath = AppSectionFactory.AppSection[string.Format("{0}_NASPATH", strNASInfo)] + strDirPath;
                //string strNASId = AppSectionFactory.AppSection[string.Format("{0}_NASID", strNASInfo)];
                //string strNASPw = AppSectionFactory.AppSection[string.Format("{0}_NASPW", strNASInfo)];

                string strTemp = string.Empty;
                string strNASId = string.Empty;
                string strNASPw = string.Empty;

                GetNASAccountInfo(strNASInfo, ref strTemp, ref strNASId, ref strNASPw);

                token = SecurityAPI.LogonNAS(strNASId, strNASPw, strNASInfo);
                ctx = WindowsIdentity.Impersonate(token);

                DirectoryInfo directoryInfo = new DirectoryInfo(strPath);
                if (directoryInfo.Exists)
                {
                    hsDirectoryInfo = new Hashtable();
                    hsDirectoryInfo.Add("LASTWRITETIME", directoryInfo.LastWriteTime);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (ctx != null)
                {
                    ctx.Undo();
                }

                if (token != IntPtr.Zero)
                {
                    SecurityAPI.CloseHandle(token);
                }
            }

            return hsDirectoryInfo;
        }
        #endregion NAS 파일 정보 - NASGetFileInfo

        #region NAS 연결 정보 - GetNASAccountInfo
        /// <summary>
        /// NAS 연결 정보
        /// </summary>
        /// <param name="nasInfo"></param>
        /// <param name="folderPath"></param>
        /// <param name="nasId"></param>
        /// <param name="nasPw"></param>
        private void GetNASAccountInfo(string nasInfo, ref string folderPath, ref string nasId, ref string nasPw)
        {
            if (nasInfo.Equals("DEFAULT"))
            {
                folderPath = @"\\10.100.18.62\" + folderPath;
                nasId = "ca02";
                nasPw = "ca02ca02";
            }
            else if (nasInfo.Equals("CA04"))
            {
                folderPath = @"\\10.100.18.62\" + folderPath;
                nasId = "ca04";
                nasPw = "ca04ca04";
            }            
            else if (nasInfo.Equals("CLOUD"))
            {
                folderPath = @"\\10.100.18.62\" + folderPath;
                nasId = "cx90cloud";
                nasPw = "P@ssw0rd";
            }
            else if (nasInfo.Equals("CJ051"))
            {
                folderPath = @"\\10.100.18.62\" + folderPath;
                nasId = "cj051";
                nasPw = "P@ssw0rd";
            }
            else if (nasInfo.Equals("NEST_DWG"))
            {
                folderPath = @"\\10.4.89.3\" + folderPath;
                nasId = "dwg";
                nasPw = "@dwg9";
            }
        }
        #endregion NAS 연결 정보 - GetNASAccountInfo

        public void Dispose()
        {

        }
    }
}
