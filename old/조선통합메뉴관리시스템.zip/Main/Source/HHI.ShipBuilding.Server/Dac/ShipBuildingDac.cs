﻿using HHI.Data.DMF.Common;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.Security;
using HHI.ShipBuilding.Transactions;
using System;
using System.Collections;
using System.Data;

namespace HHI.ShipBuilding.Dac
{
    public class ShipBuildingDac : ShipBuildingDacBase
    {
        /// <summary>
        /// 사용할 DataMapper를 지정한다
        /// </summary>
        /// <param name="configName">DataMapper명</param>
        /// <param name="dataSource">데이터 소스명</param>
        public ShipBuildingDac(string configName, string dataSource)
        {
            base._configName = configName;
            base._dataSource = dataSource;
        }

        #region Utility

        /// <summary>
        /// Serialization시 바이너리포맷[내부적으로 base64Bianary형식으로 됨^^]으로 적용되는 DataSet객체를 생성한다
        /// </summary>
        /// <returns></returns>
        private static DataSet CreateDataSetSeializationBinaryForamt()
        {
            DataSet result = new DataSet();
            result.RemotingFormat = SerializationFormat.Binary;
            return result;
        }

        #endregion Utility

        #region Multi

        #region DataSet

        /// <summary>
        /// 해당 쿼리아이디에 대하여 실행을 한다
        /// </summary>
        /// <param name="queryArray">쿼리아이디</param>
        /// <param name="paramObject">파라미터정보</param>
        /// <param name="userId">사용자 아이디</param>
        /// <param name="ipAddress">클라이언트 아이피</param>
        /// <param name="computer_name">클라언트 컴퓨터명</param>
        /// <returns>실행결과</returns>
        public DataSet ExecuteMultiDataSet(string[] queryArray, Hashtable[] paramObject, string userId, string ipAddress, string computer_name)
        {
            DataSet result = CreateDataSetSeializationBinaryForamt();

            int tableName = 1;
            for (int executeIdx = 0; executeIdx < queryArray.Length; executeIdx++)
            {
                DataSet ds = Mapper.ExecuteDataSet(queryArray[executeIdx], paramObject[executeIdx]);
                for (int i = 0; i < ds.Tables.Count; i++)
                {
                    ds.Tables[i].TableName = "Table" + tableName;
                    tableName++;

                    result.Tables.Add(ds.Tables[i].Copy());
                }
            }

            return result;
        }

        /// <summary>
        /// 해당 쿼리아이디에 대하여 실행을 한다
        /// </summary>
        /// <param name="queryArray">쿼리아이디</param>
        /// <param name="userId">사용자 아이디</param>
        /// <param name="ipAddress">클라이언트 아이피</param>
        /// <param name="computer_name">클라언트 컴퓨터명</param>
        /// <returns>실행결과</returns>
        public DataSet ExecuteMultiDataSet(string[] queryArray, string userId, string ipAddress, string computer_name)
        {
            DataSet result = CreateDataSetSeializationBinaryForamt();

            int tableName = 1;
            for (int executeIdx = 0; executeIdx < queryArray.Length; executeIdx++)
            {
                DataSet ds = Mapper.ExecuteDataSet(queryArray[executeIdx], null);
                for (int i = 0; i < ds.Tables.Count; i++)
                {
                    ds.Tables[i].TableName = "Table" + tableName;
                    tableName++;

                    result.Tables.Add(ds.Tables[i].Copy());
                }
            }

            return result;
        }

        #endregion DataSet

        #region NonQuery

        /// <summary>
        /// 해당 쿼리아이디에 대하여 다중 실행을 한다
        /// </summary>
        /// <param name="queryId">쿼리아이디</param>
        /// <param name="paramObject">파라미터정보</param>
        /// <param name="userId">사용자 아이디</param>
        /// <param name="ipAddress">클라이언트 아이피</param>
        /// <param name="computer_name">클라언트 컴퓨터명</param>
        /// <returns>영향을 받은 행수</returns>
        public DataResultSets ExecuteMultiNonQuery(string[] queryArray, object[] paramArray, string userId, string ipAddress, string computer_name)
        {
            DataResultSets resultSets = new DataResultSets();

            resultSets.dataResultSetList = new DataResultSet[queryArray.Length];

            for (int executeIdx = 0; executeIdx < queryArray.Length; executeIdx++)
            {
                resultSets.dataResultSetList[executeIdx] = ExecuteNonQuery(queryArray[executeIdx], paramArray[executeIdx], userId, ipAddress, computer_name);

                SetOutParamResultSet(queryArray[executeIdx], paramArray[executeIdx], ref resultSets.dataResultSetList[executeIdx]);
            }

            return resultSets;
        }

        #endregion NonQuery

        #endregion Multi

        #region DataSet

        /// <summary>
        /// 해당 쿼리아이디에 대하여 실행을 한다
        /// </summary>
        /// <param name="queryId">쿼리아이디</param>
        /// <param name="paramObject">파라미터정보</param>
        /// <param name="userId">사용자 아이디</param>
        /// <param name="ipAddress">클라이언트 아이피</param>
        /// <param name="computer_name">클라언트 컴퓨터명</param>
        /// <returns>실행결과</returns>
        public DataResultSet ExecuteDataSet(string queryId, object paramObject, string userId, string ipAddress, string computer_name)
        {
            DataResultSet resultSet = new DataResultSet();

            resultSet.QuerySet = Mapper.ExecuteDataSet(queryId, paramObject);
            resultSet.QuerySet.RemotingFormat = SerializationFormat.Binary;

            SetOutParamResultSet(queryId, paramObject, ref resultSet);

            return resultSet;
        }

        #endregion DataSet

        #region NonQuery

        /// <summary>
        /// 해당 쿼리아이디에 대하여 실행을 한다
        /// </summary>
        /// <param name="queryId">쿼리아이디</param>
        /// <param name="paramObject">파라미터정보</param>
        /// <param name="userId">사용자 아이디</param>
        /// <param name="ipAddress">클라이언트 아이피</param>
        /// <param name="computer_name">클라언트 컴퓨터명</param>
        /// <returns>영향을 받은 행수</returns>
        public DataResultSet ExecuteNonQuery(string queryId, object paramObject, string userId, string ipAddress, string computer_name)
        {
            DataResultSet resultSet = new DataResultSet();

            //Mapper호출
            Mapper.ExecuteNonQuery(queryId, paramObject);

            SetOutParamResultSet(queryId, paramObject, ref resultSet);

            return resultSet;
        }

        #endregion NonQuery

        #region out parameter processing

        /// <summary>
        /// output-parameter를 체크해서 에러체크 및 output 파라미터를 담는다
        /// </summary>
        /// <param name="queryId"></param>
        /// <param name="paramObject"></param>
        /// <param name="resultSet"></param>
        private void SetOutParamResultSet(string queryId, object paramObject, ref DataResultSet resultSet)
        {
            Statement statement = Mapper.GetStatement(queryId);

            for (int i = 0; i < statement.Parameters.Count; i++)
            {
                if ((statement.Parameters[i].Direction == ParameterDirection.Output || statement.Parameters[i].Direction == ParameterDirection.InputOutput) && !statement.Parameters[i].DbTypeName.Equals("RefCursor"))
                {
                    if (paramObject is DataCollection)
                    {
                        if (resultSet.OutParamList == null)
                        {
                            resultSet.OutParamList = new DataCollection();
                        }
                        string key = statement.Parameters[i].ParameterName.Replace(":", "");
                        object o = (paramObject as DataCollection)[key];

                        if (o != null)
                            resultSet.OutParamList[key] = o;
                    }
                    else if (paramObject is Hashtable)
                    {
                        if (resultSet.OutParamList == null)
                        {
                            resultSet.OutParamList = new DataCollection();
                        }
                        string key = statement.Parameters[i].ParameterName.Replace(":", "");
                        object o = (paramObject as Hashtable)[key];

                        if (o != null)
                            resultSet.OutParamList.Add(key, o);
                    }
                }
            }
            //시스템정의 파라미터를 체크한다
            //O_APP_CODE,O_APP_MSG
            if (resultSet.OutParamList != null && resultSet.OutParamList.ContainsKey(_O_APP_CODE) && resultSet.OutParamList[_O_APP_CODE] != null)
            {
                //배열처리는 DataCollection
                if (resultSet.OutParamList[_O_APP_CODE] is string[])
                {
                    string[] O_APP_CODE = (resultSet.OutParamList[_O_APP_CODE] as string[]);
                    string[] O_APP_MSG = (resultSet.OutParamList[_O_APP_MSG] as string[]);
                    for (int i = 0; i < O_APP_CODE.Length; i++)
                    {
                        bool IsSuccess = GetParseSuccessCode(O_APP_CODE[i]);

                        if (!IsSuccess)
                        {
                            string preErrorMsg = string.Empty;

                            if (paramObject is DataCollection)
                            {
                                if ((paramObject as DataCollection).ContainsKey("DATA_ROW_INDEX") && (paramObject as DataCollection)["DATA_ROW_INDEX"] != null && !(((paramObject as DataCollection)["DATA_ROW_INDEX"]) as string[])[i].Trim().Equals(""))
                                {
                                    preErrorMsg = (Convert.ToInt32((((paramObject as DataCollection)["DATA_ROW_INDEX"]) as string[])[i]) + 1) + "번째 행오류 : ";
                                }
                            }

                            resultSet.IsSuccess = false;
                            resultSet.ExceptionMessage = "APP_ERROR:" + preErrorMsg + (O_APP_MSG != null && !string.IsNullOrWhiteSpace(O_APP_MSG[i]) ? O_APP_MSG[i] : "사용자 프로시저에서 오류코드를 리턴했지만 " + _O_APP_MSG + "를 찾을 수 없습니다");
                            return;
                        }
                    }
                }
                else
                {
                    bool IsSuccess = GetParseSuccessCode(resultSet.OutParamList[_O_APP_CODE].ToString());

                    resultSet.IsSuccess = IsSuccess;

                    if (!IsSuccess)
                    {
                        resultSet.ExceptionMessage = "APP_ERROR:" + (resultSet.OutParamList[_O_APP_MSG] != null ? resultSet.OutParamList[_O_APP_MSG].ToString() : "사용자 프로시저에서 오류코드를 리턴했지만 " + _O_APP_MSG + "를 찾을 수 없습니다");
                        return;
                    }
                }
            }

            resultSet.IsSuccess = true;
        }

        #endregion out parameter processing
    }
}
