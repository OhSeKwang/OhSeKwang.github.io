﻿using HHI.ShipBuilding.Dac;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.Security;
using HHI.ShipBuilding.Transactions;
using HHI.Transactions;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;

namespace HHI.ShipBuilding.Biz
{
    public class ShipBuildingBiz : ShipBuildingBizBase
    {
        /// <summary>
        /// 기본생성자 외부로 노출 안함.
        /// </summary>
        private ShipBuildingBiz() { }

        /// <summary>
        /// 기본 생성자(Db트랜잭션 사용여부를 지정한다.)
        /// </summary>
        /// <param name="UseTransaction"></param>
        public ShipBuildingBiz(bool UseDbTransaction)
        {
            this.UseDbTransaction = UseDbTransaction;
        }

        /// <summary>
        /// DB트랜잭션 사용할지 여부를 지정하거나,가져온다.
        /// </summary>
        public bool UseDbTransaction
        {
            get;
            set;
        }

        #region Multi처리

        #region 단일 매퍼로 실행

        /// <summary>
        /// 해당 쿼리아이디에 대하여 실행을 한다
        /// </summary>
        /// <param name="configName">DataBase Connection을 지정한다</param>
        /// <param name="queryId">쿼리아이디</param>
        /// <param name="userId">사용자 아이디</param>
        /// <param name="ipAddress">클라이언트 아이피</param>
        /// <param name="computer_name">클라언트 컴퓨터명</param>
        /// <returns>실행결과</returns>
        [Transaction(TransactionOption.None)]
        public DataSet MultiExecuteDataSet(string configName, string dataSource, string[] queryId, string userId, string ipAddress, string computer_name)
        {
            ShipBuildingDac dac = new ShipBuildingDac(configName, dataSource);

            try
            {
                DataSet ds = null;

                if (UseDbTransaction)
                {
                    if (!dac.DbAccess.IsOpen)
                        dac.DbAccess.Open();

                    dac.DbAccess.BeginTrans();
                }
                ds = dac.ExecuteMultiDataSet(queryId, userId, ipAddress, computer_name);

                if (UseDbTransaction)
                    dac.DbAccess.CommitTrans();

                return ds;
            }
            catch (Exception ex)
            {
                if (dac.DbAccess.IsOpen)
                {
                    if (UseDbTransaction)
                        dac.DbAccess.RollbackTrans();
                }

                throw ex;
            }
            finally
            {
                if (dac.DbAccess.IsOpen)
                {
                    dac.DbAccess.Close();
                }
                dac.Dispose();
            }
        }

        /// <summary>
        /// 해당 쿼리아이디에 대하여 실행을 한다
        /// </summary>
        /// <param name="configName">DataBase Connection을 지정한다</param>
        /// <param name="queryId">쿼리아이디</param>
        /// <param name="paramObject">파라미터정보</param>
        /// <param name="userId">사용자 아이디</param>
        /// <param name="ipAddress">클라이언트 아이피</param>
        /// <param name="computer_name">클라언트 컴퓨터명</param>
        /// <returns>실행결과</returns>
        [Transaction(TransactionOption.None)]
        public DataSet MultiExecuteDataSet(string configName, string dataSource, string[] queryId, Hashtable[] paramObject, string userId, string ipAddress, string computer_name)
        {
            ShipBuildingDac dac = new ShipBuildingDac(configName, dataSource);

            try
            {
                DataSet ds = null;

                if (UseDbTransaction)
                {
                    if (!dac.DbAccess.IsOpen)
                        dac.DbAccess.Open();

                    dac.DbAccess.BeginTrans();
                }
                ds = dac.ExecuteMultiDataSet(queryId, paramObject, userId, ipAddress, computer_name);

                if (UseDbTransaction)
                    dac.DbAccess.CommitTrans();

                return ds;
            }
            catch (Exception ex)
            {
                if (dac.DbAccess.IsOpen)
                {
                    if (UseDbTransaction)
                        dac.DbAccess.RollbackTrans();
                }
                throw ex;
            }
            finally
            {
                if (dac.DbAccess.IsOpen)
                {
                    dac.DbAccess.Close();
                }
                dac.Dispose();
            }
        }

        /// <summary>
        /// 해당 쿼리아이디에 대하여 다중 실행을 한다
        /// </summary>
        /// <param name="configName">DataBase Connection을 지정한다</param>
        /// <param name="queryId">쿼리아이디</param>
        /// <param name="paramObject">파라미터정보</param>
        /// <param name="userId">사용자 아이디</param>
        /// <param name="ipAddress">클라이언트 아이피</param>
        /// <param name="computer_name">클라언트 컴퓨터명</param>
        /// <returns>영향을 받은 행수</returns>
        [Transaction(TransactionOption.None)]
        public DataResultSets ExecuteMultiNonQuery(string configName, string dataSource, string[] queryId, object[] paramObject, string userId, string ipAddress, string computer_name)
        {
            ShipBuildingDac dac = new ShipBuildingDac(configName, dataSource);

            DataResultSets result = null;

            try
            {
                if (UseDbTransaction)
                {
                    if (!dac.DbAccess.IsOpen)
                        dac.DbAccess.Open();

                    dac.DbAccess.BeginTrans();
                }
                result = dac.ExecuteMultiNonQuery(queryId, paramObject, userId, ipAddress, computer_name);

                //DataResultSet 객체 배열내의 성공유무를 따져서 트랜잭션 롤백여부를 판단한다.
                foreach (var item in result.dataResultSetList)
                {
                    if (!item.IsSuccess)
                        throw new HHIException(item.ExceptionMessage);
                }

                if (UseDbTransaction)
                    dac.DbAccess.CommitTrans();

            }
            catch //(Exception ex) ==> 예외기록은....쩝..
            {
                if (dac.DbAccess.IsOpen)
                {
                    if (UseDbTransaction)
                        dac.DbAccess.RollbackTrans();
                }
            }
            finally
            {
                if (dac.DbAccess.IsOpen)
                {
                    dac.DbAccess.Close();
                }
                dac.Dispose();
            }

            return result;
        }

        #endregion

        #region 다중 매퍼로 실행

        /// <summary>
        /// 해당 쿼리아이디에 대하여 실행을 한다
        /// </summary>
        /// <param name="dataSources">DBConnection구분(server_configuration.xml 의 databaseSection의 Prefix)</param>
        /// <param name="configNames">DataBase Connection을 지정한다</param>
        /// <param name="queryId">쿼리아이디</param>
        /// <param name="userId">사용자 아이디</param>
        /// <param name="ipAddress">클라이언트 아이피</param>
        /// <param name="computer_name">클라언트 컴퓨터명</param>
        /// <returns>실행결과</returns>
        [Transaction(TransactionOption.None)]
        public DataSet MultiExecuteDataSet(string[] dataSources, string[] configNames, string[] queryId, string userId, string ipAddress, string computer_name)
        {
            return MultiExecuteDataSet(dataSources, configNames, queryId, null, userId, ipAddress, computer_name);
        }

        /// <summary>
        /// 해당 쿼리아이디에 대하여 실행을 한다
        /// </summary>
        /// <param name="dataSources">DBConnection구분(server_configuration.xml 의 databaseSection의 Prefix)</param>
        /// <param name="configNames">DataBase Connection을 지정한다</param>
        /// <param name="queryId">쿼리아이디</param>
        /// <param name="paramObject">파라미터정보</param>
        /// <param name="userId">사용자 아이디</param>
        /// <param name="ipAddress">클라이언트 아이피</param>
        /// <param name="computer_name">클라언트 컴퓨터명</param>
        /// <returns>실행결과</returns>
        [Transaction(TransactionOption.None)]
        public DataSet MultiExecuteDataSet(string[] dataSources, string[] configNames, string[] queryId, Hashtable[] paramObject, string userId, string ipAddress, string computer_name)
        {
            Dictionary<string, ShipBuildingDac> dacUniqueeCache = new Dictionary<string, ShipBuildingDac>();
            try
            {
                DataSet result = new DataSet();
                int internalTableIndex = 0;
                //데이터 작업시작
                for (int i = 0; i < configNames.Length; i++)
                {
                    //Dac객체를 딕셔너리에 담는다...불필요한 객체생성은 안함..해당 커넥션Key별로
                    if (!dacUniqueeCache.ContainsKey(dataSources[i]))
                    {
                        ShipBuildingDac dac = new ShipBuildingDac(configNames[i], dataSources[i]);
                        dacUniqueeCache.Add(dataSources[i], dac);

                        //처리단위 로컬 트랜잭션 시작
                        if (UseDbTransaction)
                        {
                            if (!dac.DbAccess.IsOpen)
                                dac.DbAccess.Open();

                            dac.DbAccess.BeginTrans();
                        }
                    }

                    //개별 쿼리를 수행한다...
                    StdUserInfoContext.Current["DATASOURCE_PREFIX"] = dataSources[i];
                    DataSet ds = dacUniqueeCache[dataSources[i]].ExecuteDataSet(queryId[i], paramObject != null ? paramObject[i] : null, userId, ipAddress, computer_name).QuerySet;
                    //수행한 결과집합을 반환할 집합에 순차적으로 담는다
                    for (int j = 0; j < ds.Tables.Count; j++)
                    {
                        ds.Tables[j].TableName = "ResultSet" + internalTableIndex;
                        internalTableIndex++;
                        result.Tables.Add(ds.Tables[j].Copy());
                    }

                }


                //모든 데이터 작업처리 종료
                if (UseDbTransaction)
                {
                    Dictionary<string, ShipBuildingDac>.Enumerator enumerator = dacUniqueeCache.GetEnumerator();
                    while (enumerator.MoveNext())
                    {
                        enumerator.Current.Value.DbAccess.CommitTrans();
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                //모든 데이터 Connection에 대하여 롤백처리를 한다
                if (UseDbTransaction)
                {
                    Dictionary<string, ShipBuildingDac>.Enumerator enumerator = dacUniqueeCache.GetEnumerator();
                    while (enumerator.MoveNext())
                    {
                        if (enumerator.Current.Value.DbAccess.IsOpen)
                        {
                            enumerator.Current.Value.DbAccess.RollbackTrans();
                        }

                    }
                }
                throw ex;
            }
            finally
            {
                Dictionary<string, ShipBuildingDac>.Enumerator enumerator = dacUniqueeCache.GetEnumerator();
                while (enumerator.MoveNext())
                {
                    if (enumerator.Current.Value.DbAccess.IsOpen)
                    {
                        enumerator.Current.Value.DbAccess.Close();
                    }
                    enumerator.Current.Value.Dispose();
                }
            }
        }

        /// <summary>
        /// 해당 쿼리아이디에 대하여 다중 실행을 한다
        /// </summary>
        /// <param name="dataSources">DBConnection구분(server_configuration.xml 의 databaseSection의 Prefix)</param>
        /// <param name="configNames">DataBase Connection을 지정한다</param>
        /// <param name="queryId">쿼리아이디</param>
        /// <param name="paramObject">파라미터정보</param>
        /// <param name="userId">사용자 아이디</param>
        /// <param name="ipAddress">클라이언트 아이피</param>
        /// <param name="computer_name">클라언트 컴퓨터명</param>
        /// <returns>영향을 받은 행수</returns>
        [Transaction(TransactionOption.None)]
        public DataResultSets ExecuteMultiNonQuery(string[] dataSources, string[] configNames, string[] queryId, object[] paramObject, string userId, string ipAddress, string computer_name)
        {
            Dictionary<string, ShipBuildingDac> dacUniqueeCache = new Dictionary<string, ShipBuildingDac>();
            DataResultSets result = new DataResultSets();

            try
            {
                result.dataResultSetList = new DataResultSet[configNames.Length];
                //데이터 작업시작
                for (int i = 0; i < configNames.Length; i++)
                {
                    //Dac객체를 딕셔너리에 담는다...불필요한 객체생성은 안함..해당 커넥션Key별로
                    if (!dacUniqueeCache.ContainsKey(dataSources[i]))
                    {
                        ShipBuildingDac dac = new ShipBuildingDac(configNames[i], dataSources[i]);
                        dacUniqueeCache.Add(dataSources[i], dac);

                        //처리단위 로컬 트랜잭션 시작
                        if (UseDbTransaction)
                        {
                            if (!dac.DbAccess.IsOpen)
                                dac.DbAccess.Open();

                            dac.DbAccess.BeginTrans();
                        }
                    }

                    //개별 쿼리를 수행한다...
                    StdUserInfoContext.Current["DATASOURCE_PREFIX"] = dataSources[i];
                    result.dataResultSetList[i] = dacUniqueeCache[dataSources[i]].ExecuteNonQuery(queryId[i], paramObject != null ? paramObject[i] : null, userId, ipAddress, computer_name);
                }

                //DataResultSet 객체 배열내의 성공유무를 따져서 트랜잭션 롤백여부를 판단한다.
                foreach (var item in result.dataResultSetList)
                {
                    if (!item.IsSuccess)
                        throw new HHIException(item.ExceptionMessage);
                }

                //모든 데이터 작업처리 종료
                if (UseDbTransaction)
                {
                    Dictionary<string, ShipBuildingDac>.Enumerator enumerator = dacUniqueeCache.GetEnumerator();
                    while (enumerator.MoveNext())
                    {
                        enumerator.Current.Value.DbAccess.CommitTrans();
                    }
                }
            }
            catch //(Exception ex)
            {
                //모든 데이터 Connection에 대하여 롤백처리를 한다
                if (UseDbTransaction)
                {
                    Dictionary<string, ShipBuildingDac>.Enumerator enumerator = dacUniqueeCache.GetEnumerator();
                    while (enumerator.MoveNext())
                    {
                        if (enumerator.Current.Value.DbAccess.IsOpen)
                        {
                            enumerator.Current.Value.DbAccess.RollbackTrans();
                        }
                    }
                }
            }
            finally
            {
                Dictionary<string, ShipBuildingDac>.Enumerator enumerator = dacUniqueeCache.GetEnumerator();
                while (enumerator.MoveNext())
                {
                    if (enumerator.Current.Value.DbAccess.IsOpen)
                    {
                        enumerator.Current.Value.DbAccess.Close();
                    }
                    enumerator.Current.Value.Dispose();
                }
            }

            return result;
        }

        #endregion

        #endregion

        #region DataSet

        /// <summary>
        /// 해당 쿼리아이디에 대하여 실행을 한다
        /// </summary>
        /// <param name="configName">DataBase Connection을 지정한다</param>
        /// <param name="queryId">쿼리아이디</param>
        /// <param name="paramObject">파라미터정보</param>
        /// <param name="userId">사용자 아이디</param>
        /// <param name="ipAddress">클라이언트 아이피</param>
        /// <param name="computer_name">클라언트 컴퓨터명</param>
        /// <returns>실행결과</returns>
        [Transaction(TransactionOption.None)]
        public DataResultSet ExecuteDataSet(string configName, string dataSource, string queryId, object paramObject, string userId, string ipAddress, string computer_name)
        {
            ShipBuildingDac dac = new ShipBuildingDac(configName, dataSource);
            
            DataResultSet result = null;

            try
            {
                if (UseDbTransaction)
                {
                    if (!dac.DbAccess.IsOpen)
                        dac.DbAccess.Open();

                    dac.DbAccess.BeginTrans();
                }
                result = dac.ExecuteDataSet(queryId, paramObject, userId, ipAddress, computer_name);

                if (!result.IsSuccess)
                    throw new HHIException(result.ExceptionMessage);

                if (UseDbTransaction)
                    dac.DbAccess.CommitTrans();

            }
            catch //(Exception ex)
            {
                if (dac.DbAccess.IsOpen)
                {
                    if (UseDbTransaction)
                        dac.DbAccess.RollbackTrans();
                }
                //throw ex;
            }
            finally
            {
                if (dac.DbAccess.IsOpen)
                {
                    dac.DbAccess.Close();
                }
                dac.Dispose();
            }

            return result;
        }

        #endregion

        #region NonQuery

        /// <summary>
        /// 해당 쿼리아이디에 대하여 실행을 한다
        /// </summary>
        /// <param name="configName">DataBase Connection을 지정한다</param>
        /// <param name="queryId">쿼리아이디</param>
        /// <param name="paramObject">파라미터정보</param>
        /// <param name="userId">사용자 아이디</param>
        /// <param name="ipAddress">클라이언트 아이피</param>
        /// <param name="computer_name">클라언트 컴퓨터명</param>
        /// <returns>영향을 받은 행수</returns>
        [Transaction(TransactionOption.None)]
        public DataResultSet ExecuteNonQuery(string configName, string dataSource, string queryId, object paramObject, string userId, string ipAddress, string computer_name)
        {
            ShipBuildingDac dac = new ShipBuildingDac(configName, dataSource);

            DataResultSet result = null;

            try
            {
                if (UseDbTransaction)
                {
                    if (!dac.DbAccess.IsOpen)
                    {
                        dac.DbAccess.Open();

                        dac.DbAccess.BeginTrans();
                    }
                }
                result = dac.ExecuteNonQuery(queryId, paramObject, userId, ipAddress, computer_name);

                if (!result.IsSuccess)
                    throw new HHIException(result.ExceptionMessage);

                if (UseDbTransaction)
                    dac.DbAccess.CommitTrans();
            }
            catch //(Exception ex)
            {
                if (dac.DbAccess.IsOpen)
                {
                    if (UseDbTransaction)
                        dac.DbAccess.RollbackTrans();
                }
                //throw ex;
            }
            finally
            {
                if (dac.DbAccess.IsOpen)
                {
                    dac.DbAccess.Close();
                }
                dac.Dispose();
            }

            return result;
        }

        #endregion

    }
}
