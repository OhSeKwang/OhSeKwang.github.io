﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("HHI.ShipBuilding.Server")]
[assembly: AssemblyDescription("조선사업부 통합 프레임워크 서버 모듈")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("현대중공업 조선사업부")]
[assembly: AssemblyProduct("조선사업부 통합 프레임워크")]
[assembly: AssemblyCopyright("Copyright ©  2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("ce284baf-14f6-4eb8-b61f-eeb76973fd68")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.1.0")]
