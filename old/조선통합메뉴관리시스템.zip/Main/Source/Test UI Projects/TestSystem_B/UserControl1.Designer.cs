﻿namespace TestSystem_B
{
    partial class UserControl1
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserControl1));
            this.stdValidationManager1 = new HHI.ShipBuilding.Controls.StdValidationManager(this.components);
            this.xtraToolBarRichEditControl1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraToolBarRichEditControl();
            this.xtraTimeEditExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTimeEditExt();
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.xtraButtonExt3 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.xtraButtonExt2 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.xtraTextEditExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.xtraSyntaxRichEditControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraSyntaxRichEditControlExt();
            this.xtraSpinEditExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraSpinEditExt();
            this.xtraRichEditControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraRichEditControlExt();
            this.xtraRadioGroupExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraRadioGroupExt();
            this.xtraPopupContainerEditExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraPopupContainerEditExt();
            this.xtraMRUEditExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraMRUEditExt();
            this.xtraMemoExEditExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraMemoExEditExt();
            this.xtraMemoEditExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraMemoEditExt();
            this.xtraLookUpEditExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLookUpEditExt();
            this.xtraListBoxControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraListBoxControlExt();
            this.xtraLabelExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt();
            this.xtraImageListBoxControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraImageListBoxControlExt();
            this.xtraImageComboBoxEditExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraImageComboBoxEditExt();
            this.xtraHyperLinkEditExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraHyperLinkEditExt();
            this.xtraGridControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.xtraDateEditExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraDateEditExt();
            this.xtraComboBoxEditExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraComboBoxEditExt();
            this.xtraCheckEditExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraCheckEditExt();
            this.xtraCalcEditExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraCalcEditExt();
            this.xtraButtonExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.xtraButtonEditExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonEditExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem19 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem21 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem22 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem23 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem24 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem16 = new DevExpress.XtraLayout.LayoutControlItem();
            this.tabbedControlGroup1 = new DevExpress.XtraLayout.TabbedControlGroup();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem17 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem18 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem20 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem25 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem26 = new DevExpress.XtraLayout.LayoutControlItem();
            this.stdButtonExecuteManager1 = new HHI.ShipBuilding.Controls.StdButtonExecuteManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTimeEditExt1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTextEditExt1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraSpinEditExt1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraRadioGroupExt1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraPopupContainerEditExt1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraMRUEditExt1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraMemoExEditExt1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraMemoEditExt1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLookUpEditExt1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraListBoxControlExt1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraImageListBoxControlExt1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraImageComboBoxEditExt1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraHyperLinkEditExt1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraGridControlExt1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraDateEditExt1.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraDateEditExt1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraComboBoxEditExt1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraCheckEditExt1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraCalcEditExt1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraButtonEditExt1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabbedControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem26)).BeginInit();
            this.SuspendLayout();
            // 
            // stdValidationManager1
            // 
            this.stdValidationManager1.IsNullorWhiteSpace = true;
            this.stdValidationManager1.IsShowErrorMessage = true;
            // 
            // xtraToolBarRichEditControl1
            // 
            this.xtraToolBarRichEditControl1.BackColor = System.Drawing.Color.Transparent;
            this.xtraToolBarRichEditControl1.File_PrintVisible = true;
            this.xtraToolBarRichEditControl1.HtmlText = resources.GetString("xtraToolBarRichEditControl1.HtmlText");
            this.xtraToolBarRichEditControl1.IsValueTrim = true;
            this.xtraToolBarRichEditControl1.Key = "";
            this.xtraToolBarRichEditControl1.Location = new System.Drawing.Point(127, 226);
            this.xtraToolBarRichEditControl1.MinLength = 0;
            this.xtraToolBarRichEditControl1.Name = "xtraToolBarRichEditControl1";
            this.xtraToolBarRichEditControl1.OutputFormat = HHI.ShipBuilding.Client.Controls.DXperience.RichEditOutputFormat.Html;
            this.xtraToolBarRichEditControl1.RibbonMenuHide = false;
            this.xtraToolBarRichEditControl1.Size = new System.Drawing.Size(372, 200);
            this.xtraToolBarRichEditControl1.TabIndex = 27;
            this.stdValidationManager1.SetValidation(this.xtraToolBarRichEditControl1, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // xtraTimeEditExt1
            // 
            this.xtraTimeEditExt1.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.xtraTimeEditExt1.EditValue = new System.DateTime(2014, 9, 4, 0, 0, 0, 0);
            this.xtraTimeEditExt1.EnterExecuteButton = null;
            this.xtraTimeEditExt1.FocusColor = System.Drawing.Color.Empty;
            this.xtraTimeEditExt1.IsValueTrim = true;
            this.xtraTimeEditExt1.Key = "";
            this.xtraTimeEditExt1.Location = new System.Drawing.Point(127, 430);
            this.xtraTimeEditExt1.MinLength = 0;
            this.xtraTimeEditExt1.Name = "xtraTimeEditExt1";
            this.xtraTimeEditExt1.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.xtraTimeEditExt1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.xtraTimeEditExt1.Properties.Appearance.Options.UseBackColor = true;
            this.xtraTimeEditExt1.Properties.Appearance.Options.UseForeColor = true;
            this.xtraTimeEditExt1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.xtraTimeEditExt1.Properties.CloseUpKey = new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.F4);
            this.xtraTimeEditExt1.Properties.Mask.EditMask = "HH:mm";
            this.xtraTimeEditExt1.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.xtraTimeEditExt1.Properties.PopupBorderStyle = DevExpress.XtraEditors.Controls.PopupBorderStyles.Default;
            this.xtraTimeEditExt1.Size = new System.Drawing.Size(372, 20);
            this.xtraTimeEditExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraTimeEditExt1.TabIndex = 26;
            this.stdValidationManager1.SetValidation(this.xtraTimeEditExt1, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.xtraButtonExt3);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraButtonExt2);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraToolBarRichEditControl1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraTimeEditExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraTextEditExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraSyntaxRichEditControlExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraSpinEditExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraRichEditControlExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraRadioGroupExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraPopupContainerEditExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraMRUEditExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraMemoExEditExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraMemoEditExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraLookUpEditExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraListBoxControlExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraLabelExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraImageListBoxControlExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraImageComboBoxEditExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraHyperLinkEditExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraGridControlExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraDateEditExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraComboBoxEditExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraCheckEditExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraCalcEditExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraButtonExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraButtonEditExt1);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(807, 390, 250, 350);
            this.xtraLayoutControlExt1.OptionsView.UseDefaultDragAndDropRendering = false;
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(1113, 619);
            this.xtraLayoutControlExt1.TabIndex = 0;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // xtraButtonExt3
            // 
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.xtraButtonExt3, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.xtraButtonExt3, false);
            this.xtraButtonExt3.IsExecuteWdworkerLog = true;
            this.xtraButtonExt3.Location = new System.Drawing.Point(111, 12);
            this.xtraButtonExt3.Name = "xtraButtonExt3";
            this.xtraButtonExt3.Size = new System.Drawing.Size(96, 22);
            this.xtraButtonExt3.StyleController = this.xtraLayoutControlExt1;
            this.xtraButtonExt3.TabIndex = 29;
            this.xtraButtonExt3.Text = "Array Bind Save";
            this.xtraButtonExt3.UseSplasher = false;
            this.xtraButtonExt3.Click += new System.EventHandler(this.xtraButtonExt3_Click);
            // 
            // xtraButtonExt2
            // 
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.xtraButtonExt2, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.xtraButtonExt2, true);
            this.xtraButtonExt2.IsExecuteWdworkerLog = true;
            this.xtraButtonExt2.Location = new System.Drawing.Point(997, 12);
            this.xtraButtonExt2.Name = "xtraButtonExt2";
            this.xtraButtonExt2.Size = new System.Drawing.Size(104, 22);
            this.xtraButtonExt2.StyleController = this.xtraLayoutControlExt1;
            this.xtraButtonExt2.TabIndex = 28;
            this.xtraButtonExt2.Text = "조회";
            this.xtraButtonExt2.UseSplasher = false;
            this.xtraButtonExt2.Click += new System.EventHandler(this.xtraButtonExt2_Click);
            // 
            // xtraTextEditExt1
            // 
            this.xtraTextEditExt1.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.xtraTextEditExt1.EditValue = "";
            this.xtraTextEditExt1.EnterExecuteButton = null;
            this.xtraTextEditExt1.FocusColor = System.Drawing.Color.Empty;
            this.xtraTextEditExt1.IsValueTrim = true;
            this.xtraTextEditExt1.Key = "";
            this.xtraTextEditExt1.Location = new System.Drawing.Point(618, 251);
            this.xtraTextEditExt1.MinLength = 0;
            this.xtraTextEditExt1.Name = "xtraTextEditExt1";
            this.xtraTextEditExt1.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.xtraTextEditExt1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.xtraTextEditExt1.Properties.Appearance.Options.UseBackColor = true;
            this.xtraTextEditExt1.Properties.Appearance.Options.UseForeColor = true;
            this.xtraTextEditExt1.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.xtraTextEditExt1.Size = new System.Drawing.Size(483, 20);
            this.xtraTextEditExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraTextEditExt1.TabIndex = 25;
            this.xtraTextEditExt1.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.xtraTextEditExt1, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // xtraSyntaxRichEditControlExt1
            // 
            this.xtraSyntaxRichEditControlExt1.ActiveViewType = DevExpress.XtraRichEdit.RichEditViewType.Simple;
            this.xtraSyntaxRichEditControlExt1.Appearance.Text.Font = new System.Drawing.Font("Verdana", 9F);
            this.xtraSyntaxRichEditControlExt1.Appearance.Text.ForeColor = System.Drawing.Color.Black;
            this.xtraSyntaxRichEditControlExt1.Appearance.Text.Options.UseFont = true;
            this.xtraSyntaxRichEditControlExt1.Appearance.Text.Options.UseForeColor = true;
            this.xtraSyntaxRichEditControlExt1.IsValueTrim = true;
            this.xtraSyntaxRichEditControlExt1.Key = "";
            this.xtraSyntaxRichEditControlExt1.Location = new System.Drawing.Point(618, 275);
            this.xtraSyntaxRichEditControlExt1.MinLength = 0;
            this.xtraSyntaxRichEditControlExt1.Name = "xtraSyntaxRichEditControlExt1";
            this.xtraSyntaxRichEditControlExt1.Options.Fields.UseCurrentCultureDateTimeFormat = false;
            this.xtraSyntaxRichEditControlExt1.Options.HorizontalScrollbar.Visibility = DevExpress.XtraRichEdit.RichEditScrollbarVisibility.Visible;
            this.xtraSyntaxRichEditControlExt1.Options.MailMerge.KeepLastParagraph = false;
            this.xtraSyntaxRichEditControlExt1.OutputFormat = HHI.ShipBuilding.Client.Controls.DXperience.RichEditOutputFormat.Text;
            this.xtraSyntaxRichEditControlExt1.Size = new System.Drawing.Size(483, 52);
            this.xtraSyntaxRichEditControlExt1.TabIndex = 24;
            this.xtraSyntaxRichEditControlExt1.Text = "xtraSyntaxRichEditControlExt1";
            // 
            // xtraSpinEditExt1
            // 
            this.xtraSpinEditExt1.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.xtraSpinEditExt1.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.xtraSpinEditExt1.EnterExecuteButton = null;
            this.xtraSpinEditExt1.FocusColor = System.Drawing.Color.Empty;
            this.xtraSpinEditExt1.IsSetDecimalPoint = false;
            this.xtraSpinEditExt1.Key = "";
            this.xtraSpinEditExt1.Location = new System.Drawing.Point(630, 366);
            this.xtraSpinEditExt1.MinLength = 0;
            this.xtraSpinEditExt1.Name = "xtraSpinEditExt1";
            this.xtraSpinEditExt1.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.xtraSpinEditExt1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.xtraSpinEditExt1.Properties.Appearance.Options.UseBackColor = true;
            this.xtraSpinEditExt1.Properties.Appearance.Options.UseForeColor = true;
            this.xtraSpinEditExt1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.xtraSpinEditExt1.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.xtraSpinEditExt1.Size = new System.Drawing.Size(459, 20);
            this.xtraSpinEditExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraSpinEditExt1.TabIndex = 23;
            // 
            // xtraRichEditControlExt1
            // 
            this.xtraRichEditControlExt1.IsValueTrim = true;
            this.xtraRichEditControlExt1.Key = "";
            this.xtraRichEditControlExt1.Location = new System.Drawing.Point(127, 508);
            this.xtraRichEditControlExt1.MinLength = 0;
            this.xtraRichEditControlExt1.Name = "xtraRichEditControlExt1";
            this.xtraRichEditControlExt1.Options.Fields.UseCurrentCultureDateTimeFormat = false;
            this.xtraRichEditControlExt1.Options.MailMerge.KeepLastParagraph = false;
            this.xtraRichEditControlExt1.OutputFormat = HHI.ShipBuilding.Client.Controls.DXperience.RichEditOutputFormat.Html;
            this.xtraRichEditControlExt1.Size = new System.Drawing.Size(372, 81);
            this.xtraRichEditControlExt1.TabIndex = 22;
            this.xtraRichEditControlExt1.Text = "xtraRichEditControlExt1";
            this.stdValidationManager1.SetValidation(this.xtraRichEditControlExt1, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // xtraRadioGroupExt1
            // 
            this.xtraRadioGroupExt1.EditValue = "";
            this.xtraRadioGroupExt1.EnterExecuteButton = null;
            this.xtraRadioGroupExt1.Key = "";
            this.xtraRadioGroupExt1.Location = new System.Drawing.Point(630, 390);
            this.xtraRadioGroupExt1.MinLength = 0;
            this.xtraRadioGroupExt1.Name = "xtraRadioGroupExt1";
            this.xtraRadioGroupExt1.Size = new System.Drawing.Size(459, 16);
            this.xtraRadioGroupExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraRadioGroupExt1.TabIndex = 21;
            // 
            // xtraPopupContainerEditExt1
            // 
            this.xtraPopupContainerEditExt1.EnterExecuteButton = null;
            this.xtraPopupContainerEditExt1.Key = "";
            this.xtraPopupContainerEditExt1.Location = new System.Drawing.Point(630, 410);
            this.xtraPopupContainerEditExt1.MinLength = 0;
            this.xtraPopupContainerEditExt1.Name = "xtraPopupContainerEditExt1";
            this.xtraPopupContainerEditExt1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.xtraPopupContainerEditExt1.Size = new System.Drawing.Size(459, 20);
            this.xtraPopupContainerEditExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraPopupContainerEditExt1.TabIndex = 20;
            // 
            // xtraMRUEditExt1
            // 
            this.xtraMRUEditExt1.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.xtraMRUEditExt1.EnterExecuteButton = null;
            this.xtraMRUEditExt1.FocusColor = System.Drawing.Color.Empty;
            this.xtraMRUEditExt1.IsValueTrim = true;
            this.xtraMRUEditExt1.Key = "";
            this.xtraMRUEditExt1.Location = new System.Drawing.Point(630, 478);
            this.xtraMRUEditExt1.MinLength = 0;
            this.xtraMRUEditExt1.Name = "xtraMRUEditExt1";
            this.xtraMRUEditExt1.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.xtraMRUEditExt1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.xtraMRUEditExt1.Properties.Appearance.Options.UseBackColor = true;
            this.xtraMRUEditExt1.Properties.Appearance.Options.UseForeColor = true;
            this.xtraMRUEditExt1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.xtraMRUEditExt1.Size = new System.Drawing.Size(459, 20);
            this.xtraMRUEditExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraMRUEditExt1.TabIndex = 19;
            // 
            // xtraMemoExEditExt1
            // 
            this.xtraMemoExEditExt1.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.xtraMemoExEditExt1.EditValue = "";
            this.xtraMemoExEditExt1.EnterExecuteButton = null;
            this.xtraMemoExEditExt1.FocusColor = System.Drawing.Color.Empty;
            this.xtraMemoExEditExt1.IsValueTrim = true;
            this.xtraMemoExEditExt1.Key = "";
            this.xtraMemoExEditExt1.Location = new System.Drawing.Point(630, 502);
            this.xtraMemoExEditExt1.MinLength = 0;
            this.xtraMemoExEditExt1.Name = "xtraMemoExEditExt1";
            this.xtraMemoExEditExt1.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.xtraMemoExEditExt1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.xtraMemoExEditExt1.Properties.Appearance.Options.UseBackColor = true;
            this.xtraMemoExEditExt1.Properties.Appearance.Options.UseForeColor = true;
            this.xtraMemoExEditExt1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.xtraMemoExEditExt1.Size = new System.Drawing.Size(459, 20);
            this.xtraMemoExEditExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraMemoExEditExt1.TabIndex = 18;
            // 
            // xtraMemoEditExt1
            // 
            this.xtraMemoEditExt1.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.xtraMemoEditExt1.EditValue = "";
            this.xtraMemoEditExt1.FocusColor = System.Drawing.Color.Empty;
            this.xtraMemoEditExt1.IsValueTrim = true;
            this.xtraMemoEditExt1.Key = "COL4";
            this.xtraMemoEditExt1.Location = new System.Drawing.Point(630, 526);
            this.xtraMemoEditExt1.MinLength = 0;
            this.xtraMemoEditExt1.Name = "xtraMemoEditExt1";
            this.xtraMemoEditExt1.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.xtraMemoEditExt1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.xtraMemoEditExt1.Properties.Appearance.Options.UseBackColor = true;
            this.xtraMemoEditExt1.Properties.Appearance.Options.UseForeColor = true;
            this.xtraMemoEditExt1.Size = new System.Drawing.Size(459, 45);
            this.xtraMemoEditExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraMemoEditExt1.TabIndex = 17;
            // 
            // xtraLookUpEditExt1
            // 
            this.xtraLookUpEditExt1.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.xtraLookUpEditExt1.EnterExecuteButton = null;
            this.xtraLookUpEditExt1.FocusColor = System.Drawing.Color.Empty;
            this.xtraLookUpEditExt1.Key = "";
            this.xtraLookUpEditExt1.Location = new System.Drawing.Point(630, 575);
            this.xtraLookUpEditExt1.MinLength = 0;
            this.xtraLookUpEditExt1.Name = "xtraLookUpEditExt1";
            this.xtraLookUpEditExt1.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.xtraLookUpEditExt1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.xtraLookUpEditExt1.Properties.Appearance.Options.UseBackColor = true;
            this.xtraLookUpEditExt1.Properties.Appearance.Options.UseForeColor = true;
            this.xtraLookUpEditExt1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.xtraLookUpEditExt1.Size = new System.Drawing.Size(459, 20);
            this.xtraLookUpEditExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraLookUpEditExt1.TabIndex = 16;
            // 
            // xtraListBoxControlExt1
            // 
            this.xtraListBoxControlExt1.EnterExecuteButton = null;
            this.xtraListBoxControlExt1.Key = "COL1";
            this.xtraListBoxControlExt1.Location = new System.Drawing.Point(12, 454);
            this.xtraListBoxControlExt1.MinLength = 0;
            this.xtraListBoxControlExt1.Name = "xtraListBoxControlExt1";
            this.xtraListBoxControlExt1.Size = new System.Drawing.Size(487, 50);
            this.xtraListBoxControlExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraListBoxControlExt1.TabIndex = 15;
            this.stdValidationManager1.SetValidation(this.xtraListBoxControlExt1, new HHI.ShipBuilding.Controls.ValidationType[0]);
            // 
            // xtraLabelExt1
            // 
            this.xtraLabelExt1.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.xtraLabelExt1.IsTransparent = false;
            this.xtraLabelExt1.Key = "COL2";
            this.xtraLabelExt1.Location = new System.Drawing.Point(12, 593);
            this.xtraLabelExt1.MinLength = 0;
            this.xtraLabelExt1.Name = "xtraLabelExt1";
            this.xtraLabelExt1.Size = new System.Drawing.Size(487, 14);
            this.xtraLabelExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraLabelExt1.TabIndex = 14;
            this.xtraLabelExt1.Text = "xtraLabelExt1";
            this.stdValidationManager1.SetValidation(this.xtraLabelExt1, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // xtraImageListBoxControlExt1
            // 
            this.xtraImageListBoxControlExt1.EnterExecuteButton = null;
            this.xtraImageListBoxControlExt1.Key = "";
            this.xtraImageListBoxControlExt1.Location = new System.Drawing.Point(12, 157);
            this.xtraImageListBoxControlExt1.MinLength = 0;
            this.xtraImageListBoxControlExt1.Name = "xtraImageListBoxControlExt1";
            this.xtraImageListBoxControlExt1.Size = new System.Drawing.Size(487, 65);
            this.xtraImageListBoxControlExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraImageListBoxControlExt1.TabIndex = 13;
            this.stdValidationManager1.SetValidation(this.xtraImageListBoxControlExt1, new HHI.ShipBuilding.Controls.ValidationType[0]);
            // 
            // xtraImageComboBoxEditExt1
            // 
            this.xtraImageComboBoxEditExt1.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.xtraImageComboBoxEditExt1.EditValue = "";
            this.xtraImageComboBoxEditExt1.EnterExecuteButton = null;
            this.xtraImageComboBoxEditExt1.FocusColor = System.Drawing.Color.Empty;
            this.xtraImageComboBoxEditExt1.Key = "";
            this.xtraImageComboBoxEditExt1.Location = new System.Drawing.Point(127, 133);
            this.xtraImageComboBoxEditExt1.MinLength = 0;
            this.xtraImageComboBoxEditExt1.Name = "xtraImageComboBoxEditExt1";
            this.xtraImageComboBoxEditExt1.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.xtraImageComboBoxEditExt1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.xtraImageComboBoxEditExt1.Properties.Appearance.Options.UseBackColor = true;
            this.xtraImageComboBoxEditExt1.Properties.Appearance.Options.UseForeColor = true;
            this.xtraImageComboBoxEditExt1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.xtraImageComboBoxEditExt1.Size = new System.Drawing.Size(372, 20);
            this.xtraImageComboBoxEditExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraImageComboBoxEditExt1.TabIndex = 12;
            this.stdValidationManager1.SetValidation(this.xtraImageComboBoxEditExt1, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // xtraHyperLinkEditExt1
            // 
            this.xtraHyperLinkEditExt1.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.xtraHyperLinkEditExt1.EnterExecuteButton = null;
            this.xtraHyperLinkEditExt1.FocusColor = System.Drawing.Color.Empty;
            this.xtraHyperLinkEditExt1.IsValueTrim = true;
            this.xtraHyperLinkEditExt1.Key = "";
            this.xtraHyperLinkEditExt1.Location = new System.Drawing.Point(127, 109);
            this.xtraHyperLinkEditExt1.MinLength = 0;
            this.xtraHyperLinkEditExt1.Name = "xtraHyperLinkEditExt1";
            this.xtraHyperLinkEditExt1.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.xtraHyperLinkEditExt1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.xtraHyperLinkEditExt1.Properties.Appearance.Options.UseBackColor = true;
            this.xtraHyperLinkEditExt1.Properties.Appearance.Options.UseForeColor = true;
            this.xtraHyperLinkEditExt1.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.xtraHyperLinkEditExt1.Size = new System.Drawing.Size(372, 20);
            this.xtraHyperLinkEditExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraHyperLinkEditExt1.TabIndex = 11;
            this.stdValidationManager1.SetValidation(this.xtraHyperLinkEditExt1, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // xtraGridControlExt1
            // 
            this.xtraGridControlExt1.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.None;
            this.xtraGridControlExt1.Location = new System.Drawing.Point(618, 86);
            this.xtraGridControlExt1.MainView = this.gridView1;
            this.xtraGridControlExt1.MinLength = 0;
            this.xtraGridControlExt1.Name = "xtraGridControlExt1";
            this.xtraGridControlExt1.Size = new System.Drawing.Size(483, 161);
            this.xtraGridControlExt1.TabIndex = 10;
            this.xtraGridControlExt1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.xtraGridControlExt1;
            this.gridView1.Name = "gridView1";
            // 
            // xtraDateEditExt1
            // 
            this.xtraDateEditExt1.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.xtraDateEditExt1.EditValue = null;
            this.xtraDateEditExt1.EnterExecuteButton = null;
            this.xtraDateEditExt1.FocusColor = System.Drawing.Color.Empty;
            this.xtraDateEditExt1.Key = "COL3";
            this.xtraDateEditExt1.Location = new System.Drawing.Point(127, 85);
            this.xtraDateEditExt1.MinLength = 0;
            this.xtraDateEditExt1.Name = "xtraDateEditExt1";
            this.xtraDateEditExt1.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.xtraDateEditExt1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.xtraDateEditExt1.Properties.Appearance.Options.UseBackColor = true;
            this.xtraDateEditExt1.Properties.Appearance.Options.UseForeColor = true;
            this.xtraDateEditExt1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.xtraDateEditExt1.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.xtraDateEditExt1.Properties.CalendarTimeProperties.CloseUpKey = new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.F4);
            this.xtraDateEditExt1.Properties.CalendarTimeProperties.PopupBorderStyle = DevExpress.XtraEditors.Controls.PopupBorderStyles.Default;
            this.xtraDateEditExt1.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Vista;
            this.xtraDateEditExt1.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.xtraDateEditExt1.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.xtraDateEditExt1.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.True;
            this.xtraDateEditExt1.Size = new System.Drawing.Size(372, 20);
            this.xtraDateEditExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraDateEditExt1.TabIndex = 9;
            this.stdValidationManager1.SetValidation(this.xtraDateEditExt1, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // xtraComboBoxEditExt1
            // 
            this.xtraComboBoxEditExt1.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.xtraComboBoxEditExt1.EditValue = "";
            this.xtraComboBoxEditExt1.EnterExecuteButton = null;
            this.xtraComboBoxEditExt1.FocusColor = System.Drawing.Color.Empty;
            this.xtraComboBoxEditExt1.Key = "";
            this.xtraComboBoxEditExt1.Location = new System.Drawing.Point(618, 62);
            this.xtraComboBoxEditExt1.MinLength = 0;
            this.xtraComboBoxEditExt1.Name = "xtraComboBoxEditExt1";
            this.xtraComboBoxEditExt1.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.xtraComboBoxEditExt1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.xtraComboBoxEditExt1.Properties.Appearance.Options.UseBackColor = true;
            this.xtraComboBoxEditExt1.Properties.Appearance.Options.UseForeColor = true;
            this.xtraComboBoxEditExt1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.xtraComboBoxEditExt1.Size = new System.Drawing.Size(483, 20);
            this.xtraComboBoxEditExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraComboBoxEditExt1.TabIndex = 8;
            this.stdValidationManager1.SetValidation(this.xtraComboBoxEditExt1, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // xtraCheckEditExt1
            // 
            this.xtraCheckEditExt1.EnterExecuteButton = null;
            this.xtraCheckEditExt1.Key = "";
            this.xtraCheckEditExt1.Location = new System.Drawing.Point(12, 62);
            this.xtraCheckEditExt1.MinLength = 0;
            this.xtraCheckEditExt1.Name = "xtraCheckEditExt1";
            this.xtraCheckEditExt1.Properties.Caption = "xtraCheckEditExt1";
            this.xtraCheckEditExt1.Size = new System.Drawing.Size(487, 19);
            this.xtraCheckEditExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraCheckEditExt1.TabIndex = 7;
            this.stdValidationManager1.SetValidation(this.xtraCheckEditExt1, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // xtraCalcEditExt1
            // 
            this.xtraCalcEditExt1.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.xtraCalcEditExt1.EnterExecuteButton = null;
            this.xtraCalcEditExt1.FocusColor = System.Drawing.Color.Empty;
            this.xtraCalcEditExt1.Key = "";
            this.xtraCalcEditExt1.Location = new System.Drawing.Point(618, 38);
            this.xtraCalcEditExt1.MinLength = 0;
            this.xtraCalcEditExt1.Name = "xtraCalcEditExt1";
            this.xtraCalcEditExt1.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.xtraCalcEditExt1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.xtraCalcEditExt1.Properties.Appearance.Options.UseBackColor = true;
            this.xtraCalcEditExt1.Properties.Appearance.Options.UseForeColor = true;
            this.xtraCalcEditExt1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.xtraCalcEditExt1.Size = new System.Drawing.Size(483, 20);
            this.xtraCalcEditExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraCalcEditExt1.TabIndex = 6;
            this.stdValidationManager1.SetValidation(this.xtraCalcEditExt1, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // xtraButtonExt1
            // 
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.xtraButtonExt1, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.xtraButtonExt1, true);
            this.xtraButtonExt1.IsExecuteWdworkerLog = true;
            this.xtraButtonExt1.Location = new System.Drawing.Point(12, 12);
            this.xtraButtonExt1.Name = "xtraButtonExt1";
            this.xtraButtonExt1.Size = new System.Drawing.Size(95, 22);
            this.xtraButtonExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraButtonExt1.TabIndex = 5;
            this.xtraButtonExt1.Text = "xtraButtonExt1";
            this.xtraButtonExt1.UseSplasher = false;
            this.xtraButtonExt1.Click += new System.EventHandler(this.xtraButtonExt1_Click);
            // 
            // xtraButtonEditExt1
            // 
            this.xtraButtonEditExt1.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.xtraButtonEditExt1.EditValue = "";
            this.xtraButtonEditExt1.EnterExecuteButton = null;
            this.xtraButtonEditExt1.FocusColor = System.Drawing.Color.Empty;
            this.xtraButtonEditExt1.IsValueTrim = true;
            this.xtraButtonEditExt1.Key = "";
            this.xtraButtonEditExt1.Location = new System.Drawing.Point(127, 38);
            this.xtraButtonEditExt1.MinLength = 0;
            this.xtraButtonEditExt1.Name = "xtraButtonEditExt1";
            this.xtraButtonEditExt1.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.xtraButtonEditExt1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.xtraButtonEditExt1.Properties.Appearance.Options.UseBackColor = true;
            this.xtraButtonEditExt1.Properties.Appearance.Options.UseForeColor = true;
            this.xtraButtonEditExt1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.xtraButtonEditExt1.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.xtraButtonEditExt1.Size = new System.Drawing.Size(372, 20);
            this.xtraButtonEditExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraButtonEditExt1.TabIndex = 4;
            this.xtraButtonEditExt1.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.xtraButtonEditExt1, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "layoutControlGroup1";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup1, false);
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.layoutControlItem2,
            this.layoutControlItem3,
            this.layoutControlItem4,
            this.layoutControlItem5,
            this.layoutControlItem6,
            this.layoutControlItem7,
            this.layoutControlItem8,
            this.layoutControlItem9,
            this.layoutControlItem10,
            this.layoutControlItem11,
            this.layoutControlItem12,
            this.layoutControlItem19,
            this.layoutControlItem21,
            this.layoutControlItem22,
            this.layoutControlItem23,
            this.layoutControlItem24,
            this.layoutControlGroup2,
            this.tabbedControlGroup1,
            this.layoutControlItem25,
            this.emptySpaceItem2,
            this.layoutControlItem26});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1113, 619);
            this.layoutControlGroup1.Text = "Root";
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.xtraButtonEditExt1;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(491, 24);
            this.layoutControlItem1.Text = "layoutControlItem1";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.xtraButtonExt1;
            this.layoutControlItem2.CustomizationFormText = "layoutControlItem2";
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(99, 26);
            this.layoutControlItem2.Text = "layoutControlItem2";
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextToControlDistance = 0;
            this.layoutControlItem2.TextVisible = false;
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.xtraCalcEditExt1;
            this.layoutControlItem3.CustomizationFormText = "layoutControlItem3";
            this.layoutControlItem3.Location = new System.Drawing.Point(491, 26);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(602, 24);
            this.layoutControlItem3.Text = "layoutControlItem3";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.xtraCheckEditExt1;
            this.layoutControlItem4.CustomizationFormText = "layoutControlItem4";
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 50);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(491, 23);
            this.layoutControlItem4.Text = "layoutControlItem4";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextToControlDistance = 0;
            this.layoutControlItem4.TextVisible = false;
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.xtraComboBoxEditExt1;
            this.layoutControlItem5.CustomizationFormText = "layoutControlItem5";
            this.layoutControlItem5.Location = new System.Drawing.Point(491, 50);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(602, 24);
            this.layoutControlItem5.Text = "layoutControlItem5";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.xtraDateEditExt1;
            this.layoutControlItem6.CustomizationFormText = "layoutControlItem6";
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 73);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(491, 24);
            this.layoutControlItem6.Text = "layoutControlItem6";
            this.layoutControlItem6.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.xtraGridControlExt1;
            this.layoutControlItem7.CustomizationFormText = "layoutControlItem7";
            this.layoutControlItem7.Location = new System.Drawing.Point(491, 74);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(602, 165);
            this.layoutControlItem7.Text = "layoutControlItem7";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.xtraHyperLinkEditExt1;
            this.layoutControlItem8.CustomizationFormText = "layoutControlItem8";
            this.layoutControlItem8.Location = new System.Drawing.Point(0, 97);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(491, 24);
            this.layoutControlItem8.Text = "layoutControlItem8";
            this.layoutControlItem8.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.xtraImageComboBoxEditExt1;
            this.layoutControlItem9.CustomizationFormText = "layoutControlItem9";
            this.layoutControlItem9.Location = new System.Drawing.Point(0, 121);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(491, 24);
            this.layoutControlItem9.Text = "layoutControlItem9";
            this.layoutControlItem9.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.xtraImageListBoxControlExt1;
            this.layoutControlItem10.CustomizationFormText = "layoutControlItem10";
            this.layoutControlItem10.Location = new System.Drawing.Point(0, 145);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(491, 69);
            this.layoutControlItem10.Text = "layoutControlItem10";
            this.layoutControlItem10.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem10.TextToControlDistance = 0;
            this.layoutControlItem10.TextVisible = false;
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.xtraLabelExt1;
            this.layoutControlItem11.CustomizationFormText = "layoutControlItem11";
            this.layoutControlItem11.Location = new System.Drawing.Point(0, 581);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(491, 18);
            this.layoutControlItem11.Text = "layoutControlItem11";
            this.layoutControlItem11.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem11.TextToControlDistance = 0;
            this.layoutControlItem11.TextVisible = false;
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.xtraListBoxControlExt1;
            this.layoutControlItem12.CustomizationFormText = "layoutControlItem12";
            this.layoutControlItem12.Location = new System.Drawing.Point(0, 442);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(491, 54);
            this.layoutControlItem12.Text = "layoutControlItem12";
            this.layoutControlItem12.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem12.TextToControlDistance = 0;
            this.layoutControlItem12.TextVisible = false;
            // 
            // layoutControlItem19
            // 
            this.layoutControlItem19.Control = this.xtraRichEditControlExt1;
            this.layoutControlItem19.CustomizationFormText = "layoutControlItem19";
            this.layoutControlItem19.Location = new System.Drawing.Point(0, 496);
            this.layoutControlItem19.Name = "layoutControlItem19";
            this.layoutControlItem19.Size = new System.Drawing.Size(491, 85);
            this.layoutControlItem19.Text = "layoutControlItem19";
            this.layoutControlItem19.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlItem21
            // 
            this.layoutControlItem21.Control = this.xtraSyntaxRichEditControlExt1;
            this.layoutControlItem21.CustomizationFormText = "layoutControlItem21";
            this.layoutControlItem21.Location = new System.Drawing.Point(491, 263);
            this.layoutControlItem21.Name = "layoutControlItem21";
            this.layoutControlItem21.Size = new System.Drawing.Size(602, 56);
            this.layoutControlItem21.Text = "layoutControlItem21";
            this.layoutControlItem21.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlItem22
            // 
            this.layoutControlItem22.Control = this.xtraTextEditExt1;
            this.layoutControlItem22.CustomizationFormText = "layoutControlItem22";
            this.layoutControlItem22.Location = new System.Drawing.Point(491, 239);
            this.layoutControlItem22.Name = "layoutControlItem22";
            this.layoutControlItem22.Size = new System.Drawing.Size(602, 24);
            this.layoutControlItem22.Text = "layoutControlItem22";
            this.layoutControlItem22.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlItem23
            // 
            this.layoutControlItem23.Control = this.xtraTimeEditExt1;
            this.layoutControlItem23.CustomizationFormText = "layoutControlItem23";
            this.layoutControlItem23.Location = new System.Drawing.Point(0, 418);
            this.layoutControlItem23.Name = "layoutControlItem23";
            this.layoutControlItem23.Size = new System.Drawing.Size(491, 24);
            this.layoutControlItem23.Text = "layoutControlItem23";
            this.layoutControlItem23.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlItem24
            // 
            this.layoutControlItem24.Control = this.xtraToolBarRichEditControl1;
            this.layoutControlItem24.CustomizationFormText = "layoutControlItem24";
            this.layoutControlItem24.Location = new System.Drawing.Point(0, 214);
            this.layoutControlItem24.Name = "layoutControlItem24";
            this.layoutControlItem24.Size = new System.Drawing.Size(491, 204);
            this.layoutControlItem24.Text = "layoutControlItem24";
            this.layoutControlItem24.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.CustomizationFormText = "layoutControlGroup2";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup2, true);
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem13,
            this.layoutControlItem14,
            this.layoutControlItem15,
            this.layoutControlItem16});
            this.layoutControlGroup2.Location = new System.Drawing.Point(491, 434);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(602, 165);
            this.layoutControlGroup2.Text = "layoutControlGroup2";
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.xtraLookUpEditExt1;
            this.layoutControlItem13.CustomizationFormText = "layoutControlItem13";
            this.layoutControlItem13.Location = new System.Drawing.Point(0, 97);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(578, 24);
            this.layoutControlItem13.Text = "layoutControlItem13";
            this.layoutControlItem13.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.xtraMemoEditExt1;
            this.layoutControlItem14.CustomizationFormText = "layoutControlItem14";
            this.layoutControlItem14.Location = new System.Drawing.Point(0, 48);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Size = new System.Drawing.Size(578, 49);
            this.layoutControlItem14.Text = "layoutControlItem14";
            this.layoutControlItem14.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.Control = this.xtraMemoExEditExt1;
            this.layoutControlItem15.CustomizationFormText = "layoutControlItem15";
            this.layoutControlItem15.Location = new System.Drawing.Point(0, 24);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.Size = new System.Drawing.Size(578, 24);
            this.layoutControlItem15.Text = "layoutControlItem15";
            this.layoutControlItem15.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlItem16
            // 
            this.layoutControlItem16.Control = this.xtraMRUEditExt1;
            this.layoutControlItem16.CustomizationFormText = "layoutControlItem16";
            this.layoutControlItem16.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem16.Name = "layoutControlItem16";
            this.layoutControlItem16.Size = new System.Drawing.Size(578, 24);
            this.layoutControlItem16.Text = "layoutControlItem16";
            this.layoutControlItem16.TextSize = new System.Drawing.Size(112, 14);
            // 
            // tabbedControlGroup1
            // 
            this.tabbedControlGroup1.CustomizationFormText = "tabbedControlGroup1";
            this.tabbedControlGroup1.Location = new System.Drawing.Point(491, 319);
            this.tabbedControlGroup1.Name = "tabbedControlGroup1";
            this.tabbedControlGroup1.SelectedTabPage = this.layoutControlGroup3;
            this.tabbedControlGroup1.SelectedTabPageIndex = 0;
            this.tabbedControlGroup1.Size = new System.Drawing.Size(602, 115);
            this.tabbedControlGroup1.TabPages.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup3});
            this.tabbedControlGroup1.Text = "tabbedControlGroup1";
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.CustomizationFormText = "layoutControlGroup3";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup3, true);
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem17,
            this.layoutControlItem18,
            this.layoutControlItem20});
            this.layoutControlGroup3.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup3.Name = "layoutControlGroup3";
            this.layoutControlGroup3.Size = new System.Drawing.Size(578, 68);
            this.layoutControlGroup3.Text = "layoutControlGroup3";
            // 
            // layoutControlItem17
            // 
            this.layoutControlItem17.Control = this.xtraPopupContainerEditExt1;
            this.layoutControlItem17.CustomizationFormText = "layoutControlItem17";
            this.layoutControlItem17.Location = new System.Drawing.Point(0, 44);
            this.layoutControlItem17.Name = "layoutControlItem17";
            this.layoutControlItem17.Size = new System.Drawing.Size(578, 24);
            this.layoutControlItem17.Text = "layoutControlItem17";
            this.layoutControlItem17.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlItem18
            // 
            this.layoutControlItem18.Control = this.xtraRadioGroupExt1;
            this.layoutControlItem18.CustomizationFormText = "layoutControlItem18";
            this.layoutControlItem18.Location = new System.Drawing.Point(0, 24);
            this.layoutControlItem18.Name = "layoutControlItem18";
            this.layoutControlItem18.Size = new System.Drawing.Size(578, 20);
            this.layoutControlItem18.Text = "layoutControlItem18";
            this.layoutControlItem18.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlItem20
            // 
            this.layoutControlItem20.Control = this.xtraSpinEditExt1;
            this.layoutControlItem20.CustomizationFormText = "layoutControlItem20";
            this.layoutControlItem20.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem20.Name = "layoutControlItem20";
            this.layoutControlItem20.Size = new System.Drawing.Size(578, 24);
            this.layoutControlItem20.Text = "layoutControlItem20";
            this.layoutControlItem20.TextSize = new System.Drawing.Size(112, 14);
            // 
            // layoutControlItem25
            // 
            this.layoutControlItem25.Control = this.xtraButtonExt2;
            this.layoutControlItem25.CustomizationFormText = "layoutControlItem25";
            this.layoutControlItem25.Location = new System.Drawing.Point(985, 0);
            this.layoutControlItem25.Name = "layoutControlItem25";
            this.layoutControlItem25.Size = new System.Drawing.Size(108, 26);
            this.layoutControlItem25.Text = "layoutControlItem25";
            this.layoutControlItem25.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem25.TextToControlDistance = 0;
            this.layoutControlItem25.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(199, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(786, 26);
            this.emptySpaceItem2.Text = "emptySpaceItem2";
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem26
            // 
            this.layoutControlItem26.Control = this.xtraButtonExt3;
            this.layoutControlItem26.CustomizationFormText = "layoutControlItem26";
            this.layoutControlItem26.Location = new System.Drawing.Point(99, 0);
            this.layoutControlItem26.Name = "layoutControlItem26";
            this.layoutControlItem26.Size = new System.Drawing.Size(100, 26);
            this.layoutControlItem26.Text = "layoutControlItem26";
            this.layoutControlItem26.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem26.TextToControlDistance = 0;
            this.layoutControlItem26.TextVisible = false;
            // 
            // UserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "UserControl1";
            this.Size = new System.Drawing.Size(1113, 619);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTimeEditExt1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTextEditExt1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraSpinEditExt1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraRadioGroupExt1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraPopupContainerEditExt1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraMRUEditExt1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraMemoExEditExt1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraMemoEditExt1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLookUpEditExt1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraListBoxControlExt1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraImageListBoxControlExt1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraImageComboBoxEditExt1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraHyperLinkEditExt1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraGridControlExt1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraDateEditExt1.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraDateEditExt1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraComboBoxEditExt1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraCheckEditExt1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraCalcEditExt1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraButtonEditExt1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabbedControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem26)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private HHI.ShipBuilding.Controls.StdValidationManager stdValidationManager1;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt xtraButtonExt1;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonEditExt xtraButtonEditExt1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraComboBoxEditExt xtraComboBoxEditExt1;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraCheckEditExt xtraCheckEditExt1;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraCalcEditExt xtraCalcEditExt1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraDateEditExt xtraDateEditExt1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt xtraGridControlExt1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraHyperLinkEditExt xtraHyperLinkEditExt1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraImageComboBoxEditExt xtraImageComboBoxEditExt1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraImageListBoxControlExt xtraImageListBoxControlExt1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt xtraLabelExt1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraListBoxControlExt xtraListBoxControlExt1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraLookUpEditExt xtraLookUpEditExt1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraMemoEditExt xtraMemoEditExt1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraMemoExEditExt xtraMemoExEditExt1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraMRUEditExt xtraMRUEditExt1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem16;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraPopupContainerEditExt xtraPopupContainerEditExt1;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraRadioGroupExt xtraRadioGroupExt1;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraRichEditControlExt xtraRichEditControlExt1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem19;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraSpinEditExt xtraSpinEditExt1;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraSyntaxRichEditControlExt xtraSyntaxRichEditControlExt1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem21;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt xtraTextEditExt1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem22;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraTimeEditExt xtraTimeEditExt1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem23;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraToolBarRichEditControl xtraToolBarRichEditControl1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem24;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.TabbedControlGroup tabbedControlGroup1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem17;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem18;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem20;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt xtraButtonExt2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem25;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private HHI.ShipBuilding.Controls.StdButtonExecuteManager stdButtonExecuteManager1;
        private HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt xtraButtonExt3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem26;
    }
}
