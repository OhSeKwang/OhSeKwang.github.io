﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;

namespace TestSystem_B
{
    [ToolboxItem(true)]
    public partial class UserControl1 : StdUserControlBase
    {
        public UserControl1()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            userinfo.SetThreadPrincipal();
            userinfo.SetCallContext();

            #endregion

            stdButtonExecuteManager1.RegisterButtonExecEvent();
        }

        private void xtraButtonExt1_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("COL1");
            dt.Columns.Add("COL2");
            dt.Columns.Add("COL3");
            dt.Columns.Add("COL4");

            DataRow row = dt.NewRow();

            row["COL1"] = "1";
            row["COL2"] = "2";
            row["COL3"] = "20140902";
            row["COL4"] = "4";

            dt.Rows.Add(row);

            ClientControlHelper.CtrlNestedDataBind(row, layoutControlGroup1);

            //필수입력체크...
            if (stdValidationManager1.Validation())
            {
                DataPack parameter = ClientControlHelper.GetContainerDictionaryList(layoutControlGroup1);

                
            }
        }

        private void xtraButtonExt2_Click(object sender, EventArgs e)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("OBJECT_ID", 0);
            parameter.DataList.Add("OWNER", "SYS");
            parameter.DataList.Add("OBJECT_NAME", string.Empty);
            parameter.DataList.Add("CREATED", DateTime.Now.AddDays(-100));
            parameter.DataList.Add("LAST_DDL_TIME", "20130101");

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "GetTestDemoTableInfo", parameter);

            if (resultSet.IsSuccess)
            {
                xtraGridControlExt1.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MessageBox.Show(resultSet.ExceptionMessage);
            }
        }

        private void xtraButtonExt3_Click(object sender, EventArgs e)
        {
            DataPack parameter = new DataPack();

            string[] OWNER = new string[] { "KANG", "KANG" };

            parameter.DataList.Add("OWNER", OWNER);
            parameter.DataList.Add("OBJECT_NAME", new string[] { "KANG", "KANG" });
            parameter.DataList.Add("SUBOBJECT_NAME", new string[] { "KANG", "KANG" });
            parameter.DataList.Add("OBJECT_ID", new int[] { 1, 1 });
            parameter.DataList.Add("DATA_OBJECT_ID", new int[] { 2, 2 });
            parameter.DataList.Add("OBJECT_TYPE", new string[] { "KANG", "KANG" });
            parameter.DataList.Add("CREATED", new DateTime[] { DateTime.Now, DateTime.Now });
            parameter.DataList.Add("LAST_DDL_TIME", new DateTime[] { DateTime.Now, DateTime.Now });
            parameter.DataList.Add("TIMESTAMP", new string[] { "KANG", "KANG" });
            parameter.DataList.Add("STATUS", new string[] { "Y", "Y" });
            parameter.DataList.Add("TEMPORARY", new string[] { "Y", "Y" });
            parameter.DataList.Add("GENERATED", new string[] { "Y", "Y" });
            parameter.DataList.Add("SECONDARY", new string[] { "Y", "Y" });
            parameter.DataList.Add("NAMESPACE", new int[] { 1, 1 });
            parameter.DataList.Add("EDITION_NAME", new string[] { "KANG", "KANG" });

            parameter.ArrayItemCount = OWNER.Length; //==> ArrayBind 처리시... 항상 지정해야함...

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "SaveTestDemoTableInfo", parameter);

            if(resultSet.IsSuccess)
            {
                MessageBox.Show("OK....");
            }
            else
            {
                MessageBox.Show(resultSet.ExceptionMessage);
            }
        }
    }
}
