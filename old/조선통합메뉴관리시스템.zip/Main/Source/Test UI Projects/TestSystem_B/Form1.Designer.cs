﻿namespace TestSystem_B
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.scsyS0011 = new HHI.ShipBuilding.UI.MenuManage.SCSYS001();
            this.xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
            this.scsyS0021 = new HHI.ShipBuilding.UI.MenuManage.SCSYS002();
            this.xtraTabPage3 = new DevExpress.XtraTab.XtraTabPage();
            this.scsyS0031 = new HHI.ShipBuilding.UI.MenuManage.SCSYS003();
            this.xtraTabPage5 = new DevExpress.XtraTab.XtraTabPage();
            this.scsyS0051 = new HHI.ShipBuilding.UI.MenuManage.SCSYS005();
            this.xtraTabPage6 = new DevExpress.XtraTab.XtraTabPage();
            this.scsyS0061 = new HHI.ShipBuilding.UI.MenuManage.SCSYS006();
            this.xtraTabPage7 = new DevExpress.XtraTab.XtraTabPage();
            this.scsyS0071 = new HHI.ShipBuilding.UI.MenuManage.SCSYS007();
            this.xtraTabPage8 = new DevExpress.XtraTab.XtraTabPage();
            this.scsyS0081 = new HHI.ShipBuilding.UI.MenuManage.SCSYS008();
            this.xtraTabPage9 = new DevExpress.XtraTab.XtraTabPage();
            this.scsyS0091 = new HHI.ShipBuilding.UI.MenuManage.SCSYS009();
            this.xtraTabPage10 = new DevExpress.XtraTab.XtraTabPage();
            this.scsyS0101 = new HHI.ShipBuilding.UI.MenuManage.SCSYS010();
            this.xtraTabPage11 = new DevExpress.XtraTab.XtraTabPage();
            this.scsyS0111 = new HHI.ShipBuilding.UI.MenuManage.SCSYS011();
            this.xtraTabPage12 = new DevExpress.XtraTab.XtraTabPage();
            this.scsyS0121 = new HHI.ShipBuilding.UI.MenuManage.SCSYS012();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.xtraTabPage1.SuspendLayout();
            this.xtraTabPage2.SuspendLayout();
            this.xtraTabPage3.SuspendLayout();
            this.xtraTabPage5.SuspendLayout();
            this.xtraTabPage6.SuspendLayout();
            this.xtraTabPage7.SuspendLayout();
            this.xtraTabPage8.SuspendLayout();
            this.xtraTabPage9.SuspendLayout();
            this.xtraTabPage10.SuspendLayout();
            this.xtraTabPage11.SuspendLayout();
            this.xtraTabPage12.SuspendLayout();
            this.SuspendLayout();
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl1.Location = new System.Drawing.Point(0, 0);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.xtraTabPage1;
            this.xtraTabControl1.Size = new System.Drawing.Size(1123, 688);
            this.xtraTabControl1.TabIndex = 0;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1,
            this.xtraTabPage2,
            this.xtraTabPage3,
            this.xtraTabPage5,
            this.xtraTabPage6,
            this.xtraTabPage7,
            this.xtraTabPage8,
            this.xtraTabPage9,
            this.xtraTabPage10,
            this.xtraTabPage11,
            this.xtraTabPage12});
            // 
            // xtraTabPage1
            // 
            this.xtraTabPage1.Controls.Add(this.scsyS0011);
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Size = new System.Drawing.Size(1117, 659);
            this.xtraTabPage1.Text = "그룹관리";
            // 
            // scsyS0011
            // 
            this.scsyS0011.AuthString = null;
            this.scsyS0011.BackColor = System.Drawing.Color.Transparent;
            this.scsyS0011.BrowserWindow = null;
            this.scsyS0011.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scsyS0011.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.scsyS0011.Location = new System.Drawing.Point(0, 0);
            this.scsyS0011.MenuControl = null;
            this.scsyS0011.MenuItemInfo = null;
            this.scsyS0011.Name = "scsyS0011";
            this.scsyS0011.ProgramID = null;
            this.scsyS0011.RequireAuthentication = false;
            this.scsyS0011.RequireAuthorization = false;
            this.scsyS0011.SelfSecurityProcess = false;
            this.scsyS0011.Size = new System.Drawing.Size(1117, 659);
            this.scsyS0011.TabIndex = 0;
            // 
            // xtraTabPage2
            // 
            this.xtraTabPage2.Controls.Add(this.scsyS0021);
            this.xtraTabPage2.Name = "xtraTabPage2";
            this.xtraTabPage2.Size = new System.Drawing.Size(1117, 659);
            this.xtraTabPage2.Text = "그룹별사용자관리";
            // 
            // scsyS0021
            // 
            this.scsyS0021.AuthString = null;
            this.scsyS0021.BackColor = System.Drawing.Color.Transparent;
            this.scsyS0021.BrowserWindow = null;
            this.scsyS0021.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scsyS0021.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.scsyS0021.Location = new System.Drawing.Point(0, 0);
            this.scsyS0021.MenuControl = null;
            this.scsyS0021.MenuItemInfo = null;
            this.scsyS0021.Name = "scsyS0021";
            this.scsyS0021.ProgramID = null;
            this.scsyS0021.RequireAuthentication = false;
            this.scsyS0021.RequireAuthorization = false;
            this.scsyS0021.SelfSecurityProcess = false;
            this.scsyS0021.Size = new System.Drawing.Size(1117, 659);
            this.scsyS0021.TabIndex = 0;
            // 
            // xtraTabPage3
            // 
            this.xtraTabPage3.Controls.Add(this.scsyS0031);
            this.xtraTabPage3.Name = "xtraTabPage3";
            this.xtraTabPage3.Size = new System.Drawing.Size(1117, 659);
            this.xtraTabPage3.Text = "그룹별메뉴권한관리";
            // 
            // scsyS0031
            // 
            this.scsyS0031.AuthString = null;
            this.scsyS0031.BackColor = System.Drawing.Color.White;
            this.scsyS0031.BrowserWindow = null;
            this.scsyS0031.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scsyS0031.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.scsyS0031.Location = new System.Drawing.Point(0, 0);
            this.scsyS0031.MenuControl = null;
            this.scsyS0031.MenuItemInfo = null;
            this.scsyS0031.Name = "scsyS0031";
            this.scsyS0031.ProgramID = null;
            this.scsyS0031.RequireAuthentication = false;
            this.scsyS0031.RequireAuthorization = false;
            this.scsyS0031.SelfSecurityProcess = false;
            this.scsyS0031.Size = new System.Drawing.Size(1117, 659);
            this.scsyS0031.TabIndex = 0;
            // 
            // xtraTabPage5
            // 
            this.xtraTabPage5.Controls.Add(this.scsyS0051);
            this.xtraTabPage5.Name = "xtraTabPage5";
            this.xtraTabPage5.Size = new System.Drawing.Size(1117, 659);
            this.xtraTabPage5.Text = "메뉴별프로그램";
            // 
            // scsyS0051
            // 
            this.scsyS0051.AuthString = null;
            this.scsyS0051.BackColor = System.Drawing.Color.Transparent;
            this.scsyS0051.BrowserWindow = null;
            this.scsyS0051.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scsyS0051.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.scsyS0051.Location = new System.Drawing.Point(0, 0);
            this.scsyS0051.MenuControl = null;
            this.scsyS0051.MenuItemInfo = null;
            this.scsyS0051.Name = "scsyS0051";
            this.scsyS0051.ProgramID = null;
            this.scsyS0051.RequireAuthentication = false;
            this.scsyS0051.RequireAuthorization = false;
            this.scsyS0051.SelfSecurityProcess = false;
            this.scsyS0051.Size = new System.Drawing.Size(1117, 659);
            this.scsyS0051.TabIndex = 0;
            // 
            // xtraTabPage6
            // 
            this.xtraTabPage6.Controls.Add(this.scsyS0061);
            this.xtraTabPage6.Name = "xtraTabPage6";
            this.xtraTabPage6.Size = new System.Drawing.Size(1117, 659);
            this.xtraTabPage6.Text = "사용자관리";
            // 
            // scsyS0061
            // 
            this.scsyS0061.AuthString = null;
            this.scsyS0061.BackColor = System.Drawing.Color.White;
            this.scsyS0061.BrowserWindow = null;
            this.scsyS0061.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scsyS0061.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.scsyS0061.Location = new System.Drawing.Point(0, 0);
            this.scsyS0061.MenuControl = null;
            this.scsyS0061.MenuItemInfo = null;
            this.scsyS0061.Name = "scsyS0061";
            this.scsyS0061.ProgramID = null;
            this.scsyS0061.RequireAuthentication = false;
            this.scsyS0061.RequireAuthorization = false;
            this.scsyS0061.SelfSecurityProcess = false;
            this.scsyS0061.Size = new System.Drawing.Size(1117, 659);
            this.scsyS0061.TabIndex = 0;
            // 
            // xtraTabPage7
            // 
            this.xtraTabPage7.Controls.Add(this.scsyS0071);
            this.xtraTabPage7.Name = "xtraTabPage7";
            this.xtraTabPage7.Size = new System.Drawing.Size(1117, 659);
            this.xtraTabPage7.Text = "프로그램관리";
            // 
            // scsyS0071
            // 
            this.scsyS0071.AuthString = null;
            this.scsyS0071.BackColor = System.Drawing.Color.White;
            this.scsyS0071.BrowserWindow = null;
            this.scsyS0071.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scsyS0071.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.scsyS0071.Location = new System.Drawing.Point(0, 0);
            this.scsyS0071.MenuControl = null;
            this.scsyS0071.MenuItemInfo = null;
            this.scsyS0071.Name = "scsyS0071";
            this.scsyS0071.ProgramID = null;
            this.scsyS0071.RequireAuthentication = false;
            this.scsyS0071.RequireAuthorization = false;
            this.scsyS0071.SelfSecurityProcess = false;
            this.scsyS0071.Size = new System.Drawing.Size(1117, 659);
            this.scsyS0071.TabIndex = 0;
            // 
            // xtraTabPage8
            // 
            this.xtraTabPage8.Controls.Add(this.scsyS0081);
            this.xtraTabPage8.Name = "xtraTabPage8";
            this.xtraTabPage8.Size = new System.Drawing.Size(1117, 659);
            this.xtraTabPage8.Text = "확장권한관리";
            // 
            // scsyS0081
            // 
            this.scsyS0081.AuthString = null;
            this.scsyS0081.BackColor = System.Drawing.Color.White;
            this.scsyS0081.BrowserWindow = null;
            this.scsyS0081.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scsyS0081.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.scsyS0081.Location = new System.Drawing.Point(0, 0);
            this.scsyS0081.MenuControl = null;
            this.scsyS0081.MenuItemInfo = null;
            this.scsyS0081.Name = "scsyS0081";
            this.scsyS0081.ProgramID = null;
            this.scsyS0081.RequireAuthentication = false;
            this.scsyS0081.RequireAuthorization = false;
            this.scsyS0081.SelfSecurityProcess = false;
            this.scsyS0081.Size = new System.Drawing.Size(1117, 659);
            this.scsyS0081.TabIndex = 0;
            // 
            // xtraTabPage9
            // 
            this.xtraTabPage9.Controls.Add(this.scsyS0091);
            this.xtraTabPage9.Name = "xtraTabPage9";
            this.xtraTabPage9.Size = new System.Drawing.Size(1117, 659);
            this.xtraTabPage9.Text = "시스템관리";
            // 
            // scsyS0091
            // 
            this.scsyS0091.AuthString = null;
            this.scsyS0091.BackColor = System.Drawing.Color.Transparent;
            this.scsyS0091.BrowserWindow = null;
            this.scsyS0091.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scsyS0091.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.scsyS0091.Location = new System.Drawing.Point(0, 0);
            this.scsyS0091.MenuControl = null;
            this.scsyS0091.MenuItemInfo = null;
            this.scsyS0091.Name = "scsyS0091";
            this.scsyS0091.ProgramID = null;
            this.scsyS0091.RequireAuthentication = false;
            this.scsyS0091.RequireAuthorization = false;
            this.scsyS0091.SelfSecurityProcess = false;
            this.scsyS0091.Size = new System.Drawing.Size(1117, 659);
            this.scsyS0091.TabIndex = 0;
            // 
            // xtraTabPage10
            // 
            this.xtraTabPage10.Controls.Add(this.scsyS0101);
            this.xtraTabPage10.Name = "xtraTabPage10";
            this.xtraTabPage10.Size = new System.Drawing.Size(1117, 659);
            this.xtraTabPage10.Text = "사용자별프로그램";
            // 
            // scsyS0101
            // 
            this.scsyS0101.AuthString = null;
            this.scsyS0101.BackColor = System.Drawing.Color.Transparent;
            this.scsyS0101.BrowserWindow = null;
            this.scsyS0101.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scsyS0101.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.scsyS0101.Location = new System.Drawing.Point(0, 0);
            this.scsyS0101.MenuControl = null;
            this.scsyS0101.MenuItemInfo = null;
            this.scsyS0101.Name = "scsyS0101";
            this.scsyS0101.ProgramID = null;
            this.scsyS0101.RequireAuthentication = false;
            this.scsyS0101.RequireAuthorization = false;
            this.scsyS0101.SelfSecurityProcess = false;
            this.scsyS0101.Size = new System.Drawing.Size(1117, 659);
            this.scsyS0101.TabIndex = 0;
            // 
            // xtraTabPage11
            // 
            this.xtraTabPage11.Controls.Add(this.scsyS0111);
            this.xtraTabPage11.Name = "xtraTabPage11";
            this.xtraTabPage11.Size = new System.Drawing.Size(1117, 659);
            this.xtraTabPage11.Text = "공통코드";
            // 
            // scsyS0111
            // 
            this.scsyS0111.AuthString = null;
            this.scsyS0111.BackColor = System.Drawing.Color.Transparent;
            this.scsyS0111.BrowserWindow = null;
            this.scsyS0111.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scsyS0111.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.scsyS0111.Location = new System.Drawing.Point(0, 0);
            this.scsyS0111.MenuControl = null;
            this.scsyS0111.MenuItemInfo = null;
            this.scsyS0111.Name = "scsyS0111";
            this.scsyS0111.ProgramID = null;
            this.scsyS0111.RequireAuthentication = false;
            this.scsyS0111.RequireAuthorization = false;
            this.scsyS0111.SelfSecurityProcess = false;
            this.scsyS0111.Size = new System.Drawing.Size(1117, 659);
            this.scsyS0111.TabIndex = 0;
            // 
            // xtraTabPage12
            // 
            this.xtraTabPage12.Controls.Add(this.scsyS0121);
            this.xtraTabPage12.Name = "xtraTabPage12";
            this.xtraTabPage12.Size = new System.Drawing.Size(1117, 659);
            this.xtraTabPage12.Text = "사용자별메뉴권한관리";
            // 
            // scsyS0121
            // 
            this.scsyS0121.AuthString = null;
            this.scsyS0121.BackColor = System.Drawing.Color.White;
            this.scsyS0121.BrowserWindow = null;
            this.scsyS0121.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scsyS0121.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.scsyS0121.Location = new System.Drawing.Point(0, 0);
            this.scsyS0121.MenuControl = null;
            this.scsyS0121.MenuItemInfo = null;
            this.scsyS0121.Name = "scsyS0121";
            this.scsyS0121.ProgramID = null;
            this.scsyS0121.RequireAuthentication = false;
            this.scsyS0121.RequireAuthorization = false;
            this.scsyS0121.SelfSecurityProcess = false;
            this.scsyS0121.Size = new System.Drawing.Size(1117, 659);
            this.scsyS0121.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1123, 688);
            this.Controls.Add(this.xtraTabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.xtraTabPage1.ResumeLayout(false);
            this.xtraTabPage2.ResumeLayout(false);
            this.xtraTabPage3.ResumeLayout(false);
            this.xtraTabPage5.ResumeLayout(false);
            this.xtraTabPage6.ResumeLayout(false);
            this.xtraTabPage7.ResumeLayout(false);
            this.xtraTabPage8.ResumeLayout(false);
            this.xtraTabPage9.ResumeLayout(false);
            this.xtraTabPage10.ResumeLayout(false);
            this.xtraTabPage11.ResumeLayout(false);
            this.xtraTabPage12.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage3;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage5;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage6;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage7;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage8;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage9;
        private HHI.ShipBuilding.UI.MenuManage.SCSYS001 scsyS0011;
        private HHI.ShipBuilding.UI.MenuManage.SCSYS002 scsyS0021;
        private HHI.ShipBuilding.UI.MenuManage.SCSYS003 scsyS0031;
        private HHI.ShipBuilding.UI.MenuManage.SCSYS006 scsyS0061;
        private HHI.ShipBuilding.UI.MenuManage.SCSYS007 scsyS0071;
        private HHI.ShipBuilding.UI.MenuManage.SCSYS009 scsyS0091;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage10;
        private HHI.ShipBuilding.UI.MenuManage.SCSYS010 scsyS0101;
        private HHI.ShipBuilding.UI.MenuManage.SCSYS005 scsyS0051;
        private HHI.ShipBuilding.UI.MenuManage.SCSYS008 scsyS0081;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage11;
        private HHI.ShipBuilding.UI.MenuManage.SCSYS011 scsyS0111;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage12;
        private HHI.ShipBuilding.UI.MenuManage.SCSYS012 scsyS0121;











    }
}