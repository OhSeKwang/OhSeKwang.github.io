﻿namespace HHI.ShipBuilding.UI.WorkFlowManage
{
    partial class SCWF000_2
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btn7 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.xtraButtonExt5 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.xtraButtonExt6 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.xtraButtonExt3 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.xtraButtonExt4 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.pictureEdit1 = new DevExpress.XtraEditors.PictureEdit();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.xtraButtonExt2 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.xtraButtonExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btn4 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btn3 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn2 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btn1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.xtraTabPage1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.xtraTabControl1);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(742, 395, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(1116, 747);
            this.xtraLayoutControlExt1.TabIndex = 0;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.ClosePageButtonShowMode = DevExpress.XtraTab.ClosePageButtonShowMode.InActiveTabPageHeader;
            this.xtraTabControl1.HeaderButtons = ((DevExpress.XtraTab.TabButtons)((DevExpress.XtraTab.TabButtons.Close | DevExpress.XtraTab.TabButtons.Default)));
            this.xtraTabControl1.Location = new System.Drawing.Point(24, 24);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.xtraTabPage1;
            this.xtraTabControl1.Size = new System.Drawing.Size(1068, 699);
            this.xtraTabControl1.TabIndex = 28;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1});
            this.xtraTabControl1.CloseButtonClick += new System.EventHandler(this.xtraTabControl1_CloseButtonClick);
            // 
            // xtraTabPage1
            // 
            this.xtraTabPage1.Controls.Add(this.groupBox4);
            this.xtraTabPage1.Controls.Add(this.groupBox3);
            this.xtraTabPage1.Controls.Add(this.pictureEdit1);
            this.xtraTabPage1.Controls.Add(this.groupBox2);
            this.xtraTabPage1.Controls.Add(this.groupBox1);
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Size = new System.Drawing.Size(1062, 670);
            this.xtraTabPage1.Text = "WorkFlow Test";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btn7);
            this.groupBox4.Controls.Add(this.xtraButtonExt5);
            this.groupBox4.Controls.Add(this.xtraButtonExt6);
            this.groupBox4.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox4.Location = new System.Drawing.Point(454, 322);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(365, 206);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "연결업무 바로가기";
            // 
            // btn7
            // 
            this.btn7.IsExecuteWdworkerLog = true;
            this.btn7.Location = new System.Drawing.Point(24, 117);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(151, 57);
            this.btn7.TabIndex = 3;
            this.btn7.Tag = "";
            this.btn7.Text = "Legacy 테스트 화면";
            this.btn7.UseSplasher = false;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // xtraButtonExt5
            // 
            this.xtraButtonExt5.IsExecuteWdworkerLog = true;
            this.xtraButtonExt5.Location = new System.Drawing.Point(195, 39);
            this.xtraButtonExt5.Name = "xtraButtonExt5";
            this.xtraButtonExt5.Size = new System.Drawing.Size(151, 57);
            this.xtraButtonExt5.TabIndex = 2;
            this.xtraButtonExt5.Tag = "";
            this.xtraButtonExt5.Text = "PS.2.3 사업계획\r\n수립";
            this.xtraButtonExt5.UseSplasher = false;
            // 
            // xtraButtonExt6
            // 
            this.xtraButtonExt6.IsExecuteWdworkerLog = true;
            this.xtraButtonExt6.Location = new System.Drawing.Point(24, 39);
            this.xtraButtonExt6.Name = "xtraButtonExt6";
            this.xtraButtonExt6.Size = new System.Drawing.Size(151, 57);
            this.xtraButtonExt6.TabIndex = 1;
            this.xtraButtonExt6.Tag = "";
            this.xtraButtonExt6.Text = "PS.3.4 중일정 계획\r\n수립\r\n";
            this.xtraButtonExt6.UseSplasher = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.xtraButtonExt3);
            this.groupBox3.Controls.Add(this.xtraButtonExt4);
            this.groupBox3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox3.Location = new System.Drawing.Point(19, 322);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(365, 134);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Activity 현황";
            // 
            // xtraButtonExt3
            // 
            this.xtraButtonExt3.IsExecuteWdworkerLog = true;
            this.xtraButtonExt3.Location = new System.Drawing.Point(195, 39);
            this.xtraButtonExt3.Name = "xtraButtonExt3";
            this.xtraButtonExt3.Size = new System.Drawing.Size(151, 57);
            this.xtraButtonExt3.TabIndex = 2;
            this.xtraButtonExt3.Tag = "";
            this.xtraButtonExt3.Text = "현황2\r\n(ZPSCR???)";
            this.xtraButtonExt3.UseSplasher = false;
            // 
            // xtraButtonExt4
            // 
            this.xtraButtonExt4.IsExecuteWdworkerLog = true;
            this.xtraButtonExt4.Location = new System.Drawing.Point(24, 39);
            this.xtraButtonExt4.Name = "xtraButtonExt4";
            this.xtraButtonExt4.Size = new System.Drawing.Size(151, 57);
            this.xtraButtonExt4.TabIndex = 1;
            this.xtraButtonExt4.Tag = "";
            this.xtraButtonExt4.Text = "현황1\r\n(ZPSCR???)";
            this.xtraButtonExt4.UseSplasher = false;
            // 
            // pictureEdit1
            // 
            this.pictureEdit1.EditValue = global::HHI.ShipBuilding.UI.WorkFlowManage.Properties.Resources.Icon_화살표다음;
            this.pictureEdit1.Location = new System.Drawing.Point(402, 84);
            this.pictureEdit1.Name = "pictureEdit1";
            this.pictureEdit1.Size = new System.Drawing.Size(46, 33);
            this.pictureEdit1.TabIndex = 4;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.xtraButtonExt2);
            this.groupBox2.Controls.Add(this.xtraButtonExt1);
            this.groupBox2.Controls.Add(this.btn4);
            this.groupBox2.Controls.Add(this.btn3);
            this.groupBox2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox2.Location = new System.Drawing.Point(454, 34);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(365, 235);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "중일정 ACTIVITY 관리";
            // 
            // xtraButtonExt2
            // 
            this.xtraButtonExt2.IsExecuteWdworkerLog = true;
            this.xtraButtonExt2.Location = new System.Drawing.Point(197, 143);
            this.xtraButtonExt2.Name = "xtraButtonExt2";
            this.xtraButtonExt2.Size = new System.Drawing.Size(151, 57);
            this.xtraButtonExt2.TabIndex = 4;
            this.xtraButtonExt2.Tag = "ZPSCO215";
            this.xtraButtonExt2.Text = "중일정 Activity\r\n추가/삭제\r\n(ZPSCO215)";
            this.xtraButtonExt2.UseSplasher = false;
            this.xtraButtonExt2.Click += new System.EventHandler(this.btnSAP_Click);
            // 
            // xtraButtonExt1
            // 
            this.xtraButtonExt1.IsExecuteWdworkerLog = true;
            this.xtraButtonExt1.Location = new System.Drawing.Point(22, 143);
            this.xtraButtonExt1.Name = "xtraButtonExt1";
            this.xtraButtonExt1.Size = new System.Drawing.Size(151, 57);
            this.xtraButtonExt1.TabIndex = 3;
            this.xtraButtonExt1.Tag = "ZPSCO234";
            this.xtraButtonExt1.Text = "중일정 Activity\r\n복사 생성\r\n(ZPSCO234)";
            this.xtraButtonExt1.UseSplasher = false;
            this.xtraButtonExt1.Click += new System.EventHandler(this.btnSAP_Click);
            // 
            // btn4
            // 
            this.btn4.IsExecuteWdworkerLog = true;
            this.btn4.Location = new System.Drawing.Point(197, 39);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(151, 57);
            this.btn4.TabIndex = 2;
            this.btn4.Tag = "ZPSCO204R";
            this.btn4.Text = "공정계역 재반영 시\r\nActivity 추가/삭제\r\n(ZPSCO204R)";
            this.btn4.UseSplasher = false;
            this.btn4.Click += new System.EventHandler(this.btnSAP_Click);
            // 
            // btn3
            // 
            this.btn3.IsExecuteWdworkerLog = true;
            this.btn3.Location = new System.Drawing.Point(22, 39);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(151, 57);
            this.btn3.TabIndex = 1;
            this.btn3.Tag = "ZPSCO231";
            this.btn3.Text = "중일정 Activity \r\n생성\r\n(ZPSCO231)";
            this.btn3.UseSplasher = false;
            this.btn3.Click += new System.EventHandler(this.btnSAP_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn2);
            this.groupBox1.Controls.Add(this.btn1);
            this.groupBox1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.Location = new System.Drawing.Point(19, 34);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(365, 134);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "블록 디비전 관리";
            // 
            // btn2
            // 
            this.btn2.IsExecuteWdworkerLog = true;
            this.btn2.Location = new System.Drawing.Point(195, 39);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(151, 57);
            this.btn2.TabIndex = 2;
            this.btn2.Tag = "ZPSCO201";
            this.btn2.Text = "호선구획정보\r\n작성/변경\r\n(ZPSCO201)";
            this.btn2.UseSplasher = false;
            this.btn2.Click += new System.EventHandler(this.btnSAP_Click);
            // 
            // btn1
            // 
            this.btn1.IsExecuteWdworkerLog = true;
            this.btn1.Location = new System.Drawing.Point(24, 39);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(151, 57);
            this.btn1.TabIndex = 1;
            this.btn1.Tag = "ZPSCO200";
            this.btn1.Text = "Blcok Division\r\n작성/변경\r\n(ZPSCO200)";
            this.btn1.UseSplasher = false;
            this.btn1.Click += new System.EventHandler(this.btnSAP_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "layoutControlGroup1";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup2});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1116, 747);
            this.layoutControlGroup1.Text = "Root";
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.CaptionImage = global::HHI.ShipBuilding.UI.WorkFlowManage.Properties.Resources.Grouup_tit_ico;
            this.layoutControlGroup2.CustomizationFormText = "List";
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem3});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(1096, 727);
            this.layoutControlGroup2.Text = "SAP VIEW";
            this.layoutControlGroup2.TextVisible = false;
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.xtraTabControl1;
            this.layoutControlItem3.CustomizationFormText = "layoutControlItem3";
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(1072, 703);
            this.layoutControlItem3.Text = "layoutControlItem3";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem3.TextToControlDistance = 0;
            this.layoutControlItem3.TextVisible = false;
            // 
            // SCWF000_2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCWF000_2";
            this.Size = new System.Drawing.Size(1116, 747);
            this.Load += new System.EventHandler(this.SCWF000_2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.xtraTabPage1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private System.Windows.Forms.GroupBox groupBox1;
        private Client.Controls.DXperience.XtraButtonExt btn1;
        private Client.Controls.DXperience.XtraButtonExt btn2;
        private System.Windows.Forms.GroupBox groupBox2;
        private Client.Controls.DXperience.XtraButtonExt btn4;
        private Client.Controls.DXperience.XtraButtonExt btn3;
        private System.Windows.Forms.GroupBox groupBox4;
        private Client.Controls.DXperience.XtraButtonExt xtraButtonExt5;
        private Client.Controls.DXperience.XtraButtonExt xtraButtonExt6;
        private System.Windows.Forms.GroupBox groupBox3;
        private Client.Controls.DXperience.XtraButtonExt xtraButtonExt3;
        private Client.Controls.DXperience.XtraButtonExt xtraButtonExt4;
        private DevExpress.XtraEditors.PictureEdit pictureEdit1;
        private Client.Controls.DXperience.XtraButtonExt xtraButtonExt2;
        private Client.Controls.DXperience.XtraButtonExt xtraButtonExt1;
        private Client.Controls.DXperience.XtraButtonExt btn7;
    }
}
