﻿namespace HHI.ShipBuilding.UI.WorkFlowManage
{
    partial class ShapeEditor
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ShapeEditor));
            this.layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            this.cboWKGRP_ID2 = new DevExpress.XtraEditors.ImageComboBoxEdit();
            this.canvas1 = new HHI.ShipBuilding.Shape.Canvas();
            this.btnSave = new DevExpress.XtraEditors.SimpleButton();
            this.btnNew = new DevExpress.XtraEditors.SimpleButton();
            this.btnClose = new DevExpress.XtraEditors.SimpleButton();
            this.txtTitle = new DevExpress.XtraEditors.TextEdit();
            this.navBarControl1 = new DevExpress.XtraNavBar.NavBarControl();
            this.navBarGroup3 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarGroupControlContainer3 = new DevExpress.XtraNavBar.NavBarGroupControlContainer();
            this.layoutControl3 = new DevExpress.XtraLayout.LayoutControl();
            this.txtTCODE = new DevExpress.XtraEditors.TextEdit();
            this.txtDisplayTitle = new DevExpress.XtraEditors.TextEdit();
            this.txtMenuId = new DevExpress.XtraEditors.TextEdit();
            this.cboFontColor = new DevExpress.XtraEditors.ColorEdit();
            this.txtFontSize = new DevExpress.XtraEditors.TextEdit();
            this.cboFontItalic = new DevExpress.XtraEditors.ImageComboBoxEdit();
            this.cboFontBold = new DevExpress.XtraEditors.ImageComboBoxEdit();
            this.cboFontName = new DevExpress.XtraEditors.FontEdit();
            this.txtCANVAS_ID = new DevExpress.XtraEditors.TextEdit();
            this.cboBackColor = new DevExpress.XtraEditors.ImageComboBoxEdit();
            this.cboType = new DevExpress.XtraEditors.ImageComboBoxEdit();
            this.txtSize = new DevExpress.XtraEditors.TextEdit();
            this.txtLocation = new DevExpress.XtraEditors.TextEdit();
            this.cboCANVAS_BCOLOR = new DevExpress.XtraEditors.ColorEdit();
            this.txtCANVAS_SIZE = new DevExpress.XtraEditors.TextEdit();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.simpleSeparator1 = new DevExpress.XtraLayout.SimpleSeparator();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.simpleSeparator2 = new DevExpress.XtraLayout.SimpleSeparator();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem21 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem23 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem24 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem25 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem26 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.simpleSeparator3 = new DevExpress.XtraLayout.SimpleSeparator();
            this.emptySpaceItem6 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem7 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.simpleSeparator4 = new DevExpress.XtraLayout.SimpleSeparator();
            this.layoutControlItem27 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem28 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem29 = new DevExpress.XtraLayout.LayoutControlItem();
            this.navBarGroupControlContainer1 = new DevExpress.XtraNavBar.NavBarGroupControlContainer();
            this.layoutControl2 = new DevExpress.XtraLayout.LayoutControl();
            this.btnLoad = new DevExpress.XtraEditors.SimpleButton();
            this.btnCreateProgram = new DevExpress.XtraEditors.SimpleButton();
            this.cboWKGRP_ID = new DevExpress.XtraEditors.ImageComboBoxEdit();
            this.btnDel = new DevExpress.XtraEditors.SimpleButton();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rcboWRKGRP_ID = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.cboMENU_ID = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem5 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem18 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem22 = new DevExpress.XtraLayout.LayoutControlItem();
            this.navBarGroupControlContainer2 = new DevExpress.XtraNavBar.NavBarGroupControlContainer();
            this.treeList1 = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumn1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.navBarGroup1 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarGroup2 = new DevExpress.XtraNavBar.NavBarGroup();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.splitterItem1 = new DevExpress.XtraLayout.SplitterItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem19 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem20 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem16 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem17 = new DevExpress.XtraLayout.LayoutControlItem();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.imageListGroupArea = new System.Windows.Forms.ImageList(this.components);
            this.imageListItem = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).BeginInit();
            this.layoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboWKGRP_ID2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTitle.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl1)).BeginInit();
            this.navBarControl1.SuspendLayout();
            this.navBarGroupControlContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl3)).BeginInit();
            this.layoutControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTCODE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDisplayTitle.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMenuId.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboFontColor.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFontSize.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboFontItalic.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboFontBold.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboFontName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCANVAS_ID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboBackColor.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboType.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSize.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLocation.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboCANVAS_BCOLOR.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCANVAS_SIZE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem29)).BeginInit();
            this.navBarGroupControlContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl2)).BeginInit();
            this.layoutControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboWKGRP_ID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rcboWRKGRP_ID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboMENU_ID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem22)).BeginInit();
            this.navBarGroupControlContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.treeList1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).BeginInit();
            this.SuspendLayout();
            // 
            // layoutControl1
            // 
            this.layoutControl1.Controls.Add(this.cboWKGRP_ID2);
            this.layoutControl1.Controls.Add(this.canvas1);
            this.layoutControl1.Controls.Add(this.btnSave);
            this.layoutControl1.Controls.Add(this.btnNew);
            this.layoutControl1.Controls.Add(this.btnClose);
            this.layoutControl1.Controls.Add(this.txtTitle);
            this.layoutControl1.Controls.Add(this.navBarControl1);
            this.layoutControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl1.Location = new System.Drawing.Point(0, 0);
            this.layoutControl1.Name = "layoutControl1";
            this.layoutControl1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(907, 235, 250, 350);
            this.layoutControl1.Root = this.layoutControlGroup1;
            this.layoutControl1.Size = new System.Drawing.Size(936, 763);
            this.layoutControl1.TabIndex = 0;
            this.layoutControl1.Text = "layoutControl1";
            // 
            // cboWKGRP_ID2
            // 
            this.cboWKGRP_ID2.Location = new System.Drawing.Point(280, 12);
            this.cboWKGRP_ID2.Name = "cboWKGRP_ID2";
            this.cboWKGRP_ID2.Properties.Appearance.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold);
            this.cboWKGRP_ID2.Properties.Appearance.Options.UseFont = true;
            this.cboWKGRP_ID2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboWKGRP_ID2.Size = new System.Drawing.Size(102, 26);
            this.cboWKGRP_ID2.StyleController = this.layoutControl1;
            this.cboWKGRP_ID2.TabIndex = 11;
            // 
            // canvas1
            // 
            this.canvas1.AllowDrop = true;
            this.canvas1.AutoScroll = true;
            this.canvas1.BackColor = System.Drawing.Color.White;
            this.canvas1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.canvas1.CANVAS_ID = null;
            this.canvas1.DESCRIPTION = null;
            this.canvas1.EXTRA1 = null;
            this.canvas1.FONT_DESC = null;
            this.canvas1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.canvas1.Location = new System.Drawing.Point(192, 42);
            this.canvas1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.canvas1.Name = "canvas1";
            this.canvas1.P_SHAPE_ID = null;
            this.canvas1.RES_NAME = null;
            this.canvas1.SHAPE_ID = null;
            this.canvas1.SHAPE_LOC = "";
            this.canvas1.SHAPE_SIZE = "{Width=100, Height=100}";
            this.canvas1.Size = new System.Drawing.Size(732, 709);
            this.canvas1.SOURCE_ID = null;
            this.canvas1.TabIndex = 10;
            this.canvas1.TYPE_ENTITY = 0;
            this.canvas1.TYPE_SHAPE = 0;
            // 
            // btnSave
            // 
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.Location = new System.Drawing.Point(785, 12);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(66, 26);
            this.btnSave.StyleController = this.layoutControl1;
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "저장";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnNew
            // 
            this.btnNew.Image = ((System.Drawing.Image)(resources.GetObject("btnNew.Image")));
            this.btnNew.Location = new System.Drawing.Point(713, 12);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(68, 26);
            this.btnNew.StyleController = this.layoutControl1;
            this.btnNew.TabIndex = 8;
            this.btnNew.Text = "신규";
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnClose
            // 
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(855, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(69, 26);
            this.btnClose.StyleController = this.layoutControl1;
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "닫기";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(508, 12);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Properties.Appearance.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtTitle.Properties.Appearance.Options.UseFont = true;
            this.txtTitle.Size = new System.Drawing.Size(201, 26);
            this.txtTitle.StyleController = this.layoutControl1;
            this.txtTitle.TabIndex = 5;
            // 
            // navBarControl1
            // 
            this.navBarControl1.ActiveGroup = this.navBarGroup3;
            this.navBarControl1.Controls.Add(this.navBarGroupControlContainer1);
            this.navBarControl1.Controls.Add(this.navBarGroupControlContainer2);
            this.navBarControl1.Controls.Add(this.navBarGroupControlContainer3);
            this.navBarControl1.Groups.AddRange(new DevExpress.XtraNavBar.NavBarGroup[] {
            this.navBarGroup1,
            this.navBarGroup2,
            this.navBarGroup3});
            this.navBarControl1.Location = new System.Drawing.Point(12, 12);
            this.navBarControl1.Name = "navBarControl1";
            this.navBarControl1.OptionsNavPane.ExpandedWidth = 171;
            this.navBarControl1.Size = new System.Drawing.Size(171, 739);
            this.navBarControl1.TabIndex = 4;
            this.navBarControl1.Text = "navBarControl1";
            this.navBarControl1.View = new DevExpress.XtraNavBar.ViewInfo.StandardSkinNavigationPaneViewInfoRegistrator("Office 2013");
            // 
            // navBarGroup3
            // 
            this.navBarGroup3.Caption = "Shape 속성";
            this.navBarGroup3.ControlContainer = this.navBarGroupControlContainer3;
            this.navBarGroup3.Expanded = true;
            this.navBarGroup3.GroupClientHeight = 287;
            this.navBarGroup3.GroupStyle = DevExpress.XtraNavBar.NavBarGroupStyle.ControlContainer;
            this.navBarGroup3.LargeImage = ((System.Drawing.Image)(resources.GetObject("navBarGroup3.LargeImage")));
            this.navBarGroup3.Name = "navBarGroup3";
            this.navBarGroup3.SmallImage = ((System.Drawing.Image)(resources.GetObject("navBarGroup3.SmallImage")));
            // 
            // navBarGroupControlContainer3
            // 
            this.navBarGroupControlContainer3.Appearance.BackColor = System.Drawing.SystemColors.Control;
            this.navBarGroupControlContainer3.Appearance.Options.UseBackColor = true;
            this.navBarGroupControlContainer3.Controls.Add(this.layoutControl3);
            this.navBarGroupControlContainer3.Name = "navBarGroupControlContainer3";
            this.navBarGroupControlContainer3.Size = new System.Drawing.Size(171, 548);
            this.navBarGroupControlContainer3.TabIndex = 2;
            // 
            // layoutControl3
            // 
            this.layoutControl3.Controls.Add(this.txtTCODE);
            this.layoutControl3.Controls.Add(this.txtDisplayTitle);
            this.layoutControl3.Controls.Add(this.txtMenuId);
            this.layoutControl3.Controls.Add(this.cboFontColor);
            this.layoutControl3.Controls.Add(this.txtFontSize);
            this.layoutControl3.Controls.Add(this.cboFontItalic);
            this.layoutControl3.Controls.Add(this.cboFontBold);
            this.layoutControl3.Controls.Add(this.cboFontName);
            this.layoutControl3.Controls.Add(this.txtCANVAS_ID);
            this.layoutControl3.Controls.Add(this.cboBackColor);
            this.layoutControl3.Controls.Add(this.cboType);
            this.layoutControl3.Controls.Add(this.txtSize);
            this.layoutControl3.Controls.Add(this.txtLocation);
            this.layoutControl3.Controls.Add(this.cboCANVAS_BCOLOR);
            this.layoutControl3.Controls.Add(this.txtCANVAS_SIZE);
            this.layoutControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl3.Location = new System.Drawing.Point(0, 0);
            this.layoutControl3.Name = "layoutControl3";
            this.layoutControl3.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(559, 100, 250, 350);
            this.layoutControl3.Root = this.layoutControlGroup3;
            this.layoutControl3.Size = new System.Drawing.Size(171, 548);
            this.layoutControl3.TabIndex = 0;
            this.layoutControl3.Text = "layoutControl3";
            // 
            // txtTCODE
            // 
            this.txtTCODE.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.txtTCODE.Location = new System.Drawing.Point(108, 474);
            this.txtTCODE.Name = "txtTCODE";
            this.txtTCODE.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTCODE.Properties.Mask.EditMask = "[A-Z0-9]+";
            this.txtTCODE.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx;
            this.txtTCODE.Properties.ReadOnly = true;
            this.txtTCODE.Properties.ValidateOnEnterKey = true;
            this.txtTCODE.Properties.Validating += new System.ComponentModel.CancelEventHandler(this.txtTCODE_Properties_Validating);
            this.txtTCODE.Size = new System.Drawing.Size(51, 20);
            this.txtTCODE.StyleController = this.layoutControl3;
            this.txtTCODE.TabIndex = 19;
            // 
            // txtDisplayTitle
            // 
            this.txtDisplayTitle.Location = new System.Drawing.Point(108, 450);
            this.txtDisplayTitle.Name = "txtDisplayTitle";
            this.txtDisplayTitle.Properties.ReadOnly = true;
            this.txtDisplayTitle.Size = new System.Drawing.Size(51, 20);
            this.txtDisplayTitle.StyleController = this.layoutControl3;
            this.txtDisplayTitle.TabIndex = 18;
            // 
            // txtMenuId
            // 
            this.txtMenuId.Location = new System.Drawing.Point(108, 426);
            this.txtMenuId.Name = "txtMenuId";
            this.txtMenuId.Properties.ReadOnly = true;
            this.txtMenuId.Size = new System.Drawing.Size(51, 20);
            this.txtMenuId.StyleController = this.layoutControl3;
            this.txtMenuId.TabIndex = 17;
            // 
            // cboFontColor
            // 
            this.cboFontColor.EditValue = System.Drawing.Color.Empty;
            this.cboFontColor.Location = new System.Drawing.Point(108, 373);
            this.cboFontColor.Name = "cboFontColor";
            this.cboFontColor.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboFontColor.Size = new System.Drawing.Size(51, 20);
            this.cboFontColor.StyleController = this.layoutControl3;
            this.cboFontColor.TabIndex = 16;
            this.cboFontColor.EditValueChanged += new System.EventHandler(this.cboFontColor_EditValueChanged);
            // 
            // txtFontSize
            // 
            this.txtFontSize.Location = new System.Drawing.Point(108, 349);
            this.txtFontSize.Name = "txtFontSize";
            this.txtFontSize.Properties.Mask.EditMask = "\\d{1,2}(\\d{1,2}.\\d{1,2})?";
            this.txtFontSize.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx;
            this.txtFontSize.Properties.Mask.ShowPlaceHolders = false;
            this.txtFontSize.Properties.MaxLength = 5;
            this.txtFontSize.Properties.ValidateOnEnterKey = true;
            this.txtFontSize.Properties.Validating += new System.ComponentModel.CancelEventHandler(this.txtFontSize_Properties_Validating);
            this.txtFontSize.Size = new System.Drawing.Size(51, 20);
            this.txtFontSize.StyleController = this.layoutControl3;
            this.txtFontSize.TabIndex = 15;
            // 
            // cboFontItalic
            // 
            this.cboFontItalic.Location = new System.Drawing.Point(108, 325);
            this.cboFontItalic.Name = "cboFontItalic";
            this.cboFontItalic.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboFontItalic.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.ImageComboBoxItem[] {
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("True", true, -1),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("False", false, -1)});
            this.cboFontItalic.Size = new System.Drawing.Size(51, 20);
            this.cboFontItalic.StyleController = this.layoutControl3;
            this.cboFontItalic.TabIndex = 14;
            this.cboFontItalic.EditValueChanged += new System.EventHandler(this.cboFontItalic_EditValueChanged);
            // 
            // cboFontBold
            // 
            this.cboFontBold.Location = new System.Drawing.Point(108, 301);
            this.cboFontBold.Name = "cboFontBold";
            this.cboFontBold.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboFontBold.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.ImageComboBoxItem[] {
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("True", true, -1),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("False", false, -1)});
            this.cboFontBold.Size = new System.Drawing.Size(51, 20);
            this.cboFontBold.StyleController = this.layoutControl3;
            this.cboFontBold.TabIndex = 13;
            this.cboFontBold.EditValueChanged += new System.EventHandler(this.cboFontBold_EditValueChanged);
            // 
            // cboFontName
            // 
            this.cboFontName.Location = new System.Drawing.Point(108, 277);
            this.cboFontName.Name = "cboFontName";
            this.cboFontName.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboFontName.Size = new System.Drawing.Size(51, 20);
            this.cboFontName.StyleController = this.layoutControl3;
            this.cboFontName.TabIndex = 12;
            this.cboFontName.EditValueChanged += new System.EventHandler(this.cboFontName_EditValueChanged);
            // 
            // txtCANVAS_ID
            // 
            this.txtCANVAS_ID.Location = new System.Drawing.Point(108, 49);
            this.txtCANVAS_ID.Name = "txtCANVAS_ID";
            this.txtCANVAS_ID.Properties.ReadOnly = true;
            this.txtCANVAS_ID.Size = new System.Drawing.Size(51, 20);
            this.txtCANVAS_ID.StyleController = this.layoutControl3;
            this.txtCANVAS_ID.TabIndex = 11;
            // 
            // cboBackColor
            // 
            this.cboBackColor.Location = new System.Drawing.Point(108, 230);
            this.cboBackColor.Name = "cboBackColor";
            this.cboBackColor.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboBackColor.Size = new System.Drawing.Size(51, 20);
            this.cboBackColor.StyleController = this.layoutControl3;
            this.cboBackColor.TabIndex = 9;
            this.cboBackColor.EditValueChanged += new System.EventHandler(this.cboBackColor_EditValueChanged);
            // 
            // cboType
            // 
            this.cboType.Location = new System.Drawing.Point(108, 206);
            this.cboType.Name = "cboType";
            this.cboType.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboType.Size = new System.Drawing.Size(51, 20);
            this.cboType.StyleController = this.layoutControl3;
            this.cboType.TabIndex = 8;
            this.cboType.EditValueChanged += new System.EventHandler(this.cboType_EditValueChanged);
            // 
            // txtSize
            // 
            this.txtSize.Location = new System.Drawing.Point(108, 182);
            this.txtSize.Name = "txtSize";
            this.txtSize.Properties.ReadOnly = true;
            this.txtSize.Size = new System.Drawing.Size(51, 20);
            this.txtSize.StyleController = this.layoutControl3;
            this.txtSize.TabIndex = 7;
            // 
            // txtLocation
            // 
            this.txtLocation.Location = new System.Drawing.Point(108, 158);
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.Properties.ReadOnly = true;
            this.txtLocation.Size = new System.Drawing.Size(51, 20);
            this.txtLocation.StyleController = this.layoutControl3;
            this.txtLocation.TabIndex = 6;
            // 
            // cboCANVAS_BCOLOR
            // 
            this.cboCANVAS_BCOLOR.EditValue = System.Drawing.Color.Empty;
            this.cboCANVAS_BCOLOR.Location = new System.Drawing.Point(108, 97);
            this.cboCANVAS_BCOLOR.Name = "cboCANVAS_BCOLOR";
            this.cboCANVAS_BCOLOR.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboCANVAS_BCOLOR.Size = new System.Drawing.Size(51, 20);
            this.cboCANVAS_BCOLOR.StyleController = this.layoutControl3;
            this.cboCANVAS_BCOLOR.TabIndex = 5;
            this.cboCANVAS_BCOLOR.EditValueChanged += new System.EventHandler(this.cboCANVAS_BCOLOR_EditValueChanged);
            // 
            // txtCANVAS_SIZE
            // 
            this.txtCANVAS_SIZE.Location = new System.Drawing.Point(108, 73);
            this.txtCANVAS_SIZE.Name = "txtCANVAS_SIZE";
            this.txtCANVAS_SIZE.Properties.ReadOnly = true;
            this.txtCANVAS_SIZE.Size = new System.Drawing.Size(51, 20);
            this.txtCANVAS_SIZE.StyleController = this.layoutControl3;
            this.txtCANVAS_SIZE.TabIndex = 4;
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup3.GroupBordersVisible = false;
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem7,
            this.layoutControlItem8,
            this.emptySpaceItem1,
            this.simpleSeparator1,
            this.emptySpaceItem4,
            this.layoutControlItem9,
            this.layoutControlItem10,
            this.layoutControlItem11,
            this.simpleSeparator2,
            this.layoutControlItem12,
            this.layoutControlItem21,
            this.layoutControlItem23,
            this.layoutControlItem24,
            this.layoutControlItem25,
            this.layoutControlItem26,
            this.emptySpaceItem3,
            this.simpleSeparator3,
            this.emptySpaceItem6,
            this.layoutControlItem13,
            this.emptySpaceItem7,
            this.simpleSeparator4,
            this.layoutControlItem27,
            this.layoutControlItem28,
            this.layoutControlItem29});
            this.layoutControlGroup3.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup3.Name = "Root";
            this.layoutControlGroup3.Size = new System.Drawing.Size(171, 548);
            this.layoutControlGroup3.TextVisible = false;
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem7.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem7.Control = this.txtCANVAS_SIZE;
            this.layoutControlItem7.Location = new System.Drawing.Point(0, 61);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(151, 24);
            this.layoutControlItem7.Text = "Canvas Size";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(93, 14);
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem8.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem8.Control = this.cboCANVAS_BCOLOR;
            this.layoutControlItem8.Location = new System.Drawing.Point(0, 85);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(151, 24);
            this.layoutControlItem8.Text = "Canvas BackColor";
            this.layoutControlItem8.TextSize = new System.Drawing.Size(93, 14);
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.emptySpaceItem1.AppearanceItemCaption.Options.UseFont = true;
            this.emptySpaceItem1.Image = ((System.Drawing.Image)(resources.GetObject("emptySpaceItem1.Image")));
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 111);
            this.emptySpaceItem1.MaxSize = new System.Drawing.Size(0, 35);
            this.emptySpaceItem1.MinSize = new System.Drawing.Size(1, 35);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(151, 35);
            this.emptySpaceItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem1.Text = "Selected Shape Attributes";
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(93, 0);
            this.emptySpaceItem1.TextVisible = true;
            // 
            // simpleSeparator1
            // 
            this.simpleSeparator1.AllowHotTrack = false;
            this.simpleSeparator1.Location = new System.Drawing.Point(0, 109);
            this.simpleSeparator1.Name = "simpleSeparator1";
            this.simpleSeparator1.Size = new System.Drawing.Size(151, 2);
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.emptySpaceItem4.AppearanceItemCaption.Options.UseFont = true;
            this.emptySpaceItem4.Image = ((System.Drawing.Image)(resources.GetObject("emptySpaceItem4.Image")));
            this.emptySpaceItem4.Location = new System.Drawing.Point(0, 2);
            this.emptySpaceItem4.MaxSize = new System.Drawing.Size(0, 35);
            this.emptySpaceItem4.MinSize = new System.Drawing.Size(1, 35);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(151, 35);
            this.emptySpaceItem4.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem4.Text = "Canvas Info.";
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(93, 0);
            this.emptySpaceItem4.TextVisible = true;
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem9.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem9.Control = this.txtLocation;
            this.layoutControlItem9.Location = new System.Drawing.Point(0, 146);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(151, 24);
            this.layoutControlItem9.Text = "Location";
            this.layoutControlItem9.TextSize = new System.Drawing.Size(93, 14);
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem10.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem10.Control = this.txtSize;
            this.layoutControlItem10.Location = new System.Drawing.Point(0, 170);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(151, 24);
            this.layoutControlItem10.Text = "Size";
            this.layoutControlItem10.TextSize = new System.Drawing.Size(93, 14);
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem11.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem11.Control = this.cboType;
            this.layoutControlItem11.Location = new System.Drawing.Point(0, 194);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(151, 24);
            this.layoutControlItem11.Text = "Types";
            this.layoutControlItem11.TextSize = new System.Drawing.Size(93, 14);
            // 
            // simpleSeparator2
            // 
            this.simpleSeparator2.AllowHotTrack = false;
            this.simpleSeparator2.Location = new System.Drawing.Point(0, 0);
            this.simpleSeparator2.Name = "simpleSeparator2";
            this.simpleSeparator2.Size = new System.Drawing.Size(151, 2);
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem12.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem12.Control = this.cboBackColor;
            this.layoutControlItem12.Location = new System.Drawing.Point(0, 218);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(151, 24);
            this.layoutControlItem12.Text = "Back Color";
            this.layoutControlItem12.TextSize = new System.Drawing.Size(93, 14);
            // 
            // layoutControlItem21
            // 
            this.layoutControlItem21.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem21.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem21.Control = this.txtCANVAS_ID;
            this.layoutControlItem21.Location = new System.Drawing.Point(0, 37);
            this.layoutControlItem21.Name = "layoutControlItem21";
            this.layoutControlItem21.Size = new System.Drawing.Size(151, 24);
            this.layoutControlItem21.Text = "CANVAS ID";
            this.layoutControlItem21.TextSize = new System.Drawing.Size(93, 14);
            // 
            // layoutControlItem23
            // 
            this.layoutControlItem23.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem23.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem23.Control = this.cboFontName;
            this.layoutControlItem23.Location = new System.Drawing.Point(0, 265);
            this.layoutControlItem23.Name = "layoutControlItem23";
            this.layoutControlItem23.Size = new System.Drawing.Size(151, 24);
            this.layoutControlItem23.Text = "Name";
            this.layoutControlItem23.TextLocation = DevExpress.Utils.Locations.Left;
            this.layoutControlItem23.TextSize = new System.Drawing.Size(93, 14);
            // 
            // layoutControlItem24
            // 
            this.layoutControlItem24.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem24.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem24.Control = this.cboFontBold;
            this.layoutControlItem24.Location = new System.Drawing.Point(0, 289);
            this.layoutControlItem24.Name = "layoutControlItem24";
            this.layoutControlItem24.Size = new System.Drawing.Size(151, 24);
            this.layoutControlItem24.Text = "Bold";
            this.layoutControlItem24.TextSize = new System.Drawing.Size(93, 14);
            // 
            // layoutControlItem25
            // 
            this.layoutControlItem25.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem25.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem25.Control = this.cboFontItalic;
            this.layoutControlItem25.Location = new System.Drawing.Point(0, 313);
            this.layoutControlItem25.Name = "layoutControlItem25";
            this.layoutControlItem25.Size = new System.Drawing.Size(151, 24);
            this.layoutControlItem25.Text = "Italic";
            this.layoutControlItem25.TextSize = new System.Drawing.Size(93, 14);
            // 
            // layoutControlItem26
            // 
            this.layoutControlItem26.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem26.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem26.Control = this.txtFontSize;
            this.layoutControlItem26.Location = new System.Drawing.Point(0, 337);
            this.layoutControlItem26.Name = "layoutControlItem26";
            this.layoutControlItem26.Size = new System.Drawing.Size(151, 24);
            this.layoutControlItem26.Text = "Size";
            this.layoutControlItem26.TextSize = new System.Drawing.Size(93, 14);
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.emptySpaceItem3.AppearanceItemCaption.Options.UseFont = true;
            this.emptySpaceItem3.ControlAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.emptySpaceItem3.Image = ((System.Drawing.Image)(resources.GetObject("emptySpaceItem3.Image")));
            this.emptySpaceItem3.Location = new System.Drawing.Point(0, 244);
            this.emptySpaceItem3.MaxSize = new System.Drawing.Size(0, 21);
            this.emptySpaceItem3.MinSize = new System.Drawing.Size(10, 21);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(151, 21);
            this.emptySpaceItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem3.Spacing = new DevExpress.XtraLayout.Utils.Padding(21, 0, 0, 0);
            this.emptySpaceItem3.Text = "Font";
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(93, 0);
            this.emptySpaceItem3.TextVisible = true;
            // 
            // simpleSeparator3
            // 
            this.simpleSeparator3.AllowHotTrack = false;
            this.simpleSeparator3.Location = new System.Drawing.Point(0, 242);
            this.simpleSeparator3.Name = "simpleSeparator3";
            this.simpleSeparator3.Size = new System.Drawing.Size(151, 2);
            // 
            // emptySpaceItem6
            // 
            this.emptySpaceItem6.AllowHotTrack = false;
            this.emptySpaceItem6.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.emptySpaceItem6.AppearanceItemCaption.Options.UseFont = true;
            this.emptySpaceItem6.Image = ((System.Drawing.Image)(resources.GetObject("emptySpaceItem6.Image")));
            this.emptySpaceItem6.Location = new System.Drawing.Point(0, 387);
            this.emptySpaceItem6.MinSize = new System.Drawing.Size(104, 24);
            this.emptySpaceItem6.Name = "emptySpaceItem6";
            this.emptySpaceItem6.Size = new System.Drawing.Size(151, 27);
            this.emptySpaceItem6.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem6.Text = "Original Menu Infomation";
            this.emptySpaceItem6.TextSize = new System.Drawing.Size(93, 0);
            this.emptySpaceItem6.TextVisible = true;
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem13.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem13.Control = this.cboFontColor;
            this.layoutControlItem13.Location = new System.Drawing.Point(0, 361);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(151, 24);
            this.layoutControlItem13.Text = "Color";
            this.layoutControlItem13.TextSize = new System.Drawing.Size(93, 14);
            // 
            // emptySpaceItem7
            // 
            this.emptySpaceItem7.AllowHotTrack = false;
            this.emptySpaceItem7.Location = new System.Drawing.Point(0, 486);
            this.emptySpaceItem7.Name = "emptySpaceItem7";
            this.emptySpaceItem7.Size = new System.Drawing.Size(151, 42);
            this.emptySpaceItem7.TextSize = new System.Drawing.Size(0, 0);
            // 
            // simpleSeparator4
            // 
            this.simpleSeparator4.AllowHotTrack = false;
            this.simpleSeparator4.Location = new System.Drawing.Point(0, 385);
            this.simpleSeparator4.Name = "simpleSeparator4";
            this.simpleSeparator4.Size = new System.Drawing.Size(151, 2);
            // 
            // layoutControlItem27
            // 
            this.layoutControlItem27.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem27.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem27.Control = this.txtMenuId;
            this.layoutControlItem27.Location = new System.Drawing.Point(0, 414);
            this.layoutControlItem27.Name = "layoutControlItem27";
            this.layoutControlItem27.Size = new System.Drawing.Size(151, 24);
            this.layoutControlItem27.Text = "Menu ID";
            this.layoutControlItem27.TextSize = new System.Drawing.Size(93, 14);
            // 
            // layoutControlItem28
            // 
            this.layoutControlItem28.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem28.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem28.Control = this.txtDisplayTitle;
            this.layoutControlItem28.Location = new System.Drawing.Point(0, 438);
            this.layoutControlItem28.Name = "layoutControlItem28";
            this.layoutControlItem28.Size = new System.Drawing.Size(151, 24);
            this.layoutControlItem28.Text = "Display Title";
            this.layoutControlItem28.TextSize = new System.Drawing.Size(93, 14);
            // 
            // layoutControlItem29
            // 
            this.layoutControlItem29.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem29.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem29.Control = this.txtTCODE;
            this.layoutControlItem29.Location = new System.Drawing.Point(0, 462);
            this.layoutControlItem29.Name = "layoutControlItem29";
            this.layoutControlItem29.Size = new System.Drawing.Size(151, 24);
            this.layoutControlItem29.Text = "TCODE";
            this.layoutControlItem29.TextSize = new System.Drawing.Size(93, 14);
            // 
            // navBarGroupControlContainer1
            // 
            this.navBarGroupControlContainer1.Appearance.BackColor = System.Drawing.SystemColors.Control;
            this.navBarGroupControlContainer1.Appearance.Options.UseBackColor = true;
            this.navBarGroupControlContainer1.Controls.Add(this.layoutControl2);
            this.navBarGroupControlContainer1.Name = "navBarGroupControlContainer1";
            this.navBarGroupControlContainer1.Size = new System.Drawing.Size(203, 322);
            this.navBarGroupControlContainer1.TabIndex = 0;
            // 
            // layoutControl2
            // 
            this.layoutControl2.Controls.Add(this.btnLoad);
            this.layoutControl2.Controls.Add(this.btnCreateProgram);
            this.layoutControl2.Controls.Add(this.cboWKGRP_ID);
            this.layoutControl2.Controls.Add(this.btnDel);
            this.layoutControl2.Controls.Add(this.gridControl1);
            this.layoutControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl2.HiddenItems.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem3,
            this.layoutControlItem2});
            this.layoutControl2.Location = new System.Drawing.Point(0, 0);
            this.layoutControl2.Name = "layoutControl2";
            this.layoutControl2.Root = this.layoutControlGroup2;
            this.layoutControl2.Size = new System.Drawing.Size(203, 322);
            this.layoutControl2.TabIndex = 0;
            this.layoutControl2.Text = "layoutControl2";
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(51, 2);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(59, 22);
            this.btnLoad.StyleController = this.layoutControl2;
            this.btnLoad.TabIndex = 13;
            this.btnLoad.Text = "불러오기";
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnCreateProgram
            // 
            this.btnCreateProgram.Location = new System.Drawing.Point(114, 2);
            this.btnCreateProgram.Name = "btnCreateProgram";
            this.btnCreateProgram.Size = new System.Drawing.Size(87, 22);
            this.btnCreateProgram.StyleController = this.layoutControl2;
            this.btnCreateProgram.TabIndex = 12;
            this.btnCreateProgram.Text = "프로그램 생성";
            this.btnCreateProgram.Click += new System.EventHandler(this.btnCreateProgram_Click);
            // 
            // cboWKGRP_ID
            // 
            this.cboWKGRP_ID.Location = new System.Drawing.Point(57, 28);
            this.cboWKGRP_ID.Name = "cboWKGRP_ID";
            this.cboWKGRP_ID.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboWKGRP_ID.Size = new System.Drawing.Size(123, 20);
            this.cboWKGRP_ID.StyleController = this.layoutControl2;
            this.cboWKGRP_ID.TabIndex = 11;
            this.cboWKGRP_ID.EditValueChanged += new System.EventHandler(this.cboWKGRP_ID_EditValueChanged);
            // 
            // btnDel
            // 
            this.btnDel.Location = new System.Drawing.Point(12, 2);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(35, 22);
            this.btnDel.StyleController = this.layoutControl2;
            this.btnDel.TabIndex = 8;
            this.btnDel.Text = "삭제";
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // gridControl1
            // 
            this.gridControl1.Location = new System.Drawing.Point(2, 52);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rcboWRKGRP_ID,
            this.cboMENU_ID});
            this.gridControl1.Size = new System.Drawing.Size(199, 268);
            this.gridControl1.TabIndex = 6;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn3,
            this.gridColumn2,
            this.gridColumn5,
            this.gridColumn1,
            this.gridColumn4});
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.Editable = false;
            this.gridView1.OptionsSelection.CheckBoxSelectorColumnWidth = 30;
            this.gridView1.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView1.OptionsSelection.ResetSelectionClickOutsideCheckboxSelector = true;
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            this.gridView1.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.Never;
            this.gridView1.OptionsView.ShowGroupExpandCollapseButtons = false;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "작업 그룹";
            this.gridColumn3.ColumnEdit = this.rcboWRKGRP_ID;
            this.gridColumn3.FieldName = "WKGRP_ID";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 0;
            this.gridColumn3.Width = 80;
            // 
            // rcboWRKGRP_ID
            // 
            this.rcboWRKGRP_ID.AutoHeight = false;
            this.rcboWRKGRP_ID.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rcboWRKGRP_ID.Name = "rcboWRKGRP_ID";
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "작업명";
            this.gridColumn2.FieldName = "TITLE";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            this.gridColumn2.Width = 100;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "PROGRAM ID";
            this.gridColumn5.FieldName = "PROGRAM_ID";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 2;
            this.gridColumn5.Width = 80;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "최초 작성자";
            this.gridColumn1.FieldName = "IUSER";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 3;
            this.gridColumn1.Width = 100;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "최종 수정자";
            this.gridColumn4.FieldName = "UUSER";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 4;
            this.gridColumn4.Width = 100;
            // 
            // cboMENU_ID
            // 
            this.cboMENU_ID.AutoHeight = false;
            this.cboMENU_ID.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboMENU_ID.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("MENU_ID", 80, "메뉴 ID"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("DISPLAY_TITLE", 150, "메뉴 명")});
            this.cboMENU_ID.Name = "cboMENU_ID";
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(0, 0);
            this.layoutControlItem3.TextSize = new System.Drawing.Size(50, 20);
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextSize = new System.Drawing.Size(50, 20);
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup2.GroupBordersVisible = false;
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem4,
            this.emptySpaceItem5,
            this.layoutControlItem18,
            this.emptySpaceItem2,
            this.layoutControlItem15,
            this.layoutControlItem14,
            this.layoutControlItem22});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlGroup2.Size = new System.Drawing.Size(203, 322);
            this.layoutControlGroup2.TextVisible = false;
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.gridControl1;
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 50);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(203, 272);
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextVisible = false;
            // 
            // emptySpaceItem5
            // 
            this.emptySpaceItem5.AllowHotTrack = false;
            this.emptySpaceItem5.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem5.Name = "emptySpaceItem5";
            this.emptySpaceItem5.Size = new System.Drawing.Size(10, 26);
            this.emptySpaceItem5.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem18
            // 
            this.layoutControlItem18.Control = this.cboWKGRP_ID;
            this.layoutControlItem18.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem18.Name = "layoutControlItem18";
            this.layoutControlItem18.Size = new System.Drawing.Size(182, 24);
            this.layoutControlItem18.Text = "작업 그룹";
            this.layoutControlItem18.TextSize = new System.Drawing.Size(52, 14);
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.Location = new System.Drawing.Point(182, 26);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(21, 24);
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.Control = this.btnDel;
            this.layoutControlItem15.Location = new System.Drawing.Point(10, 0);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.Size = new System.Drawing.Size(39, 26);
            this.layoutControlItem15.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem15.TextVisible = false;
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.btnCreateProgram;
            this.layoutControlItem14.Location = new System.Drawing.Point(112, 0);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Size = new System.Drawing.Size(91, 26);
            this.layoutControlItem14.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem14.TextVisible = false;
            // 
            // layoutControlItem22
            // 
            this.layoutControlItem22.Control = this.btnLoad;
            this.layoutControlItem22.Location = new System.Drawing.Point(49, 0);
            this.layoutControlItem22.Name = "layoutControlItem22";
            this.layoutControlItem22.Size = new System.Drawing.Size(63, 26);
            this.layoutControlItem22.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem22.TextVisible = false;
            // 
            // navBarGroupControlContainer2
            // 
            this.navBarGroupControlContainer2.Appearance.BackColor = System.Drawing.SystemColors.Control;
            this.navBarGroupControlContainer2.Appearance.Options.UseBackColor = true;
            this.navBarGroupControlContainer2.Controls.Add(this.treeList1);
            this.navBarGroupControlContainer2.Name = "navBarGroupControlContainer2";
            this.navBarGroupControlContainer2.Size = new System.Drawing.Size(191, 322);
            this.navBarGroupControlContainer2.TabIndex = 1;
            // 
            // treeList1
            // 
            this.treeList1.AllowDrop = true;
            this.treeList1.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn1});
            this.treeList1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeList1.KeyFieldName = "MENU_ID";
            this.treeList1.Location = new System.Drawing.Point(0, 0);
            this.treeList1.Name = "treeList1";
            this.treeList1.OptionsDragAndDrop.DragNodesMode = DevExpress.XtraTreeList.DragNodesMode.Multiple;
            this.treeList1.OptionsBehavior.Editable = false;
            this.treeList1.OptionsLayout.AddNewColumns = false;
            this.treeList1.OptionsView.ShowColumns = false;
            this.treeList1.OptionsView.ShowHorzLines = false;
            this.treeList1.OptionsView.ShowVertLines = false;
            this.treeList1.ParentFieldName = "PARENT_ID";
            this.treeList1.Size = new System.Drawing.Size(191, 322);
            this.treeList1.TabIndex = 0;
            this.treeList1.FocusedNodeChanged += new DevExpress.XtraTreeList.FocusedNodeChangedEventHandler(this.treeList1_FocusedNodeChanged);
            this.treeList1.DragDrop += new System.Windows.Forms.DragEventHandler(this.treeList1_DragDrop);
            this.treeList1.DragOver += new System.Windows.Forms.DragEventHandler(this.treeList1_DragOver);
            this.treeList1.GiveFeedback += new System.Windows.Forms.GiveFeedbackEventHandler(this.treeList1_GiveFeedback);
            // 
            // treeListColumn1
            // 
            this.treeListColumn1.Caption = "메뉴명";
            this.treeListColumn1.FieldName = "DISPLAY_TITLE";
            this.treeListColumn1.Name = "treeListColumn1";
            this.treeListColumn1.Visible = true;
            this.treeListColumn1.VisibleIndex = 0;
            // 
            // navBarGroup1
            // 
            this.navBarGroup1.Caption = "워크플로우 메뉴";
            this.navBarGroup1.ControlContainer = this.navBarGroupControlContainer1;
            this.navBarGroup1.GroupClientHeight = 288;
            this.navBarGroup1.GroupStyle = DevExpress.XtraNavBar.NavBarGroupStyle.ControlContainer;
            this.navBarGroup1.LargeImage = ((System.Drawing.Image)(resources.GetObject("navBarGroup1.LargeImage")));
            this.navBarGroup1.Name = "navBarGroup1";
            this.navBarGroup1.SmallImage = ((System.Drawing.Image)(resources.GetObject("navBarGroup1.SmallImage")));
            // 
            // navBarGroup2
            // 
            this.navBarGroup2.Caption = "통합 메뉴";
            this.navBarGroup2.ControlContainer = this.navBarGroupControlContainer2;
            this.navBarGroup2.GroupClientHeight = 288;
            this.navBarGroup2.GroupStyle = DevExpress.XtraNavBar.NavBarGroupStyle.ControlContainer;
            this.navBarGroup2.LargeImage = ((System.Drawing.Image)(resources.GetObject("navBarGroup2.LargeImage")));
            this.navBarGroup2.Name = "navBarGroup2";
            this.navBarGroup2.SmallImage = ((System.Drawing.Image)(resources.GetObject("navBarGroup2.SmallImage")));
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.splitterItem1,
            this.layoutControlItem5,
            this.layoutControlItem19,
            this.layoutControlItem20,
            this.layoutControlItem16,
            this.layoutControlItem6,
            this.layoutControlItem17});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(936, 763);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.navBarControl1;
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(175, 743);
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // splitterItem1
            // 
            this.splitterItem1.AllowHotTrack = true;
            this.splitterItem1.Location = new System.Drawing.Point(175, 0);
            this.splitterItem1.Name = "splitterItem1";
            this.splitterItem1.Size = new System.Drawing.Size(5, 743);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.txtTitle;
            this.layoutControlItem5.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem5.Image")));
            this.layoutControlItem5.Location = new System.Drawing.Point(374, 0);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(327, 30);
            this.layoutControlItem5.Spacing = new DevExpress.XtraLayout.Utils.Padding(10, 0, 0, 0);
            this.layoutControlItem5.Text = "프로세스 메뉴명";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(109, 16);
            // 
            // layoutControlItem19
            // 
            this.layoutControlItem19.Control = this.btnClose;
            this.layoutControlItem19.Location = new System.Drawing.Point(843, 0);
            this.layoutControlItem19.MaxSize = new System.Drawing.Size(104, 30);
            this.layoutControlItem19.MinSize = new System.Drawing.Size(58, 30);
            this.layoutControlItem19.Name = "layoutControlItem19";
            this.layoutControlItem19.Size = new System.Drawing.Size(73, 30);
            this.layoutControlItem19.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem19.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem19.TextVisible = false;
            // 
            // layoutControlItem20
            // 
            this.layoutControlItem20.Control = this.btnNew;
            this.layoutControlItem20.Location = new System.Drawing.Point(701, 0);
            this.layoutControlItem20.MaxSize = new System.Drawing.Size(104, 30);
            this.layoutControlItem20.MinSize = new System.Drawing.Size(58, 30);
            this.layoutControlItem20.Name = "layoutControlItem20";
            this.layoutControlItem20.Size = new System.Drawing.Size(72, 30);
            this.layoutControlItem20.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem20.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem20.TextVisible = false;
            // 
            // layoutControlItem16
            // 
            this.layoutControlItem16.Control = this.btnSave;
            this.layoutControlItem16.Location = new System.Drawing.Point(773, 0);
            this.layoutControlItem16.MaxSize = new System.Drawing.Size(104, 30);
            this.layoutControlItem16.MinSize = new System.Drawing.Size(58, 30);
            this.layoutControlItem16.Name = "layoutControlItem16";
            this.layoutControlItem16.Size = new System.Drawing.Size(70, 30);
            this.layoutControlItem16.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem16.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem16.TextVisible = false;
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.canvas1;
            this.layoutControlItem6.Location = new System.Drawing.Point(180, 30);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(736, 713);
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextVisible = false;
            // 
            // layoutControlItem17
            // 
            this.layoutControlItem17.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem17.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem17.Control = this.cboWKGRP_ID2;
            this.layoutControlItem17.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem17.Image")));
            this.layoutControlItem17.Location = new System.Drawing.Point(180, 0);
            this.layoutControlItem17.Name = "layoutControlItem17";
            this.layoutControlItem17.Size = new System.Drawing.Size(194, 30);
            this.layoutControlItem17.Spacing = new DevExpress.XtraLayout.Utils.Padding(10, 0, 0, 0);
            this.layoutControlItem17.Text = "작업 그룹";
            this.layoutControlItem17.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem17.TextSize = new System.Drawing.Size(73, 16);
            this.layoutControlItem17.TextToControlDistance = 5;
            // 
            // fontDialog1
            // 
            this.fontDialog1.ShowApply = true;
            this.fontDialog1.ShowColor = true;
            // 
            // imageListGroupArea
            // 
            this.imageListGroupArea.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageListGroupArea.ImageSize = new System.Drawing.Size(16, 16);
            this.imageListGroupArea.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // imageListItem
            // 
            this.imageListItem.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageListItem.ImageSize = new System.Drawing.Size(16, 16);
            this.imageListItem.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // ShapeEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.layoutControl1);
            this.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "ShapeEditor";
            this.Size = new System.Drawing.Size(936, 763);
            this.Shown += new System.EventHandler(this.ShapeEditor_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).EndInit();
            this.layoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cboWKGRP_ID2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTitle.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl1)).EndInit();
            this.navBarControl1.ResumeLayout(false);
            this.navBarGroupControlContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl3)).EndInit();
            this.layoutControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtTCODE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDisplayTitle.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMenuId.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboFontColor.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFontSize.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboFontItalic.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboFontBold.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboFontName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCANVAS_ID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboBackColor.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboType.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSize.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLocation.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboCANVAS_BCOLOR.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCANVAS_SIZE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem29)).EndInit();
            this.navBarGroupControlContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl2)).EndInit();
            this.layoutControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cboWKGRP_ID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rcboWRKGRP_ID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboMENU_ID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem22)).EndInit();
            this.navBarGroupControlContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.treeList1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraLayout.LayoutControl layoutControl1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraNavBar.NavBarControl navBarControl1;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup1;
        private DevExpress.XtraNavBar.NavBarGroupControlContainer navBarGroupControlContainer1;
        private DevExpress.XtraNavBar.NavBarGroupControlContainer navBarGroupControlContainer2;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraTreeList.TreeList treeList1;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn1;
        private DevExpress.XtraLayout.LayoutControl layoutControl2;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.SplitterItem splitterItem1;
        private DevExpress.XtraEditors.TextEdit txtTitle;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup3;
        private DevExpress.XtraNavBar.NavBarGroupControlContainer navBarGroupControlContainer3;
        private DevExpress.XtraLayout.LayoutControl layoutControl3;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraEditors.ImageComboBoxEdit cboType;
        private DevExpress.XtraEditors.TextEdit txtSize;
        private DevExpress.XtraEditors.TextEdit txtLocation;
        private DevExpress.XtraEditors.ColorEdit cboCANVAS_BCOLOR;
        private DevExpress.XtraEditors.TextEdit txtCANVAS_SIZE;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private DevExpress.XtraLayout.SimpleSeparator simpleSeparator1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraLayout.SimpleSeparator simpleSeparator2;
        private DevExpress.XtraEditors.ImageComboBoxEdit cboBackColor;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private System.Windows.Forms.FontDialog fontDialog1;
        private DevExpress.XtraEditors.SimpleButton btnDel;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rcboWRKGRP_ID;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraEditors.ImageComboBoxEdit cboWKGRP_ID;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem18;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraEditors.SimpleButton btnClose;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem19;
        private DevExpress.XtraEditors.SimpleButton btnNew;
        private DevExpress.XtraEditors.SimpleButton btnCreateProgram;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit cboMENU_ID;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem20;
        private DevExpress.XtraEditors.SimpleButton btnSave;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem16;
        private Shape.Canvas canvas1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraEditors.ImageComboBoxEdit cboWKGRP_ID2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem17;
        private DevExpress.XtraEditors.TextEdit txtCANVAS_ID;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem21;
        private System.Windows.Forms.ImageList imageListGroupArea;
        private System.Windows.Forms.ImageList imageListItem;
        private DevExpress.XtraEditors.SimpleButton btnLoad;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem22;
        private DevExpress.XtraEditors.FontEdit cboFontName;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem23;
        private DevExpress.XtraEditors.TextEdit txtFontSize;
        private DevExpress.XtraEditors.ImageComboBoxEdit cboFontItalic;
        private DevExpress.XtraEditors.ImageComboBoxEdit cboFontBold;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem24;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem25;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem26;
        private DevExpress.XtraLayout.SimpleSeparator simpleSeparator3;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem6;
        private DevExpress.XtraEditors.ColorEdit cboFontColor;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraEditors.TextEdit txtTCODE;
        private DevExpress.XtraEditors.TextEdit txtDisplayTitle;
        private DevExpress.XtraEditors.TextEdit txtMenuId;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem7;
        private DevExpress.XtraLayout.SimpleSeparator simpleSeparator4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem27;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem28;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem29;


    }
}
