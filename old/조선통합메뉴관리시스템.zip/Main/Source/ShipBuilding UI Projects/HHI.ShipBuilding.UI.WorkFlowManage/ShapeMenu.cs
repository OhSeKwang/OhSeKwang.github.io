﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.Windows.Forms;
using HHI.ShipBuilding.Shape.CLS;
using HHI.ShipBuilding.UIModel;

namespace HHI.ShipBuilding.UI.WorkFlowManage
{
    public partial class ShapeMenu : StdUserControlBase
    {
        string canvas_Id = string.Empty;
        public ShapeMenu()
        {
            InitializeComponent();
        }

        private void ShapeMenu_Shown(object sender, EventArgs e)
        {
            canvas1.SetViewer();

            if (ViewerVariables.DbCalled == false)
            {
                DataTable authMenuDt = GetData("SP_GETAUTHMENULIST", UserID);
                var vv = ViewerVariables.Values;
                for (int i = 0; i < authMenuDt.Rows.Count; i++)
                {
                    vv.AuthMenuId.Add(authMenuDt.Rows[i]["MENU_ID"].ToString());
                }
            }

            DataTable dt = GetData("SHAPE_MENU", (this.MenuItemInfo as MenuItemInfoEx).ProgramId);
            
            if (dt.Rows.Count > 0)
            {
                txtTitle.Text = dt.Rows[0]["TITLE"].ToString();
                canvas_Id = dt.Rows[0]["CANVAS_ID"].ToString();

                var dtCanvas = GetData("CANVAS", canvas_Id);
                var dtShape = GetData("SHAPE", canvas_Id);
                var dtLine = GetData("LINE", canvas_Id);


                if (dtCanvas.Rows.Count == 0)
                    return;

                canvas1.lblEmptyCanvas.Visible = false;

                txtTitle.Text = Convert.ToString(dtCanvas.Rows[0]["TITLE"]);
                canvas1.CANVAS_ID = Convert.ToString(dtCanvas.Rows[0]["CANVAS_ID"]);

                int iColor = Convert.ToInt32(dtCanvas.Rows[0]["CANVAS_BCOLOR"]);
                canvas1.BackColor = Color.FromArgb(iColor); ;

                bool IsSuccess = canvas1.LoadCanvasData(dtShape, dtLine);

                if (IsSuccess == false)
                {
                    canvas1.ClearCanvas();

                    txtTitle.Text = string.Empty;
                    canvas_Id = string.Empty;
                }

                canvas1.Invalidate();
            }

            canvas1.ShapeMenuClick += canvas1_ShapeMenuClick;
        }

        void canvas1_ShapeMenuClick(object sender, ShapeMenuClickEventArg e)
        {
            SystemManager.RequestMenuClick(e.MenuId, e.TCODE);
        }

        private DataTable GetData(string sel, string val1)
        {
            DataPack dp = new DataPack();
            dp.DataList.Add("i_SEL", sel);
            dp.DataList.Add("i_VAL1", val1);
            dp.DataList.Add("i_VAL2", UserID);
            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "PKG_SHAPE.GET_MENU", dp).QuerySet.Tables[0];
        }
    }
}
