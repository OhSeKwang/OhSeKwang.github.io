﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Shape;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.Windows.Forms;
using HHI.ShipBuilding.Shape.CLS;
using HHI.ShipBuilding.Controls;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Controls;

namespace HHI.ShipBuilding.UI.WorkFlowManage
{
    public partial class ShapeEditor : StdUserControlBase
    {
        bool IsShown = false;
        bool CanInfluenceAttr = false;
        public ShapeEditor()
        {
            InitializeComponent();
        }

        // 화면이 보여진 후 초기화 작업을 한다.
        private void ShapeEditor_Shown(object sender, EventArgs e)
        {
            // 통합 메뉴
            treeList1.DataSource = GetData(string.Empty, string.Empty);
            treeList1.RefreshDataSource();

            // Work Flow 항목
            DataTable dt = GetData("WF", string.Empty);
            gridControl1.DataSource = dt;
            gridView1.RefreshData();

            // 작업 그룹 콤보 2개
            DataTable wkDt = ClientControlHelper.GetCodeInfo("CC001");
            ImageComboBindingByCommonCode(cboWKGRP_ID, wkDt, null);
            ImageComboBindingByCommonCode(cboWKGRP_ID2, wkDt, null);
            ImageComboBindingByCommonCode(rcboWRKGRP_ID, wkDt, null);

            cboWKGRP_ID.SelectedIndex = 0;

            // 사용자 정의 이벤트 핸들러
            canvas1.ChangedCanvas += canvas1_ChangedCanvas;
            canvas1.AlertMessage += canvas1_AlertMessage;
            canvas1.ChangedStaus += canvas1_ChangedStaus;

            IsShown = true;
        }

        public class SelectedShapesAttr
        {
            public List<int> TypeEntities = new List<int>();

            public List<string> txtLocation = new List<string>();
            public List<string> txtSize = new List<string>();
            public List<int> cboType = new List<int>();
            public List<string> cboBackColor = new List<string>();

            public List<string> cboFontName = new List<string>();
            public List<bool> cboFontBold = new List<bool>();
            public List<bool> cboFontItalic = new List<bool>();
            public List<string> txtFontSize = new List<string>();
            public List<int> cboFontColor = new List<int>();

            public void Clear()
            {
                TypeEntities.Clear();

                txtLocation.Clear();
                txtSize.Clear();
                cboType.Clear();
                cboBackColor.Clear();

                cboFontName.Clear();
                cboFontBold.Clear();
                cboFontItalic.Clear();
                txtFontSize.Clear();
                cboFontColor.Clear();
            }
        }

        SelectedShapesAttr sattr = null;
        // Canvas내의 shape Select Staus 값이 변경되면 처리
        void canvas1_ChangedStaus(object sender, EventArgs e)
        {
            CanInfluenceAttr = false;
            try
            {
                InfluenceAttr();
            }
            catch
            {
                throw;
            }
            finally
            {
                CanInfluenceAttr = true;
            }
            
        }

        private void InfluenceAttr()
        {
            txtLocation.Text = string.Empty;
            txtSize.Text = string.Empty;
            cboType.Properties.Items.Clear();
            cboBackColor.Properties.Items.Clear();

            cboFontName.SelectedIndex = -1;
            cboFontBold.SelectedIndex = -1;
            cboFontItalic.SelectedIndex = -1;
            txtFontSize.Text = string.Empty;
            cboFontColor.EditValue = Color.Empty;

            txtMenuId.Text = string.Empty;
            txtDisplayTitle.Text = string.Empty;
            txtTCODE.Text = string.Empty;
            txtTCODE.Properties.ReadOnly = true;

            if (sattr == null)
                sattr = new SelectedShapesAttr();

            sattr.Clear();

            if (canvas1.SelectedShapes.Count == 0)
                return;

            if (canvas1.SelectedShapes.Count == 1)
            {
                if (canvas1.SelectedShapes[0] is Item)
                {
                    var item = canvas1.SelectedShapes[0] as Item;
                    txtMenuId.Text = item.MenuId;
                    txtDisplayTitle.Text = item.MenuTitle;

                    if (item.MenuId.Equals(ShapeEvironments.Instance.TCODE_MENU, StringComparison.OrdinalIgnoreCase))
                    {
                        txtTCODE.Properties.ReadOnly = false;
                    }
                    
                    txtTCODE.Text = Convert.ToString(item.EXTRA1);
                }
            }

            foreach (var s in canvas1.SelectedShapes)
            {
                sattr.TypeEntities.Add(s.TYPE_ENTITY);

                sattr.txtLocation.Add(s.SHAPE_LOC);
                sattr.txtSize.Add(s.SHAPE_SIZE);
                sattr.cboType.Add(s.TYPE_SHAPE);
                sattr.cboBackColor.Add(s.RES_NAME.Substring(s.RES_NAME.LastIndexOf('_') + 1));

                sattr.cboFontName.Add(s.MyDescFont.Name);
                sattr.cboFontBold.Add(s.MyDescFont.Bold);
                sattr.cboFontItalic.Add(s.MyDescFont.Italic);
                sattr.txtFontSize.Add(s.MyDescFont.FontSize.ToString());
                sattr.cboFontColor.Add(s.MyDescFont.Color.ToArgb());
            }

            if (sattr.txtLocation.GroupBy(s => s).Count() == 1)
            {
                txtLocation.Text = canvas1.SelectedShapes[0].Location.ToString();
            }

            if (sattr.txtSize.GroupBy(s => s).Count() == 1)
            {
                txtSize.Text = canvas1.SelectedShapes[0].Size.ToString();
            }

            if (sattr.TypeEntities.GroupBy(s => s).Count() == 1)
            {
                int sel = -1;
                if (sattr.cboType.GroupBy(s => s).Count() == 1)
                {
                    sel = canvas1.SelectedShapes[0].TYPE_SHAPE;
                }

                BindingTypeCombo(canvas1.SelectedShapes[0], sel);

                string sel2 = string.Empty;
                if (sattr.cboBackColor.GroupBy(s => s).Count() == 1)
                {
                    sel2 = canvas1.SelectedShapes[0].RES_NAME.Substring(canvas1.SelectedShapes[0].RES_NAME.LastIndexOf('_') + 1);
                }

                BindingBackColorCombo(canvas1.SelectedShapes[0], sel2);
            }

            if (sattr.cboFontName.GroupBy(s => s).Count() == 1)
            {
                cboFontName.EditValue = canvas1.SelectedShapes[0].MyDescFont.Name;
            }

            if (sattr.cboFontBold.GroupBy(s => s).Count() == 1)
            {
                cboFontBold.EditValue = canvas1.SelectedShapes[0].MyDescFont.Bold;
            }

            if (sattr.cboFontItalic.GroupBy(s => s).Count() == 1)
            {
                cboFontItalic.EditValue = canvas1.SelectedShapes[0].MyDescFont.Italic;
            }

            if (sattr.txtFontSize.GroupBy(s => s).Count() == 1)
            {
                txtFontSize.EditValue = canvas1.SelectedShapes[0].MyDescFont.FontSize;
            }

            if (sattr.cboFontColor.GroupBy(s => s).Count() == 1)
            {
                cboFontColor.EditValue = canvas1.SelectedShapes[0].MyDescFont.Color;
            }
        }

        private void BindingTypeCombo(ShapeBase ctrl, int sel)
        {
            cboType.Properties.Items.Clear();
            cboType.Properties.Items.Add(string.Empty);
            int i = 0;
            foreach (string v in ctrl.CurrentShapeTypes.GetEnumerator().Items)
            {
                cboType.Properties.Items.Add(new ImageComboBoxItem(v, v, i++));
            }

            cboType.SelectedIndex = sel;
            
        }

        List<ImageComboBoxItem> itemImages = null;
        List<ImageComboBoxItem> groupAreaImages = null;
        private void BindingBackColorCombo(ShapeBase ctrl, string sel)
        {
            cboBackColor.Properties.Items.Clear();

            if (ctrl is Item)
            {
                cboBackColor.Properties.SmallImages = ShapeEvironments.Instance.ItemImages;

                if (itemImages == null)
                {
                    itemImages = new List<ImageComboBoxItem>();

                    var emptyItem = new ImageComboBoxItem("", "", -1);
                    cboBackColor.Properties.Items.Add(emptyItem);
                    itemImages.Add(emptyItem);

                    for (int i = 1; i < ShapeEvironments.Instance.ItemImages.Images.Count; i++)
                    {
                        string key = i.ToString().PadLeft(2, '0');
                        var item = new ImageComboBoxItem("Item Color: " + key, key, i);
                        cboBackColor.Properties.Items.Add(item);
                        itemImages.Add(item);
                    }
                }
                else
                {
                    cboBackColor.Properties.Items.AddRange(itemImages);
                }
            }
            else if (ctrl is GroupArea)
            {
                cboBackColor.Properties.SmallImages = ShapeEvironments.Instance.GroupImages;

                if (groupAreaImages == null)
                {
                    groupAreaImages = new List<ImageComboBoxItem>();
                    for (int i = 0; i < ShapeEvironments.Instance.GroupImages.Images.Count; i++)
                    {
                        string key = (i + 1).ToString().PadLeft(2, '0');
                        var item = new ImageComboBoxItem("Group Color:" + key, key, i);
                        cboBackColor.Properties.Items.Add(item);
                        groupAreaImages.Add(item);
                    }
                }
                else
                {
                    cboBackColor.Properties.Items.AddRange(groupAreaImages);
                }
            }

            cboBackColor.EditValue = sel;
            
        }

        private void ImageComboBindingByCommonCode(object cbo, DataTable dt, ImageList iList)
        {
            dynamic combo;
            int i = 0;
            if (cbo is ImageComboBoxEdit)
            {
                combo = cbo as ImageComboBoxEdit;

                foreach (DataRow dr in dt.Rows)
                {
                    combo.Properties.Items.Add(
                        new DevExpress.XtraEditors.Controls.ImageComboBoxItem(
                            Convert.ToString(dr["CDNM"]), Convert.ToString(dr["CDCODE"]), i));
                    i++;
                }
            }
            else if (cbo is RepositoryItemImageComboBox)
            {
                combo = cbo as RepositoryItem;

                foreach (DataRow dr in dt.Rows)
                {
                    combo.Properties.Items.Add(
                        new DevExpress.XtraEditors.Controls.ImageComboBoxItem(
                            Convert.ToString(dr["CDNM"]), Convert.ToString(dr["CDCODE"]), i));
                    i++;
                }
            }
        }

        #region -> Canvas 사용자 정의 이벤트 핸들러

        void canvas1_AlertMessage(object sender, AlertMessageEventArg e)
        {
            MsgBox.Show(this, e.AlertMessage, "알림", MessageBoxButtons.OK, ImageKinds.Information);
        }

        void canvas1_ChangedCanvas(object sender, ChangedCanvasEventArg e)
        {
            txtCANVAS_ID.Text = e.ID;
            txtCANVAS_SIZE.Text = e.Size;
            cboCANVAS_BCOLOR.Color = e.Color;
        }

        #endregion

        private void treeList1_DragDrop(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.None;
        }

        private void treeList1_DragOver(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.None;
        }

        private void treeList1_GiveFeedback(object sender, GiveFeedbackEventArgs e)
        {
            e.UseDefaultCursors = false;
        }

        private void treeList1_FocusedNodeChanged(object sender, DevExpress.XtraTreeList.FocusedNodeChangedEventArgs e)
        {
            var selectData = DragAndDropItem.Instance;
            selectData.SourceId = Convert.ToString(e.Node.GetValue("MENU_ID"));
            selectData.SoucrceDesc = e.Node.GetDisplayText("DISPLAY_TITLE");
        }

        #region ▶ Shape 속성 창에 있는 컨트롤 이벤트 처리

        private void cboWKGRP_ID_EditValueChanged(object sender, EventArgs e)
        {
            if (IsShown)
            {
                // Work Flow 항목
                DataTable dt = GetData("WF", Convert.ToString(cboWKGRP_ID.EditValue));
                gridControl1.DataSource = dt;
                gridView1.RefreshData();
            }
        }

        private void cboCANVAS_BCOLOR_EditValueChanged(object sender, EventArgs e)
        {
            if (IsShown)
            {
                canvas1.BackColor = cboCANVAS_BCOLOR.Color;
            }
        }

        private void txtFont_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            fontDialog1.ShowDialog();
        }

        #endregion ◀ Shape 속성 창에 있는 컨트롤 이벤트 처리

        #region ▶ 버튼들 이벤트 처리
        private void btnNew_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(canvas1.CANVAS_ID))
            {
                canvas1.lblEmptyCanvas.Visible = false;
                canvas1.NewCanvas();
                cboWKGRP_ID2.EditValue = "00";
                txtTitle.Text = "New Work Flow Menu";
            }
            else
            {
                MsgBox.Show(this, "열려 있는 작업이 있습니다.", "", MessageBoxButtons.OK, ImageKinds.Warnning);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string checkMsg = string.Empty;
            // 저장 사전 체크
            if (string.IsNullOrEmpty(canvas1.CANVAS_ID))
            {
                checkMsg = "CANVAS";
            }
            else if (string.IsNullOrEmpty(txtTitle.Text))
            {
                checkMsg = "프로세스 메뉴명";
            }

            if (!string.IsNullOrEmpty(checkMsg))
            {
                MsgBox.Show(this, "저장할 " + checkMsg + " 가 없습니다.", "", MessageBoxButtons.OK, ImageKinds.Warnning);
                return;
            }

            canvas1.VerticalScroll.Value = 0;
            canvas1.HorizontalScroll.Value = 0;
            
            //canvas1.Invalidate();
            Application.DoEvents();
            canvas1.PerformLayout();

            // 컨트롤에서 데이터를 가져온다.
            List<IShapeEntity> shapes = new List<IShapeEntity>();
            List<ILineEntity> lines = new List<ILineEntity>();
            canvas1.GetCanvasData(ref shapes, ref lines);


            // DB 데이터 매개변수: 프로시저명, DataPack
            Dictionary<string, DataPack> packs = new Dictionary<string, DataPack>();

            this.BeforeInvokeServer("저장 중입니다.");

            DataPack par = new DataPack();
            par.DataList.Add("i_OPER_ID", string.Empty); // "DELETE" 면 삭제고 NULL 이면 저장 사전 작업
            par.DataList.Add("i_CANVAS_ID", canvas1.CANVAS_ID);

            packs.Add("PKG_SHAPE.DEL_CANVAS", par);
            packs.Add("PKG_SHAPE.SET_CANVAS", PrepareSetCanvas());

            DataPack p1 = PrepareSetShape(shapes);
            if (p1.ArrayItemCount > 0)
                packs.Add("PKG_SHAPE.SET_SHAPE", p1);

            DataPack p2 = PrepareSetLine(lines);
            if (p2.ArrayItemCount > 0)
                packs.Add("PKG_SHAPE.SET_LINE", p2);

            DataResultSets resultSets = null;
            try
            {
                resultSets = ShipBuildingSystemChannel.ProcessMulti(
                    DbDataSourcePrefix.DefaultDataSource, true, packs.Keys.ToArray(), packs.Values.ToArray());
            }
            catch (HHIException)
            {
                throw;
            }
            catch (Exception)
            {
                this.AfterInvokeServer();
                Cursor.Current = Cursors.Default;
                throw;
            }
            finally
            {
                this.AfterInvokeServer();
                Cursor.Current = Cursors.Default;
            }

                        

            if (resultSets == null)
                return;

            DataResultSet resultSet = null;
            int i = -1;
            foreach (var res in resultSets.dataResultSetList)
            {
                i++;

                if (res.IsSuccess == false)
                {
                    break;
                }
            }

            resultSet = resultSets.dataResultSetList[i];

            if (resultSet.IsSuccess)
            {
                MsgBox.Show(this, "저장 하였습니다.", "저장", MessageBoxButtons.OK, ImageKinds.Information);
                // Work Flow 항목
                DataTable dt = GetData("WF", string.Empty);
                gridControl1.DataSource = dt;
                gridView1.RefreshData();
            }
            else
            {
                MsgBox.Show(this, resultSet.ExceptionMessage, "오류", MessageBoxButtons.OK, ImageKinds.Error);
            }
        }

        // Work Flow 메뉴를 삭제한다.
        private void btnDel_Click(object sender, EventArgs e)
        {

            int[] iRows = gridView1.GetSelectedRows();

            if (iRows == null || iRows.Count() != 1)
            {
                MsgBox.Show(this, "선택된 Canvas 가 없습니다..", "알림", MessageBoxButtons.OK, ImageKinds.Warnning);
                return;
            }

            var row = gridView1.GetDataRow(iRows[0]);

            var res = MsgBox.Show(this, "그리드에서 선택된 Canvas 을 삭제 하시겠습니까?", "삭제", MessageBoxButtons.YesNo, ImageKinds.Question);

            if (res == DialogResult.No)
            {
                return;
            }

            DataPack par = new DataPack();
            par.DataList.Add("i_OPER_ID", "DELETE"); // "DELETE" 면 삭제고 NULL 이면 저장 사전 작업
            par.DataList.Add("i_CANVAS_ID", row["CANVAS_ID"].ToString());

            this.BeforeInvokeServer("삭제 중입니다.");
            DataResultSet resultSet;
            try
            {
                resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "PKG_SHAPE.DEL_CANVAS", par);
            }
            catch (HHIException)
            {
                throw;
            }
            catch (Exception)
            {
                this.AfterInvokeServer();
                Cursor.Current = Cursors.Default;
                throw;
            }
            finally
            {
                this.AfterInvokeServer();
                Cursor.Current = Cursors.Default;
            }

            if (resultSet.IsSuccess)
            {
                MsgBox.Show(this, resultSet.OutParamList["ORT_CODE"].ToString(), "삭제", MessageBoxButtons.OK, ImageKinds.Error);

                // 통합 메뉴
                treeList1.DataSource = GetData(string.Empty, string.Empty);
                treeList1.RefreshDataSource();

                // Work Flow 항목
                DataTable dt = GetData("WF", Convert.ToString(cboWKGRP_ID.EditValue));
                gridControl1.DataSource = dt;
                gridView1.RefreshData();
            }
            else
            {
                MsgBox.Show(this, resultSet.ExceptionMessage, "오류", MessageBoxButtons.OK, ImageKinds.Error);
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            // 작업중인 Canvas 가 있는지 확인
            if (!string.IsNullOrEmpty(canvas1.CANVAS_ID))
            {
                MsgBox.Show(this, "열려 있는 작업이 있습니다. 닫고 다시 불러오십시오.", "진행 작업 알림", MessageBoxButtons.OK, ImageKinds.Warnning);
                return;
            }
            
            int[] iRows = gridView1.GetSelectedRows();

            if (iRows == null || iRows.Count() != 1)
            {
                MsgBox.Show(this, "선택된 Canvas 가 없습니다..", "알림", MessageBoxButtons.OK, ImageKinds.Warnning);
                return;
            }

            var row = gridView1.GetDataRow(iRows[0]);

            var dtCanvas = GetData("CANVAS", Convert.ToString(row["CANVAS_ID"]));
            var dtShape = GetData("SHAPE", Convert.ToString(row["CANVAS_ID"]));
            var dtLine = GetData("LINE", Convert.ToString(row["CANVAS_ID"]));


            if (dtCanvas.Rows.Count == 0)
                return;

            canvas1.lblEmptyCanvas.Visible = false;
            canvas1.CANVAS_ID = Convert.ToString(dtCanvas.Rows[0]["CANVAS_ID"]);
            canvas1.DESCRIPTION = Convert.ToString(dtCanvas.Rows[0]["TITLE"]);
            canvas1.SHAPE_SIZE = Convert.ToString(dtCanvas.Rows[0]["CANVAS_SIZE"]);

            cboWKGRP_ID2.EditValue = Convert.ToString(dtCanvas.Rows[0]["WKGRP_ID"]);
            txtTitle.Text = Convert.ToString(dtCanvas.Rows[0]["TITLE"]);
            txtCANVAS_SIZE.Text = Convert.ToString(dtCanvas.Rows[0]["CANVAS_SIZE"]);
            int iColor = Convert.ToInt32(dtCanvas.Rows[0]["CANVAS_BCOLOR"]);
            canvas1.BackColor = Color.FromArgb(iColor); ;

            bool IsSuccess = canvas1.LoadCanvasData(dtShape, dtLine);

            if (IsSuccess == false)
            {
                canvas1.ClearCanvas();
                
                // 이화면 초기화
                cboWKGRP_ID2.EditValue = "00";
                txtTitle.Text = string.Empty;
            }

            canvas1.Invalidate();
        }

        private void btnCreateProgram_Click(object sender, EventArgs e)
        {
            int[] iRows = gridView1.GetSelectedRows();

            if (iRows == null || iRows.Count() != 1)
            {
                MsgBox.Show(this, "선택된 Canvas 가 없습니다..", "알림", MessageBoxButtons.OK, ImageKinds.Warnning);
                return;
            }

            var row = gridView1.GetDataRow(iRows[0]);

            var res = MsgBox.Show(this, "그리드에서 선택된 Canvas 의 프로그램을 생성하시겠습니까?", "프로그램 생성", MessageBoxButtons.YesNo, ImageKinds.Question);

            if (res == DialogResult.No)
            {
                return;
            }

            DataPack par = new DataPack();

            par.DataList.Add("i_USER_ID", this.UserID);
            par.DataList.Add("i_OPER_ID", "MAKE"); // "MAKE" 면 프로그램 생성, 'DELETE 면 프로그램 삭제
            par.DataList.Add("i_CANVAS_ID", row["CANVAS_ID"].ToString());

            this.BeforeInvokeServer("프로그램 생성 중입니다.");
            DataResultSet resultSet;
            try
            {
                resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "PKG_SHAPE.SET_PROGRAM", par);
            }
            catch (HHIException)
            {
                throw;
            }
            catch (Exception)
            {
                this.AfterInvokeServer();
                Cursor.Current = Cursors.Default;
                throw;
            }
            finally
            {
                this.AfterInvokeServer();
                Cursor.Current = Cursors.Default;
            }

            if (resultSet.IsSuccess)
            {
                MsgBox.Show(this, resultSet.OutParamList["ORT_CODE"].ToString(), "프로그램 생성", MessageBoxButtons.OK, ImageKinds.Error);

                // 통합 메뉴
                treeList1.DataSource = GetData(string.Empty, string.Empty);
                treeList1.RefreshDataSource();

                // Work Flow 항목
                DataTable dt = GetData("WF", Convert.ToString(cboWKGRP_ID.EditValue));
                gridControl1.DataSource = dt;
                gridView1.RefreshData();
            }
            else
            {
                MsgBox.Show(this, resultSet.ExceptionMessage, "오류", MessageBoxButtons.OK, ImageKinds.Error);
            }
        }

        private void btnCreateMenu_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            canvas1.ClearCanvas();
            cboWKGRP_ID2.EditValue = null;
            txtTitle.Text = string.Empty;
        }

        #endregion ◀ 워크플로우 메뉴 버튼들 이벤트 처리

        #region ▶ DB

        private DataTable GetData(string sel, string val1)
        {
            DataPack dp = new DataPack();
            dp.DataList.Add("i_SEL", sel);
            dp.DataList.Add("i_VAL1", val1);
            dp.DataList.Add("i_VAL2", UserID);
            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "PKG_SHAPE.GET_MENU", dp).QuerySet.Tables[0];
        }

        private DataPack PrepareSetCanvas()
        {
            DataPack par = new DataPack();

            par.DataList.Add("i_CANVAS_ID", canvas1.CANVAS_ID);
            par.DataList.Add("i_TITLE", txtTitle.Text);
            par.DataList.Add("i_WKGRP_ID", Convert.ToString(cboWKGRP_ID2.EditValue));
            par.DataList.Add("i_CANVAS_SIZE", canvas1.SHAPE_SIZE);
            par.DataList.Add("i_CANVAS_BCOLOR", canvas1.BackColor.ToArgb().ToString());
            par.DataList.Add("i_USER_ID", UserID);

            return par;
            
        }

        private DataPack PrepareSetShape(List<IShapeEntity> shapesData)
        {
            DataPack par = new DataPack();

            List<string> i_CANVAS_ID = new List<string>();
            List<string> i_SHAPE_ID = new List<string>();
            List<string> i_P_SHAPE_ID = new List<string>();
            List<string> i_DESCRIPTION = new List<string>();
            List<string> i_FONT_DESC = new List<string>();
            List<string> i_TYPE_ENTITY = new List<string>();
            List<string> i_TYPE_SHAPE = new List<string>();
            List<string> i_SHAPE_LOC = new List<string>();
            List<string> i_SHAPE_SIZE = new List<string>();
            List<string> i_RES_NAME = new List<string>();
            List<string> i_SOURCE_ID = new List<string>();
            List<string> i_EXTRA1 = new List<string>();

            foreach (var data in shapesData)
            {
                i_CANVAS_ID.Add(data.CANVAS_ID);
                i_SHAPE_ID.Add(data.SHAPE_ID);
                i_P_SHAPE_ID.Add(data.P_SHAPE_ID);
                i_DESCRIPTION.Add(data.DESCRIPTION);
                i_FONT_DESC.Add(data.FONT_DESC);
                i_TYPE_ENTITY.Add(data.TYPE_ENTITY.ToString());
                i_TYPE_SHAPE.Add(data.TYPE_SHAPE.ToString());
                i_SHAPE_LOC.Add(data.SHAPE_LOC);
                i_SHAPE_SIZE.Add(data.SHAPE_SIZE);
                i_RES_NAME.Add(data.RES_NAME);
                i_SOURCE_ID.Add(data.SOURCE_ID);
                i_EXTRA1.Add(data.EXTRA1);
            }

            par.DataList.Add("i_CANVAS_ID", i_CANVAS_ID.ToArray());
            par.DataList.Add("i_SHAPE_ID", i_SHAPE_ID.ToArray());
            par.DataList.Add("i_P_SHAPE_ID", i_P_SHAPE_ID.ToArray());
            par.DataList.Add("i_DESCRIPTION", i_DESCRIPTION.ToArray());
            par.DataList.Add("i_FONT_DESC", i_FONT_DESC.ToArray());
            par.DataList.Add("i_TYPE_ENTITY", i_TYPE_ENTITY.ToArray());
            par.DataList.Add("i_TYPE_SHAPE", i_TYPE_SHAPE.ToArray());
            par.DataList.Add("i_SHAPE_LOC", i_SHAPE_LOC.ToArray());
            par.DataList.Add("i_SHAPE_SIZE", i_SHAPE_SIZE.ToArray());
            par.DataList.Add("i_RES_NAME", i_RES_NAME.ToArray());
            par.DataList.Add("i_SOURCE_ID", i_SOURCE_ID.ToArray());
            par.DataList.Add("i_EXTRA1", i_EXTRA1.ToArray());

            par.ArrayItemCount = i_CANVAS_ID.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            return par;
        }

        private DataPack PrepareSetLine(List<ILineEntity> lines)
        {
            DataPack par = new DataPack();

            List<string> i_CANVAS_ID = new List<string>();
            List<string> i_SHAPE_ID = new List<string>();
            List<string> i_LINE_ID = new List<string>();
            List<string> i_SPOINT = new List<string>();
            List<string> i_EPOINT = new List<string>();
            List<string> i_BCOLOR = new List<string>();
            List<string> i_WIDTH = new List<string>();
            List<string> i_START_ID = new List<string>();
            List<string> i_END_ID = new List<string>();

            foreach (var data in lines)
            {
                i_CANVAS_ID.Add(data.CANVAS_ID);
                i_SHAPE_ID.Add(data.SHAPE_ID);
                i_LINE_ID.Add(data.LINE_ID);
                i_SPOINT.Add(data.SPoint.ToString());
                i_EPOINT.Add(data.EPoint.ToString());
                i_BCOLOR.Add(data.Color.ToString());
                i_WIDTH.Add(data.Width.ToString());
                i_START_ID.Add(data.START_ID);
                i_END_ID.Add(data.END_ID);
            }

            par.DataList.Add("i_CANVAS_ID", i_CANVAS_ID.ToArray());
            par.DataList.Add("i_SHAPE_ID", i_SHAPE_ID.ToArray());
            par.DataList.Add("i_LINE_ID", i_LINE_ID.ToArray());
            par.DataList.Add("i_SPOINT", i_SPOINT.ToArray());
            par.DataList.Add("i_EPOINT", i_EPOINT.ToArray());
            par.DataList.Add("i_BCOLOR", i_BCOLOR.ToArray());
            par.DataList.Add("i_WIDTH", i_WIDTH.ToArray());
            par.DataList.Add("i_START_ID", i_START_ID.ToArray());
            par.DataList.Add("i_END_ID", i_END_ID.ToArray());

            par.ArrayItemCount = i_CANVAS_ID.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            return par;
        }
        #endregion

        #region ▶ 좌측 Shape 속성들의 값 변경시 Shape 적용하는 이벤트핸들러

        // Types
        private void cboType_EditValueChanged(object sender, EventArgs e)
        {
            if (!CanInfluenceAttr)
                return;

            if (cboType.SelectedIndex == -1)
                return;

            foreach (var s in canvas1.SelectedShapes)
            {
                string resName = string.Empty;

                dynamic ctrl;
                if (s is Item)
                {
                    ctrl = (s as Item);

                }
                else if (s is GroupArea)
                {
                    ctrl = (s as GroupArea);
                }
                else
                {
                    return;
                }

                var st = ctrl.CurrentShapeTypes.GetEnumerator();
                string cName = st.Current;
                st.Position = cboType.SelectedIndex;

                // RES_NAME 에 입력되면 컨트롤의 백그라운드 이미지가 변경된다.
                ctrl.RES_NAME = ctrl.RES_NAME.Replace(cName, st.Current);
                ctrl.TYPE_SHAPE = st.Position;
            }
        }

        // BackColor
        private void cboBackColor_EditValueChanged(object sender, EventArgs e)
        {
            if (!CanInfluenceAttr)
                return;

            if (Convert.ToString(cboBackColor.EditValue) == string.Empty)
                return;

            foreach (var s in canvas1.SelectedShapes)
            {
                s.RES_NAME = s.RES_NAME.Substring(0, s.RES_NAME.LastIndexOf('_') + 1) +  Convert.ToString(cboBackColor.EditValue);
            }
        }

        #region Description Font Attributes
        // Name
        private void cboFontName_EditValueChanged(object sender, EventArgs e)
        {
            if (!CanInfluenceAttr)
                return;

            if (cboFontName.SelectedIndex == -1)
                return;

            foreach (var s in canvas1.SelectedShapes)
            {
                s.MyDescFont.Name = Convert.ToString(cboFontName.EditValue);
                s.MyDescFont.SetShapeFontToControl();
            }
        }

        // Bold
        private void cboFontBold_EditValueChanged(object sender, EventArgs e)
        {
            if (!CanInfluenceAttr)
                return;

            if (cboFontBold.SelectedIndex == -1)
                return;

            foreach (var s in canvas1.SelectedShapes)
            {
                s.MyDescFont.Bold = Convert.ToBoolean(cboFontBold.EditValue);
                s.MyDescFont.SetShapeFontToControl();
            }
        }

        // Italic
        private void cboFontItalic_EditValueChanged(object sender, EventArgs e)
        {
            if (!CanInfluenceAttr)
                return;

            if (cboFontItalic.SelectedIndex == -1)
                return;

            foreach (var s in canvas1.SelectedShapes)
            {
                s.MyDescFont.Italic = Convert.ToBoolean(cboFontItalic.EditValue);
                s.MyDescFont.SetShapeFontToControl();
            }
        }

        // Size
        private void txtFontSize_Properties_Validating(object sender, CancelEventArgs e)
        {
            if (!CanInfluenceAttr)
                return;

            if (string.IsNullOrEmpty(txtFontSize.Text))
                return;

            foreach (var s in canvas1.SelectedShapes)
            {
                s.MyDescFont.FontSize = float.Parse(txtFontSize.Text);
                s.MyDescFont.SetShapeFontToControl();
            }
        }

        // Color
        private void cboFontColor_EditValueChanged(object sender, EventArgs e)
        {
            if (!CanInfluenceAttr)
                return;

            if (cboFontColor.EditValue == null)
                return;

            foreach (var s in canvas1.SelectedShapes)
            {
                s.MyDescFont.Color = cboFontColor.Color;
                s.MyDescFont.SetShapeFontToControl();
            }
        }
        #endregion

        #region ▶ Original Menu Infomation
        private void txtTCODE_Properties_Validating(object sender, CancelEventArgs e)
        {
            if (!CanInfluenceAttr)
                return;

            if (string.IsNullOrEmpty(txtFontSize.Text))
                return;

            foreach (var s in canvas1.SelectedShapes)
            {
                s.EXTRA1 = txtTCODE.Text;
            }
        }
        #endregion

        #endregion ▶ 좌측 Shape 속성들의 값 변경시 Shape 적용하는 이벤트핸들러
    }
}
