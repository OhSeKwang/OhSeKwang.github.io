﻿namespace HHI.ShipBuilding.UI.WorkFlowManage
{
    partial class SCWF001
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SCWF001));
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.xtraLabelExt15 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt();
            this.xtraLabelExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt();
            this.xtraLabelExt14 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt();
            this.xtraLabelExt13 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt();
            this.xtraLabelExt12 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt();
            this.xtraLabelExt11 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt();
            this.xtraLabelExt10 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt();
            this.xtraLabelExt9 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt();
            this.xtraLabelExt8 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt();
            this.xtraLabelExt7 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt();
            this.xtraLabelExt6 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt();
            this.xtraLabelExt5 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt();
            this.xtraLabelExt4 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt();
            this.xtraLabelExt3 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt();
            this.xtraLabelExt2 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.xtraTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.xtraTabControl1);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(742, 395, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(1232, 869);
            this.xtraLayoutControlExt1.TabIndex = 0;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.ClosePageButtonShowMode = DevExpress.XtraTab.ClosePageButtonShowMode.InActiveTabPageHeader;
            this.xtraTabControl1.HeaderButtons = ((DevExpress.XtraTab.TabButtons)((DevExpress.XtraTab.TabButtons.Close | DevExpress.XtraTab.TabButtons.Default)));
            this.xtraTabControl1.Location = new System.Drawing.Point(24, 24);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.xtraTabPage1;
            this.xtraTabControl1.Size = new System.Drawing.Size(1184, 821);
            this.xtraTabControl1.TabIndex = 28;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1});
            this.xtraTabControl1.CloseButtonClick += new System.EventHandler(this.xtraTabControl1_CloseButtonClick);
            // 
            // xtraTabPage1
            // 
            this.xtraTabPage1.AutoScroll = true;
            this.xtraTabPage1.Controls.Add(this.panelControl1);
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Size = new System.Drawing.Size(1178, 792);
            this.xtraTabPage1.Text = "WorkFlow";
            // 
            // panelControl1
            // 
            this.panelControl1.ContentImage = ((System.Drawing.Image)(resources.GetObject("panelControl1.ContentImage")));
            this.panelControl1.Controls.Add(this.xtraLabelExt15);
            this.panelControl1.Controls.Add(this.xtraLabelExt1);
            this.panelControl1.Controls.Add(this.xtraLabelExt14);
            this.panelControl1.Controls.Add(this.xtraLabelExt13);
            this.panelControl1.Controls.Add(this.xtraLabelExt12);
            this.panelControl1.Controls.Add(this.xtraLabelExt11);
            this.panelControl1.Controls.Add(this.xtraLabelExt10);
            this.panelControl1.Controls.Add(this.xtraLabelExt9);
            this.panelControl1.Controls.Add(this.xtraLabelExt8);
            this.panelControl1.Controls.Add(this.xtraLabelExt7);
            this.panelControl1.Controls.Add(this.xtraLabelExt6);
            this.panelControl1.Controls.Add(this.xtraLabelExt5);
            this.panelControl1.Controls.Add(this.xtraLabelExt4);
            this.panelControl1.Controls.Add(this.xtraLabelExt3);
            this.panelControl1.Controls.Add(this.xtraLabelExt2);
            this.panelControl1.Location = new System.Drawing.Point(3, 5);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(925, 696);
            this.panelControl1.TabIndex = 5;
            // 
            // xtraLabelExt15
            // 
            this.xtraLabelExt15.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.xtraLabelExt15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xtraLabelExt15.IsTransparent = false;
            this.xtraLabelExt15.Key = "";
            this.xtraLabelExt15.Location = new System.Drawing.Point(584, 145);
            this.xtraLabelExt15.MinLength = 0;
            this.xtraLabelExt15.Name = "xtraLabelExt15";
            this.xtraLabelExt15.Size = new System.Drawing.Size(98, 74);
            this.xtraLabelExt15.TabIndex = 15;
            this.xtraLabelExt15.Tag = "ZPPCO6006";
            this.xtraLabelExt15.Click += new System.EventHandler(this.lblLabel_Click);
            // 
            // xtraLabelExt1
            // 
            this.xtraLabelExt1.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.xtraLabelExt1.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.xtraLabelExt1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xtraLabelExt1.IsTransparent = false;
            this.xtraLabelExt1.Key = "";
            this.xtraLabelExt1.Location = new System.Drawing.Point(93, 221);
            this.xtraLabelExt1.MinLength = 0;
            this.xtraLabelExt1.Name = "xtraLabelExt1";
            this.xtraLabelExt1.Size = new System.Drawing.Size(99, 65);
            this.xtraLabelExt1.TabIndex = 1;
            this.xtraLabelExt1.Tag = "ZPPCO6001";
            this.xtraLabelExt1.Click += new System.EventHandler(this.lblLabel_Click);
            // 
            // xtraLabelExt14
            // 
            this.xtraLabelExt14.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.xtraLabelExt14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xtraLabelExt14.IsTransparent = false;
            this.xtraLabelExt14.Key = "";
            this.xtraLabelExt14.Location = new System.Drawing.Point(705, 533);
            this.xtraLabelExt14.MinLength = 0;
            this.xtraLabelExt14.Name = "xtraLabelExt14";
            this.xtraLabelExt14.Size = new System.Drawing.Size(89, 73);
            this.xtraLabelExt14.TabIndex = 14;
            this.xtraLabelExt14.Tag = "ZQMCR310";
            this.xtraLabelExt14.Click += new System.EventHandler(this.lblLabel_Click);
            // 
            // xtraLabelExt13
            // 
            this.xtraLabelExt13.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.xtraLabelExt13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xtraLabelExt13.IsTransparent = false;
            this.xtraLabelExt13.Key = "";
            this.xtraLabelExt13.Location = new System.Drawing.Point(576, 533);
            this.xtraLabelExt13.MinLength = 0;
            this.xtraLabelExt13.Name = "xtraLabelExt13";
            this.xtraLabelExt13.Size = new System.Drawing.Size(88, 73);
            this.xtraLabelExt13.TabIndex = 13;
            this.xtraLabelExt13.Tag = "ZQMCO342";
            this.xtraLabelExt13.Click += new System.EventHandler(this.lblLabel_Click);
            // 
            // xtraLabelExt12
            // 
            this.xtraLabelExt12.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.xtraLabelExt12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xtraLabelExt12.IsTransparent = false;
            this.xtraLabelExt12.Key = "";
            this.xtraLabelExt12.Location = new System.Drawing.Point(331, 572);
            this.xtraLabelExt12.MinLength = 0;
            this.xtraLabelExt12.Name = "xtraLabelExt12";
            this.xtraLabelExt12.Size = new System.Drawing.Size(94, 60);
            this.xtraLabelExt12.TabIndex = 12;
            this.xtraLabelExt12.Tag = "ZMMCR615";
            this.xtraLabelExt12.Click += new System.EventHandler(this.lblLabel_Click);
            // 
            // xtraLabelExt11
            // 
            this.xtraLabelExt11.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.xtraLabelExt11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xtraLabelExt11.IsTransparent = false;
            this.xtraLabelExt11.Key = "";
            this.xtraLabelExt11.Location = new System.Drawing.Point(217, 572);
            this.xtraLabelExt11.MinLength = 0;
            this.xtraLabelExt11.Name = "xtraLabelExt11";
            this.xtraLabelExt11.Size = new System.Drawing.Size(93, 68);
            this.xtraLabelExt11.TabIndex = 11;
            this.xtraLabelExt11.Tag = "ZPDCR9999";
            this.xtraLabelExt11.Click += new System.EventHandler(this.lblLabel_Click);
            // 
            // xtraLabelExt10
            // 
            this.xtraLabelExt10.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.xtraLabelExt10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xtraLabelExt10.IsTransparent = false;
            this.xtraLabelExt10.Key = "";
            this.xtraLabelExt10.Location = new System.Drawing.Point(93, 572);
            this.xtraLabelExt10.MinLength = 0;
            this.xtraLabelExt10.Name = "xtraLabelExt10";
            this.xtraLabelExt10.Size = new System.Drawing.Size(99, 68);
            this.xtraLabelExt10.TabIndex = 10;
            this.xtraLabelExt10.Tag = "ZMMCR782";
            this.xtraLabelExt10.Click += new System.EventHandler(this.lblLabel_Click);
            // 
            // xtraLabelExt9
            // 
            this.xtraLabelExt9.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.xtraLabelExt9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xtraLabelExt9.IsTransparent = false;
            this.xtraLabelExt9.Key = "";
            this.xtraLabelExt9.Location = new System.Drawing.Point(280, 474);
            this.xtraLabelExt9.MinLength = 0;
            this.xtraLabelExt9.Name = "xtraLabelExt9";
            this.xtraLabelExt9.Size = new System.Drawing.Size(96, 65);
            this.xtraLabelExt9.TabIndex = 9;
            this.xtraLabelExt9.Tag = "ZPPCR731";
            this.xtraLabelExt9.Click += new System.EventHandler(this.lblLabel_Click);
            // 
            // xtraLabelExt8
            // 
            this.xtraLabelExt8.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.xtraLabelExt8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xtraLabelExt8.IsTransparent = false;
            this.xtraLabelExt8.Key = "";
            this.xtraLabelExt8.Location = new System.Drawing.Point(164, 474);
            this.xtraLabelExt8.MinLength = 0;
            this.xtraLabelExt8.Name = "xtraLabelExt8";
            this.xtraLabelExt8.Size = new System.Drawing.Size(87, 65);
            this.xtraLabelExt8.TabIndex = 8;
            this.xtraLabelExt8.Tag = "ZPPCR730";
            this.xtraLabelExt8.Click += new System.EventHandler(this.lblLabel_Click);
            // 
            // xtraLabelExt7
            // 
            this.xtraLabelExt7.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.xtraLabelExt7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xtraLabelExt7.IsTransparent = false;
            this.xtraLabelExt7.Key = "";
            this.xtraLabelExt7.Location = new System.Drawing.Point(730, 292);
            this.xtraLabelExt7.MinLength = 0;
            this.xtraLabelExt7.Name = "xtraLabelExt7";
            this.xtraLabelExt7.Size = new System.Drawing.Size(90, 71);
            this.xtraLabelExt7.TabIndex = 7;
            this.xtraLabelExt7.Tag = "ZPSCR206";
            this.xtraLabelExt7.Click += new System.EventHandler(this.lblLabel_Click);
            // 
            // xtraLabelExt6
            // 
            this.xtraLabelExt6.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.xtraLabelExt6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xtraLabelExt6.IsTransparent = false;
            this.xtraLabelExt6.Key = "";
            this.xtraLabelExt6.Location = new System.Drawing.Point(592, 292);
            this.xtraLabelExt6.MinLength = 0;
            this.xtraLabelExt6.Name = "xtraLabelExt6";
            this.xtraLabelExt6.Size = new System.Drawing.Size(90, 54);
            this.xtraLabelExt6.TabIndex = 6;
            this.xtraLabelExt6.Tag = "ZPPCR520";
            this.xtraLabelExt6.Click += new System.EventHandler(this.lblLabel_Click);
            // 
            // xtraLabelExt5
            // 
            this.xtraLabelExt5.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.xtraLabelExt5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xtraLabelExt5.IsTransparent = false;
            this.xtraLabelExt5.Key = "";
            this.xtraLabelExt5.Location = new System.Drawing.Point(444, 284);
            this.xtraLabelExt5.MinLength = 0;
            this.xtraLabelExt5.Name = "xtraLabelExt5";
            this.xtraLabelExt5.Size = new System.Drawing.Size(99, 71);
            this.xtraLabelExt5.TabIndex = 5;
            this.xtraLabelExt5.Tag = "ZPSCO208V";
            this.xtraLabelExt5.Click += new System.EventHandler(this.lblLabel_Click);
            // 
            // xtraLabelExt4
            // 
            this.xtraLabelExt4.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.xtraLabelExt4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xtraLabelExt4.IsTransparent = false;
            this.xtraLabelExt4.Key = "";
            this.xtraLabelExt4.Location = new System.Drawing.Point(721, 153);
            this.xtraLabelExt4.MinLength = 0;
            this.xtraLabelExt4.Name = "xtraLabelExt4";
            this.xtraLabelExt4.Size = new System.Drawing.Size(99, 66);
            this.xtraLabelExt4.TabIndex = 4;
            this.xtraLabelExt4.Tag = "ZPPCO6003";
            this.xtraLabelExt4.Click += new System.EventHandler(this.lblLabel_Click);
            // 
            // xtraLabelExt3
            // 
            this.xtraLabelExt3.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.xtraLabelExt3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xtraLabelExt3.IsTransparent = false;
            this.xtraLabelExt3.Key = "";
            this.xtraLabelExt3.Location = new System.Drawing.Point(445, 145);
            this.xtraLabelExt3.MinLength = 0;
            this.xtraLabelExt3.Name = "xtraLabelExt3";
            this.xtraLabelExt3.Size = new System.Drawing.Size(98, 74);
            this.xtraLabelExt3.TabIndex = 3;
            this.xtraLabelExt3.Tag = "ZPPCO6002";
            this.xtraLabelExt3.Click += new System.EventHandler(this.lblLabel_Click);
            // 
            // xtraLabelExt2
            // 
            this.xtraLabelExt2.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.xtraLabelExt2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xtraLabelExt2.IsTransparent = false;
            this.xtraLabelExt2.Key = "";
            this.xtraLabelExt2.Location = new System.Drawing.Point(255, 172);
            this.xtraLabelExt2.MinLength = 0;
            this.xtraLabelExt2.Name = "xtraLabelExt2";
            this.xtraLabelExt2.Size = new System.Drawing.Size(100, 56);
            this.xtraLabelExt2.TabIndex = 2;
            this.xtraLabelExt2.Tag = "ZPPCO6005";
            this.xtraLabelExt2.Click += new System.EventHandler(this.lblLabel_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "layoutControlGroup1";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup2});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1232, 869);
            this.layoutControlGroup1.Text = "Root";
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.CaptionImage = global::HHI.ShipBuilding.UI.WorkFlowManage.Properties.Resources.Grouup_tit_ico;
            this.layoutControlGroup2.CustomizationFormText = "List";
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem3});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(1212, 849);
            this.layoutControlGroup2.Text = "SAP VIEW";
            this.layoutControlGroup2.TextVisible = false;
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.xtraTabControl1;
            this.layoutControlItem3.CustomizationFormText = "layoutControlItem3";
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(1188, 825);
            this.layoutControlItem3.Text = "layoutControlItem3";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem3.TextToControlDistance = 0;
            this.layoutControlItem3.TextVisible = false;
            // 
            // SCWF001
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCWF001";
            this.Size = new System.Drawing.Size(1232, 869);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.xtraTabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private Client.Controls.DXperience.XtraLabelExt xtraLabelExt1;
        private Client.Controls.DXperience.XtraLabelExt xtraLabelExt14;
        private Client.Controls.DXperience.XtraLabelExt xtraLabelExt13;
        private Client.Controls.DXperience.XtraLabelExt xtraLabelExt12;
        private Client.Controls.DXperience.XtraLabelExt xtraLabelExt11;
        private Client.Controls.DXperience.XtraLabelExt xtraLabelExt10;
        private Client.Controls.DXperience.XtraLabelExt xtraLabelExt9;
        private Client.Controls.DXperience.XtraLabelExt xtraLabelExt8;
        private Client.Controls.DXperience.XtraLabelExt xtraLabelExt7;
        private Client.Controls.DXperience.XtraLabelExt xtraLabelExt6;
        private Client.Controls.DXperience.XtraLabelExt xtraLabelExt5;
        private Client.Controls.DXperience.XtraLabelExt xtraLabelExt4;
        private Client.Controls.DXperience.XtraLabelExt xtraLabelExt3;
        private Client.Controls.DXperience.XtraLabelExt xtraLabelExt2;
        private Client.Controls.DXperience.XtraLabelExt xtraLabelExt15;
    }
}
