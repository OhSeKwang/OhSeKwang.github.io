﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraTreeList.Nodes;
using DevExpress.XtraEditors;
using DevExpress.XtraTab;
using AxSHDocVw;
using System.IO;
using HHI.Windows.Forms;
using System.Runtime.InteropServices;
using SHDocVw;
using HHI.ShipBuilding.Client.Controls.DXperience;
using HHI.ShipBuilding.Menu;
using HHI.ServiceModel;
using System.Reflection;
using System.Deployment.Application;
using HHI.ShipBuilding.UIModel;

namespace HHI.ShipBuilding.UI.WorkFlowManage
{
    public partial class SCWF000_2 : StdUserControlBase
    {
        #region 생성자 및 변수 선언

        public SCWF000_2()
        {
            InitializeComponent();
        }

        #endregion

        private void Navigate(AxWebBrowser browser, string url)
        {
            if (url == "") return;
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                object obj = null;
                browser.Navigate(url, ref obj, ref obj, ref obj, ref obj);
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }


        }

        private bool IsExistTabSelect(string tcode)
        {
            foreach (XtraTabPage page in xtraTabControl1.TabPages)
            {
                if (page.Text.Equals(tcode, StringComparison.OrdinalIgnoreCase))
                {
                    xtraTabControl1.SelectedTabPage = page;
                    return true;
                }
            }

            return false;
        }

        private void CreateTabPage(string tcode)
        {
            XtraTabPage page = xtraTabControl1.TabPages.Add();
            page.Text = tcode;

            string strUrl = HHI.Configuration.AppSectionFactory.AppSection["BIZSAP_GUI"].ToString();
            //strUrl += string.Format(@"?USER_ID={0}&GUBUN={1}&TCODE={2}", UserInfo.UserID, "2", tcode);
            strUrl += string.Format(@"?TCODE={0}", tcode);
            Navigate(CreateNewWebBrowser(page), strUrl);
            xtraTabControl1.SelectedTabPage = page;
        }

        private void CloseTabPage(XtraTabPage page)
        {
            xtraTabControl1.TabPages.Remove(page);
        }

        #region ▶ 컨트롤 이벤트

        private void btnRun_Click(object sender, EventArgs e)
        {
            //txtTCODE.Text = txtTCODE.Text.Trim();

            //if (string.IsNullOrEmpty(txtTCODE.Text))
            //{
            //    return;
            //}

            //// 존재 하는 화면 선택
            //if (IsExistTabSelect(txtTCODE.Text))
            //{
            //    return;
            //}

            //if (xtraTabControl1.TabPages.Count == 10)
            //{
            //    MsgBox.Show(this, "최대 10개 화면이 사용 가능 합니다.", "화면 제어 오류", MessageBoxButtons.OK, ImageKinds.Information);
            //    return;
            //}

            //CreateTabPage(txtTCODE.Text);
        }

        private void txtTCODE_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnRun_Click(null, null);
            }
        }

        private void xtraTabControl1_CloseButtonClick(object sender, EventArgs e)
        {
            CloseTabPage((sender as XtraTabControl).SelectedTabPage);
        }

        #endregion

        
        private AxSHDocVw.AxWebBrowser CreateNewWebBrowser(XtraTabPage page)
        {
            AxSHDocVw.AxWebBrowser _axWebBrowser = new AxSHDocVw.AxWebBrowser();
            _axWebBrowser.CreateControl();
            page.Controls.Add(_axWebBrowser);
            _axWebBrowser.Dock = DockStyle.Fill;
            
            return _axWebBrowser;
        }

        private void SCWF000_2_Load(object sender, EventArgs e)
        {            
        }

        private void btnSAP_Click(object sender, EventArgs e)
        {
            XtraButtonExt btn = sender as XtraButtonExt;

            if (!string.IsNullOrWhiteSpace(btn.Tag.ToString()))
                CreateTabPage(btn.Tag.ToString());
        }

       
        private void btn7_Click(object sender, EventArgs e)
        {
            UIMoveTo("SCSYS001", null);
        }


        #region 브라우저 이벤트

        #endregion
    }
}
