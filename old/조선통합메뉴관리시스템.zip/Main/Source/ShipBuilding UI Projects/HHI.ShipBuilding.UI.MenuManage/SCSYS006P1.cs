﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    public partial class SCSYS006P1 : DevExpress.XtraEditors.XtraForm
    {
        /// <summary>
        /// 사용자 정보 DataRow
        /// </summary>
        public DataRow hdnRow { get; set; }

        public string sUSERID { get; set; }


        public SCSYS006P1()
        {
            InitializeComponent();
        }

        #region 화면 Load - SCSYS006P1_Load
        /// <summary>
        /// 화면 Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SCSYS006P1_Load(object sender, EventArgs e)
        {
            initPage();

            

        }
        #endregion 화면 Load - SCSYS006P1_Load

        #region 화면 초기화 - initPage
        /// <summary>
        /// 화면 초기화
        /// </summary>
        private void initPage()
        {
            if (hdnRow != null)
            {
                // 컨트롤 바인딩
                ClientControlHelper.CtrlNestedDataBind(hdnRow, layoutControlGroup1);

                txtUser_Id.Enabled = false;

                stdValidationManager1.SetValidation(txtPassword, new ValidationType[] { });                
            }
            else
            {
                txtUser_Id.EditValue = string.Empty;
                txtKor_Nm.EditValue = string.Empty;
                txtEng_Nm.EditValue = string.Empty;
                txtJob_Tit_Nm.EditValue = string.Empty;
                txtOffi_Tel.EditValue = string.Empty;
                txtDept_Cd.EditValue = string.Empty;
                txtDeptName.EditValue = string.Empty;
                txtPassword.EditValue = string.Empty;
                dteSTART_DATE.EditValue = DateTime.Today.ToShortDateString();
                dteEND_DATE.EditValue = DateTime.Now.AddYears(1).ToShortDateString();
            }
        }
        #endregion 화면 초기화 - initPage

        #region 저장 - btnSave_Click
        /// <summary>
        /// 저장
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {            
            if (!stdValidationManager1.Validation())
            {
                return;
            }

            if (DateTime.Compare(Convert.ToDateTime(dteSTART_DATE.EditValue), Convert.ToDateTime(dteEND_DATE.EditValue)) > 0)
            {
                MsgBox.Show("유효종료일자는 시작일자보다 커야합니다.", "경고"); return;
            }

            DataPack parameter = new DataPack();
            parameter.DataList.Add("USER_ID", new string[] { txtUser_Id.Text });
            parameter.DataList.Add("KOR_NM", new string[] { txtKor_Nm.Text });
            parameter.DataList.Add("ENG_NM", new string[] { txtEng_Nm.Text });
            parameter.DataList.Add("ASGN_CD", new string[] { txtAsgn_Cd.Text });
            parameter.DataList.Add("DEPT_CD", new string[] { txtDept_Cd.Text });
            parameter.DataList.Add("JOB_TIT_NM", new string[] { txtJob_Tit_Nm.Text });
            parameter.DataList.Add("OFFI_TEL", new string[] { txtOffi_Tel.Text });
            parameter.DataList.Add("USE_YN", new string[] { chkUse_Yn.Checked ? "Y" : "N" });
            parameter.DataList.Add("DEPTNAME", new string[] { txtDeptName.Text });
            parameter.DataList.Add("PASSWORD", new string[] { txtPassword.Text });
            parameter.DataList.Add("START_DATE", new string[] { Convert.ToDateTime(dteSTART_DATE.EditValue).ToString("yyyyMMdd") });
            parameter.DataList.Add("END_DATE", new string[] { Convert.ToDateTime(dteEND_DATE.EditValue).ToString("yyyyMMdd") });
            parameter.DataList.Add("LOGIN_USERID", new string[] { sUSERID });
            parameter.DataList.Add("ASGNNAME", new string[] { txtASGNNAME.Text });

            parameter.ArrayItemCount = 1;

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS006.SAVE_01", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("저장되었습니다.", "확인");

                this.DialogResult = System.Windows.Forms.DialogResult.OK;
                this.Close();
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 저장 - btnSave_Click

        #region 비밀번호 변경
        private void btnPassword_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MsgBox.Show("비밀번호를 입력하세요!", "경고"); return;
            }

            DataPack parameter = new DataPack();
            parameter.DataList.Add("USER_ID", new string[] { txtUser_Id.Text });
            parameter.DataList.Add("PASSWORD", new string[] { txtPassword.Text });
            parameter.DataList.Add("LOGIN_USERID", new string[] { sUSERID });

            parameter.ArrayItemCount = 1;

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS006.SAVE_02", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("변경되었습니다.", "확인");
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }

        }
        #endregion

        #region 닫기 - btnClose_Click
        /// <summary>
        /// 닫기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }
        #endregion 닫기 - btnClose_Click

        #region HHI 사용자 팝업 - btnHHIUserPopUp_Click
        /// <summary>
        /// HHI 사용자 팝업
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnHHIUserPopUp_Click(object sender, EventArgs e)
        {
            SCSYS006P2 scsys006p2 = new SCSYS006P2();

            if (scsys006p2.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if (scsys006p2.hdnRow != null)
                {
                    ClientControlHelper.CtrlNestedDataBind(scsys006p2.hdnRow, layoutControlGroup1);
                }
            }
        }
        #endregion HHI 사용자 팝업 - btnHHIUserPopUp_Click

        #region HHI 조직도 - btnDeptPopUp_Click
        /// <summary>
        /// HHI 조직도
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDeptPopUp_Click(object sender, EventArgs e)
        {
            SCSYS002P2 scsys002p2 = new SCSYS002P2();

            if (scsys002p2.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtDept_Cd.EditValue = scsys002p2.hdnDEPT_CD;
                txtDeptName.EditValue = scsys002p2.hdnDEPT_NM;
            }
        }
        #endregion HHI 조직도 - btnDeptPopUp_Click

        private void btnAsgnPopup_Click(object sender, EventArgs e)
        {
            SCSYS006P3 pop = new SCSYS006P3();
            pop.sDEPT_CD = txtDept_Cd.Text;

            if (pop.ShowDialog() == DialogResult.OK)
            {
                if (pop.hdnRow != null)
                {
                    ClientControlHelper.CtrlNestedDataBind(pop.hdnRow, layoutControlGroup1);
                }
            }
        }

        
    }
}
