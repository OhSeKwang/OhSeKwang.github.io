﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Views.Grid;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS008 : StdUserControlBase//UserControl
    {
        #region 생성자
        public SCSYS008()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }
        #endregion

        #region 화면 Load
        private void SCSYS008_Load(object sender, EventArgs e)
        {
           
        }
        #endregion

        #region SCSYS008_Shown
        private void SCSYS008_Shown(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                initPage();

                stdSecurityManager1.ApplySecurity(this.SecurityContext);
                stdButtonExecuteManager1.RegisterButtonExecEvent();
            }
        }
        #endregion

        #region 버튼 이벤트

        #region 신규
        private void btnNew_Click(object sender, EventArgs e)
        {
            DataTable dt = grdMaster.DataSource as DataTable;

            grvMaster.AddNewRow();
            DataRow dr = grvMaster.GetFocusedDataRow();

            grvMaster.SetFocusedRowCellValue("CHK", "Y");            
            grvMaster.SetFocusedRowCellValue("DIV", "A");
            

            grvMaster.UpdateCurrentRow();
            grvMaster.Focus();


        }
        #endregion
        
        #region 조회
        private void btnSearch_Click(object sender, EventArgs e)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("WORK_GUBUN", cboWORK_GUBUN.EditValue == null ? string.Empty : cboWORK_GUBUN.EditValue.ToString());
            parameter.DataList.Add("AUTH_ID", txtAUTH_ID.Text);
            parameter.DataList.Add("DESCRIPTION", txtDESCRIPTION.Text);

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS008.SEARCH_01", parameter);

            if (resultSet.IsSuccess)
            {
                grdMaster.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }

        }
        #endregion

        #region 저장
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("저장 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            if (grvMaster.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요....", "경고"); return; }

            if ((grdMaster.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            { MsgBox.Show("저장할 데이터를 선택하세요....", "경고"); return; }

            DataTable dtMaster = (grdMaster.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();

            string[] paramnames = new string[] { "AUTH_ID", "DESCRIPTION", "WORK_GUBUN", "LOGIN_USERID"};

            DataTable controlParamInfo = new DataTable("controlParamInfo");
            for (int cnt = 0; cnt < paramnames.Length; cnt++)
            {
                controlParamInfo.Columns.Add(paramnames[cnt]);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in controlParamInfo.Columns)
            {
                //if (!dtMaster.Columns.Contains(col.ColumnName))
                //    throw new Exception(string.Format("필드명{0}을 찾을 수 없습니다."));

                if (col.DataType.Equals(typeof(int)))
                {
                    int[] col1 = new int[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = 0;
                        }
                        else
                        {
                            col1[i] = int.Parse(string.IsNullOrWhiteSpace(dtMaster.Rows[i][col.ColumnName].ToString()) ? "0" : dtMaster.Rows[i][col.ColumnName].ToString());
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }
                else
                {
                    string[] col1 = new string[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (col.ColumnName.Equals("LOGIN_USERID"))
                        {
                            col1[i] = UserInfo == null ? "ADMIN" : UserInfo.UserID; // eve
                        }
                        else if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = string.Empty;
                        }                        
                        else
                        {
                            col1[i] = dtMaster.Rows[i][col.ColumnName].ToString();
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }

            }
            parameter.ArrayItemCount = dtMaster.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            if (ValidationRequired(true, false))
            {
                DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS008.SAVE_01", parameter);

                if (resultSet.IsSuccess)
                {
                    MsgBox.Show("저장되었습니다.", "확인");
                    btnSearch.PerformClick();
                }
                else
                {
                    MsgBox.Show(resultSet.ExceptionMessage);
                }
            }

        }
        #endregion

        #region 삭제
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("삭제 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }

            if (grvMaster.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요....", "경고"); return; }

            if ((grdMaster.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            { MsgBox.Show("삭제할 데이터를 선택하세요....", "경고"); return; }

            DataTable dtMaster = (grdMaster.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();

            string[] paramnames = new string[] { "AUTH_ID" };

            DataTable controlParamInfo = new DataTable("controlParamInfo");
            for (int cnt = 0; cnt < paramnames.Length; cnt++)
            {
                controlParamInfo.Columns.Add(paramnames[cnt], (grvMaster.GridControl.DataSource as DataTable).Columns[paramnames[cnt]].DataType);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in controlParamInfo.Columns)
            {


                if (!dtMaster.Columns.Contains(col.ColumnName))
                    throw new Exception(string.Format("필드명{0}을 찾을 수 없습니다."));

                if (col.DataType.Equals(typeof(int)))
                {
                    int[] col1 = new int[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = 0;
                        }
                        else
                        {
                            col1[i] = int.Parse(string.IsNullOrWhiteSpace(dtMaster.Rows[i][col.ColumnName].ToString()) ? "0" : dtMaster.Rows[i][col.ColumnName].ToString());
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }
                else
                {
                    string[] col1 = new string[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = string.Empty;
                        }
                        else
                        {
                            col1[i] = dtMaster.Rows[i][col.ColumnName].ToString();
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }

            }

            parameter.ArrayItemCount = dtMaster.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS008.DELETE_01", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("삭제되었습니다.", "확인");

                btnSearch.PerformClick();
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion

        #endregion

        #region 그리드 이벤트
        private void grvMaster_ShowingEditor(object sender, CancelEventArgs e)
        {
            DataRow row = grvMaster.GetFocusedDataRow();
            if (row != null)
            {
                string strFieldName = grvMaster.FocusedColumn.FieldName;
                if (strFieldName.Equals("WORK_GUBUN"))
                {
                    if (row["DIV"].ToString().Equals("S"))
                        e.Cancel = true;
                    else
                        e.Cancel = false;
                }
            }
        }

        private void grvMaster_CellValueChanging(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            GridView gridView = (sender as GridView);
            if (gridView != null)
            {

                DataRow row = gridView.GetDataRow(e.RowHandle);
                if (row != null)
                {
                    if (gridView.Columns["CHK"] != null && gridView.Columns["CHK"].ColumnEdit != null && gridView.Columns["CHK"].ColumnEdit is RepositoryItemCheckEdit)
                    {
                        RepositoryItemCheckEdit chkEdit = (gridView.Columns["CHK"].ColumnEdit as RepositoryItemCheckEdit);
                        row["CHK"] = chkEdit.ValueChecked;
                    }
                }
            }
        }
        #endregion

        #region 컨트롤 이벤트
        #endregion

        #region 메서드

        private void initPage()
        {
            // 콤보 바인딩
            ClientControlHelper.ImageComboBind(cboWORK_GUBUN, "CDNM", "CDCODE", "{value}-{text}", ComboDisplayTextOption.top, "전체", string.Empty, ClientControlHelper.GetCodeInfo("SY001"));

            // 그리드 콤보 바인딩
            ClientControlHelper.ImageComboBind(rpsCboWORK_GUBUN, "CDNM", "CDCODE", "{value}-{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, ClientControlHelper.GetCodeInfo("SY001"));

            cboWORK_GUBUN.Properties.DropDownRows = cboWORK_GUBUN.Properties.Items.Count;
            rpsCboWORK_GUBUN.DropDownRows = rpsCboWORK_GUBUN.Items.Count;

            // 그리드 초기화
            DataTable dt = new DataTable();
            dt.Columns.Add("CHK");
            dt.Columns.Add("AUTH_ID");
            dt.Columns.Add("DESCRIPTION");            
            dt.Columns.Add("DIV");

            grdMaster.DataSource = dt;

        }
        
        public bool ValidationRequired(bool IsMessagePrint, bool IsFocusedRowValidationCheck)
        {
            DataTable dt = (grdMaster.DataSource as DataTable);
            if (dt.Rows.Count == 0)
                return false;

            //ArrayList requiredColumns = GetRequiredColumns();
            ArrayList requiredColumns = new ArrayList();
            requiredColumns.Add("WORK_GUBUN");            
            
            
            //전체 DataRow에 대하여 Validation체크를 한다
            if (!IsFocusedRowValidationCheck)
            {
                //int RowCount = (grvMaster != null ? grvMaster.DataRowCount : InnerLayoutView.DataRowCount);
                int RowCount = grvMaster.DataRowCount;

                for (int i = 0; i < RowCount; i++)
                {
                    bool validationResult = RequiredValidationByRowHandle(IsMessagePrint, requiredColumns, i);

                    if (!validationResult)
                        return validationResult;
                }

                return true;
            }
            //else
            //{
            //    //int focusedRowHandle = (InnerGridView != null ? InnerGridView.FocusedRowHandle : InnerLayoutView.FocusedRowHandle);

            //    return RequiredValidationByRowHandle(IsMessagePrint, requiredColumns, focusedRowHandle);
            //}
            return false;
        }


        private bool RequiredValidationByRowHandle(bool IsMessagePrint, ArrayList requiredColumns, int rowIndex)
        {
            //DataRow row = (InnerGridView != null ? InnerGridView.GetDataRow(rowIndex) : InnerLayoutView.GetDataRow(rowIndex));
            DataRow row = grvMaster.GetDataRow(rowIndex);
            bool IsValidationCheck = false;

            //선택된 행에 대하여
            if (row["CHK"].ToString().Equals("Y"))
                IsValidationCheck = true;

            if (IsValidationCheck)
            {
                foreach (string fieldName in requiredColumns)
                {
                    if (row[fieldName].ToString().Equals(""))
                    {
                        if (IsMessagePrint)
                        {
                            //string colCaption = InnerGridView != null ? InnerGridView.Columns[fieldName].Caption : InnerLayoutView.Columns[fieldName].Caption;
                            string colCaption = grvMaster.Columns[fieldName].Caption;
                            string message = string.Format("{0}은는필수입력입니다", colCaption);

                            //MessageBoxHelper.HiproMessageBoxShow(message);
                            //MsgBox.Show(message);

                            if (grvMaster != null)
                            {
                                grvMaster.ClearColumnErrors();
                                grvMaster.FocusedRowHandle = rowIndex;
                                grvMaster.SetColumnError(grvMaster.Columns[fieldName], message);
                            }
                            else
                            {
                                //InnerLayoutView.ClearColumnErrors();
                                //InnerLayoutView.FocusedRowHandle = rowIndex;
                                //InnerLayoutView.SetColumnError(InnerLayoutView.Columns[fieldName], message);
                            }
                        }
                        return false;
                    }
                }
            }
            return true;
        }

        #endregion

       

    }
}
