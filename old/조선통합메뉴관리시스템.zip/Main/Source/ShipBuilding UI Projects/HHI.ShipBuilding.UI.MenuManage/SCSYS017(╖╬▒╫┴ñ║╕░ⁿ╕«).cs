﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Views.Grid;
using HHI.Windows.Forms;
using DevExpress.XtraGrid;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS017 : StdUserControlBase//UserControl
    {
        #region 생성자
        public SCSYS017()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }
        #endregion

        #region 화면 Load
        
        #endregion

        #region SCSYS017_Shown
        private void SCSYS017_Shown(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                initPage();

                stdSecurityManager1.ApplySecurity(this.SecurityContext);
                stdButtonExecuteManager1.RegisterButtonExecEvent();

            }
        }
        #endregion

        #region 버튼 이벤트

        #region 조회
        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (!stdValidationManager1.Validation())
            {
                return;
            }

            if (DateTime.Compare(Convert.ToDateTime(dteDATE_FROM.EditValue), Convert.ToDateTime(dteDATE_TO.EditValue)) > 0)
            {
                MsgBox.Show("날짜는 시작일자보다 커야합니다.", "경고"); return;
            }

            DataPack parameter = new DataPack();
            parameter.DataList.Add("USER_ID", txtUSER_ID.Text);
            parameter.DataList.Add("DATE_FROM", dteDATE_FROM.EditValue == null ? DateTime.Today.ToString("yyyyMMdd") : Convert.ToDateTime(dteDATE_FROM.EditValue).ToString("yyyyMMdd"));
            parameter.DataList.Add("DATE_TO", dteDATE_TO.EditValue == null ? DateTime.Today.ToString("yyyyMMdd") : Convert.ToDateTime(dteDATE_TO.EditValue).ToString("yyyyMMdd"));
            
            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS017.SEARCH_01", parameter);

            if (resultSet.IsSuccess)
            {
                grdMaster.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }

        }
        #endregion

       

        #endregion

        #region 그리드 이벤트
       
        #endregion

        #region 컨트롤 이벤트
        #endregion

        #region 메서드

        private void initPage()
        {
            // 콤보 바인딩
            
            dteDATE_FROM.EditValue = DateTime.Now.AddDays(-7);
            dteDATE_TO.EditValue = DateTime.Now;


            // 그리드 초기화
            DataTable dt = new DataTable();

            grvMaster.OptionsBehavior.AutoExpandAllGroups = true;

        }
        
        #endregion

    }
}
