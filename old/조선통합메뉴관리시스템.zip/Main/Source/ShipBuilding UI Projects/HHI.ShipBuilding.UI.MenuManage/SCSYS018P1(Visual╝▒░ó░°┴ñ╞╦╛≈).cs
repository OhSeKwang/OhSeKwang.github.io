﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;

namespace HHI.ShipBuilding.UI.MenuManage
{
    public partial class SCSYS018P1 : DevExpress.XtraEditors.XtraForm
    {
        public AxSHDocVw.AxWebBrowser WebBrower
        {
            get
            {
                return axWebBrowser1;
            }
        }

        public SCSYS018P1()
        {
            InitializeComponent();
        }
        private void SCSYS018P1_Load(object sender, EventArgs e)
        {
            initPage();
        }

        #region 화면 초기화 - initPage
        /// <summary>
        /// 화면 초기화
        /// </summary>
        private void initPage()
        {
            string strUrl = axWebBrowser1.LocationURL;
        }
        #endregion 화면 초기화 - initPage

        #region 닫기 - btnClose_Click
        /// <summary>
        /// 닫기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }
        #endregion 닫기 - btnClose_Click

        private void axWebBrowser1_NavigateComplete2(object sender, AxSHDocVw.DWebBrowserEvents2_NavigateComplete2Event e)
        {
            // http://hiport.hhi.co.kr/irj/servlet/prt/portal/prtroot/com.sap.portal.appintegrator.sap.Transaction?System=sapr3_sa&TCode=ZSPCO001&GuiType=WinGui&WinGui_Type=SSD&OkCode=ONLI&AutoStart=true&
            //ApplicationParameter=ZTCODE=ZPSCR212;P_PERNR=;BLK_NO=PSPID-2564,BLKNO-F31A0,TCODE-ZPPCR520A;
            
            string strUrl = e.uRL.ToString();
            if (strUrl.IndexOf(@"http://hiport.hhi.co.kr/irj/servlet/prt/portal/prtroot/com") != -1)
            {
                string strTmpUrl = strUrl.Substring(strUrl.LastIndexOf("ApplicationParameter="));
                strTmpUrl = strTmpUrl.Replace("ApplicationParameter=", string.Empty);

                string strTCode = string.Empty; //strUrl.Substring(strUrl.LastIndexOf("TCODE")).Replace("TCODE-", string.Empty).Replace(";", string.Empty);
                string strAddParam = string.Empty;

                string[] arrTmp = strTmpUrl.Split(';');
                foreach (string strTmp in arrTmp)
                {
                    // TCODE 채번
                    if (strTmp.IndexOf("ZTCODE") != -1)
                    {
                        strTCode = strTmp.Split('=').Length > 0 ? strTmp.Split('=')[1] : string.Empty;
                    }
                    else
                    {
                        if (strTmp.IndexOf("P_PERNR=") == -1)
                        {
                            if (!string.IsNullOrWhiteSpace(strTmp))
                            {
                                strAddParam += strTmp + ";";
                            }
                        }
                    }
                }

                string strSAP_Url = HHI.Configuration.AppSectionFactory.AppSection["BIZSAP_GUI"].ToString();

                if (string.IsNullOrWhiteSpace(strTCode))
                {
                    strSAP_Url += string.Format(@"?TCODE={0}", "HIPORT");
                }
                else
                {
                    strSAP_Url += string.Format(@"?TCODE={0}&ADDPARAM={1}", strTCode, strAddParam);
                }

                object obj = null;
                axWebBrowser1.Navigate(strSAP_Url, ref obj, ref obj, ref obj, ref obj);
            }
        }
    }
}
