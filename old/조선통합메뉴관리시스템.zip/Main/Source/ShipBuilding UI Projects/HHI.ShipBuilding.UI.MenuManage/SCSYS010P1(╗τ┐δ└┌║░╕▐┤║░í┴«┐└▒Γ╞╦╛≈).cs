﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Views.Grid;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS010P1 : StdUserControlBase//UserControl
    {
        #region 생성자 밑 전역변수
        public SCSYS010P1()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }

        public string sUSER_ID = string.Empty;

        public string sGUBUN = "N";  // 더블클릭시 'Y' 변경

        #endregion

        #region 화면 Load
       
        #endregion

        #region SCSYS010P1_Shown
        private void SCSYS010P1_Shown(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                initPage();

                stdSecurityManager1.ApplySecurity(this.SecurityContext);
                stdButtonExecuteManager1.RegisterButtonExecEvent();

                btnSearch.PerformClick();
            }
        }
        #endregion

        #region 버튼 이벤트

        #region 조회
        private void btnSearch_Click(object sender, EventArgs e)
        {

            tabbedControlGroup1_SelectedPageChanged(null, null);

        }
        #endregion

        #region 닫기
        private void btnClose_Click(object sender, EventArgs e)
        {
            StdPopupHost popuphost = (StdPopupHost)this.Parent.Parent;
            popuphost.Close();
        }
        #endregion

        #endregion

        #region 그리드 이벤트
        
       
        #endregion

        #region 컨트롤 이벤트
        #endregion

        #region 메서드

        private void initPage()
        {                        
            
        }
        
        private void GetMenu()
        {
            try
            {
                treeList1.BeginUnboundLoad();
                treeList1.ClearNodes();

                if (!stdValidationManager1.Validation())
                {
                    return;
                }

                string sQueryId = "MENUMANGE.SCSYS010.SEARCH_04";

                DataPack parameter = new DataPack();
                parameter.DataList.Add("USER_ID", sUSER_ID);

                DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, sQueryId, parameter);

                if (resultSet.IsSuccess)
                {
                    treeList1.DataSource = resultSet.QuerySet.Tables[0];
                    treeList1.RefreshDataSource();

                }
                else
                {
                    MsgBox.Show(resultSet.ExceptionMessage);
                }
            }
            catch (Exception ex)
            {
                MsgBox.Show(ex.Message);
            }
            finally
            {
                treeList1.EndUnboundLoad();
            }

        }

        private void GetSAPMenu()
        {
            string strQueryId = "MENUMANGE.SCCOMMON.SCCOMMON_SEARCH_TCODE";

            DataPack parameter = new DataPack();
            parameter.DataList.Add("USERID", sUSER_ID);

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, strQueryId, parameter);
            if (resultSet.IsSuccess)
            {
                this.Invoke(new MethodInvoker(
                    delegate()
                    {
                        treeList2.DataSource = resultSet.QuerySet.Tables[0];
                    }));                
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion

        private void tabbedControlGroup1_SelectedPageChanged(object sender, DevExpress.XtraLayout.LayoutTabPageChangedEventArgs e)
        {
            if (tabbedControlGroup1.SelectedTabPageIndex.Equals(0))
            {
                GetMenu();
            }
            else
            {
                GetSAPMenu();
            }
        }

        
    }
}
