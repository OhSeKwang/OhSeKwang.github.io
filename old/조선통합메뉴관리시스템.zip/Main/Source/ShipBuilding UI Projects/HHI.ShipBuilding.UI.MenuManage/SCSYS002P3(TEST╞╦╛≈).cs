﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;

using DevExpress.XtraGrid.Views.Grid;

namespace HHI.ShipBuilding.UI.MenuManage
{
    //[ToolboxItem(true)]
    public partial class SCSYS002P3 : StdUserControlBase
    {
        #region 생성자 및 변수 선언
        public SCSYS002P3()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }

        #endregion

        #region 화면 Load - SCSYS002P3_Load
        /// <summary>
        /// 화면 Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SCSYS002P3_Load(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                initPage();

                stdSecurityManager1.ApplySecurity(this.SecurityContext);
            }
        }
        #endregion 화면 Load - SCSYS002P3_Load

        #region 화면 초기화 - initPage
        /// <summary>
        /// 화면 초기화
        /// </summary>
        private void initPage()
        {
            ClientControlHelper.ImageComboBind(rpsCboWORK_GUBUN, "CDNM", "CDCODE", "{value}-{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, ClientControlHelper.GetCodeInfo("SY001"));
            ClientControlHelper.ImageComboBind(cboWORK_GUBUN, "CDNM", "CDCODE", "{value}-{text}", ComboDisplayTextOption.top, "전체", string.Empty, ClientControlHelper.GetCodeInfo("SY001"));
            ClientControlHelper.ImageComboBind(cboSYSTEM_CODE, "SYSTEM_NAME", "SYSTEM_CODE", "{value}-{text}", ComboDisplayTextOption.top, "전체", string.Empty, GetSystemCode());
            ClientControlHelper.ImageComboBind(rpsCboSYSTEM_CODE, "SYSTEM_NAME", "SYSTEM_CODE", "{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, GetSystemCode());
            cboWORK_GUBUN.Properties.DropDownRows = cboWORK_GUBUN.Properties.Items.Count;
        
        }
        #endregion 화면 초기화 - initPage

        #region 버튼 이벤트

        #region 신규 - btnNew_Click
        /// <summary>
        /// 신규
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNew_Click(object sender, EventArgs e)
        {
            SCSYS002P1 scsys002p1 = new SCSYS002P1();

            scsys002p1.sLOGIN_USERID = UserInfo == null ? "ADMIN" : UserInfo.UserID; // eve

            if (scsys002p1.ShowDialog() == DialogResult.OK)
            {
                //btnSearch.PerformClick();
            }
        }
        #endregion 신규 - btnNew_Click

        #region 조회 - btnSearch_Click
        /// <summary>
        /// 조회
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string SYSTEM_CODE  = cboSYSTEM_CODE.EditValue == null ? string.Empty : cboSYSTEM_CODE.EditValue.ToString();
            string WORK_GUBUN = cboWORK_GUBUN.EditValue == null ? string.Empty : cboWORK_GUBUN.EditValue.ToString();

            DataResultSet resultSet = GetGroupInfo(SYSTEM_CODE, WORK_GUBUN, txtGroup_Name.Text, txtDescr.Text);

            if (resultSet.IsSuccess)
            {
                grdGroup.DataSource = resultSet.QuerySet.Tables[0];

                grvGroup_DoubleClick(null, null);
            }
            else
            {
                MessageBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 조회 - btnSearch_Click

        #region 삭제 - btnDelete_Click
        /// <summary>
        /// 삭제
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("삭제 하시겠습니까?", "경고", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }

            if (grvUser.RowCount == 0)
            {
                MessageBox.Show("삭제할 정보가 없습니다.");
                return;
            }

            if ((grdUser.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            {
                MessageBox.Show("삭제할 정보를 선택하세요!");
                return;
            }

            DataTable dtMain = (grdUser.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();
            string[] paramnames = new string[] { "USER_ID", "GROUP_ID" };

            DataTable dtParam = new DataTable();
            for (int i = 0; i < paramnames.Length; i++)
            {
                dtParam.Columns.Add(paramnames[i]);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in dtParam.Columns)
            {
                string[] col1 = new string[dtMain.Rows.Count];
                for (int i = 0; i < dtMain.Rows.Count; i++)
                {
                    col1[i] = dtMain.Rows[i][col.ColumnName].ToString();
                }

                parameter.DataList.Add(col.ColumnName, col1);
            }

            parameter.ArrayItemCount = dtMain.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS002.DELETE_01", parameter);

            if (resultSet.IsSuccess)
            {
                MessageBox.Show("삭제 되었습니다.");
                btnSearch.PerformClick();
            }
            else
            {
                MessageBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 삭제 - btnDelete_Click

        #endregion

        #region 그리드 이벤트

        #region 그룹정보 더블 클릭 - grvGroup_DoubleClick
        /// <summary>
        /// 그룹정보 더블 클릭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void grvGroup_DoubleClick(object sender, EventArgs e)
        {
            DataRow row = grvGroup.GetFocusedDataRow();
            if (row == null)
            {
                emtGroupInfo.Text = string.Format(@"그룹정보 :");
                if (grvUser.DataSource != null && (grdUser.DataSource is DataTable))
                    (grdUser.DataSource as DataTable).Rows.Clear(); 
                return;
            }

            emtGroupInfo.Text = string.Format(@"그룹정보 : {0} - {1}", row["GROUP_ID"].ToString(), row["GROUP_NAME"].ToString());

            DataResultSet resultSet = GetUserGroupInfo(row["GROUP_ID"].ToString());

            if (resultSet.IsSuccess)
            {
                grdUser.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MessageBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 그룹정보 더블 클릭 - grvGroup_DoubleClick

        #endregion

        #region 메서드

        #region 그룹정보 조회 - GetGroupInfo
        /// <summary>
        /// 그룹정보 조회
        /// </summary>
        /// <param name="strGroup_Nm"></param>
        /// <param name="strDescr"></param>
        /// <returns></returns>
        private DataResultSet GetGroupInfo(string strSYSTEM_CODE, string strWORK_GUBUN, string strGroup_Nm, string strDescr)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("SYSTEM_CODE", strSYSTEM_CODE);
            parameter.DataList.Add("WORK_GUBUN", strWORK_GUBUN);
            parameter.DataList.Add("GROUP_NAME", strGroup_Nm);
            parameter.DataList.Add("DESCR", strDescr);
            parameter.DataList.Add("USE_YN", "Y");

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS002.SEARCH_01", parameter);
        }
        #endregion 그룹정보 조회 - GetGroupInfo

        #region 그룹사용자 조회 - GetUserGroupInfo
        /// <summary>
        /// 그룹사용자 조회
        /// </summary>
        /// <param name="strGroup_Id"></param>
        /// <returns></returns>
        private DataResultSet GetUserGroupInfo(string strGroup_Id)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("GROUP_ID", strGroup_Id);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS002.SEARCH_02", parameter);
        }
        #endregion 그룹사용자 조회 - GetUserGroupInfo

        /// <summary>
        /// 시스템코드조회
        /// </summary>
        /// <returns></returns>
        private DataTable GetSystemCode()
        {
            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCCOMMON.SEARCH_SYSTEM").QuerySet.Tables[0];
        }

        #endregion

    }
}
