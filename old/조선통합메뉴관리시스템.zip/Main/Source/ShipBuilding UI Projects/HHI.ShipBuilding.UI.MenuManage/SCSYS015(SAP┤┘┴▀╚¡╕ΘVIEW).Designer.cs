﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS015
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SCSYS015));
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.btnAddMyMenu = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.xtraLabelExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLabelExt();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.btnRun = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.txtTCODE = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTCODE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.btnAddMyMenu);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraLabelExt1);
            this.xtraLayoutControlExt1.Controls.Add(this.xtraTabControl1);
            this.xtraLayoutControlExt1.Controls.Add(this.btnRun);
            this.xtraLayoutControlExt1.Controls.Add(this.txtTCODE);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(742, 395, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(1116, 747);
            this.xtraLayoutControlExt1.TabIndex = 0;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // btnAddMyMenu
            // 
            this.btnAddMyMenu.Image = ((System.Drawing.Image)(resources.GetObject("btnAddMyMenu.Image")));
            this.btnAddMyMenu.IsExecuteWdworkerLog = true;
            this.btnAddMyMenu.Location = new System.Drawing.Point(323, 24);
            this.btnAddMyMenu.Name = "btnAddMyMenu";
            this.btnAddMyMenu.Size = new System.Drawing.Size(110, 22);
            this.btnAddMyMenu.StyleController = this.xtraLayoutControlExt1;
            this.btnAddMyMenu.TabIndex = 30;
            this.btnAddMyMenu.Text = "내 메뉴에 추가";
            this.btnAddMyMenu.UseSplasher = false;
            this.btnAddMyMenu.Click += new System.EventHandler(this.btnAddMyMenu_Click);
            // 
            // xtraLabelExt1
            // 
            this.xtraLabelExt1.Appearance.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.ico_circle_blue;
            this.xtraLabelExt1.IsTransparent = false;
            this.xtraLabelExt1.Key = "";
            this.xtraLabelExt1.Location = new System.Drawing.Point(24, 24);
            this.xtraLabelExt1.MinLength = 0;
            this.xtraLabelExt1.Name = "xtraLabelExt1";
            this.xtraLabelExt1.Padding = new System.Windows.Forms.Padding(0, 4, 0, 0);
            this.xtraLabelExt1.Size = new System.Drawing.Size(16, 19);
            this.xtraLabelExt1.StyleController = this.xtraLayoutControlExt1;
            this.xtraLabelExt1.TabIndex = 29;
            this.xtraLabelExt1.Text = "    ";
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.ClosePageButtonShowMode = DevExpress.XtraTab.ClosePageButtonShowMode.InActiveTabPageHeader;
            this.xtraTabControl1.HeaderButtons = ((DevExpress.XtraTab.TabButtons)((DevExpress.XtraTab.TabButtons.Close | DevExpress.XtraTab.TabButtons.Default)));
            this.xtraTabControl1.Location = new System.Drawing.Point(24, 50);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.Size = new System.Drawing.Size(1068, 673);
            this.xtraTabControl1.TabIndex = 28;
            this.xtraTabControl1.CloseButtonClick += new System.EventHandler(this.xtraTabControl1_CloseButtonClick);
            // 
            // btnRun
            // 
            this.btnRun.IsExecuteWdworkerLog = true;
            this.btnRun.Location = new System.Drawing.Point(209, 24);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(96, 22);
            this.btnRun.StyleController = this.xtraLayoutControlExt1;
            this.btnRun.TabIndex = 27;
            this.btnRun.Text = "실행";
            this.btnRun.UseSplasher = false;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // txtTCODE
            // 
            this.txtTCODE.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtTCODE.EditValue = "";
            this.txtTCODE.EnterExecuteButton = null;
            this.txtTCODE.FocusColor = System.Drawing.Color.Empty;
            this.txtTCODE.IsValueTrim = true;
            this.txtTCODE.Key = "";
            this.txtTCODE.Location = new System.Drawing.Point(44, 24);
            this.txtTCODE.MinLength = 0;
            this.txtTCODE.Name = "txtTCODE";
            this.txtTCODE.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtTCODE.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtTCODE.Properties.Appearance.Options.UseBackColor = true;
            this.txtTCODE.Properties.Appearance.Options.UseForeColor = true;
            this.txtTCODE.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTCODE.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtTCODE.Size = new System.Drawing.Size(161, 20);
            this.txtTCODE.StyleController = this.xtraLayoutControlExt1;
            this.txtTCODE.TabIndex = 26;
            this.txtTCODE.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.txtTCODE.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtTCODE_KeyDown);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "layoutControlGroup1";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup2});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1116, 747);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.CaptionImage = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Grouup_tit_ico;
            this.layoutControlGroup2.CustomizationFormText = "List";
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.emptySpaceItem1,
            this.layoutControlItem2,
            this.layoutControlItem3,
            this.layoutControlItem4,
            this.layoutControlItem5,
            this.emptySpaceItem2});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(1096, 727);
            this.layoutControlGroup2.Text = "SAP VIEW";
            this.layoutControlGroup2.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.txtTCODE;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(20, 0);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(165, 26);
            this.layoutControlItem1.Text = " ";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(413, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(659, 26);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.btnRun;
            this.layoutControlItem2.CustomizationFormText = "layoutControlItem2";
            this.layoutControlItem2.Location = new System.Drawing.Point(185, 0);
            this.layoutControlItem2.MaxSize = new System.Drawing.Size(100, 26);
            this.layoutControlItem2.MinSize = new System.Drawing.Size(100, 26);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(100, 26);
            this.layoutControlItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextVisible = false;
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.xtraTabControl1;
            this.layoutControlItem3.CustomizationFormText = "layoutControlItem3";
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(1072, 677);
            this.layoutControlItem3.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem3.TextVisible = false;
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.xtraLabelExt1;
            this.layoutControlItem4.CustomizationFormText = "layoutControlItem4";
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(20, 26);
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextVisible = false;
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.btnAddMyMenu;
            this.layoutControlItem5.Location = new System.Drawing.Point(299, 0);
            this.layoutControlItem5.MaxSize = new System.Drawing.Size(114, 26);
            this.layoutControlItem5.MinSize = new System.Drawing.Size(114, 26);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(114, 26);
            this.layoutControlItem5.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem5.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem5.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.Location = new System.Drawing.Point(285, 0);
            this.emptySpaceItem2.MaxSize = new System.Drawing.Size(14, 26);
            this.emptySpaceItem2.MinSize = new System.Drawing.Size(14, 26);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(14, 26);
            this.emptySpaceItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // SCSYS015
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS015";
            this.Size = new System.Drawing.Size(1116, 747);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTCODE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private Client.Controls.DXperience.XtraButtonExt btnRun;
        private Client.Controls.DXperience.XtraTextEditExt txtTCODE;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private Client.Controls.DXperience.XtraLabelExt xtraLabelExt1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private Client.Controls.DXperience.XtraButtonExt btnAddMyMenu;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
    }
}
