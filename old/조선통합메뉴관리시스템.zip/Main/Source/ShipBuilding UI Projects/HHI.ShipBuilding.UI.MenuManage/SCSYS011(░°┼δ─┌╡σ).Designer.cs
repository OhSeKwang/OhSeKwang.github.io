﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS011
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SCSYS011));
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.cboCODEGRP = new HHI.ShipBuilding.Client.Controls.DXperience.XtraImageComboBoxEditExt();
            this.btnGroupAdd = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnGroupSave = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnGroupDelete = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnCodeAdd = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnCodeSave = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnCodeDelete = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.grdCode = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvCode = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpychkYN = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsTextUpp10_2 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.grdGroup = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvGroup = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpyChk = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.colCODEGRP = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboCODEGRP = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsTextUpp10_1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.txtGroup_Nm = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtGroup_Id = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnSearch = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.empGroupInfo = new DevExpress.XtraLayout.EmptySpaceItem();
            this.splitterItem2 = new DevExpress.XtraLayout.SplitterItem();
            this.layoutControlGroup4 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.stdButtonExecuteManager1 = new HHI.ShipBuilding.Controls.StdButtonExecuteManager(this.components);
            this.stdSecurityManager1 = new HHI.ShipBuilding.Windows.Forms.StdSecurityManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboCODEGRP.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkYN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsTextUpp10_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpyChk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboCODEGRP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsTextUpp10_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGroup_Nm.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGroup_Id.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.empGroupInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.cboCODEGRP);
            this.xtraLayoutControlExt1.Controls.Add(this.btnGroupAdd);
            this.xtraLayoutControlExt1.Controls.Add(this.btnGroupSave);
            this.xtraLayoutControlExt1.Controls.Add(this.btnGroupDelete);
            this.xtraLayoutControlExt1.Controls.Add(this.btnCodeAdd);
            this.xtraLayoutControlExt1.Controls.Add(this.btnCodeSave);
            this.xtraLayoutControlExt1.Controls.Add(this.btnCodeDelete);
            this.xtraLayoutControlExt1.Controls.Add(this.grdCode);
            this.xtraLayoutControlExt1.Controls.Add(this.grdGroup);
            this.xtraLayoutControlExt1.Controls.Add(this.txtGroup_Nm);
            this.xtraLayoutControlExt1.Controls.Add(this.txtGroup_Id);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearch);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(482, 529, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(1000, 600);
            this.xtraLayoutControlExt1.TabIndex = 2;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // cboCODEGRP
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.cboCODEGRP, new string[] {
            "INSERT"});
            this.cboCODEGRP.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.cboCODEGRP.EditValue = "";
            this.cboCODEGRP.EnterExecuteButton = null;
            this.cboCODEGRP.FocusColor = System.Drawing.Color.Empty;
            this.cboCODEGRP.Key = "";
            this.cboCODEGRP.Location = new System.Drawing.Point(104, 59);
            this.cboCODEGRP.MinLength = 0;
            this.cboCODEGRP.Name = "cboCODEGRP";
            this.cboCODEGRP.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.cboCODEGRP.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.cboCODEGRP.Properties.Appearance.Options.UseBackColor = true;
            this.cboCODEGRP.Properties.Appearance.Options.UseForeColor = true;
            this.cboCODEGRP.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboCODEGRP.Size = new System.Drawing.Size(132, 20);
            this.cboCODEGRP.StyleController = this.xtraLayoutControlExt1;
            this.cboCODEGRP.TabIndex = 24;
            // 
            // btnGroupAdd
            // 
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnGroupAdd, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnGroupAdd, false);
            this.btnGroupAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnGroupAdd.Image")));
            this.btnGroupAdd.IsExecuteWdworkerLog = true;
            this.btnGroupAdd.Location = new System.Drawing.Point(169, 132);
            this.btnGroupAdd.Name = "btnGroupAdd";
            this.btnGroupAdd.Size = new System.Drawing.Size(71, 22);
            this.btnGroupAdd.StyleController = this.xtraLayoutControlExt1;
            this.btnGroupAdd.TabIndex = 23;
            this.btnGroupAdd.Text = "행추가";
            this.btnGroupAdd.UseSplasher = false;
            this.btnGroupAdd.Click += new System.EventHandler(this.btnGroupAdd_Click);
            // 
            // btnGroupSave
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnGroupSave, new string[] {
            "UPDATE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnGroupSave, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnGroupSave, false);
            this.btnGroupSave.Image = ((System.Drawing.Image)(resources.GetObject("btnGroupSave.Image")));
            this.btnGroupSave.IsExecuteWdworkerLog = true;
            this.btnGroupSave.Location = new System.Drawing.Point(244, 132);
            this.btnGroupSave.Name = "btnGroupSave";
            this.btnGroupSave.Size = new System.Drawing.Size(71, 22);
            this.btnGroupSave.StyleController = this.xtraLayoutControlExt1;
            this.btnGroupSave.TabIndex = 22;
            this.btnGroupSave.Text = "저장";
            this.btnGroupSave.UseSplasher = true;
            this.btnGroupSave.Click += new System.EventHandler(this.btnGroupSave_Click);
            // 
            // btnGroupDelete
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnGroupDelete, new string[] {
            "DELETE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnGroupDelete, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnGroupDelete, false);
            this.btnGroupDelete.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_삭제;
            this.btnGroupDelete.IsExecuteWdworkerLog = true;
            this.btnGroupDelete.Location = new System.Drawing.Point(319, 132);
            this.btnGroupDelete.Name = "btnGroupDelete";
            this.btnGroupDelete.Size = new System.Drawing.Size(71, 22);
            this.btnGroupDelete.StyleController = this.xtraLayoutControlExt1;
            this.btnGroupDelete.TabIndex = 21;
            this.btnGroupDelete.Text = "삭제";
            this.btnGroupDelete.UseSplasher = true;
            this.btnGroupDelete.Click += new System.EventHandler(this.btnGroupDelete_Click);
            // 
            // btnCodeAdd
            // 
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnCodeAdd, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnCodeAdd, false);
            this.btnCodeAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnCodeAdd.Image")));
            this.btnCodeAdd.IsExecuteWdworkerLog = true;
            this.btnCodeAdd.Location = new System.Drawing.Point(755, 132);
            this.btnCodeAdd.Name = "btnCodeAdd";
            this.btnCodeAdd.Size = new System.Drawing.Size(71, 22);
            this.btnCodeAdd.StyleController = this.xtraLayoutControlExt1;
            this.btnCodeAdd.TabIndex = 20;
            this.btnCodeAdd.Text = "행추가";
            this.btnCodeAdd.UseSplasher = false;
            this.btnCodeAdd.Click += new System.EventHandler(this.btnCodeAdd_Click);
            // 
            // btnCodeSave
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnCodeSave, new string[] {
            "UPDATE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnCodeSave, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnCodeSave, false);
            this.btnCodeSave.Image = ((System.Drawing.Image)(resources.GetObject("btnCodeSave.Image")));
            this.btnCodeSave.IsExecuteWdworkerLog = true;
            this.btnCodeSave.Location = new System.Drawing.Point(830, 132);
            this.btnCodeSave.Name = "btnCodeSave";
            this.btnCodeSave.Size = new System.Drawing.Size(71, 22);
            this.btnCodeSave.StyleController = this.xtraLayoutControlExt1;
            this.btnCodeSave.TabIndex = 19;
            this.btnCodeSave.Text = "저장";
            this.btnCodeSave.UseSplasher = true;
            this.btnCodeSave.Click += new System.EventHandler(this.btnCodeSave_Click);
            // 
            // btnCodeDelete
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnCodeDelete, new string[] {
            "DELETE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnCodeDelete, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnCodeDelete, false);
            this.btnCodeDelete.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_삭제;
            this.btnCodeDelete.IsExecuteWdworkerLog = true;
            this.btnCodeDelete.Location = new System.Drawing.Point(905, 132);
            this.btnCodeDelete.Name = "btnCodeDelete";
            this.btnCodeDelete.Size = new System.Drawing.Size(71, 22);
            this.btnCodeDelete.StyleController = this.xtraLayoutControlExt1;
            this.btnCodeDelete.TabIndex = 18;
            this.btnCodeDelete.Text = "삭제";
            this.btnCodeDelete.UseSplasher = true;
            this.btnCodeDelete.Click += new System.EventHandler(this.btnCodeDelete_Click);
            // 
            // grdCode
            // 
            this.grdCode.CheckBoxFieldName = "CHK";
            this.grdCode.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdCode.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdCode.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdCode.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdCode.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default_ButtonAppend;
            this.grdCode.IsHeaderClickAllCheckedItem = true;
            this.grdCode.Location = new System.Drawing.Point(423, 158);
            this.grdCode.MainView = this.grvCode;
            this.grdCode.MinLength = 0;
            this.grdCode.Name = "grdCode";
            this.grdCode.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpychkYN,
            this.rpsTextUpp10_2});
            this.grdCode.Size = new System.Drawing.Size(553, 418);
            this.grdCode.TabIndex = 11;
            this.grdCode.UseEmbeddedNavigator = true;
            this.grdCode.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvCode});
            // 
            // grvCode
            // 
            this.grvCode.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn8});
            this.grvCode.GridControl = this.grdCode;
            this.grvCode.Name = "grvCode";
            this.grvCode.OptionsView.ColumnAutoWidth = false;
            this.grvCode.OptionsView.ShowGroupPanel = false;
            this.grvCode.ShowingEditor += new System.ComponentModel.CancelEventHandler(this.grvCode_ShowingEditor);
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.Caption = "선택";
            this.gridColumn4.ColumnEdit = this.rpychkYN;
            this.gridColumn4.FieldName = "CHK";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.AllowSort = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 0;
            this.gridColumn4.Width = 35;
            // 
            // rpychkYN
            // 
            this.rpychkYN.AutoHeight = false;
            this.rpychkYN.Caption = "Check";
            this.rpychkYN.Name = "rpychkYN";
            this.rpychkYN.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpychkYN.ValueChecked = "Y";
            this.rpychkYN.ValueUnchecked = "N";
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.Caption = "코드";
            this.gridColumn5.ColumnEdit = this.rpsTextUpp10_2;
            this.gridColumn5.FieldName = "CDCODE";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 1;
            this.gridColumn5.Width = 100;
            // 
            // rpsTextUpp10_2
            // 
            this.rpsTextUpp10_2.AutoHeight = false;
            this.rpsTextUpp10_2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.rpsTextUpp10_2.MaxLength = 10;
            this.rpsTextUpp10_2.Name = "rpsTextUpp10_2";
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.Caption = "코드명1";
            this.gridColumn6.FieldName = "CDNM";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 2;
            this.gridColumn6.Width = 150;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.Caption = "코드명2";
            this.gridColumn7.FieldName = "CDNM2";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 3;
            this.gridColumn7.Width = 150;
            // 
            // gridColumn8
            // 
            this.gridColumn8.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.Caption = "순번";
            this.gridColumn8.FieldName = "SORTCOL";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 4;
            // 
            // grdGroup
            // 
            this.grdGroup.CheckBoxFieldName = "CHK";
            this.grdGroup.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdGroup.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdGroup.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdGroup.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdGroup.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdGroup.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdGroup.IsHeaderClickAllCheckedItem = true;
            this.grdGroup.Location = new System.Drawing.Point(24, 158);
            this.grdGroup.MainView = this.grvGroup;
            this.grdGroup.MinLength = 0;
            this.grdGroup.Name = "grdGroup";
            this.grdGroup.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpyChk,
            this.rpsTextUpp10_1,
            this.rpsCboCODEGRP});
            this.grdGroup.Size = new System.Drawing.Size(366, 418);
            this.grdGroup.TabIndex = 17;
            this.grdGroup.UseEmbeddedNavigator = true;
            this.grdGroup.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvGroup});
            // 
            // grvGroup
            // 
            this.grvGroup.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.colCODEGRP,
            this.gridColumn2,
            this.gridColumn3});
            this.grvGroup.GridControl = this.grdGroup;
            this.grvGroup.Name = "grvGroup";
            this.grvGroup.OptionsView.ColumnAutoWidth = false;
            this.grvGroup.OptionsView.ShowGroupPanel = false;
            this.grvGroup.ShowingEditor += new System.ComponentModel.CancelEventHandler(this.grvGroup_ShowingEditor);
            this.grvGroup.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.grvGroup_FocusedRowChanged);
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "선택";
            this.gridColumn1.ColumnEdit = this.rpyChk;
            this.gridColumn1.FieldName = "CHK";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 35;
            // 
            // rpyChk
            // 
            this.rpyChk.AutoHeight = false;
            this.rpyChk.Caption = "Check";
            this.rpyChk.Name = "rpyChk";
            this.rpyChk.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpyChk.ValueChecked = "Y";
            this.rpyChk.ValueUnchecked = "N";
            // 
            // colCODEGRP
            // 
            this.colCODEGRP.AppearanceHeader.Options.UseTextOptions = true;
            this.colCODEGRP.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colCODEGRP.Caption = "대분류코드";
            this.colCODEGRP.ColumnEdit = this.rpsCboCODEGRP;
            this.colCODEGRP.FieldName = "CODEGRP";
            this.colCODEGRP.Name = "colCODEGRP";
            this.colCODEGRP.Visible = true;
            this.colCODEGRP.VisibleIndex = 1;
            this.colCODEGRP.Width = 92;
            // 
            // rpsCboCODEGRP
            // 
            this.rpsCboCODEGRP.AutoHeight = false;
            this.rpsCboCODEGRP.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboCODEGRP.Name = "rpsCboCODEGRP";
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "분류 코드";
            this.gridColumn2.ColumnEdit = this.rpsTextUpp10_1;
            this.gridColumn2.FieldName = "CDCLSS";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.OptionsColumn.ReadOnly = true;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 2;
            this.gridColumn2.Width = 79;
            // 
            // rpsTextUpp10_1
            // 
            this.rpsTextUpp10_1.AutoHeight = false;
            this.rpsTextUpp10_1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.rpsTextUpp10_1.MaxLength = 10;
            this.rpsTextUpp10_1.Name = "rpsTextUpp10_1";
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.Caption = "분류 코드명";
            this.gridColumn3.FieldName = "CDNM";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 3;
            this.gridColumn3.Width = 150;
            // 
            // txtGroup_Nm
            // 
            this.txtGroup_Nm.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtGroup_Nm.EditValue = "";
            this.txtGroup_Nm.EnterExecuteButton = null;
            this.txtGroup_Nm.FocusColor = System.Drawing.Color.Empty;
            this.txtGroup_Nm.IsValueTrim = true;
            this.txtGroup_Nm.Key = "CDNM";
            this.txtGroup_Nm.Location = new System.Drawing.Point(577, 59);
            this.txtGroup_Nm.MinLength = 0;
            this.txtGroup_Nm.Name = "txtGroup_Nm";
            this.txtGroup_Nm.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtGroup_Nm.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtGroup_Nm.Properties.Appearance.Options.UseBackColor = true;
            this.txtGroup_Nm.Properties.Appearance.Options.UseForeColor = true;
            this.txtGroup_Nm.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGroup_Nm.Size = new System.Drawing.Size(231, 20);
            this.txtGroup_Nm.StyleController = this.xtraLayoutControlExt1;
            this.txtGroup_Nm.TabIndex = 15;
            this.txtGroup_Nm.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtGroup_Id
            // 
            this.txtGroup_Id.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtGroup_Id.EditValue = "";
            this.txtGroup_Id.EnterExecuteButton = null;
            this.txtGroup_Id.FocusColor = System.Drawing.Color.Empty;
            this.txtGroup_Id.IsValueTrim = true;
            this.txtGroup_Id.Key = "CDCLSS";
            this.txtGroup_Id.Location = new System.Drawing.Point(340, 59);
            this.txtGroup_Id.MinLength = 0;
            this.txtGroup_Id.Name = "txtGroup_Id";
            this.txtGroup_Id.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtGroup_Id.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtGroup_Id.Properties.Appearance.Options.UseBackColor = true;
            this.txtGroup_Id.Properties.Appearance.Options.UseForeColor = true;
            this.txtGroup_Id.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGroup_Id.Size = new System.Drawing.Size(138, 20);
            this.txtGroup_Id.StyleController = this.xtraLayoutControlExt1;
            this.txtGroup_Id.TabIndex = 14;
            this.txtGroup_Id.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // btnSearch
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSearch, new string[] {
            "SELECT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSearch, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSearch, true);
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.IsExecuteWdworkerLog = true;
            this.btnSearch.Location = new System.Drawing.Point(917, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(71, 22);
            this.btnSearch.StyleController = this.xtraLayoutControlExt1;
            this.btnSearch.TabIndex = 7;
            this.btnSearch.Text = "조회";
            this.btnSearch.UseSplasher = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "Root";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup1, false);
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem2,
            this.layoutControlItem3,
            this.layoutControlGroup2,
            this.layoutControlGroup3,
            this.splitterItem2,
            this.layoutControlGroup4});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1000, 600);
            this.layoutControlGroup1.Text = "Root";
            this.layoutControlGroup1.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(905, 26);
            this.emptySpaceItem2.Text = "emptySpaceItem2";
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.btnSearch;
            this.layoutControlItem3.CustomizationFormText = "layoutControlItem3";
            this.layoutControlItem3.Location = new System.Drawing.Point(905, 0);
            this.layoutControlItem3.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem3.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem3.Text = "layoutControlItem3";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem3.TextToControlDistance = 0;
            this.layoutControlItem3.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.CaptionImage = ((System.Drawing.Image)(resources.GetObject("layoutControlGroup2.CaptionImage")));
            this.layoutControlGroup2.CustomizationFormText = "사용자정보";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup2, false);
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem4,
            this.layoutControlItem9,
            this.layoutControlItem10,
            this.layoutControlItem11,
            this.emptySpaceItem4});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 83);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(394, 497);
            this.layoutControlGroup2.Text = "코드 그룹 정보";
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.grdGroup;
            this.layoutControlItem4.CustomizationFormText = "layoutControlItem4";
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(370, 422);
            this.layoutControlItem4.Text = "layoutControlItem4";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextToControlDistance = 0;
            this.layoutControlItem4.TextVisible = false;
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.btnGroupDelete;
            this.layoutControlItem9.CustomizationFormText = "layoutControlItem9";
            this.layoutControlItem9.Location = new System.Drawing.Point(295, 0);
            this.layoutControlItem9.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem9.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem9.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem9.Text = "layoutControlItem9";
            this.layoutControlItem9.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem9.TextToControlDistance = 0;
            this.layoutControlItem9.TextVisible = false;
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.btnGroupSave;
            this.layoutControlItem10.CustomizationFormText = "layoutControlItem10";
            this.layoutControlItem10.Location = new System.Drawing.Point(220, 0);
            this.layoutControlItem10.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem10.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem10.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem10.Text = "layoutControlItem10";
            this.layoutControlItem10.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem10.TextToControlDistance = 0;
            this.layoutControlItem10.TextVisible = false;
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.btnGroupAdd;
            this.layoutControlItem11.CustomizationFormText = "layoutControlItem11";
            this.layoutControlItem11.Location = new System.Drawing.Point(145, 0);
            this.layoutControlItem11.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem11.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem11.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem11.Text = "layoutControlItem11";
            this.layoutControlItem11.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem11.TextToControlDistance = 0;
            this.layoutControlItem11.TextVisible = false;
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.CustomizationFormText = "emptySpaceItem4";
            this.emptySpaceItem4.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(145, 26);
            this.emptySpaceItem4.Text = "emptySpaceItem4";
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup3.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup3.CaptionImage = ((System.Drawing.Image)(resources.GetObject("layoutControlGroup3.CaptionImage")));
            this.layoutControlGroup3.CustomizationFormText = "그룹정보";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup3, false);
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem6,
            this.layoutControlItem2,
            this.layoutControlItem7,
            this.layoutControlItem8,
            this.empGroupInfo});
            this.layoutControlGroup3.Location = new System.Drawing.Point(399, 83);
            this.layoutControlGroup3.Name = "layoutControlGroup3";
            this.layoutControlGroup3.Size = new System.Drawing.Size(581, 497);
            this.layoutControlGroup3.Text = "코드 정보";
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.grdCode;
            this.layoutControlItem6.CustomizationFormText = "layoutControlItem6";
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(557, 422);
            this.layoutControlItem6.Text = "layoutControlItem6";
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextToControlDistance = 0;
            this.layoutControlItem6.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.btnCodeDelete;
            this.layoutControlItem2.CustomizationFormText = "layoutControlItem2";
            this.layoutControlItem2.Location = new System.Drawing.Point(482, 0);
            this.layoutControlItem2.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem2.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem2.Text = "layoutControlItem2";
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextToControlDistance = 0;
            this.layoutControlItem2.TextVisible = false;
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.btnCodeSave;
            this.layoutControlItem7.CustomizationFormText = "layoutControlItem7";
            this.layoutControlItem7.Location = new System.Drawing.Point(407, 0);
            this.layoutControlItem7.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem7.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem7.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem7.Text = "layoutControlItem7";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem7.TextToControlDistance = 0;
            this.layoutControlItem7.TextVisible = false;
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.btnCodeAdd;
            this.layoutControlItem8.CustomizationFormText = "layoutControlItem8";
            this.layoutControlItem8.Location = new System.Drawing.Point(332, 0);
            this.layoutControlItem8.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem8.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem8.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem8.Text = "layoutControlItem8";
            this.layoutControlItem8.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem8.TextToControlDistance = 0;
            this.layoutControlItem8.TextVisible = false;
            // 
            // empGroupInfo
            // 
            this.empGroupInfo.AllowHotTrack = false;
            this.empGroupInfo.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.empGroupInfo.AppearanceItemCaption.Options.UseFont = true;
            this.empGroupInfo.CustomizationFormText = "emptySpaceItem3";
            this.empGroupInfo.Location = new System.Drawing.Point(0, 0);
            this.empGroupInfo.Name = "empGroupInfo";
            this.empGroupInfo.Size = new System.Drawing.Size(332, 26);
            this.empGroupInfo.Text = "그룹 정보 :";
            this.empGroupInfo.TextSize = new System.Drawing.Size(77, 0);
            this.empGroupInfo.TextVisible = true;
            // 
            // splitterItem2
            // 
            this.splitterItem2.AllowHotTrack = true;
            this.splitterItem2.CustomizationFormText = "splitterItem2";
            this.splitterItem2.Location = new System.Drawing.Point(394, 83);
            this.splitterItem2.Name = "splitterItem2";
            this.splitterItem2.Size = new System.Drawing.Size(5, 497);
            // 
            // layoutControlGroup4
            // 
            this.layoutControlGroup4.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 1F);
            this.layoutControlGroup4.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup4.CustomizationFormText = " ";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup4, true);
            this.layoutControlGroup4.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem12,
            this.layoutControlItem5,
            this.layoutControlItem1,
            this.emptySpaceItem1});
            this.layoutControlGroup4.Location = new System.Drawing.Point(0, 26);
            this.layoutControlGroup4.Name = "layoutControlGroup4";
            this.layoutControlGroup4.Size = new System.Drawing.Size(980, 57);
            this.layoutControlGroup4.Text = " ";
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.cboCODEGRP;
            this.layoutControlItem12.CustomizationFormText = "대분류코드";
            this.layoutControlItem12.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem12.Image")));
            this.layoutControlItem12.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(216, 24);
            this.layoutControlItem12.Text = "대분류코드";
            this.layoutControlItem12.TextSize = new System.Drawing.Size(77, 16);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.txtGroup_Id;
            this.layoutControlItem5.CustomizationFormText = "시스템명";
            this.layoutControlItem5.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem5.Image")));
            this.layoutControlItem5.Location = new System.Drawing.Point(216, 0);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(257, 24);
            this.layoutControlItem5.Spacing = new DevExpress.XtraLayout.Utils.Padding(20, 15, 0, 0);
            this.layoutControlItem5.Text = "분류 코드";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(77, 16);
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.txtGroup_Nm;
            this.layoutControlItem1.CustomizationFormText = "성명";
            this.layoutControlItem1.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem1.Image")));
            this.layoutControlItem1.Location = new System.Drawing.Point(473, 0);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(330, 24);
            this.layoutControlItem1.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 15, 0, 0);
            this.layoutControlItem1.Text = "분류 코드명";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(77, 16);
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(803, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(153, 24);
            this.emptySpaceItem1.Text = "emptySpaceItem1";
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // SCSYS011
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS011";
            this.Size = new System.Drawing.Size(1000, 600);
            this.Shown += new System.EventHandler(this.SCSYS011_Shown);
            this.Load += new System.EventHandler(this.SCSYS011_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cboCODEGRP.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkYN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsTextUpp10_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpyChk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboCODEGRP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsTextUpp10_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGroup_Nm.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGroup_Id.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.empGroupInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private Client.Controls.DXperience.XtraButtonExt btnSearch;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private Controls.StdButtonExecuteManager stdButtonExecuteManager1;
        private Client.Controls.DXperience.XtraTextEditExt txtGroup_Id;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private Client.Controls.DXperience.XtraTextEditExt txtGroup_Nm;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private Client.Controls.DXperience.XtraGridControlExt grdGroup;
        private DevExpress.XtraGrid.Views.Grid.GridView grvGroup;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private Client.Controls.DXperience.XtraGridControlExt grdCode;
        private DevExpress.XtraGrid.Views.Grid.GridView grvCode;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpychkYN;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraLayout.SplitterItem splitterItem2;
        private Client.Controls.DXperience.XtraButtonExt btnCodeAdd;
        private Client.Controls.DXperience.XtraButtonExt btnCodeSave;
        private Client.Controls.DXperience.XtraButtonExt btnCodeDelete;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.EmptySpaceItem empGroupInfo;
        private Client.Controls.DXperience.XtraButtonExt btnGroupAdd;
        private Client.Controls.DXperience.XtraButtonExt btnGroupSave;
        private Client.Controls.DXperience.XtraButtonExt btnGroupDelete;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpyChk;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit rpsTextUpp10_2;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit rpsTextUpp10_1;
        private Client.Controls.DXperience.XtraImageComboBoxEditExt cboCODEGRP;
        private DevExpress.XtraGrid.Columns.GridColumn colCODEGRP;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboCODEGRP;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private Windows.Forms.StdSecurityManager stdSecurityManager1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup4;
    }
}
