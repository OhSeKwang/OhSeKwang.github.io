﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS006P2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.btnSearch = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.txtValue = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.cboGubun = new HHI.ShipBuilding.Client.Controls.DXperience.XtraImageComboBoxEditExt();
            this.grdUser = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvUser = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpychkCheckYN = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.treeDept = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumn2 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.btnClose = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.splitterItem1 = new DevExpress.XtraLayout.SplitterItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.empDeptNm = new DevExpress.XtraLayout.EmptySpaceItem();
            this.stdValidationManager1 = new HHI.ShipBuilding.Controls.StdValidationManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtValue.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboGubun.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkCheckYN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.treeDept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.empDeptNm)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearch);
            this.xtraLayoutControlExt1.Controls.Add(this.txtValue);
            this.xtraLayoutControlExt1.Controls.Add(this.cboGubun);
            this.xtraLayoutControlExt1.Controls.Add(this.grdUser);
            this.xtraLayoutControlExt1.Controls.Add(this.treeDept);
            this.xtraLayoutControlExt1.Controls.Add(this.btnClose);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(720, 273, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(697, 548);
            this.xtraLayoutControlExt1.TabIndex = 0;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // btnSearch
            // 
            this.btnSearch.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_조회;
            this.btnSearch.IsExecuteWdworkerLog = true;
            this.btnSearch.Location = new System.Drawing.Point(369, 38);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(71, 22);
            this.btnSearch.StyleController = this.xtraLayoutControlExt1;
            this.btnSearch.TabIndex = 5;
            this.btnSearch.Text = "조회";
            this.btnSearch.UseSplasher = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtValue
            // 
            this.txtValue.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtValue.EditValue = "";
            this.txtValue.EnterExecuteButton = null;
            this.txtValue.FocusColor = System.Drawing.Color.Empty;
            this.txtValue.IsValueTrim = true;
            this.txtValue.Key = "";
            this.txtValue.Location = new System.Drawing.Point(107, 38);
            this.txtValue.MinLength = 0;
            this.txtValue.Name = "txtValue";
            this.txtValue.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtValue.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtValue.Properties.Appearance.Options.UseBackColor = true;
            this.txtValue.Properties.Appearance.Options.UseForeColor = true;
            this.txtValue.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtValue.Size = new System.Drawing.Size(258, 20);
            this.txtValue.StyleController = this.xtraLayoutControlExt1;
            this.txtValue.TabIndex = 17;
            this.txtValue.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // cboGubun
            // 
            this.cboGubun.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.cboGubun.EditValue = "NAME";
            this.cboGubun.EnterExecuteButton = null;
            this.cboGubun.FocusColor = System.Drawing.Color.Empty;
            this.cboGubun.Key = "";
            this.cboGubun.Location = new System.Drawing.Point(12, 38);
            this.cboGubun.MinLength = 0;
            this.cboGubun.Name = "cboGubun";
            this.cboGubun.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.cboGubun.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.cboGubun.Properties.Appearance.Options.UseBackColor = true;
            this.cboGubun.Properties.Appearance.Options.UseForeColor = true;
            this.cboGubun.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboGubun.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.ImageComboBoxItem[] {
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("성명", "NAME", -1),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("부서명", "DEPT", -1)});
            this.cboGubun.Size = new System.Drawing.Size(91, 20);
            this.cboGubun.StyleController = this.xtraLayoutControlExt1;
            this.cboGubun.TabIndex = 16;
            // 
            // grdUser
            // 
            this.grdUser.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdUser.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdUser.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdUser.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdUser.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdUser.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdUser.Location = new System.Drawing.Point(301, 90);
            this.grdUser.MainView = this.grvUser;
            this.grdUser.MinLength = 0;
            this.grdUser.Name = "grdUser";
            this.grdUser.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpychkCheckYN});
            this.grdUser.Size = new System.Drawing.Size(384, 446);
            this.grdUser.TabIndex = 14;
            this.grdUser.UseEmbeddedNavigator = true;
            this.grdUser.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvUser});
            // 
            // grvUser
            // 
            this.grvUser.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7});
            this.grvUser.GridControl = this.grdUser;
            this.grvUser.Name = "grvUser";
            this.grvUser.OptionsView.ColumnAutoWidth = false;
            this.grvUser.OptionsView.ShowGroupPanel = false;
            this.grvUser.DoubleClick += new System.EventHandler(this.grvUser_DoubleClick);
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.Caption = "이름";
            this.gridColumn5.FieldName = "KOR_NM";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.OptionsColumn.ReadOnly = true;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 0;
            this.gridColumn5.Width = 100;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.Caption = "직위";
            this.gridColumn6.FieldName = "JOB_TIT_NM";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.OptionsColumn.ReadOnly = true;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 1;
            this.gridColumn6.Width = 90;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.Caption = "부서명";
            this.gridColumn7.FieldName = "DEPTNAME";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            this.gridColumn7.OptionsColumn.ReadOnly = true;
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 2;
            this.gridColumn7.Width = 150;
            // 
            // rpychkCheckYN
            // 
            this.rpychkCheckYN.AutoHeight = false;
            this.rpychkCheckYN.Caption = "Check";
            this.rpychkCheckYN.Name = "rpychkCheckYN";
            this.rpychkCheckYN.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpychkCheckYN.ValueChecked = "Y";
            this.rpychkCheckYN.ValueUnchecked = "N";
            // 
            // treeDept
            // 
            this.treeDept.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn2});
            this.treeDept.KeyFieldName = "ASGN_CD";
            this.treeDept.Location = new System.Drawing.Point(12, 64);
            this.treeDept.Name = "treeDept";
            this.treeDept.OptionsNavigation.AutoFocusNewNode = true;
            this.treeDept.OptionsDragAndDrop.DragNodesMode = DevExpress.XtraTreeList.DragNodesMode.Multiple;
            this.treeDept.OptionsSelection.InvertSelection = true;
            this.treeDept.OptionsSelection.UseIndicatorForSelection = true;
            this.treeDept.OptionsView.ShowColumns = false;
            this.treeDept.OptionsView.ShowHorzLines = false;
            this.treeDept.OptionsView.ShowIndicator = false;
            this.treeDept.OptionsView.ShowVertLines = false;
            this.treeDept.ParentFieldName = "WK_PRTN_CD";
            this.treeDept.Size = new System.Drawing.Size(280, 472);
            this.treeDept.TabIndex = 15;
            this.treeDept.DoubleClick += new System.EventHandler(this.treeDept_DoubleClick);
            // 
            // treeListColumn2
            // 
            this.treeListColumn2.Caption = "부서명";
            this.treeListColumn2.FieldName = "ASGN_SHRT_NM";
            this.treeListColumn2.Name = "treeListColumn2";
            this.treeListColumn2.OptionsColumn.AllowEdit = false;
            this.treeListColumn2.OptionsColumn.ReadOnly = true;
            this.treeListColumn2.Visible = true;
            this.treeListColumn2.VisibleIndex = 0;
            // 
            // btnClose
            // 
            this.btnClose.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_닫기;
            this.btnClose.IsExecuteWdworkerLog = true;
            this.btnClose.Location = new System.Drawing.Point(614, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(71, 22);
            this.btnClose.StyleController = this.xtraLayoutControlExt1;
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "닫기";
            this.btnClose.UseSplasher = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "Root";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem1,
            this.layoutControlItem1,
            this.layoutControlItem2,
            this.layoutControlItem3,
            this.splitterItem1,
            this.layoutControlItem4,
            this.layoutControlItem5,
            this.emptySpaceItem2,
            this.layoutControlItem6,
            this.empDeptNm});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(697, 548);
            this.layoutControlGroup1.Text = "Root";
            this.layoutControlGroup1.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(602, 26);
            this.emptySpaceItem1.Text = "emptySpaceItem1";
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.btnClose;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(602, 0);
            this.layoutControlItem1.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem1.Text = "layoutControlItem1";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextToControlDistance = 0;
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.treeDept;
            this.layoutControlItem2.CustomizationFormText = "layoutControlItem2";
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 52);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(284, 476);
            this.layoutControlItem2.Text = "layoutControlItem2";
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextToControlDistance = 0;
            this.layoutControlItem2.TextVisible = false;
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.grdUser;
            this.layoutControlItem3.CustomizationFormText = "layoutControlItem3";
            this.layoutControlItem3.Location = new System.Drawing.Point(289, 78);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(388, 450);
            this.layoutControlItem3.Text = "layoutControlItem3";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem3.TextToControlDistance = 0;
            this.layoutControlItem3.TextVisible = false;
            // 
            // splitterItem1
            // 
            this.splitterItem1.AllowHotTrack = true;
            this.splitterItem1.CustomizationFormText = "splitterItem1";
            this.splitterItem1.Location = new System.Drawing.Point(284, 78);
            this.splitterItem1.Name = "splitterItem1";
            this.splitterItem1.Size = new System.Drawing.Size(5, 450);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.cboGubun;
            this.layoutControlItem4.CustomizationFormText = "layoutControlItem4";
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(95, 26);
            this.layoutControlItem4.Text = "layoutControlItem4";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextToControlDistance = 0;
            this.layoutControlItem4.TextVisible = false;
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.txtValue;
            this.layoutControlItem5.CustomizationFormText = "layoutControlItem5";
            this.layoutControlItem5.Location = new System.Drawing.Point(95, 26);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(262, 26);
            this.layoutControlItem5.Text = "layoutControlItem5";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem5.TextToControlDistance = 0;
            this.layoutControlItem5.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(432, 26);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(245, 26);
            this.emptySpaceItem2.Text = "emptySpaceItem2";
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.btnSearch;
            this.layoutControlItem6.CustomizationFormText = "layoutControlItem6";
            this.layoutControlItem6.Location = new System.Drawing.Point(357, 26);
            this.layoutControlItem6.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem6.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem6.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem6.Text = "layoutControlItem6";
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextToControlDistance = 0;
            this.layoutControlItem6.TextVisible = false;
            // 
            // empDeptNm
            // 
            this.empDeptNm.AllowHotTrack = false;
            this.empDeptNm.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.empDeptNm.AppearanceItemCaption.ForeColor = System.Drawing.Color.Blue;
            this.empDeptNm.AppearanceItemCaption.Options.UseFont = true;
            this.empDeptNm.AppearanceItemCaption.Options.UseForeColor = true;
            this.empDeptNm.CustomizationFormText = "부서명 [ 0 ]";
            this.empDeptNm.Location = new System.Drawing.Point(284, 52);
            this.empDeptNm.Name = "empDeptNm";
            this.empDeptNm.Padding = new DevExpress.XtraLayout.Utils.Padding(9, 2, 2, 2);
            this.empDeptNm.Size = new System.Drawing.Size(393, 26);
            this.empDeptNm.Text = "부서명 [ 0 ]";
            this.empDeptNm.TextSize = new System.Drawing.Size(0, 0);
            this.empDeptNm.TextVisible = true;
            // 
            // stdValidationManager1
            // 
            this.stdValidationManager1.IsNullorWhiteSpace = true;
            this.stdValidationManager1.IsShowErrorMessage = true;
            // 
            // SCSYS006P2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(697, 548);
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS006P2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "HHI 사용자";
            this.Load += new System.EventHandler(this.SCSYS006P2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtValue.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboGubun.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkCheckYN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.treeDept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.empDeptNm)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private Client.Controls.DXperience.XtraButtonExt btnClose;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private Controls.StdValidationManager stdValidationManager1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraTreeList.TreeList treeDept;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private Client.Controls.DXperience.XtraGridControlExt grdUser;
        private DevExpress.XtraGrid.Views.Grid.GridView grvUser;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpychkCheckYN;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.SplitterItem splitterItem1;
        private Client.Controls.DXperience.XtraButtonExt btnSearch;
        private Client.Controls.DXperience.XtraTextEditExt txtValue;
        private Client.Controls.DXperience.XtraImageComboBoxEditExt cboGubun;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraLayout.EmptySpaceItem empDeptNm;
    }
}