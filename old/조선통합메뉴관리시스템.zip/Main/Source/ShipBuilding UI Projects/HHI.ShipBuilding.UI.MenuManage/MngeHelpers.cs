﻿using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Grid;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace HHI.ShipBuilding.UI.MenuManage
{
    public class MngHelpers
    {

        /// <summary>
        /// DataTable 을 DataPack 로 변환 한다
        /// </summary>
        /// <param name="dataPack">DataPack</param>
        /// <param name="dt">변환할 DataTable</param>
        /// <param name="arrParamNames">파라메터명(Column 명) 배열</param>
        /// <param name="hsAddParamNames">추가할 파라메터 - Hashtable 파라메터명(key) : 파라메터값(value) 으로 구성</param>
        public static void DataTableToDataPack(ref DataPack dataPack, DataTable dt, string[] arrParamNames, Hashtable hsAddParamNames)
        {
            for (int i = 0; i < arrParamNames.Length; i++)
            {
                string strParamName = arrParamNames[i];
                string[] arrCol = new string[dt.Rows.Count];
                for (int iRow = 0; iRow < dt.Rows.Count; iRow++)
                {
                    arrCol[iRow] = dt.Rows[iRow][strParamName].ToString();
                }

                dataPack.DataList.Add(strParamName, arrCol);
            }

            int iArrColAddLength = dt.Rows.Count;
            foreach (DictionaryEntry item in hsAddParamNames)
            {
                string[] arrColAdd = new string[iArrColAddLength];
                for (int iPack = 0; iPack < iArrColAddLength; iPack++)
                {
                    arrColAdd[iPack] = item.Value.ToString();
                }

                dataPack.DataList.Add(item.Key.ToString(), arrColAdd);
            }

            dataPack.ArrayItemCount = iArrColAddLength; // ArrayBind 처리시...항상 지정 해야함!
        }

        /// <summary>
        /// DataTable 을 DataPack 로 변환 한다
        /// </summary>
        /// <param name="dataPack">DataPack</param>
        /// <param name="dt">변환할 DataTable</param>
        /// <param name="arrParamNames">파라메터명(Column 명) 배열</param>
        public static void DataTableToDataPack(ref DataPack dataPack, DataTable dt, string[] arrParamNames)
        {
            for (int i = 0; i < arrParamNames.Length; i++)
            {
                string strParamName = arrParamNames[i];
                string[] arrCol = new string[dt.Rows.Count];
                for (int iRow = 0; iRow < dt.Rows.Count; iRow++)
                {
                    if (!dt.Columns.Contains(strParamName))
                    {
                        arrCol[iRow] = string.Empty;
                    }
                    else
                    {
                        arrCol[iRow] = dt.Rows[iRow][strParamName].ToString();
                    }
                }

                dataPack.DataList.Add(strParamName, arrCol);
            }

            dataPack.ArrayItemCount = dt.Rows.Count;    // ArrayBind 처리시...항상 지정 해야함!
        }


        public static void SetGridDataSourceDefault(GridView view)
        {
            GridControl grid = view.GridControl;
            if (grid.DataSource == null)
            {
                DataTable dt = new DataTable();

                foreach (GridColumn col in view.Columns)
                {
                    dt.Columns.Add(col.FieldName);
                }

                grid.DataSource = dt;
            }
        }



        #region NAS 파일 업로드 - NASFileUpLoad
        /// <summary>
        /// NAS 파일 업로드
        /// </summary>
        /// <param name="strFileSubUrl"></param>
        /// <param name="strFileName"></param>
        /// <param name="byteFile"></param>
        /// <returns></returns>
        public static bool NASFileUpLoad(NASInfo nasInfo, string strFileSubUrl, string strFileName, byte[] byteFile)
        {
            //using (INASFileHandlerEx NASService = Services.CreateINASEx())
            //{
            //    return NASService.FileUpLoadAPI(strFileSubUrl, strFileName, byteFile);
            //}

            return ShipBuildingSystemChannel.FileUpLoadAPI(nasInfo, strFileSubUrl, strFileName, byteFile);
        }
        #endregion NAS 파일 업로드 - NASFileUpLoad

        #region NAS 파일 다운로드 - NASFileDownLoad
        /// <summary>
        /// NAS 파일 다운로드
        /// </summary>
        /// <param name="strServerFileFullName"></param>
        /// <returns></returns>
        public static byte[] NASFileDownLoad(NASInfo nasInfo, string strServerFileFullName)
        {
            //using (INASFileHandlerEx NASService = Services.CreateINASEx())
            //{
            //    return NASService.FileDownLoadAPI(strServerFileFullName);
            //}

            return ShipBuildingSystemChannel.FileDownLoadAPI(nasInfo, strServerFileFullName);
        }
        #endregion NAS 파일 다운로드 - NASFileDownLoad

        #region NAS 파일 삭제 - FileDeleteAPI
        /// <summary>
        /// NAS 파일 삭제
        /// </summary>
        /// <param name="strFileSubUrl"></param>
        /// <param name="strFileName"></param>
        /// <param name="byteFile"></param>
        /// <returns></returns>
        public static bool NASFileDelete(NASInfo nasInfo, string strFileSubUrl, string strFileName)
        {
            return ShipBuildingSystemChannel.FileDeleteAPI(nasInfo, strFileSubUrl, strFileName);
        }
        #endregion NAS 파일 삭제 - NASFileUpLoad

    }
}
