﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraTreeList.Nodes;
using DevExpress.XtraEditors;
using HHI.Security;
using HHI.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS021 : StdUserControlBase// UserControl
    {

        #region 생성자 및 변수 선언
        public SCSYS021()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }

        private string _sSYSTEM_CODE = string.Empty;

        #endregion

        #region 화면 Load

        #endregion

        #region SCSYS021_Shown

        private void SCSYS021_Shown(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                initPage();

                stdSecurityManager1.ApplySecurity(this.SecurityContext);
                stdButtonExecuteManager1.RegisterButtonExecEvent();


                btnSearch.PerformClick();
            }
        }

        #endregion

        #region 버튼이벤트
        #region 조회
        /// <summary>
        /// 사용자그룹 조회[왼쪽그리드] 및 메뉴정보 조회[하단그리드]
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            _sSYSTEM_CODE = string.Empty;
            
            // 그리드 초기화
            if (grdMaster.DataSource is DataTable)
                (grdMaster.DataSource as DataTable).Rows.Clear();

            grdMaster.DataSource = getSystemInfo();

            DataResultSet result = GetAuthRequest();
            if (result.IsSuccess)
                grdAuthRequest.DataSource = result.QuerySet.Tables[0];
            
            
        }
        #endregion

        #region 신청
        /// <summary>
        /// 신청
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRequest_Click(object sender, EventArgs e)
        {
            SCSYS020 pREQUEST = new SCSYS020();
            StdPopupHost PopupHost = new StdPopupHost(pREQUEST, "현업권한신청");
            pREQUEST.SetSecurityContext(this.SecurityContext);
            pREQUEST.SetUserInfoContext(this.UserInfo);
            
            PopupHost.ShowDialog();

            if (pREQUEST._sGUBUN.Equals("Y"))
            {
                btnSearch.PerformClick();
            }
            
        }
        #endregion

        #region 반려
        private void btnReject_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("반려하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            if (grvAuthRequest.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요....", "경고"); return; }


            DataRow drRequest = grvAuthRequest.GetFocusedDataRow();

            if (drRequest != null)
            {
                if (!drRequest["REQUEST_STATUS"].ToString().Equals("N"))
                {
                    MsgBox.Show("처리상태가 미처리 인경우 반려가능합니다.");
                    return;
                }

                if (drRequest["ASSIGN"].ToString().Trim().Equals(""))
                {
                    MsgBox.Show("반려사유[처리사항]를 입력하세요."); 
                    return;
                }

                Request(btnReject.Tag.ToString());
            }

            
        }

        #endregion

        #region 처리
        private void btnComplete_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("처리하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            if (grvAuthRequest.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요....", "경고"); return; }


            DataRow drRequest = grvAuthRequest.GetFocusedDataRow();

            if (drRequest != null)
            {
                if (!drRequest["REQUEST_STATUS"].ToString().Equals("N"))
                {
                    MsgBox.Show("처리상태가 미처리 인경우 처리가능합니다.");
                    return;
                }

                if (drRequest["ASSIGN_GROUP_ID"].ToString().Equals(""))
                {
                    MsgBox.Show("할당그룹메뉴를 입력하세요.");
                    return;
                }

                Request(btnComplete.Tag.ToString());
            }



        }
        
        #endregion

        #region 권한삭제
        private void btnAuthDelete_Click(object sender, EventArgs e)
        {            
            if (grvAuthUser.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요....", "경고"); return; }

            if ((grdAuthUser.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            { MsgBox.Show("삭제할 선택된 정보가 없습니다.!", "경고"); return; }

            if (MsgBox.Show("권한삭제하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }

            DataPack parameter = new DataPack();

            DataTable dt = (grdAuthUser.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();
            string[] arrParams = {"GROUP_ID", "USER_ID"};

            MngHelpers.DataTableToDataPack(ref parameter, dt, arrParams);
            

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS021.DELETE_01", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("삭제되었습니다.", "확인");

                grvMaster_FocusedRowChanged(null, null);
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }

        }
        #endregion

        #endregion

        #region 그리드이벤트

        private void grvAuthRequest_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            DataRow row = grvAuthRequest.GetFocusedDataRow();
            if (row != null)
            {

            }
        }

        private void grvMaster_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            DataRow row = grvMaster.GetFocusedDataRow();

            if (row != null)
            {
                _sSYSTEM_CODE = row["SYSTEM_CODE"].ToString();
                
                // 시스템별 사용자 조회
                DataResultSet resultUsers = GetAuthUserInfo(row["SYSTEM_CODE"].ToString(), row["GROUP_ID"].ToString());

                if (resultUsers.IsSuccess)
                {
                    grdAuthUser.DataSource = resultUsers.QuerySet.Tables[0];
                }
                else
                {
                    MsgBox.Show(resultUsers.ExceptionMessage); return;
                }

            }
        }

        private void grvAuthRequest_ShowingEditor(object sender, CancelEventArgs e)
        {
            DataRow row = grvAuthRequest.GetFocusedDataRow();
            if (row != null)
            {
                string strFieldName = grvAuthRequest.FocusedColumn.FieldName;
                if (strFieldName.Equals("ASSIGN_GROUP_ID"))
                {
                    if (row["REQUEST_STATUS"].ToString().Equals("N"))
                        grvAuthRequest.Columns[strFieldName].OptionsColumn.ReadOnly = false;
                    else
                        grvAuthRequest.Columns[strFieldName].OptionsColumn.ReadOnly = true;
                }
            }
        }
        #endregion

        #region 컨트롤이벤트
        private void chkGUBUN_EditValueChanged(object sender, EventArgs e)
        {
            DataResultSet result = GetAuthRequest();
            if (result.IsSuccess)
                grdAuthRequest.DataSource = result.QuerySet.Tables[0];
            else
            {
                MsgBox.Show(result.ExceptionMessage); return;
            }
        }
        #endregion

        #region 메서드

        private void initPage()
        { 
            // 콤보 바인딩            
            ClientControlHelper.ImageComboBind(rpsCboWORK_GUBUN, "CDNM", "CDCODE", "{value}-{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, ClientControlHelper.GetCodeInfo("SY001"));
            ClientControlHelper.ImageComboBind(rpsCboSYSTEM_CODE, "SYSTEM_NAME", "SYSTEM_CODE", "{value}-{text}", ComboDisplayTextOption.none, string.Empty, string.Empty, GetSystemCode());
            //ClientControlHelper.ImageComboBind(cboSYSTEM_CODE, "SYSTEM_NAME", "SYSTEM_CODE", "{value}-{text}", ComboDisplayTextOption.top, "전체", string.Empty, GetSystemCode());            
            ClientControlHelper.ImageComboBind(rpsCboSYSTEM_CODE1, "SYSTEM_NAME", "SYSTEM_CODE", "{text}", ComboDisplayTextOption.none, string.Empty, string.Empty, GetSystemCode());
            ClientControlHelper.ImageComboBind(rpsCboREQUEST_GUBUN, "CDNM", "CDCODE", "{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, ClientControlHelper.GetCodeInfo("SY012"));
            ClientControlHelper.ImageComboBind(rpsCboREQUEST_STATUS, "CDNM", "CDCODE", "{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, ClientControlHelper.GetCodeInfo("SY013"));


            ClientControlHelper.ImageComboBind(rpsCboASSIGN_GROUP_ID, "GROUP_NAME", "GROUP_ID", "{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, getSystemInfo());

            dteFrom.EditValue = DateTime.Now.AddMonths(-1);
            dteTo.EditValue = DateTime.Now;
        }

        /// <summary>
        /// 시스템정보를 가져온다.
        /// </summary>
        /// <returns></returns>
        private DataTable getSystemInfo()
        {
            DataTable dt = new DataTable();

            DataPack parameter = new DataPack();
            parameter.DataList.Add("LOGIN_USERID", UserInfo.UserID);

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS021.SEARCH_01", parameter);

            if (resultSet.IsSuccess)
            {
                dt = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }

            return dt;
        }

        /// <summary>
        /// 시스템코드조회
        /// </summary>
        /// <returns></returns>
        private DataTable GetSystemCode()
        {
            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCCOMMON.SEARCH_SYSTEM").QuerySet.Tables[0];
        }

        /// <summary>
        /// 권한사용자 조회
        /// </summary>
        /// <param name="strSYSTEM_CODE"></param>
        /// <returns></returns>
        private DataResultSet GetAuthUserInfo(string strSYSTEM_CODE, string strGROUP_ID)
        {
            DataPack parameter = new DataPack();
            //parameter.DataList.Add("SYSTEM_CODE", strSYSTEM_CODE);
            parameter.DataList.Add("GROUP_ID", strGROUP_ID);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS021.SEARCH_GROUP_USERS", parameter);
        }

        
        private DataResultSet GetAuthRequest()
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("DATE_FROM", dteFrom.DateTime.ToString("yyyyMMdd"));
            parameter.DataList.Add("DATE_TO", dteTo.DateTime.ToString("yyyyMMdd"));
            parameter.DataList.Add("GUBUN", chkGUBUN.EditValue.ToString().Equals("Y") ? "N" : "");
            parameter.DataList.Add("LOGIN_USERID", UserInfo.UserID);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS021.SEARCH_AUTH_REQUEST", parameter);
        }

        private void Request(string strGUBUN)
        {
            DataRow drRequest = grvAuthRequest.GetFocusedDataRow();

            if (drRequest != null)
            {
                DataPack parameter = new DataPack();
                parameter.DataList.Add("REQUEST_USER_ID", drRequest["REQUEST_USER_ID"].ToString());
                parameter.DataList.Add("REQUEST_DATE", drRequest["REQUEST_DATE"].ToString());
                parameter.DataList.Add("SYSTEM_CODE", drRequest["SYSTEM_CODE"].ToString());                
                parameter.DataList.Add("LOGIN_USERID", UserInfo.UserID);
                parameter.DataList.Add("REQUEST_GUBUN", drRequest["REQUEST_GUBUN"].ToString());
                parameter.DataList.Add("REQUEST_STATUS", strGUBUN);
                parameter.DataList.Add("ASSIGN_GROUP_ID", drRequest["ASSIGN_GROUP_ID"].ToString());
                parameter.DataList.Add("ASSIGN", drRequest["ASSIGN"].ToString());

                DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS021.SAVE_STATUS", parameter);

                if (resultSet.IsSuccess)
                {
                    MsgBox.Show("처리되었습니다.", "확인");

                    DataResultSet result = GetAuthRequest();
                    if (result.IsSuccess)
                        grdAuthRequest.DataSource = result.QuerySet.Tables[0];
                }
                else
                {
                    MsgBox.Show(resultSet.ExceptionMessage);
                }
            }
        }

        #endregion

        private void btnExcel_Click(object sender, EventArgs e)
        {
            string sPath = Path.GetTempPath() + @"ShipBuilding\";
            if (!Directory.Exists(sPath))
            {
                Directory.CreateDirectory(sPath);
            }

            grvAuthUser.OptionsPrint.AutoWidth = false;

            string strFilePathFull = sPath + string.Format("{0}.xlsx", DateTime.Now.ToString("yyyyMMddHHmmss"));
            DevExpress.XtraGrid.GridControl Grid = grvAuthUser.GridControl;


            grvAuthUser.ExportToXlsx(strFilePathFull);
            

            OpenFile(strFilePathFull);
        }

        #region 파일 실행 - OpenFile
        /// <summary>
        /// 파일 실행
        /// </summary>
        /// <param name="strFileFullName"></param>
        public static void OpenFile(string strFileFullName)
        {
            try
            {
                Process process = new Process();
                process.StartInfo.FileName = strFileFullName;
                process.StartInfo.Verb = "Open";
                process.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
                process.Start();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion 파일 실행 - OpenFile

        private void btnViewUserAuth_Click(object sender, EventArgs e)
        {
            object oUserId = UserInfo.UserID;
            UIMoveTo("SCSYS010", oUserId);
        }

        
    }
}
