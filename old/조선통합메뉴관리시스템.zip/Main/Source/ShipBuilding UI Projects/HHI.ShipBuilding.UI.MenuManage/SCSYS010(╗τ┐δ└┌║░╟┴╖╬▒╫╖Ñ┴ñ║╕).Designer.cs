﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS010
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.cboTYPE = new DevExpress.XtraEditors.ImageComboBoxEdit();
            this.btnExcel = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnSelectMenu = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnDeptPopUp = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.grdProgram = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvProgram = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colMENU_ID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colMENU_NAME = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colGROUP_ID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colGROUP_NAME = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colMENU_ORDER = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.grdGroup = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvGroup = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpychkYN = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.grdUser = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvUser = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpychkCheckYN = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.txtDeptName = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtUser_Nm = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtUser_Id = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnSearch = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup4 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.splitterItem1 = new DevExpress.XtraLayout.SplitterItem();
            this.splitterItem2 = new DevExpress.XtraLayout.SplitterItem();
            this.layoutControlGroup5 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.stdButtonExecuteManager1 = new HHI.ShipBuilding.Controls.StdButtonExecuteManager(this.components);
            this.stdSecurityManager1 = new HHI.ShipBuilding.Windows.Forms.StdSecurityManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboTYPE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdProgram)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvProgram)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkYN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkCheckYN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDeptName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUser_Nm.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUser_Id.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.cboTYPE);
            this.xtraLayoutControlExt1.Controls.Add(this.btnExcel);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSelectMenu);
            this.xtraLayoutControlExt1.Controls.Add(this.btnDeptPopUp);
            this.xtraLayoutControlExt1.Controls.Add(this.grdProgram);
            this.xtraLayoutControlExt1.Controls.Add(this.grdGroup);
            this.xtraLayoutControlExt1.Controls.Add(this.grdUser);
            this.xtraLayoutControlExt1.Controls.Add(this.txtDeptName);
            this.xtraLayoutControlExt1.Controls.Add(this.txtUser_Nm);
            this.xtraLayoutControlExt1.Controls.Add(this.txtUser_Id);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearch);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(600, 162, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(1000, 600);
            this.xtraLayoutControlExt1.TabIndex = 2;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // cboTYPE
            // 
            this.cboTYPE.EditValue = "A";
            this.cboTYPE.Location = new System.Drawing.Point(797, 68);
            this.cboTYPE.Name = "cboTYPE";
            this.cboTYPE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboTYPE.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.ImageComboBoxItem[] {
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("사용자정보", "A", -1),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("그룹정보", "B", -1),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("프로그램정보", "C", -1)});
            this.cboTYPE.Size = new System.Drawing.Size(121, 20);
            this.cboTYPE.StyleController = this.xtraLayoutControlExt1;
            this.cboTYPE.TabIndex = 26;
            // 
            // btnExcel
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnExcel, new string[] {
            "SELECT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnExcel, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnExcel, false);
            this.btnExcel.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Btn_엑셀;
            this.btnExcel.IsExecuteWdworkerLog = true;
            this.btnExcel.Location = new System.Drawing.Point(922, 68);
            this.btnExcel.Name = "btnExcel";
            this.btnExcel.Size = new System.Drawing.Size(54, 22);
            this.btnExcel.StyleController = this.xtraLayoutControlExt1;
            this.btnExcel.TabIndex = 25;
            this.btnExcel.Text = "엑셀";
            this.btnExcel.UseSplasher = true;
            this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
            // 
            // btnSelectMenu
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSelectMenu, new string[] {
            "SELECT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSelectMenu, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSelectMenu, false);
            this.btnSelectMenu.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_조회;
            this.btnSelectMenu.IsExecuteWdworkerLog = true;
            this.btnSelectMenu.Location = new System.Drawing.Point(910, 12);
            this.btnSelectMenu.Name = "btnSelectMenu";
            this.btnSelectMenu.Size = new System.Drawing.Size(78, 22);
            this.btnSelectMenu.StyleController = this.xtraLayoutControlExt1;
            this.btnSelectMenu.TabIndex = 24;
            this.btnSelectMenu.Text = "메뉴조회";
            this.btnSelectMenu.UseSplasher = true;
            this.btnSelectMenu.Click += new System.EventHandler(this.btnSelectMenu_Click);
            // 
            // btnDeptPopUp
            // 
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnDeptPopUp, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnDeptPopUp, false);
            this.btnDeptPopUp.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_조회;
            this.btnDeptPopUp.IsExecuteWdworkerLog = true;
            this.btnDeptPopUp.Location = new System.Drawing.Point(675, 68);
            this.btnDeptPopUp.Name = "btnDeptPopUp";
            this.btnDeptPopUp.Size = new System.Drawing.Size(26, 20);
            this.btnDeptPopUp.StyleController = this.xtraLayoutControlExt1;
            this.btnDeptPopUp.TabIndex = 23;
            this.btnDeptPopUp.Text = " ";
            this.btnDeptPopUp.UseSplasher = false;
            this.btnDeptPopUp.Click += new System.EventHandler(this.btnDeptPopUp_Click);
            // 
            // grdProgram
            // 
            this.grdProgram.CheckBoxFieldName = "CHK";
            this.grdProgram.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdProgram.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdProgram.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdProgram.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdProgram.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdProgram.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdProgram.IsHeaderClickAllCheckedItem = false;
            this.grdProgram.Location = new System.Drawing.Point(375, 337);
            this.grdProgram.MainView = this.grvProgram;
            this.grdProgram.MinLength = 0;
            this.grdProgram.Name = "grdProgram";
            this.grdProgram.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit1});
            this.grdProgram.Size = new System.Drawing.Size(601, 239);
            this.grdProgram.TabIndex = 18;
            this.grdProgram.UseEmbeddedNavigator = true;
            this.grdProgram.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvProgram});
            // 
            // grvProgram
            // 
            this.grvProgram.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn16,
            this.colMENU_ID,
            this.colMENU_NAME,
            this.gridColumn6,
            this.gridColumn9,
            this.colGROUP_ID,
            this.colGROUP_NAME,
            this.gridColumn10,
            this.gridColumn17,
            this.gridColumn8,
            this.colMENU_ORDER});
            this.grvProgram.GridControl = this.grdProgram;
            this.grvProgram.GroupCount = 1;
            this.grvProgram.Name = "grvProgram";
            this.grvProgram.OptionsBehavior.AutoExpandAllGroups = true;
            this.grvProgram.OptionsBehavior.Editable = false;
            this.grvProgram.OptionsView.ColumnAutoWidth = false;
            this.grvProgram.OptionsView.ShowGroupPanel = false;
            this.grvProgram.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumn16, DevExpress.Data.ColumnSortOrder.Descending)});
            // 
            // gridColumn16
            // 
            this.gridColumn16.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn16.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn16.Caption = "구분";
            this.gridColumn16.FieldName = "GUBUN";
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.Visible = true;
            this.gridColumn16.VisibleIndex = 0;
            // 
            // colMENU_ID
            // 
            this.colMENU_ID.AppearanceCell.Options.UseTextOptions = true;
            this.colMENU_ID.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMENU_ID.AppearanceHeader.Options.UseTextOptions = true;
            this.colMENU_ID.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMENU_ID.Caption = "메뉴ID";
            this.colMENU_ID.FieldName = "MENU_ID";
            this.colMENU_ID.Name = "colMENU_ID";
            this.colMENU_ID.Visible = true;
            this.colMENU_ID.VisibleIndex = 0;
            // 
            // colMENU_NAME
            // 
            this.colMENU_NAME.AppearanceHeader.Options.UseTextOptions = true;
            this.colMENU_NAME.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMENU_NAME.Caption = "메뉴명";
            this.colMENU_NAME.FieldName = "MENU_NAME";
            this.colMENU_NAME.Name = "colMENU_NAME";
            this.colMENU_NAME.Visible = true;
            this.colMENU_NAME.VisibleIndex = 1;
            this.colMENU_NAME.Width = 150;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.Caption = "폴더명";
            this.gridColumn6.FieldName = "FOLDER_NAME";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 2;
            this.gridColumn6.Width = 150;
            // 
            // gridColumn9
            // 
            this.gridColumn9.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.Caption = "시스템";
            this.gridColumn9.FieldName = "SYSTEM_NAME";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.AllowEdit = false;
            this.gridColumn9.OptionsColumn.ReadOnly = true;
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 3;
            this.gridColumn9.Width = 120;
            // 
            // colGROUP_ID
            // 
            this.colGROUP_ID.AppearanceCell.Options.UseTextOptions = true;
            this.colGROUP_ID.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colGROUP_ID.AppearanceHeader.Options.UseTextOptions = true;
            this.colGROUP_ID.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colGROUP_ID.Caption = "그룹ID";
            this.colGROUP_ID.FieldName = "GROUP_ID";
            this.colGROUP_ID.Name = "colGROUP_ID";
            this.colGROUP_ID.Visible = true;
            this.colGROUP_ID.VisibleIndex = 4;
            this.colGROUP_ID.Width = 70;
            // 
            // colGROUP_NAME
            // 
            this.colGROUP_NAME.AppearanceHeader.Options.UseTextOptions = true;
            this.colGROUP_NAME.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colGROUP_NAME.Caption = "그룹명";
            this.colGROUP_NAME.FieldName = "GROUP_NAME";
            this.colGROUP_NAME.Name = "colGROUP_NAME";
            this.colGROUP_NAME.Visible = true;
            this.colGROUP_NAME.VisibleIndex = 5;
            this.colGROUP_NAME.Width = 130;
            // 
            // gridColumn10
            // 
            this.gridColumn10.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn10.Caption = "프로그램ID";
            this.gridColumn10.FieldName = "PROGRAM_ID";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.OptionsColumn.AllowEdit = false;
            this.gridColumn10.OptionsColumn.ReadOnly = true;
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 6;
            this.gridColumn10.Width = 130;
            // 
            // gridColumn17
            // 
            this.gridColumn17.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn17.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn17.Caption = "프로그램명";
            this.gridColumn17.FieldName = "PROGRAM_NAME";
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.OptionsColumn.AllowEdit = false;
            this.gridColumn17.OptionsColumn.ReadOnly = true;
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 7;
            this.gridColumn17.Width = 200;
            // 
            // gridColumn8
            // 
            this.gridColumn8.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.Caption = "분류";
            this.gridColumn8.FieldName = "APPLICATION_TYPE";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsColumn.AllowEdit = false;
            this.gridColumn8.OptionsColumn.ReadOnly = true;
            this.gridColumn8.Width = 100;
            // 
            // colMENU_ORDER
            // 
            this.colMENU_ORDER.AppearanceCell.Options.UseTextOptions = true;
            this.colMENU_ORDER.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.colMENU_ORDER.AppearanceHeader.Options.UseTextOptions = true;
            this.colMENU_ORDER.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMENU_ORDER.Caption = "메뉴순서";
            this.colMENU_ORDER.FieldName = "MENU_ORDER";
            this.colMENU_ORDER.Name = "colMENU_ORDER";
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Caption = "Check";
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.repositoryItemCheckEdit1.ValueChecked = "Y";
            this.repositoryItemCheckEdit1.ValueUnchecked = "N";
            // 
            // grdGroup
            // 
            this.grdGroup.CheckBoxFieldName = "CHK";
            this.grdGroup.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdGroup.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdGroup.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdGroup.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdGroup.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdGroup.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdGroup.IsHeaderClickAllCheckedItem = false;
            this.grdGroup.Location = new System.Drawing.Point(375, 142);
            this.grdGroup.MainView = this.grvGroup;
            this.grdGroup.MinLength = 0;
            this.grdGroup.Name = "grdGroup";
            this.grdGroup.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpychkYN});
            this.grdGroup.Size = new System.Drawing.Size(601, 138);
            this.grdGroup.TabIndex = 11;
            this.grdGroup.UseEmbeddedNavigator = true;
            this.grdGroup.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvGroup});
            // 
            // grvGroup
            // 
            this.grvGroup.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn7});
            this.grvGroup.GridControl = this.grdGroup;
            this.grvGroup.Name = "grvGroup";
            this.grvGroup.OptionsView.ColumnAutoWidth = false;
            this.grvGroup.OptionsView.ShowGroupPanel = false;
            this.grvGroup.DoubleClick += new System.EventHandler(this.grvGroup_DoubleClick);
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "그룹ID";
            this.gridColumn1.FieldName = "GROUP_ID";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.OptionsColumn.ReadOnly = true;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "그룹명";
            this.gridColumn2.FieldName = "GROUP_NAME";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.OptionsColumn.ReadOnly = true;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            this.gridColumn2.Width = 200;
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.Caption = "사용여부";
            this.gridColumn4.ColumnEdit = this.rpychkYN;
            this.gridColumn4.FieldName = "USE_YN";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.AllowEdit = false;
            this.gridColumn4.OptionsColumn.ReadOnly = true;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 2;
            // 
            // rpychkYN
            // 
            this.rpychkYN.AutoHeight = false;
            this.rpychkYN.Caption = "Check";
            this.rpychkYN.Name = "rpychkYN";
            this.rpychkYN.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpychkYN.ValueChecked = "Y";
            this.rpychkYN.ValueUnchecked = "N";
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.Caption = "공통그룹";
            this.gridColumn5.ColumnEdit = this.rpychkYN;
            this.gridColumn5.FieldName = "COMMON_GROUP_YN";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.OptionsColumn.ReadOnly = true;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 3;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.Caption = "적요";
            this.gridColumn7.FieldName = "DESCR";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            this.gridColumn7.OptionsColumn.ReadOnly = true;
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 4;
            this.gridColumn7.Width = 250;
            // 
            // grdUser
            // 
            this.grdUser.CheckBoxFieldName = "CHK";
            this.grdUser.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdUser.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdUser.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdUser.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdUser.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdUser.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdUser.IsHeaderClickAllCheckedItem = false;
            this.grdUser.Location = new System.Drawing.Point(24, 142);
            this.grdUser.MainView = this.grvUser;
            this.grdUser.MinLength = 0;
            this.grdUser.Name = "grdUser";
            this.grdUser.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpychkCheckYN});
            this.grdUser.Size = new System.Drawing.Size(318, 434);
            this.grdUser.TabIndex = 17;
            this.grdUser.UseEmbeddedNavigator = true;
            this.grdUser.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvUser});
            // 
            // grvUser
            // 
            this.grvUser.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn3,
            this.gridColumn12,
            this.gridColumn13,
            this.gridColumn14,
            this.gridColumn15});
            this.grvUser.GridControl = this.grdUser;
            this.grvUser.Name = "grvUser";
            this.grvUser.OptionsView.ColumnAutoWidth = false;
            this.grvUser.OptionsView.ShowGroupPanel = false;
            this.grvUser.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.grvUser_FocusedRowChanged);
            this.grvUser.DoubleClick += new System.EventHandler(this.grvUser_DoubleClick);
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.Caption = "사용자ID";
            this.gridColumn3.FieldName = "USER_ID";
            this.gridColumn3.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.OptionsColumn.ReadOnly = true;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 0;
            this.gridColumn3.Width = 90;
            // 
            // gridColumn12
            // 
            this.gridColumn12.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.Caption = "사용자명(한)";
            this.gridColumn12.FieldName = "KOR_NM";
            this.gridColumn12.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.OptionsColumn.AllowEdit = false;
            this.gridColumn12.OptionsColumn.ReadOnly = true;
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 1;
            this.gridColumn12.Width = 100;
            // 
            // gridColumn13
            // 
            this.gridColumn13.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn13.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn13.Caption = "사용자명(영)";
            this.gridColumn13.FieldName = "ENG_NM";
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.OptionsColumn.AllowEdit = false;
            this.gridColumn13.OptionsColumn.ReadOnly = true;
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 2;
            this.gridColumn13.Width = 120;
            // 
            // gridColumn14
            // 
            this.gridColumn14.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.Caption = "직급";
            this.gridColumn14.FieldName = "JOB_TIT_NM";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.OptionsColumn.AllowEdit = false;
            this.gridColumn14.OptionsColumn.ReadOnly = true;
            this.gridColumn14.Visible = true;
            this.gridColumn14.VisibleIndex = 3;
            // 
            // gridColumn15
            // 
            this.gridColumn15.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.Caption = "부서명";
            this.gridColumn15.FieldName = "DEPTNAME";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.OptionsColumn.AllowEdit = false;
            this.gridColumn15.OptionsColumn.ReadOnly = true;
            this.gridColumn15.Visible = true;
            this.gridColumn15.VisibleIndex = 4;
            this.gridColumn15.Width = 150;
            // 
            // rpychkCheckYN
            // 
            this.rpychkCheckYN.AutoHeight = false;
            this.rpychkCheckYN.Caption = "Check";
            this.rpychkCheckYN.Name = "rpychkCheckYN";
            this.rpychkCheckYN.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpychkCheckYN.ValueChecked = "Y";
            this.rpychkCheckYN.ValueUnchecked = "N";
            // 
            // txtDeptName
            // 
            this.txtDeptName.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtDeptName.EditValue = "";
            this.txtDeptName.EnterExecuteButton = null;
            this.txtDeptName.FocusColor = System.Drawing.Color.Empty;
            this.txtDeptName.IsValueTrim = true;
            this.txtDeptName.Key = "DEPTNAME";
            this.txtDeptName.Location = new System.Drawing.Point(515, 68);
            this.txtDeptName.MinLength = 0;
            this.txtDeptName.Name = "txtDeptName";
            this.txtDeptName.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtDeptName.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtDeptName.Properties.Appearance.Options.UseBackColor = true;
            this.txtDeptName.Properties.Appearance.Options.UseForeColor = true;
            this.txtDeptName.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtDeptName.Size = new System.Drawing.Size(156, 20);
            this.txtDeptName.StyleController = this.xtraLayoutControlExt1;
            this.txtDeptName.TabIndex = 16;
            this.txtDeptName.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtUser_Nm
            // 
            this.txtUser_Nm.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtUser_Nm.EditValue = "";
            this.txtUser_Nm.EnterExecuteButton = null;
            this.txtUser_Nm.FocusColor = System.Drawing.Color.Empty;
            this.txtUser_Nm.IsValueTrim = true;
            this.txtUser_Nm.Key = "KOR_NM";
            this.txtUser_Nm.Location = new System.Drawing.Point(302, 68);
            this.txtUser_Nm.MinLength = 0;
            this.txtUser_Nm.Name = "txtUser_Nm";
            this.txtUser_Nm.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtUser_Nm.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtUser_Nm.Properties.Appearance.Options.UseBackColor = true;
            this.txtUser_Nm.Properties.Appearance.Options.UseForeColor = true;
            this.txtUser_Nm.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtUser_Nm.Size = new System.Drawing.Size(130, 20);
            this.txtUser_Nm.StyleController = this.xtraLayoutControlExt1;
            this.txtUser_Nm.TabIndex = 15;
            this.txtUser_Nm.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtUser_Id
            // 
            this.txtUser_Id.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtUser_Id.EditValue = "";
            this.txtUser_Id.EnterExecuteButton = null;
            this.txtUser_Id.FocusColor = System.Drawing.Color.Empty;
            this.txtUser_Id.IsValueTrim = true;
            this.txtUser_Id.Key = "USER_ID";
            this.txtUser_Id.Location = new System.Drawing.Point(108, 68);
            this.txtUser_Id.MinLength = 0;
            this.txtUser_Id.Name = "txtUser_Id";
            this.txtUser_Id.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtUser_Id.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtUser_Id.Properties.Appearance.Options.UseBackColor = true;
            this.txtUser_Id.Properties.Appearance.Options.UseForeColor = true;
            this.txtUser_Id.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtUser_Id.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtUser_Id.Size = new System.Drawing.Size(111, 20);
            this.txtUser_Id.StyleController = this.xtraLayoutControlExt1;
            this.txtUser_Id.TabIndex = 14;
            this.txtUser_Id.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // btnSearch
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSearch, new string[] {
            "SELECT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSearch, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSearch, true);
            this.btnSearch.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_조회;
            this.btnSearch.IsExecuteWdworkerLog = true;
            this.btnSearch.Location = new System.Drawing.Point(835, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(71, 22);
            this.btnSearch.StyleController = this.xtraLayoutControlExt1;
            this.btnSearch.TabIndex = 7;
            this.btnSearch.Text = "조회";
            this.btnSearch.UseSplasher = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "Root";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup1, false);
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem2,
            this.layoutControlItem3,
            this.layoutControlGroup2,
            this.layoutControlGroup3,
            this.layoutControlGroup4,
            this.splitterItem1,
            this.splitterItem2,
            this.layoutControlGroup5,
            this.layoutControlItem9});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1000, 600);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(823, 26);
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.btnSearch;
            this.layoutControlItem3.CustomizationFormText = "layoutControlItem3";
            this.layoutControlItem3.Location = new System.Drawing.Point(823, 0);
            this.layoutControlItem3.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem3.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem3.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem3.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.CaptionImage = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Grouup_tit_ico;
            this.layoutControlGroup2.CustomizationFormText = "사용자정보";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup2, false);
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem4});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 94);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(346, 486);
            this.layoutControlGroup2.Text = "사용자정보";
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.grdUser;
            this.layoutControlItem4.CustomizationFormText = "layoutControlItem4";
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(322, 438);
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextVisible = false;
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup3.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup3.CaptionImage = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Grouup_tit_ico;
            this.layoutControlGroup3.CustomizationFormText = "그룹정보";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup3, false);
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem6});
            this.layoutControlGroup3.Location = new System.Drawing.Point(351, 94);
            this.layoutControlGroup3.Name = "layoutControlGroup3";
            this.layoutControlGroup3.Size = new System.Drawing.Size(629, 190);
            this.layoutControlGroup3.Text = "그룹정보";
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.grdGroup;
            this.layoutControlItem6.CustomizationFormText = "layoutControlItem6";
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(605, 142);
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextVisible = false;
            // 
            // layoutControlGroup4
            // 
            this.layoutControlGroup4.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup4.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup4.CaptionImage = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Grouup_tit_ico;
            this.layoutControlGroup4.CustomizationFormText = "프로그램정보";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup4, false);
            this.layoutControlGroup4.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem7});
            this.layoutControlGroup4.Location = new System.Drawing.Point(351, 289);
            this.layoutControlGroup4.Name = "layoutControlGroup4";
            this.layoutControlGroup4.Size = new System.Drawing.Size(629, 291);
            this.layoutControlGroup4.Text = "프로그램정보";
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.grdProgram;
            this.layoutControlItem7.CustomizationFormText = "layoutControlItem7";
            this.layoutControlItem7.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(605, 243);
            this.layoutControlItem7.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem7.TextVisible = false;
            // 
            // splitterItem1
            // 
            this.splitterItem1.AllowHotTrack = true;
            this.splitterItem1.CustomizationFormText = "splitterItem1";
            this.splitterItem1.Location = new System.Drawing.Point(351, 284);
            this.splitterItem1.Name = "splitterItem1";
            this.splitterItem1.Size = new System.Drawing.Size(629, 5);
            // 
            // splitterItem2
            // 
            this.splitterItem2.AllowHotTrack = true;
            this.splitterItem2.CustomizationFormText = "splitterItem2";
            this.splitterItem2.Location = new System.Drawing.Point(346, 94);
            this.splitterItem2.Name = "splitterItem2";
            this.splitterItem2.Size = new System.Drawing.Size(5, 486);
            // 
            // layoutControlGroup5
            // 
            this.layoutControlGroup5.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 1F);
            this.layoutControlGroup5.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup5.CustomizationFormText = " ";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup5, true);
            this.layoutControlGroup5.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem5,
            this.layoutControlItem1,
            this.layoutControlItem2,
            this.layoutControlItem8,
            this.emptySpaceItem1,
            this.layoutControlItem10,
            this.layoutControlItem11});
            this.layoutControlGroup5.Location = new System.Drawing.Point(0, 26);
            this.layoutControlGroup5.Name = "layoutControlGroup5";
            this.layoutControlGroup5.Size = new System.Drawing.Size(980, 68);
            this.layoutControlGroup5.Text = " ";
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.txtUser_Id;
            this.layoutControlItem5.CustomizationFormText = "시스템명";
            this.layoutControlItem5.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_blue;
            this.layoutControlItem5.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(214, 26);
            this.layoutControlItem5.Spacing = new DevExpress.XtraLayout.Utils.Padding(20, 15, 0, 0);
            this.layoutControlItem5.Text = "사용자ID";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(61, 16);
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.txtUser_Nm;
            this.layoutControlItem1.CustomizationFormText = "성명";
            this.layoutControlItem1.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_blue;
            this.layoutControlItem1.Location = new System.Drawing.Point(214, 0);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(213, 26);
            this.layoutControlItem1.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 15, 0, 0);
            this.layoutControlItem1.Text = "사용자명";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(61, 16);
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.txtDeptName;
            this.layoutControlItem2.CustomizationFormText = "부서명";
            this.layoutControlItem2.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_blue;
            this.layoutControlItem2.Location = new System.Drawing.Point(427, 0);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(224, 26);
            this.layoutControlItem2.Text = "부서명";
            this.layoutControlItem2.TextSize = new System.Drawing.Size(61, 16);
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.btnDeptPopUp;
            this.layoutControlItem8.CustomizationFormText = "layoutControlItem8";
            this.layoutControlItem8.Location = new System.Drawing.Point(651, 0);
            this.layoutControlItem8.MaxSize = new System.Drawing.Size(30, 24);
            this.layoutControlItem8.MinSize = new System.Drawing.Size(30, 24);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(30, 26);
            this.layoutControlItem8.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem8.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem8.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(681, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(92, 26);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.btnExcel;
            this.layoutControlItem10.Location = new System.Drawing.Point(898, 0);
            this.layoutControlItem10.MaxSize = new System.Drawing.Size(58, 26);
            this.layoutControlItem10.MinSize = new System.Drawing.Size(58, 26);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem10.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem10.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem10.TextVisible = false;
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.cboTYPE;
            this.layoutControlItem11.Location = new System.Drawing.Point(773, 0);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(125, 26);
            this.layoutControlItem11.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem11.TextVisible = false;
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.btnSelectMenu;
            this.layoutControlItem9.Location = new System.Drawing.Point(898, 0);
            this.layoutControlItem9.MaxSize = new System.Drawing.Size(82, 26);
            this.layoutControlItem9.MinSize = new System.Drawing.Size(82, 26);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(82, 26);
            this.layoutControlItem9.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem9.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem9.TextVisible = false;
            // 
            // SCSYS010
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS010";
            this.Size = new System.Drawing.Size(1000, 600);
            this.Shown += new System.EventHandler(this.SCSYS010_Shown);
            this.Load += new System.EventHandler(this.SCSYS010_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cboTYPE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdProgram)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvProgram)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkYN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkCheckYN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDeptName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUser_Nm.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUser_Id.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private Client.Controls.DXperience.XtraButtonExt btnSearch;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private Controls.StdButtonExecuteManager stdButtonExecuteManager1;
        private Client.Controls.DXperience.XtraTextEditExt txtUser_Id;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private Client.Controls.DXperience.XtraTextEditExt txtDeptName;
        private Client.Controls.DXperience.XtraTextEditExt txtUser_Nm;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private Client.Controls.DXperience.XtraGridControlExt grdUser;
        private DevExpress.XtraGrid.Views.Grid.GridView grvUser;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpychkCheckYN;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private Client.Controls.DXperience.XtraGridControlExt grdGroup;
        private DevExpress.XtraGrid.Views.Grid.GridView grvGroup;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpychkYN;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private Client.Controls.DXperience.XtraGridControlExt grdProgram;
        private DevExpress.XtraGrid.Views.Grid.GridView grvProgram;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.SplitterItem splitterItem1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraLayout.SplitterItem splitterItem2;
        private Client.Controls.DXperience.XtraButtonExt btnDeptPopUp;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private Windows.Forms.StdSecurityManager stdSecurityManager1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup5;
        private DevExpress.XtraGrid.Columns.GridColumn colMENU_ID;
        private DevExpress.XtraGrid.Columns.GridColumn colMENU_NAME;
        private DevExpress.XtraGrid.Columns.GridColumn colGROUP_ID;
        private DevExpress.XtraGrid.Columns.GridColumn colGROUP_NAME;
        private DevExpress.XtraGrid.Columns.GridColumn colMENU_ORDER;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private Client.Controls.DXperience.XtraButtonExt btnSelectMenu;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private Client.Controls.DXperience.XtraButtonExt btnExcel;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraEditors.ImageComboBoxEdit cboTYPE;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
    }
}
