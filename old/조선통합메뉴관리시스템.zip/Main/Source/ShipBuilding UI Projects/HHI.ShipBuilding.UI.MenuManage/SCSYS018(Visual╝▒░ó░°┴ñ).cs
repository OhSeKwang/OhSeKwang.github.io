﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraTreeList.Nodes;
using DevExpress.XtraEditors;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(false)]
    public partial class SCSYS018 : StdUserControlBase// UserControl
    {
        #region 생성자 및 변수 선언
        public SCSYS018()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();



            #endregion
        }

        private string sUSER_ID = string.Empty;

        /// <summary>
        /// 그리드 RepositoryItem의 PopupContainerEdit를 형변환해서 전역으로 선언한다
        /// </summary>
        PopupContainerEdit txtButtonRegisterPopupContainer = null;

        string sMENU_ID = string.Empty;
        #endregion

        #region 화면 Load
        private void SCSYS013_Load(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                
            }
        }

        private void SCSYS013_Shown(object sender, EventArgs e)
        {
            string strUrl = string.Empty;

            // http://ship.hhi.co.kr/block/index.asp?sabun=A401226
            strUrl += string.Format(@"http://ship.hhi.co.kr/block/index.asp?sabun={0}", UserInfo.UserID);
            
            object obj = null;

            axWebBrowser1.Navigate(strUrl, ref obj, ref obj, ref obj, ref obj);
        }
        #endregion

        private void axWebBrowser1_NewWindow2(object sender, AxSHDocVw.DWebBrowserEvents2_NewWindow2Event e)
        {
            SCSYS018P1 scsys018p1 = new SCSYS018P1();
            scsys018p1.Show(this);

            e.ppDisp = scsys018p1.WebBrower.Application;
            scsys018p1.WebBrower.RegisterAsBrowser = true;
        }
    }
}
