﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;

namespace HHI.ShipBuilding.UI.MenuManage
{
    public partial class SCSYS013P1 : DevExpress.XtraEditors.XtraForm
    {
        public AxSHDocVw.AxWebBrowser WebBrower
        {
            get
            {
                return axWebBrowser1;
            }
        }

        public SCSYS013P1()
        {
            InitializeComponent();
        }

        #region 화면 Load - SCSYS009P1_Load
        /// <summary>
        /// 화면 Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SCSYS009P1_Load(object sender, EventArgs e)
        {
            initPage();
        }

        private void SCSYS013P1_Load(object sender, EventArgs e)
        {
            initPage();
        }
        #endregion 화면 Load - SCSYS009P1_Load

        #region 화면 초기화 - initPage
        /// <summary>
        /// 화면 초기화
        /// </summary>
        private void initPage()
        {
            
        }
        #endregion 화면 초기화 - initPage

        #region 닫기 - btnClose_Click
        /// <summary>
        /// 닫기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }
        #endregion 닫기 - btnClose_Click

    }
}
