﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    public partial class SCSYS002P1 : DevExpress.XtraEditors.XtraForm
    {
        /// <summary>
        /// 사용자 정보 DataRow
        /// </summary>
        public DataRow hdnRow { get; set; }

        public string sLOGIN_USERID { get; set; }

        private string sIS_GUBUN = "N";

        public SCSYS002P1()
        {
            InitializeComponent();
        }

        #region 화면 Load - SCSYS002P1_Load
        /// <summary>
        /// 화면 Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SCSYS002P1_Load(object sender, EventArgs e)
        {
            initPage();
        }
        #endregion 화면 Load - SCSYS002P1_Load

        #region 화면 초기화 - initPage
        /// <summary>
        /// 화면 초기화
        /// </summary>
        private void initPage()
        {
            // 그룹 사용자 그리드 초기화
            DataTable dt = new DataTable();
            dt.Columns.Add("CHK");
            dt.Columns.Add("GROUP_ID");
            dt.Columns.Add("GROUP_NAME");
            dt.Columns.Add("USER_ID");
            dt.Columns.Add("KOR_NM");
            dt.Columns.Add("JOB_TIT_NM");
            dt.Columns.Add("DEPTNAME");
            dt.Columns.Add("ASGN_NM");

            grdGroupUser.DataSource = dt;

            // 콤보바인딩
            ClientControlHelper.ImageComboBind(rpsCboWORK_GUBUN, "CDNM", "CDCODE", "{value}-{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, ClientControlHelper.GetCodeInfo("SY001"));
            ClientControlHelper.ImageComboBind(rpsCboSYSTEM_CODE, "SYSTEM_NAME", "SYSTEM_CODE", "{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, GetSystemCode());
            ClientControlHelper.ImageComboBind(cboWORK_GUBUN, "CDNM", "CDCODE", "{value}-{text}", ComboDisplayTextOption.top, "전체", string.Empty, ClientControlHelper.GetCodeInfo("SY001"));
            ClientControlHelper.ImageComboBind(cboSYSTEM_CODE, "SYSTEM_NAME", "SYSTEM_CODE", "{value}-{text}", ComboDisplayTextOption.top, "전체", string.Empty, GetSystemCode());
            
        }
        #endregion 화면 초기화 - initPage

        #region 닫기 - btnClose_Click
        /// <summary>
        /// 닫기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }
        #endregion 닫기 - btnClose_Click

        #region 그룹 조회 - btnSearch_Group_Click
        /// <summary>
        /// 그룹 조회
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Group_Click(object sender, EventArgs e)
        {
            DataResultSet resultSet = GetGroupInfo(cboSYSTEM_CODE.EditValue.ToString(), cboWORK_GUBUN.EditValue.ToString(), txtGroup_Name.Text, string.Empty);

            if (resultSet.IsSuccess)
            {
                grdGroup.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 그룹 조회 - btnSearch_Group_Click

        #region 그룹정보 조회 - GetGroupInfo
        /// <summary>
        /// 그룹정보 조회
        /// </summary>
        /// <param name="strGroup_Nm"></param>
        /// <param name="strDescr"></param>
        /// <returns></returns>
        private DataResultSet GetGroupInfo(string strSYSTEM_CODE, string strWORK_GUBUN, string strGroup_Nm, string strDescr)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("SYSTEM_CODE", strSYSTEM_CODE);
            parameter.DataList.Add("WORK_GUBUN", strWORK_GUBUN);
            parameter.DataList.Add("GROUP_NAME", strGroup_Nm);
            parameter.DataList.Add("DESCR", strDescr);
            parameter.DataList.Add("USE_YN", "Y");

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS002.SEARCH_01", parameter);
        }
        #endregion 그룹정보 조회 - GetGroupInfo

        #region 사용자 조회 - btnSearch_User_Click
        /// <summary>
        /// 사용자 조회
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_User_Click(object sender, EventArgs e)
        {
            string strSearchCheck = txtUser_Id.Text + txtUser_Nm.Text + txtDeptName.Text;
            if (string.IsNullOrWhiteSpace(strSearchCheck))
            {
                MsgBox.Show("조회 조건중 하나 이상을 입력 하세요!", "경고");
                txtUser_Id.Focus();
                return;
            }

            DataResultSet resultSet = GetUserInfo(txtUser_Id.Text, txtUser_Nm.Text, txtDeptName.Text);

            if (resultSet.IsSuccess)
            {
                grdUser.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 사용자 조회 - btnSearch_User_Click

        #region 사용자 조회 - GetUserInfo
        /// <summary>
        /// 그룹정보 조회
        /// </summary>
        /// <param name="strGroup_Nm"></param>
        /// <param name="strDescr"></param>
        /// <returns></returns>
        private DataResultSet GetUserInfo(string strUser_Id, string strUser_Nm, string strDeptName)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("USER_ID", strUser_Id);
            parameter.DataList.Add("USER_NM", strUser_Nm);
            parameter.DataList.Add("DEPTNAME", strDeptName);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS002.SEARCH_03", parameter);
        }
        #endregion 사용자 조회 - GetUserInfo

        #region 그룹 사용자 추가 - btnAddRow_Click
        /// <summary>
        /// 그룹 사용자 추가
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddRow_Click(object sender, EventArgs e)
        {
            #region 그룹 정보 선택 체크

            if (grvGroup.RowCount == 0)
            {
                MsgBox.Show("그룹 정보를 조회후 그룹 사용자에 추가 할 그룹 정보를 선택 하세요!", "경고");
                return;
            }

            if ((grdGroup.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            {
                MsgBox.Show("그룹 사용자에 추가 할 그룹 정보를 선택 하세요!", "경고");
                return;
            }

            #endregion 그룹 정보 선택 체크

            #region 사용자 정보 선택 체크

            if (grvUser.RowCount == 0)
            {
                MsgBox.Show("사용자 정보를 조회후 그룹 사용자에 추가 할 사용자 정보를 선택 하세요!", "경고");
                return;
            }

            if (sIS_GUBUN.Equals("N"))
            {// 행추가 버튼일때만 체크
                if ((grdUser.DataSource as DataTable).Select("CHK='Y'").Length == 0)
                {
                    MsgBox.Show("그룹 사용자에 추가 할 사용자 정보를 선택 하세요!", "경고");
                    return;
                }
            }

            #endregion 사용자 정보 선택 체크

            // 그룹 사용자 정보 DataTable
            DataTable dtGroupUser = (grdGroupUser.DataSource as DataTable).Copy();

            // 그룹 정보 DataTable
            DataTable dtGroup = (grdGroup.DataSource as DataTable).Select("CHK = 'Y'").CopyToDataTable();

            // 사용자 정보 DataTable
            DataTable dtUser = (grdUser.DataSource as DataTable).Select("CHK = 'Y'").CopyToDataTable();

            foreach (DataRow rowGroup in dtGroup.Rows)
            {
                foreach (DataRow rowUser in dtUser.Rows)
                {
                    int iAddRowCheck = dtGroupUser.Select(string.Format("GROUP_ID = '{0}' AND USER_ID = '{1}'", rowGroup["GROUP_ID"].ToString(), rowUser["USER_ID"].ToString())).Length;
                    if (iAddRowCheck > 0)
                    {
                        continue;
                    }

                    DataRow rowGroupUser = dtGroupUser.NewRow();
                    rowGroupUser["CHK"] = "N";
                    rowGroupUser["GROUP_ID"] = rowGroup["GROUP_ID"];
                    rowGroupUser["GROUP_NAME"] = rowGroup["GROUP_NAME"];
                    rowGroupUser["USER_ID"] = rowUser["USER_ID"];
                    rowGroupUser["KOR_NM"] = rowUser["KOR_NM"];
                    rowGroupUser["JOB_TIT_NM"] = rowUser["JOB_TIT_NM"];
                    rowGroupUser["DEPTNAME"] = rowUser["DEPTNAME"];
                    rowGroupUser["ASGN_NM"] = rowUser["ASGN_NM"];

                    dtGroupUser.Rows.Add(rowGroupUser);
                }
            }

            grdGroupUser.DataSource = dtGroupUser.Select(null, "KOR_NM ASC").CopyToDataTable();

            // 그룹 정보 선택 해제
            for (int iGroup = 0; iGroup <= grvGroup.RowCount; iGroup++)
            {
                grvGroup.SetRowCellValue(iGroup, "CHK", "N");
            }

            // 사용자 정보 선택 해제
            for (int iUser = 0; iUser <= grvUser.RowCount; iUser++)
            {
                grvUser.SetRowCellValue(iUser, "CHK", "N");
            }
        }
        #endregion 그룹 사용자 추가 - btnAddRow_Click

        #region 행삭제 - btnRowDelete_Click
        /// <summary>
        /// 행삭제
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRowDelete_Click(object sender, EventArgs e)
        {
            for (int i = grvGroupUser.RowCount - 1; i >= 0; i--)
            {
                if (grvGroupUser.GetRowCellValue(i, "CHK").ToString().Equals("Y"))
                {
                    grvGroupUser.DeleteRow(i);
                }
            }
        }
        #endregion 행삭제 - btnRowDelete_Click

        #region 저장 - btnSave_Click
        /// <summary>
        /// 저장
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("저장 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            if (grvGroupUser.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요....", "경고"); return; }

            
            DataTable dtMain = grdGroupUser.DataSource as DataTable;
            string[] paramnames = new string[] { "USER_ID", "GROUP_ID", "LOGIN_USERID" };

            DataTable dtParam = new DataTable();
            for (int i = 0; i < paramnames.Length; i++)
            {
                dtParam.Columns.Add(paramnames[i]);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in dtParam.Columns)
            {
                string[] col1 = new string[dtMain.Rows.Count];
                for (int i = 0; i < dtMain.Rows.Count; i++)
                {
                    if (col.ColumnName.Equals("USER_ID"))
                    {
                        if (string.IsNullOrWhiteSpace(dtMain.Rows[i][col.ColumnName].ToString()))
                        {
                            MsgBox.Show("사용자ID는 필수 입력 입니다.", "경고");
                            return;
                        }
                    }

                    if (col.ColumnName.Equals("GROUP_ID"))
                    {
                        if (string.IsNullOrWhiteSpace(dtMain.Rows[i][col.ColumnName].ToString()))
                        {
                            MsgBox.Show("그룹ID는 필수 입력 입니다.", "경고");
                            return;
                        }
                    }
                    if (col.ColumnName.Equals("LOGIN_USERID"))
                    {
                        col1[i] = sLOGIN_USERID;
                    }
                    else
                    {
                        col1[i] = dtMain.Rows[i][col.ColumnName].ToString();
                    }
                }

                parameter.DataList.Add(col.ColumnName, col1);
            }

            parameter.ArrayItemCount = dtMain.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS002.SAVE_01", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("저장되었습니다.", "확인");
                //this.DialogResult = System.Windows.Forms.DialogResult.OK;
                //this.Close();
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 저장 - btnSave_Click

        #region HHI 조직도 - btnDeptPopUp_Click
        /// <summary>
        /// HHI 조직도
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDeptPopUp_Click(object sender, EventArgs e)
        {
            SCSYS002P2 scsys002p2 = new SCSYS002P2();

            if (scsys002p2.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtDeptName.EditValue = scsys002p2.hdnDEPT_NM;
            }
        }
        #endregion HHI 조직도 - btnDeptPopUp_Click

        /// <summary>
        /// 시스템코드조회
        /// </summary>
        /// <returns></returns>
        private DataTable GetSystemCode()
        {
            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCCOMMON.SEARCH_SYSTEM").QuerySet.Tables[0];
        }


        private void grvUser_DoubleClick(object sender, EventArgs e)
        {
            DataRow row = grvUser.GetFocusedDataRow();
            if (row != null)
            {
                sIS_GUBUN = "Y";
                row["CHK"] = "Y";
                btnAddRow.PerformClick();
                sIS_GUBUN = "N";
            }
        }

        #region 컨트롤 이벤트
        /// <summary>
        /// 그룹정보 조건 입력 후, 엔터시 조회
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void groupInfo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearch_Group.PerformClick();
            }
        }
        /// <summary>
        /// 사용자정보 조건 입력 후, 엔터시 조회
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void userInfo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearch_User.PerformClick();
            }
        }

        #endregion
    }
}
