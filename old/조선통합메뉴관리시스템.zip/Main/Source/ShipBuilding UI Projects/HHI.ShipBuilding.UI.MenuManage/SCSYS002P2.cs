﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using DevExpress.XtraTreeList.Nodes;
using DevExpress.XtraTreeList;

namespace HHI.ShipBuilding.UI.MenuManage
{
    public partial class SCSYS002P2 : DevExpress.XtraEditors.XtraForm
    {
        public string hdnDEPT_CD { get; set; }

        public string hdnDEPT_NM { get; set; }

        public SCSYS002P2()
        {
            InitializeComponent();
        }

        #region 화면 Load - SCSYS002P2_Load
        /// <summary>
        /// 화면 Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SCSYS002P2_Load(object sender, EventArgs e)
        {
            initPage();
        }
        #endregion 화면 Load - SCSYS002P2_Load

        #region 화면 초기화 - initPage
        /// <summary>
        /// 화면 초기화
        /// </summary>
        private void initPage()
        {
            GetHHIDeptInfo("ROOT");
        }
        #endregion 화면 초기화 - initPage

        #region 트리 조회 - GetHHIDeptInfo
        /// <summary>
        /// 트리 조회
        /// </summary>
        /// <param name="strPRNT_CD"></param>
        private void GetHHIDeptInfo(string strPRNT_CD)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("PRNT_CD", strPRNT_CD);

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS002.SEARCH_04", parameter);

            if (resultSet.IsSuccess)
            {
                treeDept.DataSource = resultSet.QuerySet.Tables[0];

                treeDept.ExpandAll();
                treeDept.VertScrollVisibility = DevExpress.XtraTreeList.ScrollVisibility.Always;
                treeDept.HorzScrollVisibility = DevExpress.XtraTreeList.ScrollVisibility.Always;
            }
            else
            {
                MessageBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 트리 조회 - GetHHIDeptInfo

        #region 닫기 - btnClose_Click
        /// <summary>
        /// 닫기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }
        #endregion 닫기 - btnClose_Click

        #region 트리 노드 더블 클릭 - treeDept_DoubleClick
        /// <summary>
        /// 트리 노드 더블 클릭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void treeDept_DoubleClick(object sender, EventArgs e)
        {
            TreeListNode node = (sender as TreeList).FocusedNode;

            if(!node.HasChildren)
            {
                hdnDEPT_CD = node.GetValue("ASGN_CD").ToString();
                hdnDEPT_NM = node.GetValue("ASGN_SHRT_NM").ToString();
                this.DialogResult = System.Windows.Forms.DialogResult.OK;
            }
        }
        #endregion 트리 노드 더블 클릭 - treeDept_DoubleClick
    }
}
