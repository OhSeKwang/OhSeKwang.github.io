﻿using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.Windows.Forms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    /// <summary>
    /// 컨트롤에서 DB 파라미터등을 처리하는 클래스. TextEdit, CheckEdit 만 구현했다.
    /// (접두어 다음에 필드명을 사용하는 컨트롤)
    /// </summary>
    public class CtrlDBKey
    {
        private static readonly Lazy<CtrlDBKey> instance = new Lazy<CtrlDBKey>(() => new CtrlDBKey());

        /// <summary>
        /// VSFileType 개체 생성
        /// </summary>
        /// <returns></returns>
        public static CtrlDBKey Instance
        {
            get
            {
                return instance.Value;
            }
        }

        /// <summary>
        /// DB 필드명을 컨트롤 명에서 추출하여 통합 메뉴 관리 컨트롤을 사용할 경우 Key 속에 아니면 Tag 에 입력함.
        /// </summary>
        /// <param name="ctrl">검색할 부모 컨트롤</param>
        /// <param name="prefix">컨트롤 명에 사용된 접두어들 (txt, chk 등)</param>
        public void InsertControlDBkey(Control ctrl, params string[] prefix)
        {
            foreach (Control c in ctrl.Controls)
            {
                if (IsManagedType(c))
                {
                    for (int i = 0; i < prefix.Length; i++)
                    {
                        if (c.Name.StartsWith(prefix[i]))
                        {
                            try
                            {
                                if (c is HHI.ShipBuilding.Controls.IStdBaseDataMappingControl)
                                {
                                    (c as HHI.ShipBuilding.Controls.IStdBaseDataMappingControl).Key = c.Name.Substring(prefix[i].Length);
                                }
                                else
                                {
                                    c.Tag = c.Name.Substring(prefix[i].Length);
                                }
                                break;
                            }
                            catch
                            {
                                continue;
                            }
                        }
                    }
                }
                else if (c.HasChildren)
                {
                    InsertControlDBkey(c, prefix);
                }
            }
        }

        /// <summary>
        /// 통합 메뉴에 있는, 공통 DB 호출 메서드에서 사용하는 파라미터를 만든다.
        /// </summary>
        /// <param name="cols">HHI.ShipBuilding.Data.Model.WcfParameter.DataCollection 타입 매개 변수</param>
        /// <param name="ctrl">검색할 부모 컨트롤</param>
        /// <param name="paramPrefix">입력할 db 파라미터 접두어</param>
        /// <param name="prefix">컨트롤 명에 사용된 접두어들 (txt, chk 등)</param>
        /// <example>CtrlSupport.SetControlDataList(par.DataList, (Control)xtraLayoutControlExt1, "i_", "txt");</example>
        public void SetControlDataList(DataCollection cols, Control ctrl, string paramPrefix, params string[] prefix)
        {
            SetControlDataList(cols, ctrl, null, paramPrefix, prefix);
        }

        /// <summary>
        /// 통합 메뉴에 있는, 공통 DB 호출 메서드에서 사용하는 파라미터를 만든다. 
        /// (대상 컨트롤의 자식들 중에 제외해야 할 컨트롤의 자식들이 있을때 해당 부모를 넣어 모두 제외 시킨다.)
        /// </summary>
        /// <param name="cols">HHI.ShipBuilding.Data.Model.WcfParameter.DataCollection 타입 매개 변수</param>
        /// <param name="ctrl">검색할 부모 컨트롤</param>
        /// <param name="exceptCtrl">검색에서 제외할 부모 컨트롤</param>
        /// <param name="paramPrefix">입력할 db 파라미터 접두어</param>
        /// <param name="prefix">컨트롤 명에 사용된 접두어들 (txt, chk 등)</param>
        /// <example>CtrlSupport.SetControlDataList(par.DataList, (Control)xtraLayoutControlExt1, "i_", "txt");</example>
        public void SetControlDataList(DataCollection cols, Control ctrl, Control exceptCtrl, string paramPrefix, params string[] prefix)
        {
            foreach (Control c in ctrl.Controls)
            {
                if (exceptCtrl != null && c.Equals(exceptCtrl))
                    continue;

                if (IsManagedType(c))
                {
                    for (int i = 0; i < prefix.Length; i++)
                    {
                        if (c.Name.StartsWith(prefix[i]))
                        {
                            try
                            {
                                if (c is HHI.ShipBuilding.Controls.IStdBaseDataMappingControl)
                                {
                                    if (string.IsNullOrEmpty((c as HHI.ShipBuilding.Controls.IStdBaseDataMappingControl).Key))
                                        continue;

                                    cols.Add(paramPrefix + (c as HHI.ShipBuilding.Controls.IStdBaseDataMappingControl).Key, GetValue(c));
                                    break;
                                }
                                else
                                {
                                    if (c.Tag == null || string.IsNullOrEmpty(c.Tag.ToString()))
                                        continue;

                                    cols.Add(paramPrefix + Convert.ToString(c.Tag), GetValue(c));
                                    break;
                                }
                            }
                            catch
                            {
                                continue;
                            }
                        }
                    }
                }
                else if (c.HasChildren)
                {
                    SetControlDataList(cols, c, exceptCtrl, paramPrefix, prefix);
                }
            }
        }

        /// <summary>
        /// 컨트롤을 값을 비운다.
        /// </summary>
        /// <param name="ctrl">대상 부모 컨트롤</param>
        /// <param name="prefix">접두어</param>
        public void ClearControls(Control ctrl, params string[] prefix)
        {
            ClearControls(ctrl, null, prefix);
        }

        /// <summary>
        /// 컨트롤을 값을 비운다.
        /// </summary>
        /// <param name="ctrl">대상 부모 컨트롤</param>
        /// <param name="exceptCtrl">제외 부모 컨트롤</param>
        /// <param name="prefix">접두어</param>
        public void ClearControls(Control ctrl, Control exceptCtrl, params string[] prefix)
        {
            foreach (Control c in ctrl.Controls)
            {
                if (exceptCtrl != null && c.Equals(exceptCtrl))
                    continue;

                if (IsManagedType(c))
                {
                    for (int i = 0; i < prefix.Length; i++)
                    {
                        if (c.Name.StartsWith(prefix[i]))
                        {
                            try
                            {
                                /* private static bool IsManagedType(Control ctrl) 메서드의 
                                 * 내부 분기와 쌍을 이뤄야 합니다.*/
                                if (c is DevExpress.XtraEditors.TextEdit)
                                {
                                    (c as DevExpress.XtraEditors.TextEdit).Text = string.Empty;
                                }
                                else if (c is DevExpress.XtraEditors.CheckEdit)
                                {
                                    (c as DevExpress.XtraEditors.CheckEdit).Checked = false;
                                }

                                break;
                            }
                            catch
                            {
                                continue;
                            }
                        }
                    }
                }
                else if (c.HasChildren)
                {
                    ClearControls(c, exceptCtrl, prefix);
                }
            }
        }

        /// <summary>
        /// 컨트롤에 DataRow 값을 입력한다.
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="row"></param>
        /// <param name="prefix"></param>
        public void SetControlsValue(Control ctrl, DataRow row, params string[] prefix)
        {
            SetControlsValue(ctrl, null, row, prefix);
        }

        /// <summary>
        /// 컨트롤에 DataRow 값을 입력한다.
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="exceptCtrl"></param>
        /// <param name="row"></param>
        /// <param name="prefix"></param>
        public void SetControlsValue(Control ctrl, Control exceptCtrl, DataRow row, params string[] prefix)
        {
            foreach (Control c in ctrl.Controls)
            {
                if (exceptCtrl != null && c.Equals(exceptCtrl))
                    continue;

                if (IsManagedType(c))
                {
                    for (int i = 0; i < prefix.Length; i++)
                    {
                        if (c.Name.StartsWith(prefix[i]))
                        {
                            try
                            {
                                /* private static bool IsManagedType(Control ctrl) 메서드의 
                                 * 내부 분기와 쌍을 이뤄야 합니다.*/
                                if (c is DevExpress.XtraEditors.TextEdit)
                                {
                                    if (c is HHI.ShipBuilding.Controls.IStdBaseDataMappingControl)
                                    {
                                        (c as DevExpress.XtraEditors.TextEdit).Text = Convert.ToString(row[(c as HHI.ShipBuilding.Controls.IStdBaseDataMappingControl).Key]);
                                    }
                                    else
                                    {
                                        (c as DevExpress.XtraEditors.TextEdit).Text = Convert.ToString(row[c.Tag.ToString()]);
                                    }
                                    
                                }
                                else if (c is DevExpress.XtraEditors.CheckEdit)
                                {
                                    if (c is HHI.ShipBuilding.Controls.IStdBaseDataMappingControl)
                                    {
                                        (c as DevExpress.XtraEditors.CheckEdit).EditValue = Convert.ToString(row[(c as HHI.ShipBuilding.Controls.IStdBaseDataMappingControl).Key]);
                                    }
                                    else
                                    {
                                        (c as DevExpress.XtraEditors.CheckEdit).Text = Convert.ToString(row[c.Tag.ToString()]);
                                    }
                                }

                                break;
                            }
                            catch
                            {
                                continue;
                            }
                        }
                    }
                }
                else if (c.HasChildren)
                {
                    SetControlsValue(c, exceptCtrl, row, prefix);
                }
            }
        }

        /// <summary>
        /// 복수의 DataRow 값을 DataPack 에 담는다.
        /// </summary>
        /// <param name="rows">대상 DataRows</param>
        /// <param name="dbPrefix">파라미터 접두어</param>
        /// <param name="exceptColName">제외 칼럼들</param>
        /// <returns></returns>
        public DataPack SetDataRowValue(DataRow[] rows, string dbPrefix, params string[] exceptColName)
        {
            DataPack par = new DataPack();

            Dictionary<string, List<string>> dic = new Dictionary<string, List<string>>();

            for (int h = 0; h < rows[0].Table.Columns.Count; h++)
            {
                bool IsContinue = false;
                foreach (string val in exceptColName)
                {
                    if (rows[0].Table.Columns[h].ColumnName.Equals(val, StringComparison.OrdinalIgnoreCase))
                    {
                        IsContinue = true;
                    }
                }

                if (IsContinue)
                    continue;

                List<string> vList = new List<string>();
                dic.Add(rows[0].Table.Columns[h].ColumnName, vList);

                for (int i = 0; i < rows.Length; i++)
                {
                    vList.Add(Convert.ToString(rows[i][h]));
                }
            }

            foreach (KeyValuePair<string, List<string>> val in dic)
            {
                par.DataList.Add(dbPrefix + val.Key, val.Value.ToArray());
            }

            par.ArrayItemCount = rows.Length; //==> ArrayBind 처리시... 항상 지정해야함...

            return par;
        }

        /// <summary>
        /// CHK = 'Y' 인 DataRow[] 을 반환한다. (사용자에게 보여주는 메시지가 처리 되어 있다.)
        /// </summary>
        /// <param name="owner"></param>
        /// <param name="grd"></param>
        /// <param name="title"></param>
        /// <returns></returns>
        public DataRow[] CheckedRows(IWin32Window owner, DevExpress.XtraGrid.GridControl grd, string title)
        {
            if (grd.MainView.RowCount == 0)
                return null;

            if (MsgBox.Show(owner, title + " 하시겠습니까?", "확인", MessageBoxButtons.OKCancel, ImageKinds.Question) == DialogResult.Cancel)
            {
                return null;
            }

            DataRow[] rows = (grd.DataSource as DataTable).Select("CHK='Y'");
            if (rows.Length == 0)
            {
                MsgBox.Show(owner, title + "할 정보를 선택하세요!", "알림", MessageBoxButtons.OK, ImageKinds.Warnning);
                return null;
            }

            return rows;
        }

        /// <summary>
        /// 해당 컨트롤이 여기서 관리하는 컨트롤 타입인지 여부
        /// </summary>
        /// <param name="ctrl"></param>
        /// <returns></returns>
        private bool IsManagedType(Control ctrl)
        {
            if (ctrl is DevExpress.XtraEditors.TextEdit)
            {
                return true;
            }
            else if (ctrl is DevExpress.XtraEditors.CheckEdit)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private object GetValue(object o)
        {
            try
            {
                if (o is DevExpress.XtraEditors.TextEdit)
                {
                    return (o as DevExpress.XtraEditors.TextEdit).Text;
                }
                else if (o is DevExpress.XtraEditors.CheckEdit)
                {
                    if ((o as DevExpress.XtraEditors.CheckEdit).CheckState == CheckState.Checked)
                    {
                        return (o as DevExpress.XtraEditors.CheckEdit).Properties.ValueChecked;
                    }
                    else if ((o as DevExpress.XtraEditors.CheckEdit).CheckState == CheckState.Unchecked)
                    {
                        return (o as DevExpress.XtraEditors.CheckEdit).Properties.ValueUnchecked;
                    }
                    else
                    {
                        return (o as DevExpress.XtraEditors.CheckEdit).Properties.ValueGrayed;
                    }
                }
                else
                {
                    throw new TypeAccessException("CtrlDBKey.GetValue 사용중 관리되지 않은 타입이 있습니다..");
                }
            }
            catch
            {
                return string.Empty;
            }
        }
    }
}