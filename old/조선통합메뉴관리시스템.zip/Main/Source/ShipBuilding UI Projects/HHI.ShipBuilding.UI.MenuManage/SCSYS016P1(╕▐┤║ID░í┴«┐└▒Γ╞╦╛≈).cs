﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Views.Grid;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS016P1 : StdUserControlBase//UserControl
    {
        #region 생성자 밑 전역변수
        public SCSYS016P1()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }

        public string sSYSTEM_CODE = string.Empty;
        public string sMENU_ID = string.Empty;
        public string sMENU_NAME = string.Empty;
        public string sGUBUN = "N";  // 더블클릭시 'Y' 변경

        #endregion

        #region 화면 Load
       
        #endregion

        #region SCSYS016_Shown        
        private void SCSYS016P1_Shown(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                initPage();

                stdSecurityManager1.ApplySecurity(this.SecurityContext);
                stdButtonExecuteManager1.RegisterButtonExecEvent();

                btnSearch.PerformClick();
            }
        }
        #endregion

        #region 버튼 이벤트

        #region 조회
        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (!stdValidationManager1.Validation())
            {
                return;
            }

            DataPack parameter = new DataPack();
            parameter.DataList.Add("SYSTEM_CODE",   cboSYSTEM_CODE.EditValue.ToString());
            parameter.DataList.Add("MENU_ID", txtMENU_ID.Text);
            parameter.DataList.Add("MENU_NAME", txtMENU_NAME.Text);
            
            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS016.SEARCH_02", parameter);

            if (resultSet.IsSuccess)
            {
                grdMaster.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }

        }
        #endregion

        #region 닫기
        private void btnClose_Click(object sender, EventArgs e)
        {
            StdPopupHost popuphost = (StdPopupHost)this.Parent.Parent;
            popuphost.Close();
        }
        #endregion

        #endregion

        #region 그리드 이벤트
        
        private void grvMaster_DoubleClick(object sender, EventArgs e)
        {
            DataRow row = grvMaster.GetFocusedDataRow();

            if (row != null)
            {
                sGUBUN = "Y";
                sSYSTEM_CODE = row["SYSTEM_CODE"].ToString();
                sMENU_ID = row["MENU_ID"].ToString();
                sMENU_NAME = row["MENU_NAME"].ToString();

                StdPopupHost popuphost = (StdPopupHost)this.Parent.Parent;
                popuphost.Close();
            }
        }
        #endregion

        #region 컨트롤 이벤트
        #endregion

        #region 메서드

        private void initPage()
        {                        
            // 콤보 바인딩
            ClientControlHelper.ImageComboBind(cboSYSTEM_CODE, "SYSTEM_NAME", "SYSTEM_CODE", "{value}-{text}", ComboDisplayTextOption.top, "전체", string.Empty, GetSystemCode());
            ClientControlHelper.ImageComboBind(rpsCboSystemCode, "SYSTEM_NAME", "SYSTEM_CODE", "{value}-{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, GetSystemCode());

            txtMENU_ID.Text = sMENU_ID;
            cboSYSTEM_CODE.EditValue = sSYSTEM_CODE;
            

            // 그리드 초기화
            DataTable dt = new DataTable();
            
        }
        
        /// <summary>
        /// 시스템코드조회
        /// </summary>
        /// <returns></returns>
        private DataTable GetSystemCode()
        {
            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCCOMMON.SEARCH_SYSTEM").QuerySet.Tables[0];
        }

        #endregion

        
        
    }
}
