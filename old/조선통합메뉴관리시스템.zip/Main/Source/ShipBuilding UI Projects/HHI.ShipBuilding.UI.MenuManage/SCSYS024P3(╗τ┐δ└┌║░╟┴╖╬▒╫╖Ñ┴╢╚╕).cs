﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;

using DevExpress.XtraGrid.Views.Grid;

using HHI.ServiceModel;
using HHI.Windows.Forms;

//using BIZWORKCommon.Helpers;
//using BIZWORKCommon.Security;
//using BIZWORKCommon.WcfService.SystemChannel;

using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Controls;
using DevExpress.XtraTreeList.Nodes;

namespace HHI.ShipBuilding.UI.MenuManage
{
    public partial class SCSYS024P3 : DevExpress.XtraEditors.XtraForm
    {
        #region 전역변수
        
        /// <summary>
        /// 결과 
        /// </summary>
        public bool pRESULT { get; set; }

        /// <summary>
        /// ID
        /// </summary>
        public string pUSERID { get; set; }


        public string pPROGRAM_ID { get; set; }

        public string pPROGRAM_NAME { get; set; }

        #endregion 전역변수

        public SCSYS024P3()
        {
            InitializeComponent();
        }

        private void SCSYS024P3_Load(object sender, EventArgs e)
        {
            InitForm();
        }

        #region 화면 초기 설정 - InitForm
        /// <summary>
        /// 화면 초기 설정
        /// </summary>
        private void InitForm()
        {
            pRESULT = false;

            btnSearch.PerformClick();
        }
        #endregion 화면 초기 설정 - InitForm

        private void btnSearch_Click(object sender, EventArgs e)
        {            
            GetMenu();
        }

        #region 닫기 - btnClose_Click
        /// <summary>
        /// 닫기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            pRESULT = false;
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }
        #endregion 닫기 - btnClose_Click

        #region  메뉴가져오기
        private void GetMenu()
        {
            try
            {
                treeList1.BeginUnboundLoad();
                treeList1.ClearNodes();

                string sQueryId = "MENUMANGE.SCSYS010.SEARCH_04";

                DataPack parameter = new DataPack();
                parameter.DataList.Add("USER_ID", pUSERID);

                DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, sQueryId, parameter);

                if (resultSet.IsSuccess)
                {
                    treeList1.DataSource = resultSet.QuerySet.Tables[0];
                    treeList1.RefreshDataSource();

                }
                else
                {
                    MsgBox.Show(resultSet.ExceptionMessage);
                }
            }
            catch (Exception ex)
            {
                MsgBox.Show(ex.Message);
            }
            finally
            {
                treeList1.EndUnboundLoad();
            }

        }
        #endregion

        #region
        private void treeList1_DoubleClick(object sender, EventArgs e)
        {
            TreeListNode node = treeList1.FocusedNode;

            if (!node.HasChildren)
            {
                pPROGRAM_ID = node["PROGRAM_ID"].ToString();
                pPROGRAM_NAME = node["DISPLAY_TITLE"].ToString();
                pRESULT = true;
                this.Close();
            }
        }
        #endregion
    }
}