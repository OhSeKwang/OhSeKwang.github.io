﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS016P1
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SCSYS016P1));
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.btnClose = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.cboSYSTEM_CODE = new HHI.ShipBuilding.Client.Controls.DXperience.XtraImageComboBoxEditExt();
            this.grdMaster = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvMaster = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colCHK = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCHK = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.colMENU_ID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colMENU_NAME = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSYSTEM_CODE = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboSystemCode = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.colDIV = new DevExpress.XtraGrid.Columns.GridColumn();
            this.txtMENU_ID = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtMENU_NAME = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnSearch = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem5 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.stdSecurityManager1 = new HHI.ShipBuilding.Windows.Forms.StdSecurityManager(this.components);
            this.stdButtonExecuteManager1 = new HHI.ShipBuilding.Controls.StdButtonExecuteManager(this.components);
            this.stdValidationManager1 = new HHI.ShipBuilding.Controls.StdValidationManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboSYSTEM_CODE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMaster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMaster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboSystemCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMENU_ID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMENU_NAME.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.btnClose);
            this.xtraLayoutControlExt1.Controls.Add(this.cboSYSTEM_CODE);
            this.xtraLayoutControlExt1.Controls.Add(this.grdMaster);
            this.xtraLayoutControlExt1.Controls.Add(this.txtMENU_ID);
            this.xtraLayoutControlExt1.Controls.Add(this.txtMENU_NAME);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearch);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(770, 395, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(974, 624);
            this.xtraLayoutControlExt1.TabIndex = 0;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // btnClose
            // 
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnClose, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnClose, false);
            this.btnClose.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_닫기;
            this.btnClose.IsExecuteWdworkerLog = true;
            this.btnClose.Location = new System.Drawing.Point(908, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(54, 22);
            this.btnClose.StyleController = this.xtraLayoutControlExt1;
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "닫기";
            this.btnClose.UseSplasher = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // cboSYSTEM_CODE
            // 
            this.cboSYSTEM_CODE.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.cboSYSTEM_CODE.EditValue = "";
            this.cboSYSTEM_CODE.EnterExecuteButton = null;
            this.cboSYSTEM_CODE.FocusColor = System.Drawing.Color.Empty;
            this.cboSYSTEM_CODE.Key = "";
            this.cboSYSTEM_CODE.Location = new System.Drawing.Point(100, 59);
            this.cboSYSTEM_CODE.MinLength = 0;
            this.cboSYSTEM_CODE.Name = "cboSYSTEM_CODE";
            this.cboSYSTEM_CODE.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.cboSYSTEM_CODE.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.cboSYSTEM_CODE.Properties.Appearance.Options.UseBackColor = true;
            this.cboSYSTEM_CODE.Properties.Appearance.Options.UseForeColor = true;
            this.cboSYSTEM_CODE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboSYSTEM_CODE.Size = new System.Drawing.Size(211, 20);
            this.cboSYSTEM_CODE.StyleController = this.xtraLayoutControlExt1;
            this.cboSYSTEM_CODE.TabIndex = 10;
            // 
            // grdMaster
            // 
            this.grdMaster.CheckBoxFieldName = "CHK";
            this.grdMaster.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdMaster.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdMaster.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdMaster.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdMaster.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdMaster.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdMaster.IsHeaderClickAllCheckedItem = true;
            this.grdMaster.Location = new System.Drawing.Point(24, 151);
            this.grdMaster.MainView = this.grvMaster;
            this.grdMaster.MinLength = 0;
            this.grdMaster.Name = "grdMaster";
            this.grdMaster.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpsCHK,
            this.rpsCboSystemCode});
            this.grdMaster.Size = new System.Drawing.Size(926, 449);
            this.grdMaster.TabIndex = 9;
            this.grdMaster.UseEmbeddedNavigator = true;
            this.grdMaster.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvMaster});
            // 
            // grvMaster
            // 
            this.grvMaster.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colCHK,
            this.colSYSTEM_CODE,
            this.colMENU_ID,
            this.colMENU_NAME,
            this.colDIV});
            this.grvMaster.GridControl = this.grdMaster;
            this.grvMaster.Name = "grvMaster";
            this.grvMaster.OptionsBehavior.Editable = false;
            this.grvMaster.OptionsView.ColumnAutoWidth = false;
            this.grvMaster.OptionsView.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.grvMaster.OptionsView.ShowFooter = true;
            this.grvMaster.OptionsView.ShowGroupPanel = false;
            this.grvMaster.DoubleClick += new System.EventHandler(this.grvMaster_DoubleClick);
            // 
            // colCHK
            // 
            this.colCHK.AppearanceHeader.Options.UseTextOptions = true;
            this.colCHK.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colCHK.Caption = "선택";
            this.colCHK.ColumnEdit = this.rpsCHK;
            this.colCHK.FieldName = "CHK";
            this.colCHK.Name = "colCHK";
            this.colCHK.Width = 56;
            // 
            // rpsCHK
            // 
            this.rpsCHK.AutoHeight = false;
            this.rpsCHK.Caption = "Check";
            this.rpsCHK.Name = "rpsCHK";
            this.rpsCHK.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpsCHK.ValueChecked = "Y";
            this.rpsCHK.ValueUnchecked = "N";
            // 
            // colMENU_ID
            // 
            this.colMENU_ID.AppearanceHeader.Options.UseTextOptions = true;
            this.colMENU_ID.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMENU_ID.Caption = "메뉴ID";
            this.colMENU_ID.FieldName = "MENU_ID";
            this.colMENU_ID.Name = "colMENU_ID";
            this.colMENU_ID.Visible = true;
            this.colMENU_ID.VisibleIndex = 1;
            this.colMENU_ID.Width = 119;
            // 
            // colMENU_NAME
            // 
            this.colMENU_NAME.AppearanceHeader.Options.UseTextOptions = true;
            this.colMENU_NAME.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMENU_NAME.Caption = "메뉴명";
            this.colMENU_NAME.FieldName = "MENU_NAME";
            this.colMENU_NAME.Name = "colMENU_NAME";
            this.colMENU_NAME.Visible = true;
            this.colMENU_NAME.VisibleIndex = 2;
            this.colMENU_NAME.Width = 216;
            // 
            // colSYSTEM_CODE
            // 
            this.colSYSTEM_CODE.AppearanceHeader.Options.UseTextOptions = true;
            this.colSYSTEM_CODE.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSYSTEM_CODE.Caption = "시스템코드";
            this.colSYSTEM_CODE.ColumnEdit = this.rpsCboSystemCode;
            this.colSYSTEM_CODE.FieldName = "SYSTEM_CODE";
            this.colSYSTEM_CODE.Name = "colSYSTEM_CODE";
            this.colSYSTEM_CODE.Visible = true;
            this.colSYSTEM_CODE.VisibleIndex = 0;
            this.colSYSTEM_CODE.Width = 234;
            // 
            // rpsCboSystemCode
            // 
            this.rpsCboSystemCode.AutoHeight = false;
            this.rpsCboSystemCode.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboSystemCode.Name = "rpsCboSystemCode";
            // 
            // colDIV
            // 
            this.colDIV.Caption = "DIV";
            this.colDIV.FieldName = "DIV";
            this.colDIV.Name = "colDIV";
            // 
            // txtMENU_ID
            // 
            this.txtMENU_ID.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtMENU_ID.EditValue = "";
            this.txtMENU_ID.EnterExecuteButton = null;
            this.txtMENU_ID.FocusColor = System.Drawing.Color.Empty;
            this.txtMENU_ID.IsValueTrim = true;
            this.txtMENU_ID.Key = "";
            this.txtMENU_ID.Location = new System.Drawing.Point(391, 59);
            this.txtMENU_ID.MinLength = 0;
            this.txtMENU_ID.Name = "txtMENU_ID";
            this.txtMENU_ID.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtMENU_ID.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtMENU_ID.Properties.Appearance.Options.UseBackColor = true;
            this.txtMENU_ID.Properties.Appearance.Options.UseForeColor = true;
            this.txtMENU_ID.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtMENU_ID.Size = new System.Drawing.Size(172, 20);
            this.txtMENU_ID.StyleController = this.xtraLayoutControlExt1;
            this.txtMENU_ID.TabIndex = 7;
            this.txtMENU_ID.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtMENU_NAME
            // 
            this.txtMENU_NAME.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtMENU_NAME.EditValue = "";
            this.txtMENU_NAME.EnterExecuteButton = null;
            this.txtMENU_NAME.FocusColor = System.Drawing.Color.Empty;
            this.txtMENU_NAME.IsValueTrim = true;
            this.txtMENU_NAME.Key = "";
            this.txtMENU_NAME.Location = new System.Drawing.Point(100, 83);
            this.txtMENU_NAME.MinLength = 0;
            this.txtMENU_NAME.Name = "txtMENU_NAME";
            this.txtMENU_NAME.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtMENU_NAME.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtMENU_NAME.Properties.Appearance.Options.UseBackColor = true;
            this.txtMENU_NAME.Properties.Appearance.Options.UseForeColor = true;
            this.txtMENU_NAME.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMENU_NAME.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtMENU_NAME.Size = new System.Drawing.Size(153, 20);
            this.txtMENU_NAME.StyleController = this.xtraLayoutControlExt1;
            this.txtMENU_NAME.TabIndex = 6;
            this.txtMENU_NAME.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // btnSearch
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSearch, new string[] {
            "SELECT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSearch, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSearch, true);
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.IsExecuteWdworkerLog = true;
            this.btnSearch.Location = new System.Drawing.Point(850, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(54, 22);
            this.btnSearch.StyleController = this.xtraLayoutControlExt1;
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "조회";
            this.btnSearch.UseSplasher = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "layoutControlGroup1";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup1, false);
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem1,
            this.layoutControlItem1,
            this.layoutControlGroup2,
            this.layoutControlGroup3,
            this.layoutControlItem7});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(974, 624);
            this.layoutControlGroup1.Text = "Root";
            this.layoutControlGroup1.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(838, 26);
            this.emptySpaceItem1.Text = "emptySpaceItem1";
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.btnSearch;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(838, 0);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem1.Text = "layoutControlItem1";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextToControlDistance = 0;
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.CustomizationFormText = "List";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup2, false);
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem6});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 107);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(954, 497);
            this.layoutControlGroup2.Text = "List";
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.grdMaster;
            this.layoutControlItem6.CustomizationFormText = "layoutControlItem6";
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(930, 453);
            this.layoutControlItem6.Text = "layoutControlItem6";
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextToControlDistance = 0;
            this.layoutControlItem6.TextVisible = false;
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 1F);
            this.layoutControlGroup3.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup3.CustomizationFormText = " ";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup3, true);
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem2,
            this.layoutControlItem8,
            this.emptySpaceItem3,
            this.layoutControlItem3,
            this.emptySpaceItem5,
            this.layoutControlItem4});
            this.layoutControlGroup3.Location = new System.Drawing.Point(0, 26);
            this.layoutControlGroup3.Name = "layoutControlGroup3";
            this.layoutControlGroup3.Size = new System.Drawing.Size(954, 81);
            this.layoutControlGroup3.Text = " ";
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(543, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(387, 24);
            this.emptySpaceItem2.Text = "emptySpaceItem2";
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.cboSYSTEM_CODE;
            this.layoutControlItem8.CustomizationFormText = "업무구분";
            this.layoutControlItem8.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem8.Image")));
            this.layoutControlItem8.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(291, 24);
            this.layoutControlItem8.Text = "시스템코드";
            this.layoutControlItem8.TextSize = new System.Drawing.Size(73, 16);
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.CustomizationFormText = "emptySpaceItem3";
            this.emptySpaceItem3.Location = new System.Drawing.Point(291, 24);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(639, 24);
            this.emptySpaceItem3.Text = "emptySpaceItem3";
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.txtMENU_NAME;
            this.layoutControlItem3.CustomizationFormText = "AuthName";
            this.layoutControlItem3.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem3.Image")));
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 24);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(233, 24);
            this.layoutControlItem3.Text = "메뉴명";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(73, 16);
            // 
            // emptySpaceItem5
            // 
            this.emptySpaceItem5.AllowHotTrack = false;
            this.emptySpaceItem5.CustomizationFormText = "emptySpaceItem5";
            this.emptySpaceItem5.Location = new System.Drawing.Point(233, 24);
            this.emptySpaceItem5.Name = "emptySpaceItem5";
            this.emptySpaceItem5.Size = new System.Drawing.Size(58, 24);
            this.emptySpaceItem5.Text = "emptySpaceItem5";
            this.emptySpaceItem5.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.txtMENU_ID;
            this.layoutControlItem4.CustomizationFormText = "Note";
            this.layoutControlItem4.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem4.Image")));
            this.layoutControlItem4.Location = new System.Drawing.Point(291, 0);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(252, 24);
            this.layoutControlItem4.Text = "메뉴ID";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(73, 16);
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.btnClose;
            this.layoutControlItem7.CustomizationFormText = "layoutControlItem7";
            this.layoutControlItem7.Location = new System.Drawing.Point(896, 0);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem7.Text = "layoutControlItem7";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem7.TextToControlDistance = 0;
            this.layoutControlItem7.TextVisible = false;
            // 
            // stdValidationManager1
            // 
            this.stdValidationManager1.IsNullorWhiteSpace = true;
            this.stdValidationManager1.IsShowErrorMessage = true;
            // 
            // SCSYS016P1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS016P1";
            this.Size = new System.Drawing.Size(974, 624);
            this.Shown += new System.EventHandler(this.SCSYS016P1_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cboSYSTEM_CODE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMaster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMaster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboSystemCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMENU_ID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMENU_NAME.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private Client.Controls.DXperience.XtraGridControlExt grdMaster;
        private DevExpress.XtraGrid.Views.Grid.GridView grvMaster;
        private DevExpress.XtraGrid.Columns.GridColumn colCHK;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpsCHK;
        private Client.Controls.DXperience.XtraTextEditExt txtMENU_ID;
        private Client.Controls.DXperience.XtraTextEditExt txtMENU_NAME;
        private Client.Controls.DXperience.XtraButtonExt btnSearch;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraGrid.Columns.GridColumn colDIV;
        private Client.Controls.DXperience.XtraImageComboBoxEditExt cboSYSTEM_CODE;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private Windows.Forms.StdSecurityManager stdSecurityManager1;
        private Controls.StdButtonExecuteManager stdButtonExecuteManager1;
        private DevExpress.XtraGrid.Columns.GridColumn colMENU_ID;
        private DevExpress.XtraGrid.Columns.GridColumn colSYSTEM_CODE;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private Controls.StdValidationManager stdValidationManager1;
        private DevExpress.XtraGrid.Columns.GridColumn colMENU_NAME;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboSystemCode;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem5;
        private Client.Controls.DXperience.XtraButtonExt btnClose;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
    }
}
