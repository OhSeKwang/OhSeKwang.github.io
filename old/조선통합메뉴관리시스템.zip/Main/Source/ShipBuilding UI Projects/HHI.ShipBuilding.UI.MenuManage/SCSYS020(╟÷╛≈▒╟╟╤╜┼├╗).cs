﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraTreeList.Nodes;
using DevExpress.XtraEditors;
using HHI.Security;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS020 : StdUserControlBase// UserControl
    {

        #region 생성자 및 변수 선언
        public SCSYS020()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }

        private string _sSYSTEM_CODE = string.Empty;

        public string _sGUBUN = "N"; // 팝업으로 호출시 상태값 

        #endregion

        #region 화면 Load

        #endregion

        #region SCSYS020_Shown
        private void SCSYS020_Shown(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                initPage();

                stdSecurityManager1.ApplySecurity(this.SecurityContext);
                stdButtonExecuteManager1.RegisterButtonExecEvent();


                btnSearch.PerformClick();
            }
        }

        #endregion

        #region 버튼이벤트
        #region 조회
        /// <summary>
        /// 사용자그룹 조회[왼쪽그리드] 및 메뉴정보 조회[하단그리드]
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            _sSYSTEM_CODE = string.Empty;
            
            // 그리드 초기화
            if (grdMaster.DataSource is DataTable)
                (grdMaster.DataSource as DataTable).Rows.Clear();

            grdMaster.DataSource = getSystemInfo();

            DataResultSet result = GetAuthRequest();
            if (result.IsSuccess)
                grdAuthRequest.DataSource = result.QuerySet.Tables[0];
            
            
        }
        #endregion

        /// <summary>
        /// 사용자정보 조회
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearchUser_Click(object sender, EventArgs e)
        {
            string strSearchCheck = txtUser_Id.Text + txtUser_Nm.Text;
            if (string.IsNullOrWhiteSpace(strSearchCheck))
            {
                MsgBox.Show("조회 조건중 하나 이상을 입력 하세요!", "경고");
                txtUser_Id.Focus();
                return;
            }

            DataResultSet resultUSER = GetUserInfo(txtUser_Id.Text, txtUser_Nm.Text, string.Empty);

            if (resultUSER.IsSuccess)
                grdUser.DataSource = resultUSER.QuerySet.Tables[0];
            else
                MsgBox.Show(resultUSER.ExceptionMessage);
        }

        /// <summary>
        /// 신청
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRequest_Click(object sender, EventArgs e)
        {
            if (grvAuthRequest.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요....", "경고"); return; }

            if ((grdAuthRequest.DataSource as DataTable).Select("REQUEST_DATE IS NULL").Length == 0)
            { MsgBox.Show("신청할 정보가 없습니다. 추가후 신청하세요.", "경고"); return; }


            if (MsgBox.Show("신청 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            
            DataPack parameter = new DataPack();
            DataTable dt = (grdAuthRequest.DataSource as DataTable).Select("REQUEST_DATE IS NULL").CopyToDataTable();
            string[] arrParams = { "REQUEST_USER_ID", "REQUEST_DATE", "SYSTEM_CODE", "REQUEST", "REQUEST_GUBUN" };

            Hashtable hParam = new Hashtable();
            hParam.Add("LOGIN_USERID", UserInfo.UserID);

            foreach (DataRow drRequest in dt.Rows)
            {
                if (drRequest["SYSTEM_CODE"].ToString().Equals(""))
                { MsgBox.Show("시스템코드를 선택하세요"); return; }
                else if (drRequest["REQUEST_GUBUN"].ToString().Equals(""))
                { MsgBox.Show("요청구분을 선택하세요"); return; }
  
            }

            MngHelpers.DataTableToDataPack(ref parameter, dt, arrParams, hParam);

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS020.SAVE_REQUEST_01", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("신청되었습니다.", "확인");

                btnSearch.PerformClick();

                _sGUBUN = "Y";  // 
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("취소 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            if (grvAuthRequest.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요....", "경고"); return; }

            DataRow drRequest = grvAuthRequest.GetFocusedDataRow();

            if (drRequest != null)
            {
                if(!drRequest["REQUEST_STATUS"].ToString().Equals("N"))
                {
                    MsgBox.Show("진행상태가 미처리 인경우 취소 가능합니다.");
                    return;
                }

                DataPack parameter = new DataPack();
                parameter.DataList.Add("REQUEST_USER_ID", drRequest["REQUEST_USER_ID"].ToString());
                parameter.DataList.Add("REQUEST_DATE", drRequest["REQUEST_DATE"].ToString() != "" ? Convert.ToDateTime(drRequest["REQUEST_DATE"].ToString()).ToString("yyyyMMddHHmmss") : "");
                parameter.DataList.Add("SYSTEM_CODE", drRequest["SYSTEM_CODE"].ToString());

                DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS020.CANCEL_01", parameter);

                if (resultSet.IsSuccess)
                {
                    MsgBox.Show("취소되었습니다.", "확인");

                    btnSearch.PerformClick();
                }
                else
                {
                    MsgBox.Show(resultSet.ExceptionMessage);
                }

            }

        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("변경요청 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            if (grvAuthRequest.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요....", "경고"); return; }

            

        }

        #region 삭제
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("삭제요청 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            if (grvAuthRequest.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요....", "경고"); return; }

            
        }

        #endregion

        #region 저장
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("저장하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            if (grvAuthRequest.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요....", "경고"); return; }


            DataRow drRequest = grvAuthRequest.GetFocusedDataRow();

            if (drRequest != null)
            {
                if (string.IsNullOrWhiteSpace(drRequest["REQUEST_DATE"].ToString()))
                {
                    MsgBox.Show("신청되지 않은 데이터입니다. 신청후 수정가능합니다.");
                    return;
                }
                else if (!drRequest["REQUEST_STATUS"].ToString().Equals("N"))
                {
                    MsgBox.Show("처리상태가 미처리 인경우 수정가능합니다.");
                    return;
                }


                DataPack parameter = new DataPack();
                parameter.DataList.Add("REQUEST_USER_ID", drRequest["REQUEST_USER_ID"].ToString());
                parameter.DataList.Add("REQUEST_DATE", Convert.ToDateTime(drRequest["REQUEST_DATE"].ToString()).ToString("yyyyMMddHHmmss"));
                parameter.DataList.Add("SYSTEM_CODE", drRequest["SYSTEM_CODE"].ToString());
                parameter.DataList.Add("REQUEST", drRequest["REQUEST"].ToString());
                parameter.DataList.Add("LOGIN_USERID", UserInfo.UserID);

                DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS020.SAVE_01", parameter);

                if (resultSet.IsSuccess)
                {
                    MsgBox.Show("수정되었습니다.", "확인");

                    btnSearch.PerformClick();
                }
                else
                {
                    MsgBox.Show(resultSet.ExceptionMessage);
                }
            }



        }
        #endregion

        #endregion

        #region 그리드이벤트

        private void grvAuthRequest_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            DataRow row = grvAuthRequest.GetFocusedDataRow();
            if (row != null)
            {
            }
        }

        private void grvUser_DoubleClick(object sender, EventArgs e)
        {
            DataRow row = grvUser.GetFocusedDataRow();

            if (row != null)
            {                
                grvAuthRequest.AddNewRow();

                grvAuthRequest.SetFocusedRowCellValue("CHK", "N");
                grvAuthRequest.SetFocusedRowCellValue("REQUEST_USER_ID", row["USER_ID"].ToString());
                grvAuthRequest.SetFocusedRowCellValue("REQUEST_USER_NAME", row["KOR_NM"].ToString());
                grvAuthRequest.SetFocusedRowCellValue("DEPTNAME", row["DEPTNAME"].ToString());
                grvAuthRequest.SetFocusedRowCellValue("SYSTEM_CODE", _sSYSTEM_CODE);
                grvAuthRequest.SetFocusedRowCellValue("REQUEST_STATUS", "N");

                grvAuthRequest.UpdateCurrentRow();
                grvAuthRequest.Focus();
            }
        }

        private void grvMaster_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            DataRow row = grvMaster.GetFocusedDataRow();

            if (row != null)
            {
                _sSYSTEM_CODE = row["SYSTEM_CODE"].ToString();
                
                // 시스템별 사용자 조회
                DataResultSet resultUsers = GetAuthUserInfo(row["SYSTEM_CODE"].ToString());

                if (resultUsers.IsSuccess)
                {
                    grdAuthUser.DataSource = resultUsers.QuerySet.Tables[0];
                }
                else
                {
                    MsgBox.Show(resultUsers.ExceptionMessage); return;
                }

                // 시스템 그룹별 메뉴 조회
                DataResultSet resultMenu = GetMenuInfo(row["SYSTEM_CODE"].ToString());
                if (resultMenu.IsSuccess)
                {
                    grdMenuInfo.DataSource = resultMenu.QuerySet.Tables[0];
                }
                else
                { MsgBox.Show(resultMenu.ExceptionMessage); return; }
            }
        }

        private void grvAuthRequest_ShowingEditor(object sender, CancelEventArgs e)
        {
            DataRow row = grvAuthRequest.GetFocusedDataRow();
            if (row != null)
            {
                string strFieldName = grvAuthRequest.FocusedColumn.FieldName;
                if (strFieldName.Equals("REQUEST") || strFieldName.Equals("SYSTEM_CODE"))
                {
                    if (row["REQUEST_DATE"].ToString().Equals(""))
                        grvAuthRequest.Columns[strFieldName].OptionsColumn.ReadOnly = false;
                    else
                        grvAuthRequest.Columns[strFieldName].OptionsColumn.ReadOnly = true;


                }
            }
        }

        #endregion

        #region 컨트롤이벤트
        
        #endregion

        #region 메서드

        private void initPage()
        { 
            // 콤보 바인딩            
            ClientControlHelper.ImageComboBind(rpsCboWORK_GUBUN, "CDNM", "CDCODE", "{value}-{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, ClientControlHelper.GetCodeInfo("SY001"));
            ClientControlHelper.ImageComboBind(cboSYSTEM_CODE, "SYSTEM_NAME", "SYSTEM_CODE", "{value}-{text}", ComboDisplayTextOption.top, "전체", string.Empty, GetSystemCode());
            //ClientControlHelper.ImageComboBind(cboSYSTEM_CODE1, "SYSTEM_NAME", "SYSTEM_CODE", "{value}-{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, GetSystemCode());
            ClientControlHelper.ImageComboBind(rpsCboSYSTEM_CODE1, "SYSTEM_NAME", "SYSTEM_CODE", "{text}", ComboDisplayTextOption.none, string.Empty, string.Empty, GetSystemCode());
            ClientControlHelper.ImageComboBind(rpsCboREQUEST_GUBUN, "CDNM", "CDCODE", "{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, ClientControlHelper.GetCodeInfo("SY012"));
            ClientControlHelper.ImageComboBind(rpsCboREQUEST_STATUS, "CDNM", "CDCODE", "{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, ClientControlHelper.GetCodeInfo("SY013"));            
        }

        /// <summary>
        /// 시스템정보를 가져온다.
        /// </summary>
        /// <returns></returns>
        private DataTable getSystemInfo()
        {
            DataTable dt = new DataTable();

            DataPack parameter = new DataPack();
            parameter.DataList.Add("SYSTEM_CODE", cboSYSTEM_CODE.EditValue.ToString());


            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS020.SEARCH_01", parameter);

            if (resultSet.IsSuccess)
            {
                dt = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }

            return dt;
        }

        /// <summary>
        /// 시스템코드조회
        /// </summary>
        /// <returns></returns>
        private DataTable GetSystemCode()
        {
            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCCOMMON.SEARCH_SYSTEM").QuerySet.Tables[0];
        }


        #region 사용자 조회 - GetUserInfo
        /// <summary>
        /// 사용자정보 조회
        /// </summary>
        /// <param name="strGroup_Nm"></param>
        /// <param name="strDescr"></param>
        /// <returns></returns>
        private DataResultSet GetUserInfo(string strUser_Id, string strUser_Nm, string strDeptName)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("USER_ID", strUser_Id);
            parameter.DataList.Add("USER_NM", strUser_Nm);
            parameter.DataList.Add("DEPTNAME", strDeptName);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS020.SEARCH_02", parameter);
        }
        #endregion 사용자 조회 - GetUserInfo

        /// <summary>
        /// 권한사용자 조회
        /// </summary>
        /// <param name="strSYSTEM_CODE"></param>
        /// <returns></returns>
        private DataResultSet GetAuthUserInfo(string strSYSTEM_CODE)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("SYSTEM_CODE", strSYSTEM_CODE);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS020.SEARCH_AUTH_USERS", parameter);
        }

        private DataResultSet GetMenuInfo(string strSYSTEM_CODE)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("SYSTEM_CODE", strSYSTEM_CODE);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS020.SEARCH_MENUINFO", parameter);
        }

        private DataResultSet GetAuthRequest()
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("LOGIN_USERID", UserInfo.UserID);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS020.SEARCH_AUTH_REQUEST", parameter);
        }

        private void Request(string strGUBUN)
        {
            DataRow drRequest = grvAuthRequest.GetFocusedDataRow();

            if (drRequest != null)
            {
                DataPack parameter = new DataPack();
                parameter.DataList.Add("REQUEST_USER_ID", drRequest["REQUEST_USER_ID"].ToString());
                parameter.DataList.Add("REQUEST_DATE", drRequest["REQUEST_DATE"].ToString());
                parameter.DataList.Add("SYSTEM_CODE", drRequest["SYSTEM_CODE"].ToString());
                parameter.DataList.Add("REQUEST", drRequest["REQUEST"].ToString());
                parameter.DataList.Add("LOGIN_USERID", UserInfo.UserID);
                parameter.DataList.Add("GUBUN", strGUBUN);

                DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS020.SAVE_REQUEST_01", parameter);

                if (resultSet.IsSuccess)
                {
                    MsgBox.Show("신청되었습니다.", "확인");

                    btnSearch.PerformClick();

                    _sGUBUN = "Y";  // 
                }
                else
                {
                    MsgBox.Show(resultSet.ExceptionMessage);
                }
            }
        }

        #endregion

        

    }
}
