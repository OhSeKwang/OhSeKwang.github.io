﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    public partial class SCSYS006P3 : DevExpress.XtraEditors.XtraForm
    {
        /// <summary>
        /// 프로그램정보 DataRow
        /// </summary>
        public DataRow hdnRow { get; set; }

        public string sSYSTEM_CODE = string.Empty;

        public string sDEPT_CD = string.Empty;

        public SCSYS006P3()
        {
            InitializeComponent();
        }

        #region 화면 Load - SCSYS006P3_Load
        /// <summary>
        /// 화면 Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>        
        private void SCSYS006P3_Load(object sender, EventArgs e)
        {
            txtDEPT_CD.Text = sDEPT_CD;

            initPage();
        }
        #endregion 화면 Load - SCSYS006P3_Load

        #region 화면 초기화 - initPage
        /// <summary>
        /// 화면 초기화
        /// </summary>
        private void initPage()
        {
            btnSearch.PerformClick();
        }
        #endregion 화면 초기화 - initPage

        #region 조회 - btnSearch_Click
        /// <summary>
        /// 조회
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            //string strSearchCheck = txtSystem_Name.Text + txtProgram_Name.Text;
            //if (string.IsNullOrWhiteSpace(cboSYSTEM_CODE.EditValue.ToString()) && string.IsNullOrWhiteSpace(strSearchCheck))
            //{
            //    MsgBox.Show("조회 조건중 하나 이상을 입력 하세요!", "경고");
            //    txtSystem_Name.Focus();
            //    return;
            //}

            DataResultSet resultSet = GetAsgnInfo(txtDEPT_CD.Text);

            if (resultSet.IsSuccess)
            {
                grdMain.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 조회 - btnSearch_Click

        #region 조직코드 조회 - GetAsgnInfo
        /// <summary>
        /// 조직코드 조회
        /// </summary>
        /// <param name="strSystem_Name"></param>
        /// <param name="strProgram_Name"></param>
        /// <returns></returns>
        private DataResultSet GetAsgnInfo(string strDEPT_CD)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("DEPT_CD", strDEPT_CD);
            
            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS006.SEARCH_03", parameter);
        }
        #endregion 조직코드 조회 - GetAsgnInfo

        #region 닫기 - btnClose_Click
        /// <summary>
        /// 닫기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }
        #endregion 닫기 - btnClose_Click

        #region 그리드 더블 클릭 - grvMain_DoubleClick
        /// <summary>
        /// 그리드 더블 클릭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void grvMain_DoubleClick(object sender, EventArgs e)
        {
            DataRow row = grvMain.GetFocusedDataRow();
            if (row == null)
            {
                hdnRow = null;
            }
            else
            {
                hdnRow = row;
            }

            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }
        #endregion 그리드 더블 클릭 - grvMain_DoubleClick

        #region 메소드
        /// <summary>
        /// 시스템코드조회
        /// </summary>
        /// <returns></returns>
        private DataTable GetSystemCode()
        {
            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCCOMMON.SEARCH_SYSTEM").QuerySet.Tables[0];
        }
        #endregion

       
    }
}
