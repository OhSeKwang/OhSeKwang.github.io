﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraTreeList.Nodes;
using DevExpress.XtraEditors;
using HHI.Security;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS019 : StdUserControlBase// UserControl
    {

        #region 생성자 및 변수 선언
        public SCSYS019()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }

        private string _sSYSTEM_CODE = string.Empty;

        #endregion

        #region 화면 Load

        #endregion

        #region SCSYS019_Shown
        private void SCSYS019_Shown(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                initPage();

                stdSecurityManager1.ApplySecurity(this.SecurityContext);
                stdButtonExecuteManager1.RegisterButtonExecEvent();

                btnSearch.PerformClick();
            }
        }

        #endregion

        #region 버튼이벤트
        #region 조회
        /// <summary>
        /// 사용자그룹 조회[왼쪽그리드] 및 메뉴정보 조회[하단그리드]
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            _sSYSTEM_CODE = string.Empty;
            // 그리드 초기화
            if (grdMaster.DataSource is DataTable)
                (grdMaster.DataSource as DataTable).Rows.Clear();

            grdMaster.DataSource = getSystemInfo();
            
            
        }
        #endregion

        /// <summary>
        /// 사용자정보 조회
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearchUser_Click(object sender, EventArgs e)
        {
            string strSearchCheck = txtUser_Id.Text + txtUser_Nm.Text;
            if (string.IsNullOrWhiteSpace(strSearchCheck))
            {
                MsgBox.Show("조회 조건중 하나 이상을 입력 하세요!", "경고");
                txtUser_Id.Focus();
                return;
            }

            DataResultSet resultUSER = GetUserInfo(txtUser_Id.Text, txtUser_Nm.Text, string.Empty);

            if (resultUSER.IsSuccess)
                grdUser.DataSource = resultUSER.QuerySet.Tables[0];
            else
                MsgBox.Show(resultUSER.ExceptionMessage);
        }


        #region 저장
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("저장 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            if (grvAuthGorupID.RowCount == 0)
            { MsgBox.Show("권한그룹 데이터를 조회하세요....", "경고"); return; }
            if (grvAuthUser.RowCount == 0)
            { MsgBox.Show("권한 등록할 사용자를 조회하세요....", "경고"); return; }

            //if ((grvAuthUser.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            //{ MsgBox.Show("권한 등록할 사용자를 선택하세요....", "경고"); return; }


            DataRow drUser = grvAuthUser.GetFocusedDataRow();
            
            DataPack parameter = new DataPack();
            DataTable dtGroupInfo = grdAuthGorupID.DataSource as DataTable;
            string[] arrParamName = new string[] { "GROUP_ID", "SYSTEM_CODE", "AUTH_YN", "OUT_YN" };

            Hashtable haddParameter = new Hashtable();
            haddParameter.Add("USER_ID", drUser["USER_ID"].ToString());
            haddParameter.Add("LOGIN_USERID", UserInfo.UserID);

            MngHelpers.DataTableToDataPack(ref parameter, dtGroupInfo, arrParamName, haddParameter);

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS019.SAVE_01", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("저장되었습니다.", "확인");

                grvMaster_FocusedRowChanged(null, null);
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
            

        }
        #endregion
        
        #region 삭제
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("삭제 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            if (grvAuthUser.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요....", "경고"); return; }

            //if ((grdAuthUser.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            //{ MsgBox.Show("삭제할 데이터를 선택하세요....", "경고"); return; }

            DataPack parameter = new DataPack();
            DataRow drUser = grvAuthUser.GetFocusedDataRow();

            parameter.DataList.Add("SYSTEM_CODE", drUser["SYSTEM_CODE"].ToString());
            parameter.DataList.Add("USER_ID", drUser["USER_ID"].ToString());

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS019.DELETE_01", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("삭제되었습니다.", "확인");

                btnSearch.PerformClick();
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion

        #endregion

        #region 그리드이벤트
        private void grvAuthUser_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            DataRow row = grvAuthUser.GetFocusedDataRow();
            if (row != null)
            {// 시스템, 사용자별 권한 그룹 조회
                DataResultSet resultAuthGroup = GetAuthGroupIDInfo(_sSYSTEM_CODE, row["USER_ID"].ToString());
                if (resultAuthGroup.IsSuccess)
                    grdAuthGorupID.DataSource = resultAuthGroup.QuerySet.Tables[0];
                else
                    MsgBox.Show(resultAuthGroup.ExceptionMessage);
            }
        }

        private void grvUser_DoubleClick(object sender, EventArgs e)
        {
            DataRow row = grvUser.GetFocusedDataRow();

            if (row != null)
            {
                // user id check 
                DataRow[] dr = (grdAuthUser.DataSource as DataTable).Select(string.Format("USER_ID='{0}'", row["USER_ID"].ToString()));
                if (dr.Length > 0)
                    return;

                grvAuthUser.AddNewRow();

                grvAuthUser.SetFocusedRowCellValue("CHK", "N");
                grvAuthUser.SetFocusedRowCellValue("USER_ID", row["USER_ID"].ToString());
                grvAuthUser.SetFocusedRowCellValue("KOR_NM", row["KOR_NM"].ToString());
                grvAuthUser.SetFocusedRowCellValue("ENG_NM", row["ENG_NM"].ToString());
                grvAuthUser.SetFocusedRowCellValue("DEPTNAME", row["DEPTNAME"].ToString());
                grvAuthUser.SetFocusedRowCellValue("JOB_TIT_NM", row["JOB_TIT_NM"].ToString());

                grvAuthUser.UpdateCurrentRow();
                grvAuthUser.Focus();
            }
        }

        private void grvAuthGorupID_CellValueChanging(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            if (e.Column.FieldName.Equals("AUTH_YN"))
            {
                if (e.Value.Equals("N"))
                {
                    grvAuthGorupID.SetRowCellValue(e.RowHandle, "OUT_YN", "N");
                }
            }
            else if (e.Column.FieldName.Equals("OUT_YN"))
            {
                if (e.Value.Equals("Y"))
                {
                    grvAuthGorupID.SetRowCellValue(e.RowHandle, "AUTH_YN", "Y");
                }
            }
        }

        private void grvMaster_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            DataRow row = grvMaster.GetFocusedDataRow();

            if (row != null)
            {
                _sSYSTEM_CODE = row["SYSTEM_CODE"].ToString();

                // 시스템별 사용자 조회
                DataResultSet resultUsers = GetAuthUserInfo(row["SYSTEM_CODE"].ToString());

                if (resultUsers.IsSuccess)
                {
                    grdAuthUser.DataSource = resultUsers.QuerySet.Tables[0];

                    if (resultUsers.QuerySet.Tables[0].Rows.Count == 0)
                    {// 시스템, 사용자별 권한 그룹 조회
                        DataResultSet resultAuthGroup = GetAuthGroupIDInfo(row["SYSTEM_CODE"].ToString(), string.Empty);
                        if (resultAuthGroup.IsSuccess)
                            grdAuthGorupID.DataSource = resultAuthGroup.QuerySet.Tables[0];                        
                            
                    }

                }
                else
                {
                    MsgBox.Show(resultUsers.ExceptionMessage);
                }
            }
        }


        #endregion

        #region 컨트롤이벤트
        
        #endregion

        #region 메서드

        private void initPage()
        { 
            // 콤보 바인딩            
            ClientControlHelper.ImageComboBind(rpsCboWORK_GUBUN, "CDNM", "CDCODE", "{value}-{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, ClientControlHelper.GetCodeInfo("SY001"));
            ClientControlHelper.ImageComboBind(cboSYSTEM_CODE, "SYSTEM_NAME", "SYSTEM_CODE", "{value}-{text}", ComboDisplayTextOption.top, "전체", string.Empty, GetSystemCode());
        }

        /// <summary>
        /// 시스템정보를 가져온다.
        /// </summary>
        /// <returns></returns>
        private DataTable getSystemInfo()
        {
            DataTable dt = new DataTable();

            DataPack parameter = new DataPack();
            parameter.DataList.Add("SYSTEM_CODE", cboSYSTEM_CODE.EditValue.ToString());


            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS019.SEARCH_01", parameter);

            if (resultSet.IsSuccess)
            {
                dt = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }

            return dt;
        }

        /// <summary>
        /// 시스템코드조회
        /// </summary>
        /// <returns></returns>
        private DataTable GetSystemCode()
        {
            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCCOMMON.SEARCH_SYSTEM").QuerySet.Tables[0];
        }


        #region 사용자 조회 - GetUserInfo
        /// <summary>
        /// 사용자정보 조회
        /// </summary>
        /// <param name="strGroup_Nm"></param>
        /// <param name="strDescr"></param>
        /// <returns></returns>
        private DataResultSet GetUserInfo(string strUser_Id, string strUser_Nm, string strDeptName)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("USER_ID", strUser_Id);
            parameter.DataList.Add("USER_NM", strUser_Nm);
            parameter.DataList.Add("DEPTNAME", strDeptName);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS019.SEARCH_02", parameter);
        }
        #endregion 사용자 조회 - GetUserInfo

        /// <summary>
        /// 권한사용자 조회
        /// </summary>
        /// <param name="strSYSTEM_CODE"></param>
        /// <returns></returns>
        private DataResultSet GetAuthUserInfo(string strSYSTEM_CODE)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("SYSTEM_CODE", strSYSTEM_CODE);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS019.SEARCH_AUTH_USERS", parameter);
        }

        /// <summary>
        /// 시스템별 사용자별 그룹권한
        /// </summary>
        /// <param name="strSYSTEM_CODE">시스템코드</param>
        /// <param name="strUSER_ID">사용자id</param>
        /// <returns></returns>
        private DataResultSet GetAuthGroupIDInfo(string strSYSTEM_CODE, string strUSER_ID)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("SYSTEM_CODE", strSYSTEM_CODE);
            parameter.DataList.Add("USER_ID", strUSER_ID);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS019.SEARCH_AUTH_GROUPID", parameter);
        }


        #endregion

    }
}
