﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS009P1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.chkBizWork = new HHI.ShipBuilding.Client.Controls.DXperience.XtraCheckEditExt();
            this.chkUseUpdater = new HHI.ShipBuilding.Client.Controls.DXperience.XtraCheckEditExt();
            this.txtPROGRAM = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtFILE_PATH = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtSYSTEM_GUBUN = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.cboWORK_GUBUN = new HHI.ShipBuilding.Client.Controls.DXperience.XtraImageComboBoxEditExt();
            this.txtSAUPBU = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtFtp_Ip = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtFtp_Server_Path = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnFileSave = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnFileDelete = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnFileAttach = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.grdFile = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvFile = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpychkYN = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpyMemoExEdit = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colLOCAL_FILE_PATH = new DevExpress.XtraGrid.Columns.GridColumn();
            this.txtPassword = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtUser_Id = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtInitialize_Class = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtInitialize_Module = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtDownload_Base_Url = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtSystem_Name = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtSystem_Code = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnSave = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnClose = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.lcgSYSTEM_CODE_N = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem16 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem17 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem18 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.lciSYSTEM_CODE_R = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem19 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem20 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem21 = new DevExpress.XtraLayout.LayoutControlItem();
            this.stdValidationManager1 = new HHI.ShipBuilding.Controls.StdValidationManager(this.components);
            this.stdSecurityManager1 = new HHI.ShipBuilding.Windows.Forms.StdSecurityManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkBizWork.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkUseUpdater.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPROGRAM.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFILE_PATH.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSYSTEM_GUBUN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboWORK_GUBUN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSAUPBU.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFtp_Ip.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFtp_Server_Path.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdFile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvFile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkYN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpyMemoExEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPassword.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUser_Id.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInitialize_Class.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInitialize_Module.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDownload_Base_Url.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSystem_Name.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSystem_Code.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcgSYSTEM_CODE_N)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lciSYSTEM_CODE_R)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.chkBizWork);
            this.xtraLayoutControlExt1.Controls.Add(this.chkUseUpdater);
            this.xtraLayoutControlExt1.Controls.Add(this.txtPROGRAM);
            this.xtraLayoutControlExt1.Controls.Add(this.txtFILE_PATH);
            this.xtraLayoutControlExt1.Controls.Add(this.txtSYSTEM_GUBUN);
            this.xtraLayoutControlExt1.Controls.Add(this.cboWORK_GUBUN);
            this.xtraLayoutControlExt1.Controls.Add(this.txtSAUPBU);
            this.xtraLayoutControlExt1.Controls.Add(this.txtFtp_Ip);
            this.xtraLayoutControlExt1.Controls.Add(this.txtFtp_Server_Path);
            this.xtraLayoutControlExt1.Controls.Add(this.btnFileSave);
            this.xtraLayoutControlExt1.Controls.Add(this.btnFileDelete);
            this.xtraLayoutControlExt1.Controls.Add(this.btnFileAttach);
            this.xtraLayoutControlExt1.Controls.Add(this.grdFile);
            this.xtraLayoutControlExt1.Controls.Add(this.txtPassword);
            this.xtraLayoutControlExt1.Controls.Add(this.txtUser_Id);
            this.xtraLayoutControlExt1.Controls.Add(this.txtInitialize_Class);
            this.xtraLayoutControlExt1.Controls.Add(this.txtInitialize_Module);
            this.xtraLayoutControlExt1.Controls.Add(this.txtDownload_Base_Url);
            this.xtraLayoutControlExt1.Controls.Add(this.txtSystem_Name);
            this.xtraLayoutControlExt1.Controls.Add(this.txtSystem_Code);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSave);
            this.xtraLayoutControlExt1.Controls.Add(this.btnClose);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(720, 273, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(695, 510);
            this.xtraLayoutControlExt1.TabIndex = 0;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // chkBizWork
            // 
            this.chkBizWork.EditValue = "N";
            this.chkBizWork.EnterExecuteButton = null;
            this.chkBizWork.Key = "SHARED_SYS";
            this.chkBizWork.Location = new System.Drawing.Point(626, 112);
            this.chkBizWork.Margin = new System.Windows.Forms.Padding(0);
            this.chkBizWork.MinLength = 0;
            this.chkBizWork.Name = "chkBizWork";
            this.chkBizWork.Properties.Caption = "";
            this.chkBizWork.Properties.CheckStyle = DevExpress.XtraEditors.Controls.CheckStyles.Style1;
            this.chkBizWork.Properties.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.chkBizWork.Properties.ValueChecked = "A";
            this.chkBizWork.Properties.ValueGrayed = "";
            this.chkBizWork.Properties.ValueUnchecked = "";
            this.chkBizWork.Size = new System.Drawing.Size(57, 22);
            this.chkBizWork.StyleController = this.xtraLayoutControlExt1;
            this.chkBizWork.TabIndex = 28;
            // 
            // chkUseUpdater
            // 
            this.chkUseUpdater.EditValue = "N";
            this.chkUseUpdater.EnterExecuteButton = null;
            this.chkUseUpdater.Key = "USE_UPDATER";
            this.chkUseUpdater.Location = new System.Drawing.Point(661, 86);
            this.chkUseUpdater.Margin = new System.Windows.Forms.Padding(0);
            this.chkUseUpdater.MinLength = 0;
            this.chkUseUpdater.Name = "chkUseUpdater";
            this.chkUseUpdater.Properties.Caption = "";
            this.chkUseUpdater.Properties.CheckStyle = DevExpress.XtraEditors.Controls.CheckStyles.Style1;
            this.chkUseUpdater.Properties.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.chkUseUpdater.Properties.ValueChecked = "Y";
            this.chkUseUpdater.Properties.ValueGrayed = "";
            this.chkUseUpdater.Properties.ValueUnchecked = "";
            this.chkUseUpdater.Size = new System.Drawing.Size(22, 22);
            this.chkUseUpdater.StyleController = this.xtraLayoutControlExt1;
            this.chkUseUpdater.TabIndex = 27;
            // 
            // txtPROGRAM
            // 
            this.txtPROGRAM.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtPROGRAM.EditValue = "";
            this.txtPROGRAM.EnterExecuteButton = null;
            this.txtPROGRAM.FocusColor = System.Drawing.Color.Empty;
            this.txtPROGRAM.IsValueTrim = true;
            this.txtPROGRAM.Key = "";
            this.txtPROGRAM.Location = new System.Drawing.Point(87, 270);
            this.txtPROGRAM.MinLength = 0;
            this.txtPROGRAM.Name = "txtPROGRAM";
            this.txtPROGRAM.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtPROGRAM.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtPROGRAM.Properties.Appearance.Options.UseBackColor = true;
            this.txtPROGRAM.Properties.Appearance.Options.UseForeColor = true;
            this.txtPROGRAM.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtPROGRAM.Size = new System.Drawing.Size(142, 20);
            this.txtPROGRAM.StyleController = this.xtraLayoutControlExt1;
            this.txtPROGRAM.TabIndex = 14;
            this.txtPROGRAM.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtFILE_PATH
            // 
            this.txtFILE_PATH.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtFILE_PATH.EditValue = "";
            this.txtFILE_PATH.EnterExecuteButton = null;
            this.txtFILE_PATH.FocusColor = System.Drawing.Color.Empty;
            this.txtFILE_PATH.IsValueTrim = true;
            this.txtFILE_PATH.Key = "";
            this.txtFILE_PATH.Location = new System.Drawing.Point(286, 270);
            this.txtFILE_PATH.MinLength = 0;
            this.txtFILE_PATH.Name = "txtFILE_PATH";
            this.txtFILE_PATH.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtFILE_PATH.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtFILE_PATH.Properties.Appearance.Options.UseBackColor = true;
            this.txtFILE_PATH.Properties.Appearance.Options.UseForeColor = true;
            this.txtFILE_PATH.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtFILE_PATH.Size = new System.Drawing.Size(139, 20);
            this.txtFILE_PATH.StyleController = this.xtraLayoutControlExt1;
            this.txtFILE_PATH.TabIndex = 13;
            this.txtFILE_PATH.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtSYSTEM_GUBUN
            // 
            this.txtSYSTEM_GUBUN.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.txtSYSTEM_GUBUN.EditValue = "";
            this.txtSYSTEM_GUBUN.EnterExecuteButton = null;
            this.txtSYSTEM_GUBUN.FocusColor = System.Drawing.Color.Empty;
            this.txtSYSTEM_GUBUN.IsValueTrim = true;
            this.txtSYSTEM_GUBUN.Key = "SYSTEM_GUBUN";
            this.txtSYSTEM_GUBUN.Location = new System.Drawing.Point(359, 38);
            this.txtSYSTEM_GUBUN.MinLength = 3;
            this.txtSYSTEM_GUBUN.Name = "txtSYSTEM_GUBUN";
            this.txtSYSTEM_GUBUN.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.txtSYSTEM_GUBUN.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtSYSTEM_GUBUN.Properties.Appearance.Options.UseBackColor = true;
            this.txtSYSTEM_GUBUN.Properties.Appearance.Options.UseForeColor = true;
            this.txtSYSTEM_GUBUN.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSYSTEM_GUBUN.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSYSTEM_GUBUN.Properties.MaxLength = 3;
            this.txtSYSTEM_GUBUN.Size = new System.Drawing.Size(80, 20);
            this.txtSYSTEM_GUBUN.StyleController = this.xtraLayoutControlExt1;
            this.txtSYSTEM_GUBUN.TabIndex = 8;
            this.txtSYSTEM_GUBUN.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtSYSTEM_GUBUN, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required,
            HHI.ShipBuilding.Controls.ValidationType.MinLength});
            // 
            // cboWORK_GUBUN
            // 
            this.cboWORK_GUBUN.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.cboWORK_GUBUN.EditValue = "";
            this.cboWORK_GUBUN.EnterExecuteButton = null;
            this.cboWORK_GUBUN.FocusColor = System.Drawing.Color.Empty;
            this.cboWORK_GUBUN.Key = "WORK_GUBUN";
            this.cboWORK_GUBUN.Location = new System.Drawing.Point(192, 38);
            this.cboWORK_GUBUN.MinLength = 0;
            this.cboWORK_GUBUN.Name = "cboWORK_GUBUN";
            this.cboWORK_GUBUN.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.cboWORK_GUBUN.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.cboWORK_GUBUN.Properties.Appearance.Options.UseBackColor = true;
            this.cboWORK_GUBUN.Properties.Appearance.Options.UseForeColor = true;
            this.cboWORK_GUBUN.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboWORK_GUBUN.Size = new System.Drawing.Size(163, 20);
            this.cboWORK_GUBUN.StyleController = this.xtraLayoutControlExt1;
            this.cboWORK_GUBUN.TabIndex = 20;
            this.stdValidationManager1.SetValidation(this.cboWORK_GUBUN, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // txtSAUPBU
            // 
            this.txtSAUPBU.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.txtSAUPBU.EditValue = "";
            this.txtSAUPBU.Enabled = false;
            this.txtSAUPBU.EnterExecuteButton = null;
            this.txtSAUPBU.FocusColor = System.Drawing.Color.Empty;
            this.txtSAUPBU.IsValueTrim = true;
            this.txtSAUPBU.Key = "SAUPBU";
            this.txtSAUPBU.Location = new System.Drawing.Point(105, 38);
            this.txtSAUPBU.MinLength = 0;
            this.txtSAUPBU.Name = "txtSAUPBU";
            this.txtSAUPBU.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.txtSAUPBU.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtSAUPBU.Properties.Appearance.Options.UseBackColor = true;
            this.txtSAUPBU.Properties.Appearance.Options.UseForeColor = true;
            this.txtSAUPBU.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSAUPBU.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSAUPBU.Properties.MaxLength = 1;
            this.txtSAUPBU.Properties.ReadOnly = true;
            this.txtSAUPBU.Size = new System.Drawing.Size(83, 20);
            this.txtSAUPBU.StyleController = this.xtraLayoutControlExt1;
            this.txtSAUPBU.TabIndex = 7;
            this.txtSAUPBU.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtSAUPBU, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // txtFtp_Ip
            // 
            this.txtFtp_Ip.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtFtp_Ip.EditValue = "";
            this.txtFtp_Ip.EnterExecuteButton = null;
            this.txtFtp_Ip.FocusColor = System.Drawing.Color.Empty;
            this.txtFtp_Ip.IsValueTrim = true;
            this.txtFtp_Ip.Key = "FTP_IP";
            this.txtFtp_Ip.Location = new System.Drawing.Point(117, 198);
            this.txtFtp_Ip.MinLength = 0;
            this.txtFtp_Ip.Name = "txtFtp_Ip";
            this.txtFtp_Ip.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtFtp_Ip.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtFtp_Ip.Properties.Appearance.Options.UseBackColor = true;
            this.txtFtp_Ip.Properties.Appearance.Options.UseForeColor = true;
            this.txtFtp_Ip.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtFtp_Ip.Size = new System.Drawing.Size(554, 20);
            this.txtFtp_Ip.StyleController = this.xtraLayoutControlExt1;
            this.txtFtp_Ip.TabIndex = 19;
            this.txtFtp_Ip.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtFtp_Server_Path
            // 
            this.txtFtp_Server_Path.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtFtp_Server_Path.EditValue = "";
            this.txtFtp_Server_Path.EnterExecuteButton = null;
            this.txtFtp_Server_Path.FocusColor = System.Drawing.Color.Empty;
            this.txtFtp_Server_Path.IsValueTrim = true;
            this.txtFtp_Server_Path.Key = "FTP_SERVER_PATH";
            this.txtFtp_Server_Path.Location = new System.Drawing.Point(117, 222);
            this.txtFtp_Server_Path.MinLength = 0;
            this.txtFtp_Server_Path.Name = "txtFtp_Server_Path";
            this.txtFtp_Server_Path.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtFtp_Server_Path.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtFtp_Server_Path.Properties.Appearance.Options.UseBackColor = true;
            this.txtFtp_Server_Path.Properties.Appearance.Options.UseForeColor = true;
            this.txtFtp_Server_Path.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtFtp_Server_Path.Size = new System.Drawing.Size(554, 20);
            this.txtFtp_Server_Path.StyleController = this.xtraLayoutControlExt1;
            this.txtFtp_Server_Path.TabIndex = 18;
            this.txtFtp_Server_Path.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // btnFileSave
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnFileSave, new string[] {
            "SAVE"});
            this.btnFileSave.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_저장;
            this.btnFileSave.IsExecuteWdworkerLog = true;
            this.btnFileSave.Location = new System.Drawing.Point(511, 270);
            this.btnFileSave.Name = "btnFileSave";
            this.btnFileSave.Size = new System.Drawing.Size(78, 22);
            this.btnFileSave.StyleController = this.xtraLayoutControlExt1;
            this.btnFileSave.TabIndex = 16;
            this.btnFileSave.Text = "파일저장";
            this.btnFileSave.UseSplasher = false;
            this.btnFileSave.Click += new System.EventHandler(this.btnFileSave_Click);
            // 
            // btnFileDelete
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnFileDelete, new string[] {
            "DELETE"});
            this.btnFileDelete.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_파일삭제;
            this.btnFileDelete.IsExecuteWdworkerLog = true;
            this.btnFileDelete.Location = new System.Drawing.Point(593, 270);
            this.btnFileDelete.Name = "btnFileDelete";
            this.btnFileDelete.Size = new System.Drawing.Size(78, 22);
            this.btnFileDelete.StyleController = this.xtraLayoutControlExt1;
            this.btnFileDelete.TabIndex = 15;
            this.btnFileDelete.Text = "파일삭제";
            this.btnFileDelete.UseSplasher = false;
            this.btnFileDelete.Click += new System.EventHandler(this.btnFileDelete_Click);
            // 
            // btnFileAttach
            // 
            this.btnFileAttach.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_파일찾기;
            this.btnFileAttach.IsExecuteWdworkerLog = true;
            this.btnFileAttach.Location = new System.Drawing.Point(429, 270);
            this.btnFileAttach.Name = "btnFileAttach";
            this.btnFileAttach.Size = new System.Drawing.Size(78, 22);
            this.btnFileAttach.StyleController = this.xtraLayoutControlExt1;
            this.btnFileAttach.TabIndex = 14;
            this.btnFileAttach.Text = "파일첨부";
            this.btnFileAttach.UseSplasher = false;
            this.btnFileAttach.Click += new System.EventHandler(this.btnFileAttach_Click);
            // 
            // grdFile
            // 
            this.grdFile.AllowDrop = true;
            this.grdFile.CheckBoxFieldName = "CHK";
            this.grdFile.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdFile.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdFile.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdFile.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdFile.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdFile.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdFile.IsHeaderClickAllCheckedItem = false;
            this.grdFile.Location = new System.Drawing.Point(24, 296);
            this.grdFile.MainView = this.grvFile;
            this.grdFile.MinLength = 0;
            this.grdFile.Name = "grdFile";
            this.grdFile.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpychkYN,
            this.rpyMemoExEdit});
            this.grdFile.Size = new System.Drawing.Size(647, 190);
            this.grdFile.TabIndex = 12;
            this.grdFile.UseEmbeddedNavigator = true;
            this.grdFile.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvFile});
            this.grdFile.DragDrop += new System.Windows.Forms.DragEventHandler(this.grdFile_DragDrop);
            this.grdFile.DragEnter += new System.Windows.Forms.DragEventHandler(this.grdFile_DragEnter);
            // 
            // grvFile
            // 
            this.grvFile.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn5,
            this.gridColumn4,
            this.gridColumn6,
            this.gridColumn7,
            this.colLOCAL_FILE_PATH});
            this.grvFile.GridControl = this.grdFile;
            this.grvFile.Name = "grvFile";
            this.grvFile.OptionsView.ColumnAutoWidth = false;
            this.grvFile.OptionsView.ShowGroupPanel = false;
            this.grvFile.DoubleClick += new System.EventHandler(this.grvFile_DoubleClick);
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "선택";
            this.gridColumn1.ColumnEdit = this.rpychkYN;
            this.gridColumn1.FieldName = "CHK";
            this.gridColumn1.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 35;
            // 
            // rpychkYN
            // 
            this.rpychkYN.AutoHeight = false;
            this.rpychkYN.Caption = "Check";
            this.rpychkYN.Name = "rpychkYN";
            this.rpychkYN.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpychkYN.ValueChecked = "Y";
            this.rpychkYN.ValueUnchecked = "N";
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "ID";
            this.gridColumn2.FieldName = "ID";
            this.gridColumn2.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.OptionsColumn.ReadOnly = true;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            this.gridColumn2.Width = 45;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.Caption = "프로그램";
            this.gridColumn3.ColumnEdit = this.rpyMemoExEdit;
            this.gridColumn3.FieldName = "PROGRAM_NAME";
            this.gridColumn3.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 2;
            this.gridColumn3.Width = 120;
            // 
            // rpyMemoExEdit
            // 
            this.rpyMemoExEdit.AutoHeight = false;
            this.rpyMemoExEdit.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpyMemoExEdit.Name = "rpyMemoExEdit";
            this.rpyMemoExEdit.ShowIcon = false;
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.Caption = "파일명";
            this.gridColumn5.FieldName = "FILE_NAME";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.OptionsColumn.ReadOnly = true;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 3;
            this.gridColumn5.Width = 120;
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.Caption = "파일경로";
            this.gridColumn4.FieldName = "FILE_PATH";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 4;
            this.gridColumn4.Width = 150;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.Caption = "업로드일시";
            this.gridColumn6.FieldName = "UPDATE_DATE";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.OptionsColumn.ReadOnly = true;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 5;
            this.gridColumn6.Width = 120;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.Caption = "NEWFILE";
            this.gridColumn7.FieldName = "NEWFILE";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            this.gridColumn7.OptionsColumn.ReadOnly = true;
            // 
            // colLOCAL_FILE_PATH
            // 
            this.colLOCAL_FILE_PATH.Caption = "로컬경로";
            this.colLOCAL_FILE_PATH.FieldName = "LOCAL_FILE_PATH";
            this.colLOCAL_FILE_PATH.Name = "colLOCAL_FILE_PATH";
            // 
            // txtPassword
            // 
            this.txtPassword.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtPassword.EditValue = "";
            this.txtPassword.EnterExecuteButton = null;
            this.txtPassword.FocusColor = System.Drawing.Color.Empty;
            this.txtPassword.IsValueTrim = true;
            this.txtPassword.Key = "PASSWORD";
            this.txtPassword.Location = new System.Drawing.Point(415, 246);
            this.txtPassword.MinLength = 0;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtPassword.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtPassword.Properties.Appearance.Options.UseBackColor = true;
            this.txtPassword.Properties.Appearance.Options.UseForeColor = true;
            this.txtPassword.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtPassword.Properties.UseSystemPasswordChar = true;
            this.txtPassword.Size = new System.Drawing.Size(256, 20);
            this.txtPassword.StyleController = this.xtraLayoutControlExt1;
            this.txtPassword.TabIndex = 13;
            this.txtPassword.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtUser_Id
            // 
            this.txtUser_Id.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtUser_Id.EditValue = "";
            this.txtUser_Id.EnterExecuteButton = null;
            this.txtUser_Id.FocusColor = System.Drawing.Color.Empty;
            this.txtUser_Id.IsValueTrim = true;
            this.txtUser_Id.Key = "USER_ID";
            this.txtUser_Id.Location = new System.Drawing.Point(117, 246);
            this.txtUser_Id.MinLength = 0;
            this.txtUser_Id.Name = "txtUser_Id";
            this.txtUser_Id.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtUser_Id.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtUser_Id.Properties.Appearance.Options.UseBackColor = true;
            this.txtUser_Id.Properties.Appearance.Options.UseForeColor = true;
            this.txtUser_Id.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtUser_Id.Size = new System.Drawing.Size(201, 20);
            this.txtUser_Id.StyleController = this.xtraLayoutControlExt1;
            this.txtUser_Id.TabIndex = 12;
            this.txtUser_Id.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtInitialize_Class
            // 
            this.txtInitialize_Class.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtInitialize_Class.EditValue = "";
            this.txtInitialize_Class.EnterExecuteButton = null;
            this.txtInitialize_Class.FocusColor = System.Drawing.Color.Empty;
            this.txtInitialize_Class.IsValueTrim = true;
            this.txtInitialize_Class.Key = "INITIALIZE_CLASS";
            this.txtInitialize_Class.Location = new System.Drawing.Point(105, 138);
            this.txtInitialize_Class.MinLength = 0;
            this.txtInitialize_Class.Name = "txtInitialize_Class";
            this.txtInitialize_Class.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtInitialize_Class.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtInitialize_Class.Properties.Appearance.Options.UseBackColor = true;
            this.txtInitialize_Class.Properties.Appearance.Options.UseForeColor = true;
            this.txtInitialize_Class.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtInitialize_Class.Size = new System.Drawing.Size(578, 20);
            this.txtInitialize_Class.StyleController = this.xtraLayoutControlExt1;
            this.txtInitialize_Class.TabIndex = 10;
            this.txtInitialize_Class.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtInitialize_Module
            // 
            this.txtInitialize_Module.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtInitialize_Module.EditValue = "";
            this.txtInitialize_Module.EnterExecuteButton = null;
            this.txtInitialize_Module.FocusColor = System.Drawing.Color.Empty;
            this.txtInitialize_Module.IsValueTrim = true;
            this.txtInitialize_Module.Key = "INITIALIZE_MODULE";
            this.txtInitialize_Module.Location = new System.Drawing.Point(105, 112);
            this.txtInitialize_Module.MinLength = 0;
            this.txtInitialize_Module.Name = "txtInitialize_Module";
            this.txtInitialize_Module.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtInitialize_Module.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtInitialize_Module.Properties.Appearance.Options.UseBackColor = true;
            this.txtInitialize_Module.Properties.Appearance.Options.UseForeColor = true;
            this.txtInitialize_Module.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtInitialize_Module.Size = new System.Drawing.Size(380, 20);
            this.txtInitialize_Module.StyleController = this.xtraLayoutControlExt1;
            this.txtInitialize_Module.TabIndex = 9;
            this.txtInitialize_Module.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtDownload_Base_Url
            // 
            this.txtDownload_Base_Url.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtDownload_Base_Url.EditValue = "";
            this.txtDownload_Base_Url.EnterExecuteButton = null;
            this.txtDownload_Base_Url.FocusColor = System.Drawing.Color.Empty;
            this.txtDownload_Base_Url.IsValueTrim = true;
            this.txtDownload_Base_Url.Key = "DOWNLOAD_BASE_URL";
            this.txtDownload_Base_Url.Location = new System.Drawing.Point(105, 86);
            this.txtDownload_Base_Url.MinLength = 0;
            this.txtDownload_Base_Url.Name = "txtDownload_Base_Url";
            this.txtDownload_Base_Url.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtDownload_Base_Url.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtDownload_Base_Url.Properties.Appearance.Options.UseBackColor = true;
            this.txtDownload_Base_Url.Properties.Appearance.Options.UseForeColor = true;
            this.txtDownload_Base_Url.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtDownload_Base_Url.Size = new System.Drawing.Size(380, 20);
            this.txtDownload_Base_Url.StyleController = this.xtraLayoutControlExt1;
            this.txtDownload_Base_Url.TabIndex = 8;
            this.txtDownload_Base_Url.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtDownload_Base_Url, new HHI.ShipBuilding.Controls.ValidationType[0]);
            // 
            // txtSystem_Name
            // 
            this.txtSystem_Name.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.txtSystem_Name.EditValue = "";
            this.txtSystem_Name.EnterExecuteButton = null;
            this.txtSystem_Name.FocusColor = System.Drawing.Color.Empty;
            this.txtSystem_Name.IsValueTrim = true;
            this.txtSystem_Name.Key = "SYSTEM_NAME";
            this.txtSystem_Name.Location = new System.Drawing.Point(348, 62);
            this.txtSystem_Name.MinLength = 0;
            this.txtSystem_Name.Name = "txtSystem_Name";
            this.txtSystem_Name.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.txtSystem_Name.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtSystem_Name.Properties.Appearance.Options.UseBackColor = true;
            this.txtSystem_Name.Properties.Appearance.Options.UseForeColor = true;
            this.txtSystem_Name.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSystem_Name.Size = new System.Drawing.Size(335, 20);
            this.txtSystem_Name.StyleController = this.xtraLayoutControlExt1;
            this.txtSystem_Name.TabIndex = 7;
            this.txtSystem_Name.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtSystem_Name, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // txtSystem_Code
            // 
            this.txtSystem_Code.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.txtSystem_Code.EditValue = "";
            this.txtSystem_Code.EnterExecuteButton = null;
            this.txtSystem_Code.FocusColor = System.Drawing.Color.Empty;
            this.txtSystem_Code.IsValueTrim = true;
            this.txtSystem_Code.Key = "SYSTEM_CODE";
            this.txtSystem_Code.Location = new System.Drawing.Point(105, 62);
            this.txtSystem_Code.MinLength = 0;
            this.txtSystem_Code.Name = "txtSystem_Code";
            this.txtSystem_Code.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.txtSystem_Code.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtSystem_Code.Properties.Appearance.Options.UseBackColor = true;
            this.txtSystem_Code.Properties.Appearance.Options.UseForeColor = true;
            this.txtSystem_Code.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSystem_Code.Size = new System.Drawing.Size(146, 20);
            this.txtSystem_Code.StyleController = this.xtraLayoutControlExt1;
            this.txtSystem_Code.TabIndex = 6;
            this.txtSystem_Code.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtSystem_Code, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // btnSave
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSave, new string[] {
            "SAVE"});
            this.btnSave.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_저장;
            this.btnSave.IsExecuteWdworkerLog = true;
            this.btnSave.Location = new System.Drawing.Point(537, 12);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(71, 22);
            this.btnSave.StyleController = this.xtraLayoutControlExt1;
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "저장";
            this.btnSave.UseSplasher = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_닫기;
            this.btnClose.IsExecuteWdworkerLog = true;
            this.btnClose.Location = new System.Drawing.Point(612, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(71, 22);
            this.btnClose.StyleController = this.xtraLayoutControlExt1;
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "닫기";
            this.btnClose.UseSplasher = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "Root";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.layoutControlItem2,
            this.emptySpaceItem2,
            this.layoutControlItem5,
            this.layoutControlItem6,
            this.layoutControlItem7,
            this.layoutControlItem4,
            this.lcgSYSTEM_CODE_N,
            this.lciSYSTEM_CODE_R,
            this.layoutControlGroup2,
            this.layoutControlItem20,
            this.layoutControlItem21});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(695, 510);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.btnClose;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(600, 0);
            this.layoutControlItem1.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.btnSave;
            this.layoutControlItem2.CustomizationFormText = "layoutControlItem2";
            this.layoutControlItem2.Location = new System.Drawing.Point(525, 0);
            this.layoutControlItem2.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem2.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(525, 26);
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem5.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem5.Control = this.txtDownload_Base_Url;
            this.layoutControlItem5.CustomizationFormText = "다운로드 경로";
            this.layoutControlItem5.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem5.Location = new System.Drawing.Point(0, 74);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(477, 26);
            this.layoutControlItem5.Text = "다운로드 경로";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(90, 16);
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem6.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem6.Control = this.txtInitialize_Module;
            this.layoutControlItem6.CustomizationFormText = "모듈정보";
            this.layoutControlItem6.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 100);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(477, 26);
            this.layoutControlItem6.Text = "모듈정보";
            this.layoutControlItem6.TextSize = new System.Drawing.Size(90, 16);
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem7.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem7.Control = this.txtInitialize_Class;
            this.layoutControlItem7.CustomizationFormText = "Class 정보";
            this.layoutControlItem7.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem7.Location = new System.Drawing.Point(0, 126);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(675, 24);
            this.layoutControlItem7.Text = "Class 정보";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(90, 16);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem4.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem4.Control = this.txtSystem_Name;
            this.layoutControlItem4.CustomizationFormText = "시스템명";
            this.layoutControlItem4.Location = new System.Drawing.Point(243, 50);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(432, 24);
            this.layoutControlItem4.Text = "시스템명";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(90, 14);
            // 
            // lcgSYSTEM_CODE_N
            // 
            this.lcgSYSTEM_CODE_N.CustomizationFormText = "lcgSYSTEM_CODE_N";
            this.lcgSYSTEM_CODE_N.GroupBordersVisible = false;
            this.lcgSYSTEM_CODE_N.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem16,
            this.layoutControlItem17,
            this.layoutControlItem18,
            this.emptySpaceItem3});
            this.lcgSYSTEM_CODE_N.Location = new System.Drawing.Point(0, 26);
            this.lcgSYSTEM_CODE_N.Name = "lcgSYSTEM_CODE_N";
            this.lcgSYSTEM_CODE_N.Size = new System.Drawing.Size(675, 24);
            // 
            // layoutControlItem16
            // 
            this.layoutControlItem16.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem16.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem16.Control = this.txtSAUPBU;
            this.layoutControlItem16.CustomizationFormText = "시스템코드";
            this.layoutControlItem16.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem16.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem16.Name = "layoutControlItem16";
            this.layoutControlItem16.Size = new System.Drawing.Size(180, 24);
            this.layoutControlItem16.Text = "시스템코드";
            this.layoutControlItem16.TextSize = new System.Drawing.Size(90, 16);
            // 
            // layoutControlItem17
            // 
            this.layoutControlItem17.Control = this.cboWORK_GUBUN;
            this.layoutControlItem17.CustomizationFormText = "업무구분";
            this.layoutControlItem17.Location = new System.Drawing.Point(180, 0);
            this.layoutControlItem17.Name = "layoutControlItem17";
            this.layoutControlItem17.Size = new System.Drawing.Size(167, 24);
            this.layoutControlItem17.Text = "업무구분";
            this.layoutControlItem17.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem17.TextVisible = false;
            // 
            // layoutControlItem18
            // 
            this.layoutControlItem18.Control = this.txtSYSTEM_GUBUN;
            this.layoutControlItem18.CustomizationFormText = "시스템구분";
            this.layoutControlItem18.Location = new System.Drawing.Point(347, 0);
            this.layoutControlItem18.Name = "layoutControlItem18";
            this.layoutControlItem18.Size = new System.Drawing.Size(84, 24);
            this.layoutControlItem18.Text = "시스템구분";
            this.layoutControlItem18.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem18.TextVisible = false;
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.CustomizationFormText = "emptySpaceItem3";
            this.emptySpaceItem3.Location = new System.Drawing.Point(431, 0);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(244, 24);
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // lciSYSTEM_CODE_R
            // 
            this.lciSYSTEM_CODE_R.AppearanceItemCaption.Options.UseTextOptions = true;
            this.lciSYSTEM_CODE_R.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.lciSYSTEM_CODE_R.Control = this.txtSystem_Code;
            this.lciSYSTEM_CODE_R.CustomizationFormText = "시스템코드";
            this.lciSYSTEM_CODE_R.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.lciSYSTEM_CODE_R.Location = new System.Drawing.Point(0, 50);
            this.lciSYSTEM_CODE_R.Name = "lciSYSTEM_CODE_R";
            this.lciSYSTEM_CODE_R.Size = new System.Drawing.Size(243, 24);
            this.lciSYSTEM_CODE_R.Text = "시스템코드";
            this.lciSYSTEM_CODE_R.TextSize = new System.Drawing.Size(90, 16);
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.CaptionImage = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Grouup_tit_ico;
            this.layoutControlGroup2.CustomizationFormText = "FTP 정보";
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem13,
            this.layoutControlItem14,
            this.layoutControlItem12,
            this.layoutControlItem11,
            this.layoutControlItem9,
            this.layoutControlItem10,
            this.layoutControlItem8,
            this.layoutControlItem15,
            this.layoutControlItem3,
            this.layoutControlItem19,
            this.emptySpaceItem1});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 150);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(675, 340);
            this.layoutControlGroup2.Text = "FTP 정보";
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.btnFileDelete;
            this.layoutControlItem13.CustomizationFormText = "layoutControlItem13";
            this.layoutControlItem13.Location = new System.Drawing.Point(569, 72);
            this.layoutControlItem13.MaxSize = new System.Drawing.Size(82, 26);
            this.layoutControlItem13.MinSize = new System.Drawing.Size(82, 26);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(82, 26);
            this.layoutControlItem13.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem13.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem13.TextVisible = false;
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.btnFileSave;
            this.layoutControlItem14.CustomizationFormText = "layoutControlItem14";
            this.layoutControlItem14.Location = new System.Drawing.Point(487, 72);
            this.layoutControlItem14.MaxSize = new System.Drawing.Size(82, 26);
            this.layoutControlItem14.MinSize = new System.Drawing.Size(82, 26);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Size = new System.Drawing.Size(82, 26);
            this.layoutControlItem14.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem14.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem14.TextVisible = false;
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.btnFileAttach;
            this.layoutControlItem12.CustomizationFormText = "layoutControlItem12";
            this.layoutControlItem12.Location = new System.Drawing.Point(405, 72);
            this.layoutControlItem12.MaxSize = new System.Drawing.Size(82, 26);
            this.layoutControlItem12.MinSize = new System.Drawing.Size(82, 26);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(82, 26);
            this.layoutControlItem12.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem12.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem12.TextVisible = false;
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.grdFile;
            this.layoutControlItem11.CustomizationFormText = "layoutControlItem11";
            this.layoutControlItem11.Location = new System.Drawing.Point(0, 98);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(651, 194);
            this.layoutControlItem11.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem11.TextVisible = false;
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem9.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem9.Control = this.txtUser_Id;
            this.layoutControlItem9.CustomizationFormText = "사용자ID";
            this.layoutControlItem9.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem9.Location = new System.Drawing.Point(0, 48);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(298, 24);
            this.layoutControlItem9.Text = "FTP ID";
            this.layoutControlItem9.TextSize = new System.Drawing.Size(90, 16);
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem10.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem10.Control = this.txtPassword;
            this.layoutControlItem10.CustomizationFormText = "Password";
            this.layoutControlItem10.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem10.Location = new System.Drawing.Point(298, 48);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(353, 24);
            this.layoutControlItem10.Text = "FTP Password";
            this.layoutControlItem10.TextSize = new System.Drawing.Size(90, 16);
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.txtFtp_Server_Path;
            this.layoutControlItem8.CustomizationFormText = "FTP 서버 경로";
            this.layoutControlItem8.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem8.Location = new System.Drawing.Point(0, 24);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(651, 24);
            this.layoutControlItem8.Text = "FTP 서버 경로";
            this.layoutControlItem8.TextSize = new System.Drawing.Size(90, 16);
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem15.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem15.Control = this.txtFtp_Ip;
            this.layoutControlItem15.CustomizationFormText = "FTP IP";
            this.layoutControlItem15.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem15.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.Size = new System.Drawing.Size(651, 24);
            this.layoutControlItem15.Text = "FTP IP";
            this.layoutControlItem15.TextSize = new System.Drawing.Size(90, 16);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.txtFILE_PATH;
            this.layoutControlItem3.CustomizationFormText = "파일경로";
            this.layoutControlItem3.Location = new System.Drawing.Point(209, 72);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(196, 26);
            this.layoutControlItem3.Text = "파일경로";
            this.layoutControlItem3.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem3.TextSize = new System.Drawing.Size(48, 14);
            this.layoutControlItem3.TextToControlDistance = 5;
            // 
            // layoutControlItem19
            // 
            this.layoutControlItem19.Control = this.txtPROGRAM;
            this.layoutControlItem19.CustomizationFormText = "프로그램";
            this.layoutControlItem19.Location = new System.Drawing.Point(10, 72);
            this.layoutControlItem19.Name = "layoutControlItem19";
            this.layoutControlItem19.Size = new System.Drawing.Size(199, 26);
            this.layoutControlItem19.Text = "프로그램";
            this.layoutControlItem19.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem19.TextSize = new System.Drawing.Size(48, 14);
            this.layoutControlItem19.TextToControlDistance = 5;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 72);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(10, 26);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem20
            // 
            this.layoutControlItem20.Control = this.chkUseUpdater;
            this.layoutControlItem20.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_red;
            this.layoutControlItem20.Location = new System.Drawing.Point(477, 74);
            this.layoutControlItem20.Name = "layoutControlItem20";
            this.layoutControlItem20.Padding = new DevExpress.XtraLayout.Utils.Padding(10, 2, 2, 2);
            this.layoutControlItem20.Size = new System.Drawing.Size(198, 26);
            this.layoutControlItem20.Text = "우드워커4.6 업데이터 사용";
            this.layoutControlItem20.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem20.TextSize = new System.Drawing.Size(159, 16);
            this.layoutControlItem20.TextToControlDistance = 5;
            // 
            // layoutControlItem21
            // 
            this.layoutControlItem21.Control = this.chkBizWork;
            this.layoutControlItem21.CustomizationFormText = "BizWork 시스템 연동";
            this.layoutControlItem21.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_red;
            this.layoutControlItem21.Location = new System.Drawing.Point(477, 100);
            this.layoutControlItem21.Name = "layoutControlItem21";
            this.layoutControlItem21.Padding = new DevExpress.XtraLayout.Utils.Padding(10, 2, 2, 2);
            this.layoutControlItem21.Size = new System.Drawing.Size(198, 26);
            this.layoutControlItem21.Text = "BizWork 시스템 연동";
            this.layoutControlItem21.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem21.TextSize = new System.Drawing.Size(124, 16);
            this.layoutControlItem21.TextToControlDistance = 5;
            // 
            // stdValidationManager1
            // 
            this.stdValidationManager1.IsNullorWhiteSpace = true;
            this.stdValidationManager1.IsShowErrorMessage = true;
            // 
            // SCSYS009P1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(695, 510);
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS009P1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "시스템 정보 저장";
            this.Load += new System.EventHandler(this.SCSYS009P1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chkBizWork.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkUseUpdater.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPROGRAM.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFILE_PATH.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSYSTEM_GUBUN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboWORK_GUBUN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSAUPBU.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFtp_Ip.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFtp_Server_Path.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdFile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvFile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkYN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpyMemoExEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPassword.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUser_Id.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInitialize_Class.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInitialize_Module.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDownload_Base_Url.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSystem_Name.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSystem_Code.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcgSYSTEM_CODE_N)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lciSYSTEM_CODE_R)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private Client.Controls.DXperience.XtraTextEditExt txtPassword;
        private Client.Controls.DXperience.XtraTextEditExt txtUser_Id;
        private Client.Controls.DXperience.XtraTextEditExt txtInitialize_Class;
        private Client.Controls.DXperience.XtraTextEditExt txtInitialize_Module;
        private Client.Controls.DXperience.XtraTextEditExt txtDownload_Base_Url;
        private Client.Controls.DXperience.XtraTextEditExt txtSystem_Name;
        private Client.Controls.DXperience.XtraTextEditExt txtSystem_Code;
        private Client.Controls.DXperience.XtraButtonExt btnSave;
        private Client.Controls.DXperience.XtraButtonExt btnClose;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraLayout.LayoutControlItem lciSYSTEM_CODE_R;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private Controls.StdValidationManager stdValidationManager1;
        private Client.Controls.DXperience.XtraGridControlExt grdFile;
        private DevExpress.XtraGrid.Views.Grid.GridView grvFile;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpychkYN;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private Client.Controls.DXperience.XtraButtonExt btnFileDelete;
        private Client.Controls.DXperience.XtraButtonExt btnFileAttach;
        private Client.Controls.DXperience.XtraButtonExt btnFileSave;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit rpyMemoExEdit;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private Client.Controls.DXperience.XtraTextEditExt txtFtp_Server_Path;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private Client.Controls.DXperience.XtraTextEditExt txtFtp_Ip;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private Client.Controls.DXperience.XtraTextEditExt txtSYSTEM_GUBUN;
        private Client.Controls.DXperience.XtraImageComboBoxEditExt cboWORK_GUBUN;
        private Client.Controls.DXperience.XtraTextEditExt txtSAUPBU;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem16;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem17;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem18;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private DevExpress.XtraLayout.LayoutControlGroup lcgSYSTEM_CODE_N;
        private Windows.Forms.StdSecurityManager stdSecurityManager1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraGrid.Columns.GridColumn colLOCAL_FILE_PATH;
        private Client.Controls.DXperience.XtraTextEditExt txtPROGRAM;
        private Client.Controls.DXperience.XtraTextEditExt txtFILE_PATH;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem19;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private Client.Controls.DXperience.XtraCheckEditExt chkUseUpdater;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem20;
        private Client.Controls.DXperience.XtraCheckEditExt chkBizWork;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem21;
    }
}