﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS005
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.radioGroup1 = new DevExpress.XtraEditors.RadioGroup();
            this.luSYSTEM_CODE = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLookUpEditExt();
            this.btnTitleCopy = new DevExpress.XtraEditors.SimpleButton();
            this.luCustom_Action = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLookUpEditExt();
            this.luMenu_Action = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLookUpEditExt();
            this.btnProgram = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.txtProgram_Name = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.chkUse_Yn = new HHI.ShipBuilding.Client.Controls.DXperience.XtraCheckEditExt();
            this.chkMenu_Hide = new HHI.ShipBuilding.Client.Controls.DXperience.XtraCheckEditExt();
            this.chkExpanded = new HHI.ShipBuilding.Client.Controls.DXperience.XtraCheckEditExt();
            this.txtMenu_Order = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtProgram_Id = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtExtra_Info = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtDisplay_Title = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtTitle = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtMenu_Id = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.treeMenu = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumn2 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.contextMenuStrip_TreeMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.현재LevelNode생서ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.topToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bottomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.treeExpandToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.treeCollapseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnSearch = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnDelete = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnSave = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.splitterItem1 = new DevExpress.XtraLayout.SplitterItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem16 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem17 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem18 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem19 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem20 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem21 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem22 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem5 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.stdButtonExecuteManager1 = new HHI.ShipBuilding.Controls.StdButtonExecuteManager(this.components);
            this.stdValidationManager1 = new HHI.ShipBuilding.Controls.StdValidationManager(this.components);
            this.stdSecurityManager1 = new HHI.ShipBuilding.Windows.Forms.StdSecurityManager(this.components);
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radioGroup1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.luSYSTEM_CODE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.luCustom_Action.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.luMenu_Action.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProgram_Name.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkUse_Yn.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMenu_Hide.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkExpanded.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMenu_Order.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProgram_Id.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtExtra_Info.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDisplay_Title.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTitle.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMenu_Id.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.treeMenu)).BeginInit();
            this.contextMenuStrip_TreeMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.radioGroup1);
            this.xtraLayoutControlExt1.Controls.Add(this.luSYSTEM_CODE);
            this.xtraLayoutControlExt1.Controls.Add(this.btnTitleCopy);
            this.xtraLayoutControlExt1.Controls.Add(this.luCustom_Action);
            this.xtraLayoutControlExt1.Controls.Add(this.luMenu_Action);
            this.xtraLayoutControlExt1.Controls.Add(this.btnProgram);
            this.xtraLayoutControlExt1.Controls.Add(this.txtProgram_Name);
            this.xtraLayoutControlExt1.Controls.Add(this.chkUse_Yn);
            this.xtraLayoutControlExt1.Controls.Add(this.chkMenu_Hide);
            this.xtraLayoutControlExt1.Controls.Add(this.chkExpanded);
            this.xtraLayoutControlExt1.Controls.Add(this.txtMenu_Order);
            this.xtraLayoutControlExt1.Controls.Add(this.txtProgram_Id);
            this.xtraLayoutControlExt1.Controls.Add(this.txtExtra_Info);
            this.xtraLayoutControlExt1.Controls.Add(this.txtDisplay_Title);
            this.xtraLayoutControlExt1.Controls.Add(this.txtTitle);
            this.xtraLayoutControlExt1.Controls.Add(this.txtMenu_Id);
            this.xtraLayoutControlExt1.Controls.Add(this.treeMenu);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearch);
            this.xtraLayoutControlExt1.Controls.Add(this.btnDelete);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSave);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(600, 492, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(1000, 600);
            this.xtraLayoutControlExt1.TabIndex = 2;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // radioGroup1
            // 
            this.radioGroup1.Location = new System.Drawing.Point(54, 12);
            this.radioGroup1.Name = "radioGroup1";
            this.radioGroup1.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "최상위메뉴"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "프로그램 시스템")});
            this.radioGroup1.Size = new System.Drawing.Size(230, 25);
            this.radioGroup1.StyleController = this.xtraLayoutControlExt1;
            this.radioGroup1.TabIndex = 37;
            this.radioGroup1.SelectedIndexChanged += new System.EventHandler(this.radioGroup1_SelectedIndexChanged);
            // 
            // luSYSTEM_CODE
            // 
            this.luSYSTEM_CODE.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.luSYSTEM_CODE.EnterExecuteButton = null;
            this.luSYSTEM_CODE.FocusColor = System.Drawing.Color.Empty;
            this.luSYSTEM_CODE.Key = "";
            this.luSYSTEM_CODE.Location = new System.Drawing.Point(288, 12);
            this.luSYSTEM_CODE.MinLength = 0;
            this.luSYSTEM_CODE.Name = "luSYSTEM_CODE";
            this.luSYSTEM_CODE.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.luSYSTEM_CODE.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.luSYSTEM_CODE.Properties.Appearance.Options.UseBackColor = true;
            this.luSYSTEM_CODE.Properties.Appearance.Options.UseForeColor = true;
            this.luSYSTEM_CODE.Properties.AutoHeight = false;
            this.luSYSTEM_CODE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.luSYSTEM_CODE.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("SYSTEM_CODE", 80, "코드"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("SYSTEM_NAME", 150, "명칭")});
            this.luSYSTEM_CODE.Properties.NullText = "";
            this.luSYSTEM_CODE.Size = new System.Drawing.Size(255, 25);
            this.luSYSTEM_CODE.StyleController = this.xtraLayoutControlExt1;
            this.luSYSTEM_CODE.TabIndex = 36;
            // 
            // btnTitleCopy
            // 
            this.btnTitleCopy.Location = new System.Drawing.Point(849, 101);
            this.btnTitleCopy.Name = "btnTitleCopy";
            this.btnTitleCopy.Size = new System.Drawing.Size(127, 22);
            this.btnTitleCopy.StyleController = this.xtraLayoutControlExt1;
            this.btnTitleCopy.TabIndex = 35;
            this.btnTitleCopy.Text = "메뉴 표시명으로 복사";
            this.btnTitleCopy.Click += new System.EventHandler(this.btnTitleCopy_Click);
            // 
            // luCustom_Action
            // 
            this.luCustom_Action.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.luCustom_Action.EnterExecuteButton = null;
            this.luCustom_Action.FocusColor = System.Drawing.Color.Empty;
            this.luCustom_Action.Key = "CUSTOM_ACTION";
            this.luCustom_Action.Location = new System.Drawing.Point(421, 175);
            this.luCustom_Action.MinLength = 0;
            this.luCustom_Action.Name = "luCustom_Action";
            this.luCustom_Action.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.luCustom_Action.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.luCustom_Action.Properties.Appearance.Options.UseBackColor = true;
            this.luCustom_Action.Properties.Appearance.Options.UseForeColor = true;
            this.luCustom_Action.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.luCustom_Action.Properties.NullText = "";
            this.luCustom_Action.Size = new System.Drawing.Size(114, 20);
            this.luCustom_Action.StyleController = this.xtraLayoutControlExt1;
            this.luCustom_Action.TabIndex = 33;
            // 
            // luMenu_Action
            // 
            this.luMenu_Action.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.luMenu_Action.EnterExecuteButton = null;
            this.luMenu_Action.FocusColor = System.Drawing.Color.Empty;
            this.luMenu_Action.Key = "MENU_ACTION";
            this.luMenu_Action.Location = new System.Drawing.Point(421, 151);
            this.luMenu_Action.MinLength = 0;
            this.luMenu_Action.Name = "luMenu_Action";
            this.luMenu_Action.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.luMenu_Action.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.luMenu_Action.Properties.Appearance.Options.UseBackColor = true;
            this.luMenu_Action.Properties.Appearance.Options.UseForeColor = true;
            this.luMenu_Action.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.luMenu_Action.Properties.NullText = "";
            this.luMenu_Action.Size = new System.Drawing.Size(114, 20);
            this.luMenu_Action.StyleController = this.xtraLayoutControlExt1;
            this.luMenu_Action.TabIndex = 32;
            this.stdValidationManager1.SetValidation(this.luMenu_Action, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // btnProgram
            // 
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnProgram, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnProgram, false);
            this.btnProgram.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_조회;
            this.btnProgram.IsExecuteWdworkerLog = true;
            this.btnProgram.Location = new System.Drawing.Point(954, 175);
            this.btnProgram.Name = "btnProgram";
            this.btnProgram.Size = new System.Drawing.Size(22, 22);
            this.btnProgram.StyleController = this.xtraLayoutControlExt1;
            this.btnProgram.TabIndex = 29;
            this.btnProgram.Text = " ";
            this.btnProgram.UseSplasher = false;
            this.btnProgram.Click += new System.EventHandler(this.btnProgram_Click);
            // 
            // txtProgram_Name
            // 
            this.txtProgram_Name.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtProgram_Name.EditValue = "";
            this.txtProgram_Name.EnterExecuteButton = null;
            this.txtProgram_Name.FocusColor = System.Drawing.Color.Empty;
            this.txtProgram_Name.IsValueTrim = true;
            this.txtProgram_Name.Key = "PROGRAM_NAME";
            this.txtProgram_Name.Location = new System.Drawing.Point(769, 175);
            this.txtProgram_Name.MinLength = 0;
            this.txtProgram_Name.Name = "txtProgram_Name";
            this.txtProgram_Name.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtProgram_Name.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtProgram_Name.Properties.Appearance.Options.UseBackColor = true;
            this.txtProgram_Name.Properties.Appearance.Options.UseForeColor = true;
            this.txtProgram_Name.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProgram_Name.Size = new System.Drawing.Size(181, 20);
            this.txtProgram_Name.StyleController = this.xtraLayoutControlExt1;
            this.txtProgram_Name.TabIndex = 28;
            this.txtProgram_Name.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // chkUse_Yn
            // 
            this.chkUse_Yn.EnterExecuteButton = null;
            this.chkUse_Yn.Key = "USE_YN";
            this.chkUse_Yn.Location = new System.Drawing.Point(724, 201);
            this.chkUse_Yn.MinLength = 0;
            this.chkUse_Yn.Name = "chkUse_Yn";
            this.chkUse_Yn.Properties.Caption = "사용여부";
            this.chkUse_Yn.Properties.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.chkUse_Yn.Properties.ValueChecked = "Y";
            this.chkUse_Yn.Properties.ValueUnchecked = "N";
            this.chkUse_Yn.Size = new System.Drawing.Size(81, 19);
            this.chkUse_Yn.StyleController = this.xtraLayoutControlExt1;
            this.chkUse_Yn.TabIndex = 27;
            // 
            // chkMenu_Hide
            // 
            this.chkMenu_Hide.EnterExecuteButton = null;
            this.chkMenu_Hide.Key = "MENU_HIDE";
            this.chkMenu_Hide.Location = new System.Drawing.Point(639, 201);
            this.chkMenu_Hide.MinLength = 0;
            this.chkMenu_Hide.Name = "chkMenu_Hide";
            this.chkMenu_Hide.Properties.Caption = "메뉴숨김";
            this.chkMenu_Hide.Properties.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.chkMenu_Hide.Properties.ValueChecked = "Y";
            this.chkMenu_Hide.Properties.ValueUnchecked = "N";
            this.chkMenu_Hide.Size = new System.Drawing.Size(81, 19);
            this.chkMenu_Hide.StyleController = this.xtraLayoutControlExt1;
            this.chkMenu_Hide.TabIndex = 26;
            // 
            // chkExpanded
            // 
            this.chkExpanded.EnterExecuteButton = null;
            this.chkExpanded.Key = "EXPANDED";
            this.chkExpanded.Location = new System.Drawing.Point(554, 201);
            this.chkExpanded.MinLength = 0;
            this.chkExpanded.Name = "chkExpanded";
            this.chkExpanded.Properties.Caption = "확장여부";
            this.chkExpanded.Properties.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.chkExpanded.Properties.ValueChecked = "Y";
            this.chkExpanded.Properties.ValueUnchecked = "N";
            this.chkExpanded.Size = new System.Drawing.Size(81, 19);
            this.chkExpanded.StyleController = this.xtraLayoutControlExt1;
            this.chkExpanded.TabIndex = 25;
            // 
            // txtMenu_Order
            // 
            this.txtMenu_Order.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtMenu_Order.EditValue = "";
            this.txtMenu_Order.Enabled = false;
            this.txtMenu_Order.EnterExecuteButton = null;
            this.txtMenu_Order.FocusColor = System.Drawing.Color.Empty;
            this.txtMenu_Order.IsValueTrim = true;
            this.txtMenu_Order.Key = "MENU_ORDER";
            this.txtMenu_Order.Location = new System.Drawing.Point(421, 201);
            this.txtMenu_Order.MinLength = 0;
            this.txtMenu_Order.Name = "txtMenu_Order";
            this.txtMenu_Order.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtMenu_Order.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtMenu_Order.Properties.Appearance.Options.UseBackColor = true;
            this.txtMenu_Order.Properties.Appearance.Options.UseForeColor = true;
            this.txtMenu_Order.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtMenu_Order.Size = new System.Drawing.Size(114, 20);
            this.txtMenu_Order.StyleController = this.xtraLayoutControlExt1;
            this.txtMenu_Order.TabIndex = 23;
            this.txtMenu_Order.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtMenu_Order, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // txtProgram_Id
            // 
            this.txtProgram_Id.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtProgram_Id.EditValue = "";
            this.txtProgram_Id.EnterExecuteButton = null;
            this.txtProgram_Id.FocusColor = System.Drawing.Color.Empty;
            this.txtProgram_Id.IsValueTrim = true;
            this.txtProgram_Id.Key = "PROGRAM_ID";
            this.txtProgram_Id.Location = new System.Drawing.Point(648, 175);
            this.txtProgram_Id.MinLength = 0;
            this.txtProgram_Id.Name = "txtProgram_Id";
            this.txtProgram_Id.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtProgram_Id.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtProgram_Id.Properties.Appearance.Options.UseBackColor = true;
            this.txtProgram_Id.Properties.Appearance.Options.UseForeColor = true;
            this.txtProgram_Id.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProgram_Id.Size = new System.Drawing.Size(117, 20);
            this.txtProgram_Id.StyleController = this.xtraLayoutControlExt1;
            this.txtProgram_Id.TabIndex = 22;
            this.txtProgram_Id.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtExtra_Info
            // 
            this.txtExtra_Info.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtExtra_Info.EditValue = "";
            this.txtExtra_Info.EnterExecuteButton = null;
            this.txtExtra_Info.FocusColor = System.Drawing.Color.Empty;
            this.txtExtra_Info.IsValueTrim = true;
            this.txtExtra_Info.Key = "EXTRA_INFO";
            this.txtExtra_Info.Location = new System.Drawing.Point(648, 151);
            this.txtExtra_Info.MinLength = 0;
            this.txtExtra_Info.Name = "txtExtra_Info";
            this.txtExtra_Info.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtExtra_Info.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtExtra_Info.Properties.Appearance.Options.UseBackColor = true;
            this.txtExtra_Info.Properties.Appearance.Options.UseForeColor = true;
            this.txtExtra_Info.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtExtra_Info.Size = new System.Drawing.Size(313, 20);
            this.txtExtra_Info.StyleController = this.xtraLayoutControlExt1;
            this.txtExtra_Info.TabIndex = 20;
            this.txtExtra_Info.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtDisplay_Title
            // 
            this.txtDisplay_Title.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtDisplay_Title.EditValue = "";
            this.txtDisplay_Title.EnterExecuteButton = null;
            this.txtDisplay_Title.FocusColor = System.Drawing.Color.Empty;
            this.txtDisplay_Title.IsValueTrim = true;
            this.txtDisplay_Title.Key = "DISPLAY_TITLE";
            this.txtDisplay_Title.Location = new System.Drawing.Point(421, 127);
            this.txtDisplay_Title.MinLength = 0;
            this.txtDisplay_Title.Name = "txtDisplay_Title";
            this.txtDisplay_Title.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtDisplay_Title.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtDisplay_Title.Properties.Appearance.Options.UseBackColor = true;
            this.txtDisplay_Title.Properties.Appearance.Options.UseForeColor = true;
            this.txtDisplay_Title.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtDisplay_Title.Size = new System.Drawing.Size(540, 20);
            this.txtDisplay_Title.StyleController = this.xtraLayoutControlExt1;
            this.txtDisplay_Title.TabIndex = 18;
            this.txtDisplay_Title.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtTitle
            // 
            this.txtTitle.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.txtTitle.EditValue = "";
            this.txtTitle.EnterExecuteButton = null;
            this.txtTitle.FocusColor = System.Drawing.Color.Empty;
            this.txtTitle.IsValueTrim = true;
            this.txtTitle.Key = "TITLE";
            this.txtTitle.Location = new System.Drawing.Point(421, 101);
            this.txtTitle.MinLength = 0;
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.txtTitle.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtTitle.Properties.Appearance.Options.UseBackColor = true;
            this.txtTitle.Properties.Appearance.Options.UseForeColor = true;
            this.txtTitle.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtTitle.Size = new System.Drawing.Size(409, 20);
            this.txtTitle.StyleController = this.xtraLayoutControlExt1;
            this.txtTitle.TabIndex = 17;
            this.txtTitle.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtTitle, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // txtMenu_Id
            // 
            this.txtMenu_Id.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.txtMenu_Id.EditValue = "";
            this.txtMenu_Id.EnterExecuteButton = null;
            this.txtMenu_Id.FocusColor = System.Drawing.Color.Empty;
            this.txtMenu_Id.IsValueTrim = true;
            this.txtMenu_Id.Key = "MENU_ID";
            this.txtMenu_Id.Location = new System.Drawing.Point(421, 77);
            this.txtMenu_Id.MinLength = 15;
            this.txtMenu_Id.Name = "txtMenu_Id";
            this.txtMenu_Id.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.txtMenu_Id.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtMenu_Id.Properties.Appearance.Options.UseBackColor = true;
            this.txtMenu_Id.Properties.Appearance.Options.UseForeColor = true;
            this.txtMenu_Id.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMenu_Id.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtMenu_Id.Properties.MaxLength = 15;
            this.txtMenu_Id.Size = new System.Drawing.Size(199, 20);
            this.txtMenu_Id.StyleController = this.xtraLayoutControlExt1;
            this.txtMenu_Id.TabIndex = 15;
            this.txtMenu_Id.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtMenu_Id, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required,
            HHI.ShipBuilding.Controls.ValidationType.MinLength});
            // 
            // treeMenu
            // 
            this.treeMenu.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn2});
            this.treeMenu.ContextMenuStrip = this.contextMenuStrip_TreeMenu;
            this.treeMenu.KeyFieldName = "MENU_ID";
            this.treeMenu.Location = new System.Drawing.Point(12, 41);
            this.treeMenu.Name = "treeMenu";
            this.treeMenu.OptionsBehavior.Editable = false;
            this.treeMenu.OptionsDragAndDrop.DragNodesMode = DevExpress.XtraTreeList.DragNodesMode.Multiple;
            this.treeMenu.OptionsNavigation.AutoFocusNewNode = true;
            this.treeMenu.OptionsSelection.InvertSelection = true;
            this.treeMenu.OptionsSelection.UseIndicatorForSelection = true;
            this.treeMenu.OptionsView.ShowColumns = false;
            this.treeMenu.OptionsView.ShowHorzLines = false;
            this.treeMenu.OptionsView.ShowIndicator = false;
            this.treeMenu.OptionsView.ShowVertLines = false;
            this.treeMenu.ParentFieldName = "PARENT_ID";
            this.treeMenu.RootValue = "ROOT";
            this.treeMenu.Size = new System.Drawing.Size(294, 547);
            this.treeMenu.TabIndex = 14;
            this.treeMenu.AfterDragNode += new DevExpress.XtraTreeList.AfterDragNodeEventHandler(this.treeMenu_AfterDragNode);
            this.treeMenu.FocusedNodeChanged += new DevExpress.XtraTreeList.FocusedNodeChangedEventHandler(this.treeMenu_FocusedNodeChanged);
            // 
            // treeListColumn2
            // 
            this.treeListColumn2.Caption = "메뉴명";
            this.treeListColumn2.FieldName = "TITLE";
            this.treeListColumn2.Name = "treeListColumn2";
            this.treeListColumn2.OptionsColumn.AllowEdit = false;
            this.treeListColumn2.OptionsColumn.ReadOnly = true;
            this.treeListColumn2.Visible = true;
            this.treeListColumn2.VisibleIndex = 0;
            // 
            // contextMenuStrip_TreeMenu
            // 
            this.contextMenuStrip_TreeMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.현재LevelNode생서ToolStripMenuItem,
            this.toolStripSeparator1,
            this.treeExpandToolStripMenuItem,
            this.treeCollapseToolStripMenuItem});
            this.contextMenuStrip_TreeMenu.Name = "contextMenuStrip_TreeMenu";
            this.contextMenuStrip_TreeMenu.Size = new System.Drawing.Size(188, 76);
            this.contextMenuStrip_TreeMenu.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip_TreeMenu_Opening);
            // 
            // 현재LevelNode생서ToolStripMenuItem
            // 
            this.현재LevelNode생서ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topToolStripMenuItem,
            this.toolStripSeparator2,
            this.bottomToolStripMenuItem});
            this.현재LevelNode생서ToolStripMenuItem.Name = "현재LevelNode생서ToolStripMenuItem";
            this.현재LevelNode생서ToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.현재LevelNode생서ToolStripMenuItem.Text = "현재 Level-Node생성";
            // 
            // topToolStripMenuItem
            // 
            this.topToolStripMenuItem.Name = "topToolStripMenuItem";
            this.topToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.topToolStripMenuItem.Text = "TOP";
            this.topToolStripMenuItem.Click += new System.EventHandler(this.topToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(111, 6);
            // 
            // bottomToolStripMenuItem
            // 
            this.bottomToolStripMenuItem.Name = "bottomToolStripMenuItem";
            this.bottomToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.bottomToolStripMenuItem.Text = "Bottom";
            this.bottomToolStripMenuItem.Click += new System.EventHandler(this.bottomToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(184, 6);
            // 
            // treeExpandToolStripMenuItem
            // 
            this.treeExpandToolStripMenuItem.Name = "treeExpandToolStripMenuItem";
            this.treeExpandToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.treeExpandToolStripMenuItem.Text = "Tree Expand";
            this.treeExpandToolStripMenuItem.Click += new System.EventHandler(this.treeExpandToolStripMenuItem_Click);
            // 
            // treeCollapseToolStripMenuItem
            // 
            this.treeCollapseToolStripMenuItem.Name = "treeCollapseToolStripMenuItem";
            this.treeCollapseToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.treeCollapseToolStripMenuItem.Text = "Tree Collapse";
            this.treeCollapseToolStripMenuItem.Click += new System.EventHandler(this.treeCollapseToolStripMenuItem_Click);
            // 
            // btnSearch
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSearch, new string[] {
            "SELECT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSearch, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSearch, false);
            this.btnSearch.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_조회;
            this.btnSearch.IsExecuteWdworkerLog = true;
            this.btnSearch.Location = new System.Drawing.Point(767, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(71, 22);
            this.btnSearch.StyleController = this.xtraLayoutControlExt1;
            this.btnSearch.TabIndex = 7;
            this.btnSearch.Text = "조회";
            this.btnSearch.UseSplasher = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnDelete
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnDelete, new string[] {
            "DELETE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnDelete, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnDelete, false);
            this.btnDelete.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_삭제;
            this.btnDelete.IsExecuteWdworkerLog = true;
            this.btnDelete.Location = new System.Drawing.Point(917, 12);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(71, 22);
            this.btnDelete.StyleController = this.xtraLayoutControlExt1;
            this.btnDelete.TabIndex = 6;
            this.btnDelete.Text = "삭제";
            this.btnDelete.UseSplasher = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSave
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSave, new string[] {
            "UPDATE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSave, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSave, false);
            this.btnSave.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_저장;
            this.btnSave.IsExecuteWdworkerLog = true;
            this.btnSave.Location = new System.Drawing.Point(842, 12);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(71, 22);
            this.btnSave.StyleController = this.xtraLayoutControlExt1;
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "저장";
            this.btnSave.UseSplasher = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "Root";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup1, false);
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem2,
            this.emptySpaceItem2,
            this.layoutControlItem1,
            this.layoutControlItem3,
            this.layoutControlItem10,
            this.splitterItem1,
            this.layoutControlGroup2,
            this.layoutControlItem7,
            this.layoutControlItem5});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1000, 600);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.btnSave;
            this.layoutControlItem2.CustomizationFormText = "layoutControlItem2";
            this.layoutControlItem2.Location = new System.Drawing.Point(830, 0);
            this.layoutControlItem2.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem2.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(75, 29);
            this.layoutControlItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(535, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(220, 29);
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.btnDelete;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(905, 0);
            this.layoutControlItem1.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(75, 29);
            this.layoutControlItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.btnSearch;
            this.layoutControlItem3.CustomizationFormText = "layoutControlItem3";
            this.layoutControlItem3.Location = new System.Drawing.Point(755, 0);
            this.layoutControlItem3.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem3.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(75, 29);
            this.layoutControlItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem3.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem3.TextVisible = false;
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.treeMenu;
            this.layoutControlItem10.CustomizationFormText = "layoutControlItem10";
            this.layoutControlItem10.Location = new System.Drawing.Point(0, 29);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(298, 551);
            this.layoutControlItem10.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem10.TextVisible = false;
            // 
            // splitterItem1
            // 
            this.splitterItem1.AllowHotTrack = true;
            this.splitterItem1.CustomizationFormText = "splitterItem1";
            this.splitterItem1.Location = new System.Drawing.Point(298, 29);
            this.splitterItem1.Name = "splitterItem1";
            this.splitterItem1.Size = new System.Drawing.Size(5, 551);
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.CaptionImage = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Grouup_tit_ico;
            this.layoutControlGroup2.CustomizationFormText = "메뉴 정보";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup2, false);
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem6,
            this.emptySpaceItem3,
            this.layoutControlItem11,
            this.layoutControlItem14,
            this.layoutControlItem16,
            this.layoutControlItem17,
            this.layoutControlItem18,
            this.layoutControlItem19,
            this.layoutControlItem20,
            this.emptySpaceItem4,
            this.layoutControlItem12,
            this.layoutControlItem21,
            this.layoutControlItem22,
            this.emptySpaceItem5,
            this.layoutControlItem9,
            this.layoutControlItem13,
            this.layoutControlItem4,
            this.emptySpaceItem1});
            this.layoutControlGroup2.Location = new System.Drawing.Point(303, 29);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(677, 551);
            this.layoutControlGroup2.Text = "메뉴 정보";
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem6.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem6.Control = this.txtMenu_Id;
            this.layoutControlItem6.CustomizationFormText = "메뉴ID";
            this.layoutControlItem6.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(312, 24);
            this.layoutControlItem6.Spacing = new DevExpress.XtraLayout.Utils.Padding(15, 15, 0, 0);
            this.layoutControlItem6.Text = "메뉴ID";
            this.layoutControlItem6.TextSize = new System.Drawing.Size(76, 16);
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.emptySpaceItem3.AppearanceItemCaption.Options.UseForeColor = true;
            this.emptySpaceItem3.AppearanceItemCaption.Options.UseTextOptions = true;
            this.emptySpaceItem3.AppearanceItemCaption.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.emptySpaceItem3.AppearanceItemCaption.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.emptySpaceItem3.CustomizationFormText = "emptySpaceItem3";
            this.emptySpaceItem3.Location = new System.Drawing.Point(0, 148);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(653, 49);
            this.emptySpaceItem3.Text = "※ 구분에서 프로그램 시스템을 선택 후 개별 시스템 코드로 조회 하시면 최하위 레벨에 프로그램 아이디가 있는 폴더만 표시 됩니다.";
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(76, 0);
            this.emptySpaceItem3.TextVisible = true;
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem11.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem11.Control = this.txtTitle;
            this.layoutControlItem11.CustomizationFormText = "메뉴 Title";
            this.layoutControlItem11.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem11.Location = new System.Drawing.Point(0, 24);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(522, 26);
            this.layoutControlItem11.Spacing = new DevExpress.XtraLayout.Utils.Padding(15, 15, 0, 0);
            this.layoutControlItem11.Text = "메뉴 Title";
            this.layoutControlItem11.TextSize = new System.Drawing.Size(76, 16);
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem14.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem14.Control = this.txtExtra_Info;
            this.layoutControlItem14.CustomizationFormText = "추가정보";
            this.layoutControlItem14.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem14.Location = new System.Drawing.Point(227, 74);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Size = new System.Drawing.Size(426, 24);
            this.layoutControlItem14.Spacing = new DevExpress.XtraLayout.Utils.Padding(15, 15, 0, 0);
            this.layoutControlItem14.Text = "추가정보";
            this.layoutControlItem14.TextSize = new System.Drawing.Size(76, 16);
            // 
            // layoutControlItem16
            // 
            this.layoutControlItem16.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem16.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem16.Control = this.txtProgram_Id;
            this.layoutControlItem16.CustomizationFormText = "프로그램";
            this.layoutControlItem16.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem16.Location = new System.Drawing.Point(227, 98);
            this.layoutControlItem16.Name = "layoutControlItem16";
            this.layoutControlItem16.Size = new System.Drawing.Size(215, 26);
            this.layoutControlItem16.Spacing = new DevExpress.XtraLayout.Utils.Padding(15, 0, 0, 0);
            this.layoutControlItem16.Text = "프로그램";
            this.layoutControlItem16.TextSize = new System.Drawing.Size(76, 16);
            // 
            // layoutControlItem17
            // 
            this.layoutControlItem17.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem17.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem17.Control = this.txtMenu_Order;
            this.layoutControlItem17.CustomizationFormText = "메뉴순서";
            this.layoutControlItem17.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem17.Location = new System.Drawing.Point(0, 124);
            this.layoutControlItem17.Name = "layoutControlItem17";
            this.layoutControlItem17.Size = new System.Drawing.Size(227, 24);
            this.layoutControlItem17.Spacing = new DevExpress.XtraLayout.Utils.Padding(15, 15, 0, 0);
            this.layoutControlItem17.Text = "메뉴순서";
            this.layoutControlItem17.TextSize = new System.Drawing.Size(76, 16);
            // 
            // layoutControlItem18
            // 
            this.layoutControlItem18.Control = this.chkMenu_Hide;
            this.layoutControlItem18.CustomizationFormText = "layoutControlItem18";
            this.layoutControlItem18.Location = new System.Drawing.Point(312, 124);
            this.layoutControlItem18.MaxSize = new System.Drawing.Size(85, 23);
            this.layoutControlItem18.MinSize = new System.Drawing.Size(85, 23);
            this.layoutControlItem18.Name = "layoutControlItem18";
            this.layoutControlItem18.Size = new System.Drawing.Size(85, 24);
            this.layoutControlItem18.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem18.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem18.TextVisible = false;
            // 
            // layoutControlItem19
            // 
            this.layoutControlItem19.Control = this.chkExpanded;
            this.layoutControlItem19.CustomizationFormText = "layoutControlItem19";
            this.layoutControlItem19.Location = new System.Drawing.Point(227, 124);
            this.layoutControlItem19.MaxSize = new System.Drawing.Size(85, 23);
            this.layoutControlItem19.MinSize = new System.Drawing.Size(85, 23);
            this.layoutControlItem19.Name = "layoutControlItem19";
            this.layoutControlItem19.Size = new System.Drawing.Size(85, 24);
            this.layoutControlItem19.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem19.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem19.TextVisible = false;
            // 
            // layoutControlItem20
            // 
            this.layoutControlItem20.Control = this.chkUse_Yn;
            this.layoutControlItem20.CustomizationFormText = "layoutControlItem20";
            this.layoutControlItem20.Location = new System.Drawing.Point(397, 124);
            this.layoutControlItem20.MaxSize = new System.Drawing.Size(85, 23);
            this.layoutControlItem20.MinSize = new System.Drawing.Size(85, 23);
            this.layoutControlItem20.Name = "layoutControlItem20";
            this.layoutControlItem20.Size = new System.Drawing.Size(85, 24);
            this.layoutControlItem20.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem20.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem20.TextVisible = false;
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.CustomizationFormText = "emptySpaceItem4";
            this.emptySpaceItem4.Location = new System.Drawing.Point(482, 124);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(171, 24);
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem12.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem12.Control = this.txtDisplay_Title;
            this.layoutControlItem12.CustomizationFormText = "메뉴표시명";
            this.layoutControlItem12.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem12.Location = new System.Drawing.Point(0, 50);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(653, 24);
            this.layoutControlItem12.Spacing = new DevExpress.XtraLayout.Utils.Padding(15, 15, 0, 0);
            this.layoutControlItem12.Text = "메뉴표시명";
            this.layoutControlItem12.TextSize = new System.Drawing.Size(76, 16);
            // 
            // layoutControlItem21
            // 
            this.layoutControlItem21.Control = this.txtProgram_Name;
            this.layoutControlItem21.CustomizationFormText = "layoutControlItem21";
            this.layoutControlItem21.Location = new System.Drawing.Point(442, 98);
            this.layoutControlItem21.Name = "layoutControlItem21";
            this.layoutControlItem21.Size = new System.Drawing.Size(185, 26);
            this.layoutControlItem21.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem21.TextVisible = false;
            // 
            // layoutControlItem22
            // 
            this.layoutControlItem22.Control = this.btnProgram;
            this.layoutControlItem22.CustomizationFormText = "layoutControlItem22";
            this.layoutControlItem22.Location = new System.Drawing.Point(627, 98);
            this.layoutControlItem22.MaxSize = new System.Drawing.Size(26, 26);
            this.layoutControlItem22.MinSize = new System.Drawing.Size(26, 26);
            this.layoutControlItem22.Name = "layoutControlItem22";
            this.layoutControlItem22.Size = new System.Drawing.Size(26, 26);
            this.layoutControlItem22.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem22.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem22.TextVisible = false;
            // 
            // emptySpaceItem5
            // 
            this.emptySpaceItem5.AllowHotTrack = false;
            this.emptySpaceItem5.CustomizationFormText = "emptySpaceItem5";
            this.emptySpaceItem5.Location = new System.Drawing.Point(312, 0);
            this.emptySpaceItem5.Name = "emptySpaceItem5";
            this.emptySpaceItem5.Size = new System.Drawing.Size(341, 24);
            this.emptySpaceItem5.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem9.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem9.Control = this.luMenu_Action;
            this.layoutControlItem9.CustomizationFormText = "메뉴 Action";
            this.layoutControlItem9.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem9.Location = new System.Drawing.Point(0, 74);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(227, 24);
            this.layoutControlItem9.Spacing = new DevExpress.XtraLayout.Utils.Padding(15, 15, 0, 0);
            this.layoutControlItem9.Text = "메뉴 Action";
            this.layoutControlItem9.TextSize = new System.Drawing.Size(76, 16);
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem13.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem13.Control = this.luCustom_Action;
            this.layoutControlItem13.CustomizationFormText = "커스텀액션";
            this.layoutControlItem13.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem13.Location = new System.Drawing.Point(0, 98);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(227, 26);
            this.layoutControlItem13.Spacing = new DevExpress.XtraLayout.Utils.Padding(15, 15, 0, 0);
            this.layoutControlItem13.Text = "커스텀액션";
            this.layoutControlItem13.TextSize = new System.Drawing.Size(76, 16);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.btnTitleCopy;
            this.layoutControlItem4.Location = new System.Drawing.Point(522, 24);
            this.layoutControlItem4.MaxSize = new System.Drawing.Size(131, 26);
            this.layoutControlItem4.MinSize = new System.Drawing.Size(131, 26);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(131, 26);
            this.layoutControlItem4.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextVisible = false;
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.AppearanceItemCaption.BackColor = System.Drawing.Color.White;
            this.layoutControlItem7.AppearanceItemCaption.Options.UseBackColor = true;
            this.layoutControlItem7.Control = this.luSYSTEM_CODE;
            this.layoutControlItem7.Location = new System.Drawing.Point(276, 0);
            this.layoutControlItem7.MaxSize = new System.Drawing.Size(259, 29);
            this.layoutControlItem7.MinSize = new System.Drawing.Size(259, 29);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(259, 29);
            this.layoutControlItem7.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem7.Text = "사용 시스템";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem7.TextVisible = false;
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.radioGroup1;
            this.layoutControlItem5.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_red;
            this.layoutControlItem5.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem5.MaxSize = new System.Drawing.Size(276, 29);
            this.layoutControlItem5.MinSize = new System.Drawing.Size(276, 29);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(276, 29);
            this.layoutControlItem5.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem5.Text = "구분";
            this.layoutControlItem5.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem5.TextSize = new System.Drawing.Size(37, 16);
            this.layoutControlItem5.TextToControlDistance = 5;
            // 
            // stdValidationManager1
            // 
            this.stdValidationManager1.IsNullorWhiteSpace = true;
            this.stdValidationManager1.IsShowErrorMessage = true;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 197);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(653, 306);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // SCSYS005
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS005";
            this.Size = new System.Drawing.Size(1000, 600);
            this.Shown += new System.EventHandler(this.SCSYS005_Shown);
            this.Load += new System.EventHandler(this.SCSYS005_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radioGroup1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.luSYSTEM_CODE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.luCustom_Action.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.luMenu_Action.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProgram_Name.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkUse_Yn.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkMenu_Hide.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkExpanded.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMenu_Order.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProgram_Id.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtExtra_Info.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDisplay_Title.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTitle.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMenu_Id.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.treeMenu)).EndInit();
            this.contextMenuStrip_TreeMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private Controls.StdButtonExecuteManager stdButtonExecuteManager1;
        private Client.Controls.DXperience.XtraButtonExt btnSearch;
        private Client.Controls.DXperience.XtraButtonExt btnDelete;
        private Client.Controls.DXperience.XtraButtonExt btnSave;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraTreeList.TreeList treeMenu;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn2;
        private Client.Controls.DXperience.XtraTextEditExt txtMenu_Id;
        private DevExpress.XtraLayout.SplitterItem splitterItem1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private Client.Controls.DXperience.XtraCheckEditExt chkUse_Yn;
        private Client.Controls.DXperience.XtraCheckEditExt chkMenu_Hide;
        private Client.Controls.DXperience.XtraCheckEditExt chkExpanded;
        private Client.Controls.DXperience.XtraTextEditExt txtMenu_Order;
        private Client.Controls.DXperience.XtraTextEditExt txtProgram_Id;
        private Client.Controls.DXperience.XtraTextEditExt txtExtra_Info;
        private Client.Controls.DXperience.XtraTextEditExt txtDisplay_Title;
        private Client.Controls.DXperience.XtraTextEditExt txtTitle;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem16;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem17;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem19;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem18;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem20;
        private Client.Controls.DXperience.XtraButtonExt btnProgram;
        private Client.Controls.DXperience.XtraTextEditExt txtProgram_Name;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem21;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem22;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip_TreeMenu;
        private System.Windows.Forms.ToolStripMenuItem 현재LevelNode생서ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem topToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem bottomToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem treeExpandToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem treeCollapseToolStripMenuItem;
        private Controls.StdValidationManager stdValidationManager1;
        private Client.Controls.DXperience.XtraLookUpEditExt luCustom_Action;
        private Client.Controls.DXperience.XtraLookUpEditExt luMenu_Action;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private Windows.Forms.StdSecurityManager stdSecurityManager1;
        private DevExpress.XtraEditors.SimpleButton btnTitleCopy;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private Client.Controls.DXperience.XtraLookUpEditExt luSYSTEM_CODE;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraEditors.RadioGroup radioGroup1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
    }
}
