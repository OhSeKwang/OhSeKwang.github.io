﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS012
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SCSYS012));
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.btnSearchMenuInfo = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.txtUSER_NM = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnDeptPopUp = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.txtDEPTNAME = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.popupContainerControl1 = new DevExpress.XtraEditors.PopupContainerControl();
            this.xtraLayoutControlExt2 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.btnAuthButtonDelete = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.grdAuthButton = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvAuthButton = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colCHK3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCHK3 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.colDESCR = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colUSE_YN = new DevExpress.XtraGrid.Columns.GridColumn();
            this.btnAuthButtonSave = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup4 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.treeList1 = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumn3 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.grdMaster = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvMaster = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colUSER_ID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colUSER_NM = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDEPTNAME = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.btnDelete = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.grdMaster1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvMaster1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCHK = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsChk2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsPopupContainerEdit = new DevExpress.XtraEditors.Repository.RepositoryItemPopupContainerEdit();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colUSER_ID1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCheckedCboAUTH = new DevExpress.XtraEditors.Repository.RepositoryItemCheckedComboBoxEdit();
            this.txtUSER_ID = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnSave = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnSearch = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.splitterItem1 = new DevExpress.XtraLayout.SplitterItem();
            this.splitterItem2 = new DevExpress.XtraLayout.SplitterItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.stdSecurityManager1 = new HHI.ShipBuilding.Windows.Forms.StdSecurityManager(this.components);
            this.stdButtonExecuteManager1 = new HHI.ShipBuilding.Controls.StdButtonExecuteManager(this.components);
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtUSER_NM.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDEPTNAME.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupContainerControl1)).BeginInit();
            this.popupContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt2)).BeginInit();
            this.xtraLayoutControlExt2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdAuthButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvAuthButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.treeList1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMaster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMaster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMaster1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMaster1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsChk2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsPopupContainerEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCheckedCboAUTH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUSER_ID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearchMenuInfo);
            this.xtraLayoutControlExt1.Controls.Add(this.txtUSER_NM);
            this.xtraLayoutControlExt1.Controls.Add(this.btnDeptPopUp);
            this.xtraLayoutControlExt1.Controls.Add(this.txtDEPTNAME);
            this.xtraLayoutControlExt1.Controls.Add(this.popupContainerControl1);
            this.xtraLayoutControlExt1.Controls.Add(this.treeList1);
            this.xtraLayoutControlExt1.Controls.Add(this.grdMaster);
            this.xtraLayoutControlExt1.Controls.Add(this.btnDelete);
            this.xtraLayoutControlExt1.Controls.Add(this.grdMaster1);
            this.xtraLayoutControlExt1.Controls.Add(this.txtUSER_ID);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSave);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearch);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(742, 395, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(1116, 747);
            this.xtraLayoutControlExt1.TabIndex = 0;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // btnSearchMenuInfo
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSearchMenuInfo, new string[] {
            "SELECT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSearchMenuInfo, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSearchMenuInfo, false);
            this.btnSearchMenuInfo.Image = ((System.Drawing.Image)(resources.GetObject("btnSearchMenuInfo.Image")));
            this.btnSearchMenuInfo.IsExecuteWdworkerLog = true;
            this.btnSearchMenuInfo.Location = new System.Drawing.Point(253, 337);
            this.btnSearchMenuInfo.Name = "btnSearchMenuInfo";
            this.btnSearchMenuInfo.Size = new System.Drawing.Size(67, 22);
            this.btnSearchMenuInfo.StyleController = this.xtraLayoutControlExt1;
            this.btnSearchMenuInfo.TabIndex = 5;
            this.btnSearchMenuInfo.Text = "조회";
            this.btnSearchMenuInfo.UseSplasher = true;
            this.btnSearchMenuInfo.Click += new System.EventHandler(this.btnSearchMenuInfo_Click);
            // 
            // txtUSER_NM
            // 
            this.txtUSER_NM.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtUSER_NM.EditValue = "";
            this.txtUSER_NM.EnterExecuteButton = null;
            this.txtUSER_NM.FocusColor = System.Drawing.Color.Empty;
            this.txtUSER_NM.IsValueTrim = true;
            this.txtUSER_NM.Key = "";
            this.txtUSER_NM.Location = new System.Drawing.Point(511, 59);
            this.txtUSER_NM.MinLength = 0;
            this.txtUSER_NM.Name = "txtUSER_NM";
            this.txtUSER_NM.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtUSER_NM.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtUSER_NM.Properties.Appearance.Options.UseBackColor = true;
            this.txtUSER_NM.Properties.Appearance.Options.UseForeColor = true;
            this.txtUSER_NM.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtUSER_NM.Size = new System.Drawing.Size(161, 20);
            this.txtUSER_NM.StyleController = this.xtraLayoutControlExt1;
            this.txtUSER_NM.TabIndex = 7;
            this.txtUSER_NM.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // btnDeptPopUp
            // 
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnDeptPopUp, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnDeptPopUp, false);
            this.btnDeptPopUp.Image = ((System.Drawing.Image)(resources.GetObject("btnDeptPopUp.Image")));
            this.btnDeptPopUp.ImageLocation = DevExpress.XtraEditors.ImageLocation.MiddleCenter;
            this.btnDeptPopUp.IsExecuteWdworkerLog = true;
            this.btnDeptPopUp.Location = new System.Drawing.Point(230, 59);
            this.btnDeptPopUp.Name = "btnDeptPopUp";
            this.btnDeptPopUp.Size = new System.Drawing.Size(33, 22);
            this.btnDeptPopUp.StyleController = this.xtraLayoutControlExt1;
            this.btnDeptPopUp.TabIndex = 24;
            this.btnDeptPopUp.Text = " ";
            this.btnDeptPopUp.UseSplasher = false;
            this.btnDeptPopUp.Click += new System.EventHandler(this.btnDeptPopUp_Click);
            // 
            // txtDEPTNAME
            // 
            this.txtDEPTNAME.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtDEPTNAME.EditValue = "";
            this.txtDEPTNAME.EnterExecuteButton = null;
            this.txtDEPTNAME.FocusColor = System.Drawing.Color.Empty;
            this.txtDEPTNAME.IsValueTrim = true;
            this.txtDEPTNAME.Key = "DEPTNAME";
            this.txtDEPTNAME.Location = new System.Drawing.Point(88, 59);
            this.txtDEPTNAME.MinLength = 0;
            this.txtDEPTNAME.Name = "txtDEPTNAME";
            this.txtDEPTNAME.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtDEPTNAME.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtDEPTNAME.Properties.Appearance.Options.UseBackColor = true;
            this.txtDEPTNAME.Properties.Appearance.Options.UseForeColor = true;
            this.txtDEPTNAME.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtDEPTNAME.Size = new System.Drawing.Size(138, 20);
            this.txtDEPTNAME.StyleController = this.xtraLayoutControlExt1;
            this.txtDEPTNAME.TabIndex = 17;
            this.txtDEPTNAME.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // popupContainerControl1
            // 
            this.popupContainerControl1.Controls.Add(this.xtraLayoutControlExt2);
            this.popupContainerControl1.Location = new System.Drawing.Point(665, 269);
            this.popupContainerControl1.Name = "popupContainerControl1";
            this.popupContainerControl1.Size = new System.Drawing.Size(336, 241);
            this.popupContainerControl1.TabIndex = 13;
            // 
            // xtraLayoutControlExt2
            // 
            this.xtraLayoutControlExt2.Controls.Add(this.btnAuthButtonDelete);
            this.xtraLayoutControlExt2.Controls.Add(this.grdAuthButton);
            this.xtraLayoutControlExt2.Controls.Add(this.btnAuthButtonSave);
            this.xtraLayoutControlExt2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt2.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt2.Name = "xtraLayoutControlExt2";
            this.xtraLayoutControlExt2.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(1176, 279, 250, 350);
            this.xtraLayoutControlExt2.Root = this.layoutControlGroup4;
            this.xtraLayoutControlExt2.Size = new System.Drawing.Size(336, 241);
            this.xtraLayoutControlExt2.TabIndex = 0;
            this.xtraLayoutControlExt2.Text = "xtraLayoutControlExt2";
            // 
            // btnAuthButtonDelete
            // 
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnAuthButtonDelete, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnAuthButtonDelete, false);
            this.btnAuthButtonDelete.IsExecuteWdworkerLog = true;
            this.btnAuthButtonDelete.Location = new System.Drawing.Point(289, 12);
            this.btnAuthButtonDelete.Name = "btnAuthButtonDelete";
            this.btnAuthButtonDelete.Size = new System.Drawing.Size(35, 22);
            this.btnAuthButtonDelete.StyleController = this.xtraLayoutControlExt2;
            this.btnAuthButtonDelete.TabIndex = 6;
            this.btnAuthButtonDelete.Text = "삭제";
            this.btnAuthButtonDelete.UseSplasher = false;
            this.btnAuthButtonDelete.Click += new System.EventHandler(this.btnAuthButtonDelete_Click);
            // 
            // grdAuthButton
            // 
            this.grdAuthButton.CheckBoxFieldName = "CHK";
            this.grdAuthButton.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.None;
            this.grdAuthButton.IsHeaderClickAllCheckedItem = false;
            this.grdAuthButton.Location = new System.Drawing.Point(12, 38);
            this.grdAuthButton.MainView = this.grvAuthButton;
            this.grdAuthButton.MinLength = 0;
            this.grdAuthButton.Name = "grdAuthButton";
            this.grdAuthButton.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpsCHK3});
            this.grdAuthButton.Size = new System.Drawing.Size(312, 191);
            this.grdAuthButton.TabIndex = 11;
            this.grdAuthButton.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvAuthButton});
            // 
            // grvAuthButton
            // 
            this.grvAuthButton.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colCHK3,
            this.colDESCR,
            this.colUSE_YN});
            this.grvAuthButton.GridControl = this.grdAuthButton;
            this.grvAuthButton.Name = "grvAuthButton";
            this.grvAuthButton.OptionsView.ColumnAutoWidth = false;
            this.grvAuthButton.OptionsView.ShowGroupPanel = false;
            // 
            // colCHK3
            // 
            this.colCHK3.AppearanceHeader.Options.UseTextOptions = true;
            this.colCHK3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colCHK3.Caption = "선택";
            this.colCHK3.ColumnEdit = this.rpsCHK3;
            this.colCHK3.FieldName = "CHK";
            this.colCHK3.Name = "colCHK3";
            this.colCHK3.Visible = true;
            this.colCHK3.VisibleIndex = 0;
            // 
            // rpsCHK3
            // 
            this.rpsCHK3.AutoHeight = false;
            this.rpsCHK3.Caption = "Check";
            this.rpsCHK3.Name = "rpsCHK3";
            this.rpsCHK3.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpsCHK3.ValueChecked = "Y";
            this.rpsCHK3.ValueUnchecked = "N";
            // 
            // colDESCR
            // 
            this.colDESCR.AppearanceHeader.Options.UseTextOptions = true;
            this.colDESCR.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDESCR.Caption = "내용";
            this.colDESCR.FieldName = "DESCR";
            this.colDESCR.Name = "colDESCR";
            this.colDESCR.OptionsColumn.AllowEdit = false;
            this.colDESCR.OptionsColumn.ReadOnly = true;
            this.colDESCR.Visible = true;
            this.colDESCR.VisibleIndex = 1;
            this.colDESCR.Width = 133;
            // 
            // colUSE_YN
            // 
            this.colUSE_YN.AppearanceHeader.Options.UseTextOptions = true;
            this.colUSE_YN.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colUSE_YN.Caption = "사용";
            this.colUSE_YN.ColumnEdit = this.rpsCHK3;
            this.colUSE_YN.FieldName = "USE_YN";
            this.colUSE_YN.Name = "colUSE_YN";
            this.colUSE_YN.Visible = true;
            this.colUSE_YN.VisibleIndex = 2;
            // 
            // btnAuthButtonSave
            // 
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnAuthButtonSave, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnAuthButtonSave, false);
            this.btnAuthButtonSave.IsExecuteWdworkerLog = true;
            this.btnAuthButtonSave.Location = new System.Drawing.Point(250, 12);
            this.btnAuthButtonSave.Name = "btnAuthButtonSave";
            this.btnAuthButtonSave.Size = new System.Drawing.Size(35, 22);
            this.btnAuthButtonSave.StyleController = this.xtraLayoutControlExt2;
            this.btnAuthButtonSave.TabIndex = 6;
            this.btnAuthButtonSave.Text = "저장";
            this.btnAuthButtonSave.UseSplasher = false;
            this.btnAuthButtonSave.Click += new System.EventHandler(this.btnAuthButtonSave_Click);
            // 
            // layoutControlGroup4
            // 
            this.layoutControlGroup4.CustomizationFormText = "layoutControlGroup4";
            this.layoutControlGroup4.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup4, false);
            this.layoutControlGroup4.GroupBordersVisible = false;
            this.layoutControlGroup4.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem3,
            this.layoutControlItem4,
            this.layoutControlItem5,
            this.layoutControlItem8});
            this.layoutControlGroup4.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup4.Name = "layoutControlGroup4";
            this.layoutControlGroup4.Size = new System.Drawing.Size(336, 241);
            this.layoutControlGroup4.Text = "layoutControlGroup4";
            this.layoutControlGroup4.TextVisible = false;
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.CustomizationFormText = "emptySpaceItem3";
            this.emptySpaceItem3.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(238, 26);
            this.emptySpaceItem3.Text = "emptySpaceItem3";
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.btnAuthButtonSave;
            this.layoutControlItem4.CustomizationFormText = "layoutControlItem4";
            this.layoutControlItem4.Location = new System.Drawing.Point(238, 0);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(39, 26);
            this.layoutControlItem4.Text = "layoutControlItem4";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextToControlDistance = 0;
            this.layoutControlItem4.TextVisible = false;
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.grdAuthButton;
            this.layoutControlItem5.CustomizationFormText = "layoutControlItem5";
            this.layoutControlItem5.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(316, 195);
            this.layoutControlItem5.Text = "layoutControlItem5";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem5.TextToControlDistance = 0;
            this.layoutControlItem5.TextVisible = false;
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.btnAuthButtonDelete;
            this.layoutControlItem8.CustomizationFormText = "layoutControlItem8";
            this.layoutControlItem8.Location = new System.Drawing.Point(277, 0);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(39, 26);
            this.layoutControlItem8.Text = "layoutControlItem8";
            this.layoutControlItem8.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem8.TextToControlDistance = 0;
            this.layoutControlItem8.TextVisible = false;
            // 
            // treeList1
            // 
            this.treeList1.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn3});
            this.treeList1.ImageIndexFieldName = "";
            this.treeList1.KeyFieldName = "MENU_ID";
            this.treeList1.Location = new System.Drawing.Point(24, 363);
            this.treeList1.Name = "treeList1";
            this.treeList1.OptionsDragAndDrop.CanCloneNodesOnDrop = true;
            this.treeList1.OptionsDragAndDrop.DragNodesMode = DevExpress.XtraTreeList.DragNodesMode.Multiple;
            this.treeList1.OptionsBehavior.Editable = false;
            this.treeList1.OptionsBehavior.ShowEditorOnMouseUp = true;
            this.treeList1.OptionsView.ShowColumns = false;
            this.treeList1.OptionsView.ShowHorzLines = false;
            this.treeList1.OptionsView.ShowIndicator = false;
            this.treeList1.OptionsView.ShowVertLines = false;
            this.treeList1.ParentFieldName = "PARENT_ID";
            this.treeList1.Size = new System.Drawing.Size(296, 360);
            this.treeList1.TabIndex = 11;
            this.treeList1.DragDrop += new System.Windows.Forms.DragEventHandler(this.treeList1_DragDrop);
            // 
            // treeListColumn3
            // 
            this.treeListColumn3.Caption = "MENU_NAME";
            this.treeListColumn3.FieldName = "MENU_NAME";
            this.treeListColumn3.Name = "treeListColumn3";
            this.treeListColumn3.Visible = true;
            this.treeListColumn3.VisibleIndex = 0;
            this.treeListColumn3.Width = 163;
            // 
            // grdMaster
            // 
            this.grdMaster.CheckBoxFieldName = "CHK";
            this.grdMaster.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.None;
            this.grdMaster.IsHeaderClickAllCheckedItem = false;
            this.grdMaster.Location = new System.Drawing.Point(24, 134);
            this.grdMaster.MainView = this.grvMaster;
            this.grdMaster.MinLength = 0;
            this.grdMaster.Name = "grdMaster";
            this.grdMaster.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit1});
            this.grdMaster.Size = new System.Drawing.Size(296, 194);
            this.grdMaster.TabIndex = 10;
            this.grdMaster.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvMaster});
            // 
            // grvMaster
            // 
            this.grvMaster.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colUSER_ID,
            this.colUSER_NM,
            this.colDEPTNAME});
            this.grvMaster.GridControl = this.grdMaster;
            this.grvMaster.Name = "grvMaster";
            this.grvMaster.OptionsBehavior.Editable = false;
            this.grvMaster.OptionsView.ColumnAutoWidth = false;
            this.grvMaster.OptionsView.ShowGroupPanel = false;
            this.grvMaster.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.grvMaster_FocusedRowChanged);
            // 
            // colUSER_ID
            // 
            this.colUSER_ID.AppearanceHeader.Options.UseTextOptions = true;
            this.colUSER_ID.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colUSER_ID.Caption = "사용자ID";
            this.colUSER_ID.FieldName = "USER_ID";
            this.colUSER_ID.Name = "colUSER_ID";
            this.colUSER_ID.Visible = true;
            this.colUSER_ID.VisibleIndex = 0;
            // 
            // colUSER_NM
            // 
            this.colUSER_NM.AppearanceHeader.Options.UseTextOptions = true;
            this.colUSER_NM.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colUSER_NM.Caption = "사용자명";
            this.colUSER_NM.FieldName = "KOR_NM";
            this.colUSER_NM.Name = "colUSER_NM";
            this.colUSER_NM.Visible = true;
            this.colUSER_NM.VisibleIndex = 1;
            // 
            // colDEPTNAME
            // 
            this.colDEPTNAME.AppearanceHeader.Options.UseTextOptions = true;
            this.colDEPTNAME.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDEPTNAME.Caption = "부서";
            this.colDEPTNAME.FieldName = "DEPTNAME";
            this.colDEPTNAME.Name = "colDEPTNAME";
            this.colDEPTNAME.Visible = true;
            this.colDEPTNAME.VisibleIndex = 2;
            this.colDEPTNAME.Width = 133;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Caption = "Check";
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.repositoryItemCheckEdit1.ValueChecked = "Y";
            this.repositoryItemCheckEdit1.ValueUnchecked = "N";
            // 
            // btnDelete
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnDelete, new string[] {
            "DELETE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnDelete, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnDelete, false);
            this.btnDelete.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_삭제;
            this.btnDelete.IsExecuteWdworkerLog = true;
            this.btnDelete.Location = new System.Drawing.Point(1050, 12);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(54, 22);
            this.btnDelete.StyleController = this.xtraLayoutControlExt1;
            this.btnDelete.TabIndex = 5;
            this.btnDelete.Text = "삭제";
            this.btnDelete.UseSplasher = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // grdMaster1
            // 
            this.grdMaster1.AllowDrop = true;
            this.grdMaster1.CheckBoxFieldName = "CHK";
            this.grdMaster1.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdMaster1.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdMaster1.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdMaster1.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdMaster1.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdMaster1.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdMaster1.IsHeaderClickAllCheckedItem = true;
            this.grdMaster1.Location = new System.Drawing.Point(329, 134);
            this.grdMaster1.MainView = this.grvMaster1;
            this.grdMaster1.MinLength = 0;
            this.grdMaster1.Name = "grdMaster1";
            this.grdMaster1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpsCHK,
            this.rpsChk2,
            this.rpsCheckedCboAUTH,
            this.rpsPopupContainerEdit});
            this.grdMaster1.Size = new System.Drawing.Size(763, 589);
            this.grdMaster1.TabIndex = 9;
            this.grdMaster1.UseEmbeddedNavigator = true;
            this.grdMaster1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvMaster1});
            this.grdMaster1.DragDrop += new System.Windows.Forms.DragEventHandler(this.grdMaster1_DragDrop);
            this.grdMaster1.DragEnter += new System.Windows.Forms.DragEventHandler(this.grdMaster1_DragEnter);
            // 
            // grvMaster1
            // 
            this.grvMaster1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn5,
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn19,
            this.gridColumn18,
            this.gridColumn17,
            this.gridColumn16,
            this.gridColumn6,
            this.gridColumn15,
            this.gridColumn14,
            this.gridColumn13,
            this.colUSER_ID1});
            this.grvMaster1.GridControl = this.grdMaster1;
            this.grvMaster1.Name = "grvMaster1";
            this.grvMaster1.OptionsView.ColumnAutoWidth = false;
            this.grvMaster1.OptionsView.ShowGroupPanel = false;
            this.grvMaster1.ShowingEditor += new System.ComponentModel.CancelEventHandler(this.grvMaster1_ShowingEditor);
            this.grvMaster1.CellValueChanging += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.grvMaster1_CellValueChanging);
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.Caption = "CHK";
            this.gridColumn5.ColumnEdit = this.rpsCHK;
            this.gridColumn5.FieldName = "CHK";
            this.gridColumn5.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 0;
            this.gridColumn5.Width = 35;
            // 
            // rpsCHK
            // 
            this.rpsCHK.AutoHeight = false;
            this.rpsCHK.Caption = "Check";
            this.rpsCHK.Name = "rpsCHK";
            this.rpsCHK.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpsCHK.ValueChecked = "Y";
            this.rpsCHK.ValueUnchecked = "N";
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "Menu ID";
            this.gridColumn1.FieldName = "MENU_ID";
            this.gridColumn1.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 1;
            this.gridColumn1.Width = 120;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "Menu Name";
            this.gridColumn2.FieldName = "MENU_NAME";
            this.gridColumn2.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 2;
            this.gridColumn2.Width = 133;
            // 
            // gridColumn19
            // 
            this.gridColumn19.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn19.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn19.Caption = "Create";
            this.gridColumn19.ColumnEdit = this.rpsChk2;
            this.gridColumn19.FieldName = "BASIC_ACLC";
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 3;
            // 
            // rpsChk2
            // 
            this.rpsChk2.AutoHeight = false;
            this.rpsChk2.Caption = "Check";
            this.rpsChk2.Name = "rpsChk2";
            this.rpsChk2.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpsChk2.ValueChecked = "1";
            this.rpsChk2.ValueUnchecked = "0";
            // 
            // gridColumn18
            // 
            this.gridColumn18.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn18.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn18.Caption = "Read";
            this.gridColumn18.ColumnEdit = this.rpsChk2;
            this.gridColumn18.FieldName = "BASIC_ACLR";
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 4;
            // 
            // gridColumn17
            // 
            this.gridColumn17.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn17.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn17.Caption = "Update";
            this.gridColumn17.ColumnEdit = this.rpsChk2;
            this.gridColumn17.FieldName = "BASIC_ACLU";
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 5;
            // 
            // gridColumn16
            // 
            this.gridColumn16.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn16.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn16.Caption = "Delete";
            this.gridColumn16.ColumnEdit = this.rpsChk2;
            this.gridColumn16.FieldName = "BASIC_ACLD";
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.Visible = true;
            this.gridColumn16.VisibleIndex = 6;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.Caption = "확장권한";
            this.gridColumn6.ColumnEdit = this.rpsPopupContainerEdit;
            this.gridColumn6.FieldName = "AUTH";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 7;
            // 
            // rpsPopupContainerEdit
            // 
            this.rpsPopupContainerEdit.AutoHeight = false;
            this.rpsPopupContainerEdit.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsPopupContainerEdit.Name = "rpsPopupContainerEdit";
            this.rpsPopupContainerEdit.PopupControl = this.popupContainerControl1;
            this.rpsPopupContainerEdit.Popup += new System.EventHandler(this.rpsPopupContainerEdit_Popup);
            // 
            // gridColumn15
            // 
            this.gridColumn15.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.Caption = "Excel";
            this.gridColumn15.ColumnEdit = this.rpsChk2;
            this.gridColumn15.Name = "gridColumn15";
            // 
            // gridColumn14
            // 
            this.gridColumn14.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.Caption = "Print";
            this.gridColumn14.ColumnEdit = this.rpsChk2;
            this.gridColumn14.Name = "gridColumn14";
            // 
            // gridColumn13
            // 
            this.gridColumn13.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn13.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn13.Caption = "Upload";
            this.gridColumn13.ColumnEdit = this.rpsChk2;
            this.gridColumn13.Name = "gridColumn13";
            // 
            // colUSER_ID1
            // 
            this.colUSER_ID1.Caption = "USER_ID";
            this.colUSER_ID1.FieldName = "USER_ID";
            this.colUSER_ID1.Name = "colUSER_ID1";
            // 
            // rpsCheckedCboAUTH
            // 
            this.rpsCheckedCboAUTH.AutoHeight = false;
            this.rpsCheckedCboAUTH.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCheckedCboAUTH.Name = "rpsCheckedCboAUTH";
            // 
            // txtUSER_ID
            // 
            this.txtUSER_ID.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtUSER_ID.EditValue = "";
            this.txtUSER_ID.EnterExecuteButton = null;
            this.txtUSER_ID.FocusColor = System.Drawing.Color.Empty;
            this.txtUSER_ID.IsValueTrim = true;
            this.txtUSER_ID.Key = "";
            this.txtUSER_ID.Location = new System.Drawing.Point(331, 59);
            this.txtUSER_ID.MinLength = 0;
            this.txtUSER_ID.Name = "txtUSER_ID";
            this.txtUSER_ID.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtUSER_ID.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtUSER_ID.Properties.Appearance.Options.UseBackColor = true;
            this.txtUSER_ID.Properties.Appearance.Options.UseForeColor = true;
            this.txtUSER_ID.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtUSER_ID.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtUSER_ID.Size = new System.Drawing.Size(112, 20);
            this.txtUSER_ID.StyleController = this.xtraLayoutControlExt1;
            this.txtUSER_ID.TabIndex = 6;
            this.txtUSER_ID.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // btnSave
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSave, new string[] {
            "UPDATE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSave, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSave, false);
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.IsExecuteWdworkerLog = true;
            this.btnSave.Location = new System.Drawing.Point(992, 12);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(54, 22);
            this.btnSave.StyleController = this.xtraLayoutControlExt1;
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "저장";
            this.btnSave.UseSplasher = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnSearch
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSearch, new string[] {
            "SELECT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSearch, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSearch, true);
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.IsExecuteWdworkerLog = true;
            this.btnSearch.Location = new System.Drawing.Point(934, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(54, 22);
            this.btnSearch.StyleController = this.xtraLayoutControlExt1;
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "조회";
            this.btnSearch.UseSplasher = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "layoutControlGroup1";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup1, false);
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem1,
            this.layoutControlItem1,
            this.layoutControlItem2,
            this.layoutControlItem7,
            this.layoutControlGroup2,
            this.layoutControlGroup3});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1116, 747);
            this.layoutControlGroup1.Text = "Root";
            this.layoutControlGroup1.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(922, 26);
            this.emptySpaceItem1.Text = "emptySpaceItem1";
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.btnSearch;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(922, 0);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem1.Text = "layoutControlItem1";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextToControlDistance = 0;
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.btnSave;
            this.layoutControlItem2.CustomizationFormText = "layoutControlItem2";
            this.layoutControlItem2.Location = new System.Drawing.Point(980, 0);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem2.Text = "layoutControlItem2";
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextToControlDistance = 0;
            this.layoutControlItem2.TextVisible = false;
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.btnDelete;
            this.layoutControlItem7.CustomizationFormText = "layoutControlItem7";
            this.layoutControlItem7.Location = new System.Drawing.Point(1038, 0);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem7.Text = "layoutControlItem7";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem7.TextToControlDistance = 0;
            this.layoutControlItem7.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.CaptionImage = ((System.Drawing.Image)(resources.GetObject("layoutControlGroup2.CaptionImage")));
            this.layoutControlGroup2.CustomizationFormText = "List";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup2, false);
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem9,
            this.layoutControlItem6,
            this.splitterItem1,
            this.splitterItem2,
            this.layoutControlItem10,
            this.layoutControlItem15,
            this.emptySpaceItem4});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 85);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(1096, 642);
            this.layoutControlGroup2.Text = "사용자별 권한정보";
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.grdMaster;
            this.layoutControlItem9.CustomizationFormText = "layoutControlItem9";
            this.layoutControlItem9.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(300, 198);
            this.layoutControlItem9.Text = "layoutControlItem9";
            this.layoutControlItem9.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem9.TextToControlDistance = 0;
            this.layoutControlItem9.TextVisible = false;
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.grdMaster1;
            this.layoutControlItem6.CustomizationFormText = "layoutControlItem6";
            this.layoutControlItem6.Location = new System.Drawing.Point(305, 0);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(767, 593);
            this.layoutControlItem6.Text = "layoutControlItem6";
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextToControlDistance = 0;
            this.layoutControlItem6.TextVisible = false;
            // 
            // splitterItem1
            // 
            this.splitterItem1.AllowHotTrack = true;
            this.splitterItem1.CustomizationFormText = "splitterItem1";
            this.splitterItem1.Location = new System.Drawing.Point(300, 0);
            this.splitterItem1.Name = "splitterItem1";
            this.splitterItem1.Size = new System.Drawing.Size(5, 593);
            // 
            // splitterItem2
            // 
            this.splitterItem2.AllowHotTrack = true;
            this.splitterItem2.CustomizationFormText = "splitterItem2";
            this.splitterItem2.Location = new System.Drawing.Point(0, 198);
            this.splitterItem2.Name = "splitterItem2";
            this.splitterItem2.Size = new System.Drawing.Size(300, 5);
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.treeList1;
            this.layoutControlItem10.CustomizationFormText = "layoutControlItem10";
            this.layoutControlItem10.Location = new System.Drawing.Point(0, 229);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(300, 364);
            this.layoutControlItem10.Text = "layoutControlItem10";
            this.layoutControlItem10.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem10.TextToControlDistance = 0;
            this.layoutControlItem10.TextVisible = false;
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.Control = this.btnSearchMenuInfo;
            this.layoutControlItem15.CustomizationFormText = "layoutControlItem15";
            this.layoutControlItem15.Location = new System.Drawing.Point(229, 203);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.Size = new System.Drawing.Size(71, 26);
            this.layoutControlItem15.Text = "layoutControlItem15";
            this.layoutControlItem15.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem15.TextToControlDistance = 0;
            this.layoutControlItem15.TextVisible = false;
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 1F);
            this.layoutControlGroup3.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup3.CustomizationFormText = " ";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup3, true);
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem3,
            this.emptySpaceItem2,
            this.layoutControlItem11,
            this.layoutControlItem12,
            this.layoutControlItem13});
            this.layoutControlGroup3.Location = new System.Drawing.Point(0, 26);
            this.layoutControlGroup3.Name = "layoutControlGroup3";
            this.layoutControlGroup3.Size = new System.Drawing.Size(1096, 59);
            this.layoutControlGroup3.Text = " ";
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.txtUSER_ID;
            this.layoutControlItem3.CustomizationFormText = "AuthName";
            this.layoutControlItem3.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem3.Image")));
            this.layoutControlItem3.Location = new System.Drawing.Point(243, 0);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(180, 26);
            this.layoutControlItem3.Text = "사용자ID";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(61, 16);
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(652, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(420, 26);
            this.emptySpaceItem2.Text = "emptySpaceItem2";
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.txtDEPTNAME;
            this.layoutControlItem11.CustomizationFormText = "부서";
            this.layoutControlItem11.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem11.Image")));
            this.layoutControlItem11.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(206, 26);
            this.layoutControlItem11.Text = "부서";
            this.layoutControlItem11.TextSize = new System.Drawing.Size(61, 16);
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.btnDeptPopUp;
            this.layoutControlItem12.CustomizationFormText = "layoutControlItem12";
            this.layoutControlItem12.Location = new System.Drawing.Point(206, 0);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(37, 26);
            this.layoutControlItem12.Text = "layoutControlItem12";
            this.layoutControlItem12.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem12.TextToControlDistance = 0;
            this.layoutControlItem12.TextVisible = false;
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.txtUSER_NM;
            this.layoutControlItem13.CustomizationFormText = "사용자명";
            this.layoutControlItem13.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem13.Image")));
            this.layoutControlItem13.Location = new System.Drawing.Point(423, 0);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(229, 26);
            this.layoutControlItem13.Text = "사용자명";
            this.layoutControlItem13.TextSize = new System.Drawing.Size(61, 16);
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.CustomizationFormText = "emptySpaceItem4";
            this.emptySpaceItem4.Location = new System.Drawing.Point(0, 203);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(229, 26);
            this.emptySpaceItem4.Text = "emptySpaceItem4";
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // SCSYS012
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS012";
            this.Size = new System.Drawing.Size(1116, 747);
            this.Shown += new System.EventHandler(this.SCSYS012_Shown);
            this.Load += new System.EventHandler(this.SCSYS003_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtUSER_NM.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDEPTNAME.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupContainerControl1)).EndInit();
            this.popupContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt2)).EndInit();
            this.xtraLayoutControlExt2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdAuthButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvAuthButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.treeList1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMaster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMaster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMaster1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMaster1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsChk2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsPopupContainerEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCheckedCboAUTH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUSER_ID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private Client.Controls.DXperience.XtraGridControlExt grdMaster1;
        private DevExpress.XtraGrid.Views.Grid.GridView grvMaster1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpsCHK;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private Client.Controls.DXperience.XtraTextEditExt txtUSER_ID;
        private Client.Controls.DXperience.XtraButtonExt btnSave;
        private Client.Controls.DXperience.XtraButtonExt btnSearch;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private Client.Controls.DXperience.XtraButtonExt btnDelete;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private Client.Controls.DXperience.XtraGridControlExt grdMaster;
        private DevExpress.XtraGrid.Views.Grid.GridView grvMaster;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn colUSER_NM;
        private DevExpress.XtraGrid.Columns.GridColumn colDEPTNAME;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpsChk2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.SplitterItem splitterItem1;
        private DevExpress.XtraLayout.SplitterItem splitterItem2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraTreeList.TreeList treeList1;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraGrid.Columns.GridColumn colUSER_ID1;
        private DevExpress.XtraGrid.Columns.GridColumn colUSER_ID;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckedComboBoxEdit rpsCheckedCboAUTH;
        private DevExpress.XtraEditors.Repository.RepositoryItemPopupContainerEdit rpsPopupContainerEdit;
        private DevExpress.XtraEditors.PopupContainerControl popupContainerControl1;
        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt2;
        private Client.Controls.DXperience.XtraGridControlExt grdAuthButton;
        private DevExpress.XtraGrid.Views.Grid.GridView grvAuthButton;
        private DevExpress.XtraGrid.Columns.GridColumn colCHK3;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpsCHK3;
        private DevExpress.XtraGrid.Columns.GridColumn colDESCR;
        private DevExpress.XtraGrid.Columns.GridColumn colUSE_YN;
        private Client.Controls.DXperience.XtraButtonExt btnAuthButtonSave;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup4;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private Client.Controls.DXperience.XtraButtonExt btnAuthButtonDelete;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private Client.Controls.DXperience.XtraTextEditExt txtDEPTNAME;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private Client.Controls.DXperience.XtraTextEditExt txtUSER_NM;
        private Client.Controls.DXperience.XtraButtonExt btnDeptPopUp;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private Windows.Forms.StdSecurityManager stdSecurityManager1;
        private Client.Controls.DXperience.XtraButtonExt btnSearchMenuInfo;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private Controls.StdButtonExecuteManager stdButtonExecuteManager1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
    }
}
