﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS024
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SCSYS024));
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.cboPROCESS = new HHI.ShipBuilding.Client.Controls.DXperience.XtraImageComboBoxEditExt();
            this.dteReq_To = new HHI.ShipBuilding.Client.Controls.DXperience.XtraDateEditExt();
            this.dteReq_From = new HHI.ShipBuilding.Client.Controls.DXperience.XtraDateEditExt();
            this.txtReq_Userno = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnDeptPopUp = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.grdMain = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvMain = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpyChkUseYN = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboAfile = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsMemoEdit = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboGUBUN = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboPROCESS = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn20 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn21 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.txtReq_User_Nm = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtDeptName = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnNew = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnSearch = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnDelete = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.simpleLabelItem1 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem5 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.stdButtonExecuteManager1 = new HHI.ShipBuilding.Controls.StdButtonExecuteManager(this.components);
            this.stdSecurityManager1 = new HHI.ShipBuilding.Windows.Forms.StdSecurityManager(this.components);
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboPROCESS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteReq_To.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteReq_To.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteReq_From.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteReq_From.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReq_Userno.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpyChkUseYN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboAfile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsMemoEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboGUBUN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboPROCESS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReq_User_Nm.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDeptName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.cboPROCESS);
            this.xtraLayoutControlExt1.Controls.Add(this.dteReq_To);
            this.xtraLayoutControlExt1.Controls.Add(this.dteReq_From);
            this.xtraLayoutControlExt1.Controls.Add(this.txtReq_Userno);
            this.xtraLayoutControlExt1.Controls.Add(this.btnDeptPopUp);
            this.xtraLayoutControlExt1.Controls.Add(this.grdMain);
            this.xtraLayoutControlExt1.Controls.Add(this.txtReq_User_Nm);
            this.xtraLayoutControlExt1.Controls.Add(this.txtDeptName);
            this.xtraLayoutControlExt1.Controls.Add(this.btnNew);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearch);
            this.xtraLayoutControlExt1.Controls.Add(this.btnDelete);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(600, 407, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(1000, 600);
            this.xtraLayoutControlExt1.TabIndex = 1;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // cboPROCESS
            // 
            this.cboPROCESS.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.cboPROCESS.EditValue = "";
            this.cboPROCESS.EnterExecuteButton = null;
            this.cboPROCESS.FocusColor = System.Drawing.Color.Empty;
            this.cboPROCESS.Key = "PROCESS";
            this.cboPROCESS.Location = new System.Drawing.Point(492, 92);
            this.cboPROCESS.MinLength = 0;
            this.cboPROCESS.Name = "cboPROCESS";
            this.cboPROCESS.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.cboPROCESS.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.cboPROCESS.Properties.Appearance.Options.UseBackColor = true;
            this.cboPROCESS.Properties.Appearance.Options.UseForeColor = true;
            this.cboPROCESS.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboPROCESS.Size = new System.Drawing.Size(121, 20);
            this.cboPROCESS.StyleController = this.xtraLayoutControlExt1;
            this.cboPROCESS.TabIndex = 34;
            // 
            // dteReq_To
            // 
            this.dteReq_To.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.dteReq_To.EditValue = null;
            this.dteReq_To.EnterExecuteButton = null;
            this.dteReq_To.FocusColor = System.Drawing.Color.Empty;
            this.dteReq_To.Key = "CDATE";
            this.dteReq_To.Location = new System.Drawing.Point(240, 92);
            this.dteReq_To.MinLength = 0;
            this.dteReq_To.Name = "dteReq_To";
            this.dteReq_To.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.dteReq_To.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.dteReq_To.Properties.Appearance.Options.UseBackColor = true;
            this.dteReq_To.Properties.Appearance.Options.UseForeColor = true;
            this.dteReq_To.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteReq_To.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteReq_To.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Vista;
            this.dteReq_To.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.dteReq_To.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dteReq_To.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.True;
            this.dteReq_To.Size = new System.Drawing.Size(115, 20);
            this.dteReq_To.StyleController = this.xtraLayoutControlExt1;
            this.dteReq_To.TabIndex = 26;
            // 
            // dteReq_From
            // 
            this.dteReq_From.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.dteReq_From.EditValue = null;
            this.dteReq_From.EnterExecuteButton = null;
            this.dteReq_From.FocusColor = System.Drawing.Color.Empty;
            this.dteReq_From.Key = "CDATE";
            this.dteReq_From.Location = new System.Drawing.Point(92, 92);
            this.dteReq_From.MinLength = 0;
            this.dteReq_From.Name = "dteReq_From";
            this.dteReq_From.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.dteReq_From.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.dteReq_From.Properties.Appearance.Options.UseBackColor = true;
            this.dteReq_From.Properties.Appearance.Options.UseForeColor = true;
            this.dteReq_From.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteReq_From.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteReq_From.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Vista;
            this.dteReq_From.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.dteReq_From.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dteReq_From.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.True;
            this.dteReq_From.Size = new System.Drawing.Size(130, 20);
            this.dteReq_From.StyleController = this.xtraLayoutControlExt1;
            this.dteReq_From.TabIndex = 25;
            // 
            // txtReq_Userno
            // 
            this.txtReq_Userno.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtReq_Userno.EditValue = "";
            this.txtReq_Userno.EnterExecuteButton = null;
            this.txtReq_Userno.FocusColor = System.Drawing.Color.Empty;
            this.txtReq_Userno.IsValueTrim = true;
            this.txtReq_Userno.Key = "USER_NM";
            this.txtReq_Userno.Location = new System.Drawing.Point(92, 68);
            this.txtReq_Userno.MinLength = 0;
            this.txtReq_Userno.Name = "txtReq_Userno";
            this.txtReq_Userno.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtReq_Userno.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtReq_Userno.Properties.Appearance.Options.UseBackColor = true;
            this.txtReq_Userno.Properties.Appearance.Options.UseForeColor = true;
            this.txtReq_Userno.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtReq_Userno.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtReq_Userno.Size = new System.Drawing.Size(92, 20);
            this.txtReq_Userno.StyleController = this.xtraLayoutControlExt1;
            this.txtReq_Userno.TabIndex = 22;
            this.txtReq_Userno.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // btnDeptPopUp
            // 
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnDeptPopUp, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnDeptPopUp, false);
            this.btnDeptPopUp.Image = ((System.Drawing.Image)(resources.GetObject("btnDeptPopUp.Image")));
            this.btnDeptPopUp.IsExecuteWdworkerLog = true;
            this.btnDeptPopUp.Location = new System.Drawing.Point(655, 68);
            this.btnDeptPopUp.Name = "btnDeptPopUp";
            this.btnDeptPopUp.Size = new System.Drawing.Size(26, 20);
            this.btnDeptPopUp.StyleController = this.xtraLayoutControlExt1;
            this.btnDeptPopUp.TabIndex = 21;
            this.btnDeptPopUp.Text = " ";
            this.btnDeptPopUp.UseSplasher = false;
            this.btnDeptPopUp.Click += new System.EventHandler(this.btnDeptPopUp_Click);
            // 
            // grdMain
            // 
            this.grdMain.CheckBoxFieldName = "CHK";
            this.grdMain.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdMain.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdMain.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdMain.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdMain.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdMain.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdMain.IsHeaderClickAllCheckedItem = true;
            this.grdMain.Location = new System.Drawing.Point(24, 164);
            this.grdMain.MainView = this.grvMain;
            this.grdMain.MinLength = 0;
            this.grdMain.Name = "grdMain";
            this.grdMain.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpyChkUseYN,
            this.rpsCboAfile,
            this.rpsCboPROCESS,
            this.rpsMemoEdit,
            this.rpsCboGUBUN});
            this.grdMain.Size = new System.Drawing.Size(952, 412);
            this.grdMain.TabIndex = 13;
            this.grdMain.UseEmbeddedNavigator = true;
            this.grdMain.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvMain});
            // 
            // grvMain
            // 
            this.grvMain.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn2,
            this.gridColumn8,
            this.gridColumn19,
            this.gridColumn12,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn7,
            this.gridColumn16,
            this.gridColumn15,
            this.gridColumn14,
            this.gridColumn17,
            this.gridColumn9,
            this.gridColumn6,
            this.gridColumn3,
            this.gridColumn18,
            this.gridColumn10,
            this.gridColumn1,
            this.gridColumn13,
            this.gridColumn20,
            this.gridColumn21,
            this.gridColumn11});
            this.grvMain.GridControl = this.grdMain;
            this.grvMain.Name = "grvMain";
            this.grvMain.OptionsView.ColumnAutoWidth = false;
            this.grvMain.OptionsView.ShowGroupPanel = false;
            this.grvMain.DoubleClick += new System.EventHandler(this.grvMain_DoubleClick);
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = " ";
            this.gridColumn2.ColumnEdit = this.rpyChkUseYN;
            this.gridColumn2.FieldName = "CHK";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 0;
            this.gridColumn2.Width = 30;
            // 
            // rpyChkUseYN
            // 
            this.rpyChkUseYN.AutoHeight = false;
            this.rpyChkUseYN.Caption = "Check";
            this.rpyChkUseYN.Name = "rpyChkUseYN";
            this.rpyChkUseYN.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpyChkUseYN.ValueChecked = "Y";
            this.rpyChkUseYN.ValueUnchecked = "N";
            // 
            // gridColumn8
            // 
            this.gridColumn8.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.Caption = "요청";
            this.gridColumn8.ColumnEdit = this.rpsCboAfile;
            this.gridColumn8.FieldName = "CHKFILE";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsColumn.AllowEdit = false;
            this.gridColumn8.OptionsColumn.ReadOnly = true;
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 1;
            this.gridColumn8.Width = 33;
            // 
            // rpsCboAfile
            // 
            this.rpsCboAfile.AutoHeight = false;
            this.rpsCboAfile.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboAfile.GlyphAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.rpsCboAfile.Items.AddRange(new DevExpress.XtraEditors.Controls.ImageComboBoxItem[] {
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", "1", 0)});
            this.rpsCboAfile.Name = "rpsCboAfile";
            this.rpsCboAfile.SmallImages = this.imageList1;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Ico_03_16x16.png");
            this.imageList1.Images.SetKeyName(1, "ItemMarked_16x16.png");
            this.imageList1.Images.SetKeyName(2, "Ico_03_16x16_red.png");
            // 
            // gridColumn19
            // 
            this.gridColumn19.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn19.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn19.Caption = "회신";
            this.gridColumn19.ColumnEdit = this.rpsCboAfile;
            this.gridColumn19.FieldName = "RCV_CHKFILE";
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.OptionsColumn.AllowEdit = false;
            this.gridColumn19.OptionsColumn.ReadOnly = true;
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 2;
            this.gridColumn19.Width = 33;
            // 
            // gridColumn12
            // 
            this.gridColumn12.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.Caption = "No.";
            this.gridColumn12.FieldName = "CODE1";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.OptionsColumn.AllowEdit = false;
            this.gridColumn12.OptionsColumn.ReadOnly = true;
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 3;
            this.gridColumn12.Width = 85;
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.Caption = "요청자ID";
            this.gridColumn4.FieldName = "USERNO";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.AllowEdit = false;
            this.gridColumn4.OptionsColumn.ReadOnly = true;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 4;
            this.gridColumn4.Width = 90;
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.Caption = "요청자";
            this.gridColumn5.FieldName = "HNAME";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.OptionsColumn.ReadOnly = true;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 5;
            this.gridColumn5.Width = 100;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.Caption = "요청부서";
            this.gridColumn7.FieldName = "DEPTDESC";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            this.gridColumn7.OptionsColumn.ReadOnly = true;
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 6;
            this.gridColumn7.Width = 130;
            // 
            // gridColumn16
            // 
            this.gridColumn16.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn16.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn16.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn16.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn16.Caption = "요청일";
            this.gridColumn16.FieldName = "IDATE";
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.OptionsColumn.AllowEdit = false;
            this.gridColumn16.OptionsColumn.ReadOnly = true;
            this.gridColumn16.Visible = true;
            this.gridColumn16.VisibleIndex = 7;
            // 
            // gridColumn15
            // 
            this.gridColumn15.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.Caption = "프로그램ID";
            this.gridColumn15.FieldName = "PROGRAM_ID";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.OptionsColumn.AllowEdit = false;
            this.gridColumn15.OptionsColumn.ReadOnly = true;
            this.gridColumn15.Visible = true;
            this.gridColumn15.VisibleIndex = 8;
            // 
            // gridColumn14
            // 
            this.gridColumn14.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.Caption = "프로그램명";
            this.gridColumn14.FieldName = "PROGRAM_NAME";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.OptionsColumn.AllowEdit = false;
            this.gridColumn14.OptionsColumn.ReadOnly = true;
            this.gridColumn14.Visible = true;
            this.gridColumn14.VisibleIndex = 9;
            this.gridColumn14.Width = 103;
            // 
            // gridColumn17
            // 
            this.gridColumn17.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn17.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn17.Caption = "제목";
            this.gridColumn17.ColumnEdit = this.rpsMemoEdit;
            this.gridColumn17.FieldName = "SUBJECT";
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.OptionsColumn.ReadOnly = true;
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 10;
            this.gridColumn17.Width = 118;
            // 
            // rpsMemoEdit
            // 
            this.rpsMemoEdit.AutoHeight = false;
            this.rpsMemoEdit.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsMemoEdit.Name = "rpsMemoEdit";
            this.rpsMemoEdit.ShowIcon = false;
            // 
            // gridColumn9
            // 
            this.gridColumn9.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.Caption = "내용";
            this.gridColumn9.ColumnEdit = this.rpsMemoEdit;
            this.gridColumn9.FieldName = "CONTENT";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.ReadOnly = true;
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 11;
            this.gridColumn9.Width = 120;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.Caption = "내용구분";
            this.gridColumn6.ColumnEdit = this.rpsCboGUBUN;
            this.gridColumn6.FieldName = "GUBUN";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.OptionsColumn.ReadOnly = true;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 12;
            // 
            // rpsCboGUBUN
            // 
            this.rpsCboGUBUN.AutoHeight = false;
            this.rpsCboGUBUN.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboGUBUN.Name = "rpsCboGUBUN";
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.Caption = "상태";
            this.gridColumn3.ColumnEdit = this.rpsCboPROCESS;
            this.gridColumn3.FieldName = "PROCESS";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.OptionsColumn.ReadOnly = true;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 13;
            // 
            // rpsCboPROCESS
            // 
            this.rpsCboPROCESS.AutoHeight = false;
            this.rpsCboPROCESS.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboPROCESS.Name = "rpsCboPROCESS";
            // 
            // gridColumn18
            // 
            this.gridColumn18.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn18.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn18.Caption = "조치내용";
            this.gridColumn18.ColumnEdit = this.rpsMemoEdit;
            this.gridColumn18.FieldName = "CS_CONTENT";
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.OptionsColumn.ReadOnly = true;
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 14;
            // 
            // gridColumn10
            // 
            this.gridColumn10.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn10.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn10.Caption = "완료일";
            this.gridColumn10.FieldName = "CDATE";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.OptionsColumn.AllowEdit = false;
            this.gridColumn10.OptionsColumn.ReadOnly = true;
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 15;
            this.gridColumn10.Width = 120;
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "비고";
            this.gridColumn1.ColumnEdit = this.rpsMemoEdit;
            this.gridColumn1.FieldName = "USE_YN";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.ReadOnly = true;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 16;
            // 
            // gridColumn13
            // 
            this.gridColumn13.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn13.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn13.Caption = "AFILECODE";
            this.gridColumn13.FieldName = "AFILECODE";
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.OptionsColumn.AllowEdit = false;
            this.gridColumn13.OptionsColumn.ReadOnly = true;
            // 
            // gridColumn20
            // 
            this.gridColumn20.Caption = "AFILECODE2";
            this.gridColumn20.FieldName = "AFILECODE2";
            this.gridColumn20.Name = "gridColumn20";
            // 
            // gridColumn21
            // 
            this.gridColumn21.Caption = "RCV_TELNO";
            this.gridColumn21.FieldName = "RCV_TELNO";
            this.gridColumn21.Name = "gridColumn21";
            // 
            // gridColumn11
            // 
            this.gridColumn11.Caption = "CODE";
            this.gridColumn11.FieldName = "CODE";
            this.gridColumn11.Name = "gridColumn11";
            // 
            // txtReq_User_Nm
            // 
            this.txtReq_User_Nm.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtReq_User_Nm.EditValue = "";
            this.txtReq_User_Nm.EnterExecuteButton = null;
            this.txtReq_User_Nm.FocusColor = System.Drawing.Color.Empty;
            this.txtReq_User_Nm.IsValueTrim = true;
            this.txtReq_User_Nm.Key = "USER_NM";
            this.txtReq_User_Nm.Location = new System.Drawing.Point(314, 68);
            this.txtReq_User_Nm.MinLength = 0;
            this.txtReq_User_Nm.Name = "txtReq_User_Nm";
            this.txtReq_User_Nm.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtReq_User_Nm.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtReq_User_Nm.Properties.Appearance.Options.UseBackColor = true;
            this.txtReq_User_Nm.Properties.Appearance.Options.UseForeColor = true;
            this.txtReq_User_Nm.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtReq_User_Nm.Size = new System.Drawing.Size(91, 20);
            this.txtReq_User_Nm.StyleController = this.xtraLayoutControlExt1;
            this.txtReq_User_Nm.TabIndex = 11;
            this.txtReq_User_Nm.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtDeptName
            // 
            this.txtDeptName.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtDeptName.EditValue = "";
            this.txtDeptName.EnterExecuteButton = null;
            this.txtDeptName.FocusColor = System.Drawing.Color.Empty;
            this.txtDeptName.IsValueTrim = true;
            this.txtDeptName.Key = "DEPTNAME";
            this.txtDeptName.Location = new System.Drawing.Point(492, 68);
            this.txtDeptName.MinLength = 0;
            this.txtDeptName.Name = "txtDeptName";
            this.txtDeptName.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtDeptName.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtDeptName.Properties.Appearance.Options.UseBackColor = true;
            this.txtDeptName.Properties.Appearance.Options.UseForeColor = true;
            this.txtDeptName.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtDeptName.Size = new System.Drawing.Size(159, 20);
            this.txtDeptName.StyleController = this.xtraLayoutControlExt1;
            this.txtDeptName.TabIndex = 9;
            this.txtDeptName.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // btnNew
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnNew, new string[] {
            "INSERT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnNew, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnNew, false);
            this.btnNew.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_신규;
            this.btnNew.IsExecuteWdworkerLog = true;
            this.btnNew.Location = new System.Drawing.Point(842, 12);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(71, 22);
            this.btnNew.StyleController = this.xtraLayoutControlExt1;
            this.btnNew.TabIndex = 8;
            this.btnNew.Text = "신규";
            this.btnNew.UseSplasher = false;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnSearch
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSearch, new string[] {
            "SELECT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSearch, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSearch, true);
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.IsExecuteWdworkerLog = true;
            this.btnSearch.Location = new System.Drawing.Point(767, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(71, 22);
            this.btnSearch.StyleController = this.xtraLayoutControlExt1;
            this.btnSearch.TabIndex = 7;
            this.btnSearch.Text = "조회";
            this.btnSearch.UseSplasher = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnDelete
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnDelete, new string[] {
            "DELETE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnDelete, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnDelete, false);
            this.btnDelete.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_삭제;
            this.btnDelete.IsExecuteWdworkerLog = true;
            this.btnDelete.Location = new System.Drawing.Point(917, 12);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(71, 22);
            this.btnDelete.StyleController = this.xtraLayoutControlExt1;
            this.btnDelete.TabIndex = 6;
            this.btnDelete.Text = "삭제";
            this.btnDelete.UseSplasher = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "Root";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup1, false);
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem2,
            this.layoutControlItem1,
            this.layoutControlItem4,
            this.layoutControlGroup2,
            this.layoutControlGroup3,
            this.layoutControlItem3});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1000, 600);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(755, 26);
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.btnDelete;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(905, 0);
            this.layoutControlItem1.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.btnNew;
            this.layoutControlItem4.CustomizationFormText = "layoutControlItem4";
            this.layoutControlItem4.Location = new System.Drawing.Point(830, 0);
            this.layoutControlItem4.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem4.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem4.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 1F);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.CustomizationFormText = " ";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup2, true);
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem7,
            this.layoutControlItem5,
            this.layoutControlItem2,
            this.emptySpaceItem1,
            this.layoutControlItem9,
            this.emptySpaceItem3,
            this.layoutControlItem10,
            this.layoutControlItem11,
            this.simpleLabelItem1,
            this.layoutControlItem8,
            this.emptySpaceItem4,
            this.emptySpaceItem5});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 26);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(980, 90);
            this.layoutControlGroup2.Text = " ";
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.txtReq_User_Nm;
            this.layoutControlItem7.CustomizationFormText = "그룹ID";
            this.layoutControlItem7.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem7.Image")));
            this.layoutControlItem7.Location = new System.Drawing.Point(202, 0);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(198, 24);
            this.layoutControlItem7.Spacing = new DevExpress.XtraLayout.Utils.Padding(20, 15, 0, 0);
            this.layoutControlItem7.Text = "요청자명";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(65, 16);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.txtDeptName;
            this.layoutControlItem5.CustomizationFormText = "layoutControlItem5";
            this.layoutControlItem5.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem5.Image")));
            this.layoutControlItem5.Location = new System.Drawing.Point(400, 0);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(231, 24);
            this.layoutControlItem5.Text = "부서명";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(65, 16);
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.btnDeptPopUp;
            this.layoutControlItem2.CustomizationFormText = "layoutControlItem2";
            this.layoutControlItem2.Location = new System.Drawing.Point(631, 0);
            this.layoutControlItem2.MaxSize = new System.Drawing.Size(30, 24);
            this.layoutControlItem2.MinSize = new System.Drawing.Size(30, 24);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(30, 24);
            this.layoutControlItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(661, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(295, 24);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.txtReq_Userno;
            this.layoutControlItem9.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_blue;
            this.layoutControlItem9.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(164, 24);
            this.layoutControlItem9.Text = "요청자 ID";
            this.layoutControlItem9.TextSize = new System.Drawing.Size(65, 16);
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.Location = new System.Drawing.Point(593, 24);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(363, 24);
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.dteReq_From;
            this.layoutControlItem10.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_blue;
            this.layoutControlItem10.Location = new System.Drawing.Point(0, 24);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(202, 24);
            this.layoutControlItem10.Text = "요청일자";
            this.layoutControlItem10.TextSize = new System.Drawing.Size(65, 16);
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.dteReq_To;
            this.layoutControlItem11.Location = new System.Drawing.Point(216, 24);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(119, 24);
            this.layoutControlItem11.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem11.TextVisible = false;
            // 
            // simpleLabelItem1
            // 
            this.simpleLabelItem1.AllowHotTrack = false;
            this.simpleLabelItem1.Location = new System.Drawing.Point(202, 24);
            this.simpleLabelItem1.MaxSize = new System.Drawing.Size(14, 18);
            this.simpleLabelItem1.MinSize = new System.Drawing.Size(14, 18);
            this.simpleLabelItem1.Name = "simpleLabelItem1";
            this.simpleLabelItem1.Size = new System.Drawing.Size(14, 24);
            this.simpleLabelItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem1.Text = "~";
            this.simpleLabelItem1.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.simpleLabelItem1.TextSize = new System.Drawing.Size(9, 14);
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.cboPROCESS;
            this.layoutControlItem8.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_blue;
            this.layoutControlItem8.Location = new System.Drawing.Point(400, 24);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(193, 24);
            this.layoutControlItem8.Text = "처리상태";
            this.layoutControlItem8.TextSize = new System.Drawing.Size(65, 16);
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.Location = new System.Drawing.Point(164, 0);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(38, 24);
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem5
            // 
            this.emptySpaceItem5.AllowHotTrack = false;
            this.emptySpaceItem5.Location = new System.Drawing.Point(335, 24);
            this.emptySpaceItem5.Name = "emptySpaceItem5";
            this.emptySpaceItem5.Size = new System.Drawing.Size(65, 24);
            this.emptySpaceItem5.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup3.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup3.CaptionImage = ((System.Drawing.Image)(resources.GetObject("layoutControlGroup3.CaptionImage")));
            this.layoutControlGroup3.CustomizationFormText = "사용자정보";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup3, false);
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem6});
            this.layoutControlGroup3.Location = new System.Drawing.Point(0, 116);
            this.layoutControlGroup3.Name = "layoutControlGroup3";
            this.layoutControlGroup3.Size = new System.Drawing.Size(980, 464);
            this.layoutControlGroup3.Text = "사용자정보";
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.grdMain;
            this.layoutControlItem6.CustomizationFormText = "layoutControlItem6";
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(956, 416);
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextVisible = false;
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.btnSearch;
            this.layoutControlItem3.CustomizationFormText = "layoutControlItem3";
            this.layoutControlItem3.Location = new System.Drawing.Point(755, 0);
            this.layoutControlItem3.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem3.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem3.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem3.TextVisible = false;
            // 
            // imageList2
            // 
            this.imageList2.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList2.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // SCSYS024
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS024";
            this.Size = new System.Drawing.Size(1000, 600);
            this.Shown += new System.EventHandler(this.SCSYS024_Shown);
            this.Load += new System.EventHandler(this.SCSYS024_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cboPROCESS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteReq_To.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteReq_To.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteReq_From.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteReq_From.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReq_Userno.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpyChkUseYN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboAfile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsMemoEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboGUBUN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboPROCESS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReq_User_Nm.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDeptName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private Client.Controls.DXperience.XtraTextEditExt txtReq_User_Nm;
        private Client.Controls.DXperience.XtraTextEditExt txtDeptName;
        private Client.Controls.DXperience.XtraButtonExt btnNew;
        private Client.Controls.DXperience.XtraButtonExt btnSearch;
        private Client.Controls.DXperience.XtraButtonExt btnDelete;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private Client.Controls.DXperience.XtraGridControlExt grdMain;
        private DevExpress.XtraGrid.Views.Grid.GridView grvMain;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpyChkUseYN;
        private Controls.StdButtonExecuteManager stdButtonExecuteManager1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private Client.Controls.DXperience.XtraButtonExt btnDeptPopUp;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private Windows.Forms.StdSecurityManager stdSecurityManager1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboAfile;
        private System.Windows.Forms.ImageList imageList1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboPROCESS;
        private System.Windows.Forms.ImageList imageList2;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit rpsMemoEdit;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboGUBUN;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn20;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn21;
        private Client.Controls.DXperience.XtraTextEditExt txtReq_Userno;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private Client.Controls.DXperience.XtraDateEditExt dteReq_To;
        private Client.Controls.DXperience.XtraDateEditExt dteReq_From;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem1;
        private Client.Controls.DXperience.XtraImageComboBoxEditExt cboPROCESS;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
    }
}
