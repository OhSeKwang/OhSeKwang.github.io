﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;

using DevExpress.XtraGrid.Views.Grid;
using System.Collections;
using HHI.ShipBuilding.Client.Controls.DXperience;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS011 : StdUserControlBase
    {
        string hdnCDCLSS = string.Empty;

        public SCSYS011()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }

        #region 화면 Load - SCSYS011_Load
        /// <summary>
        /// 화면 Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SCSYS011_Load(object sender, EventArgs e)
        {
           
        }
        #endregion 화면 Load - SCSYS011_Load

        #region SCSYS011_Shown
        private void SCSYS011_Shown(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                initPage();

                stdSecurityManager1.ApplySecurity(this.SecurityContext);
                stdButtonExecuteManager1.RegisterButtonExecEvent();
            }
        }
        #endregion

        #region 화면 초기화 - initPage
        /// <summary>
        /// 화면 초기화
        /// </summary>
        private void initPage()
        {
            

            // 그룹 그리드 초기화
            DataTable dtGroup = new DataTable();
            dtGroup.Columns.Add("CHK");
            dtGroup.Columns.Add("CDCLSS");
            dtGroup.Columns.Add("CDNM");
            dtGroup.Columns.Add("CDNM2");
            dtGroup.Columns.Add("IS_SAVE");

            grdGroup.DataSource = dtGroup;

            // 코드 그리드 초기화
            DataTable dtCode = new DataTable();
            dtCode.Columns.Add("CHK");
            dtCode.Columns.Add("CDCODE");
            dtCode.Columns.Add("CDNM");
            dtCode.Columns.Add("CDNM2");
            dtCode.Columns.Add("SORTCOL");
            dtCode.Columns.Add("IS_SAVE");

            grdCode.DataSource = dtCode;

            // 콤보 
            ClientControlHelper.ImageComboBind(cboCODEGRP, "CDNM", "CDCODE", "{value}-{text}", ComboDisplayTextOption.top, "전체", string.Empty, ClientControlHelper.GetCodeInfo("SY001"));
            ClientControlHelper.ImageComboBind(rpsCboCODEGRP, "CDNM", "CDCODE", "{value}-{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, ClientControlHelper.GetCodeInfo("SY001"));
        }
        #endregion 화면 초기화 - initPage

        #region 조회 - btnSearch_Click
        /// <summary>
        /// 조회
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            DataResultSet resultSet = GetCodeGroupInfo(txtGroup_Id.Text, txtGroup_Nm.Text, cboCODEGRP.EditValue.ToString());

            if (resultSet.IsSuccess)
            {
                grdGroup.DataSource = resultSet.QuerySet.Tables[0];
                grvGroup_FocusedRowChanged(null, null);
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 조회 - btnSearch_Click

        #region 공통코드 그룹 조회 - GetUserInfo
        /// <summary>
        /// 공통코드 그룹 조회
        /// </summary>
        /// <param name="strGroup_Nm"></param>
        /// <param name="strDescr"></param>
        /// <returns></returns>
        private DataResultSet GetCodeGroupInfo(string strGroup_Id, string strGroup_Nm, string strCode)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("CODEGRP", strCode);
            parameter.DataList.Add("CDCLSS", strGroup_Id);
            parameter.DataList.Add("CDNM", strGroup_Nm);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS011.SEARCH_01", parameter);
        }
        #endregion 공통코드 그룹 조회 - GetUserInfo

        #region 그룹 그리드 Row 변경 - grvGroup_FocusedRowChanged
        /// <summary>
        /// 그룹 그리드 Row 변경
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void grvGroup_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            DataRow row = grvGroup.GetFocusedDataRow();
            if (row == null)
                return;

            hdnCDCLSS = row["CDCLSS"].ToString();

            DataResultSet resultSet = GetCodeInfo(hdnCDCLSS);

            if (resultSet.IsSuccess)
            {
                empGroupInfo.Text = string.IsNullOrWhiteSpace(hdnCDCLSS) ? " " : string.Format("{0} : {1}", hdnCDCLSS, row["CDNM"].ToString());
                grdCode.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 그룹 그리드 Row 변경 - grvGroup_FocusedRowChanged

        #region 공통코드 조회 - GetCodeInfo
        /// <summary>
        /// 공통코드 조회
        /// </summary>
        /// <param name="strGroup_Id"></param>
        /// <returns></returns>
        private DataResultSet GetCodeInfo(string strGroup_Id)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("CDCLSS", strGroup_Id);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS011.SEARCH_02", parameter);
        }
        #endregion 공통코드 조회 - GetCodeInfo

        #region 그룹정보 행추가 - btnGroupAdd_Click
        /// <summary>
        /// 그룹정보 행추가
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGroupAdd_Click(object sender, EventArgs e)
        {
            grvGroup.AddNewRow();
            grvGroup.SetRowCellValue(grvGroup.FocusedRowHandle, "CHK", "Y");
            grvGroup.SetRowCellValue(grvGroup.FocusedRowHandle, "IS_SAVE", "Y");
        }
        #endregion 그룹정보 행추가 - btnGroupAdd_Click

        #region 그룹정보 저장 - btnGroupSave_Click
        /// <summary>
        /// 그룹정보 저장
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGroupSave_Click(object sender, EventArgs e)
        {
            if (grvGroup.RowCount == 0)
            {
                MsgBox.Show("저장할 정보가 없습니다.", "경고");
                return;
            }

            if ((grdGroup.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            {
                MsgBox.Show("저장할 정보를 선택하세요!", "경고");
                return;
            }

            DataTable dtGroup = (grdGroup.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();
            string[] paramnames = new string[] { "CODEGRP", "CDCLSS", "CDNM", "USER_ID", "LOGIN_USERID" };

            DataTable dtParam = new DataTable();
            for (int i = 0; i < paramnames.Length; i++)
            {
                dtParam.Columns.Add(paramnames[i]);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in dtParam.Columns)
            {
                string[] col1 = new string[dtGroup.Rows.Count];
                for (int i = 0; i < dtGroup.Rows.Count; i++)
                {
                    if (col.ColumnName.Equals("CODEGRP"))
                    {
                        if (string.IsNullOrWhiteSpace(dtGroup.Rows[i][col.ColumnName].ToString()))
                        {
                            MsgBox.Show("대분류코드는 필수 입력 입니다.", "경고");
                            return;
                        }
                    }

                    if (col.ColumnName.Equals("CDNM"))
                    {
                        if (string.IsNullOrWhiteSpace(dtGroup.Rows[i][col.ColumnName].ToString()))
                        {
                            MsgBox.Show("분류코드명는 필수 입력 입니다.", "경고");
                            return;
                        }
                    }

                    if(col.ColumnName.Equals("USER_ID"))
                    {
                        col1[i] = string.Empty;
                    }
                    else if (col.ColumnName.Equals("LOGIN_USERID"))
                    {
                        col1[i] = UserInfo == null ? "ADMIN" : UserInfo.UserID; // eve
                    }
                    else
                    {
                        col1[i] = dtGroup.Rows[i][col.ColumnName].ToString();
                    }
                    
                }

                parameter.DataList.Add(col.ColumnName, col1);
            }

            parameter.ArrayItemCount = dtGroup.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS011.SAVE_01", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("저장되었습니다.", "경고");
                btnSearch.PerformClick();
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 그룹정보 저장 - btnGroupSave_Click

        #region 그룹정보 삭제 - btnGroupDelete_Click
        /// <summary>
        /// 그룹정보 삭제
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGroupDelete_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("삭제 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }

            if (grvGroup.RowCount == 0)
            {
                MsgBox.Show("삭제할 정보가 없습니다.", "경고");
                return;
            }

            if ((grdGroup.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            {
                MsgBox.Show("삭제할 정보를 선택하세요!", "경고");
                return;
            }

            DataTable dtGroup = (grdGroup.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();
            string[] paramnames = new string[] { "CDCLSS" };

            DataTable dtParam = new DataTable();
            for (int i = 0; i < paramnames.Length; i++)
            {
                dtParam.Columns.Add(paramnames[i]);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in dtParam.Columns)
            {
                string[] col1 = new string[dtGroup.Rows.Count];
                for (int i = 0; i < dtGroup.Rows.Count; i++)
                {
                    if (col.ColumnName.Equals("CDCLSS"))
                    {
                        if (string.IsNullOrWhiteSpace(dtGroup.Rows[i][col.ColumnName].ToString()))
                        {
                            MsgBox.Show("분류코드가 없습니다!", "경고");
                            return;
                        }

                        if (!CheckGroupChildCodeInfo(dtGroup.Rows[i][col.ColumnName].ToString()))
                        {
                            return;
                        }
                    }

                    col1[i] = dtGroup.Rows[i][col.ColumnName].ToString();
                }

                parameter.DataList.Add(col.ColumnName, col1);
            }

            parameter.ArrayItemCount = dtGroup.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS011.DELETE_01", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("삭제 되었습니다.", "확인");
                btnSearch.PerformClick();
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 그룹정보 삭제 - btnGroupDelete_Click

        #region 그룹정보 삭제 체크 - CheckGroupChildCodeInfo
        /// <summary>
        /// 그룹정보 삭제 체크
        /// </summary>
        /// <param name="strGroup_Id"></param>
        /// <returns></returns>
        private bool CheckGroupChildCodeInfo(string strGroup_Id)
        {
            bool bResult = true;

            DataTable dtCheck = GetCodeInfo(hdnCDCLSS).QuerySet.Tables[0];
            if (dtCheck != null && dtCheck.Rows.Count > 0)
            {
                MsgBox.Show(string.Format("분류코드 : {0} 의 코드 정보를 먼저 삭제 하세요!", strGroup_Id), "경고");
                bResult = false;
            }

            return bResult;
        }
        #endregion 그룹정보 삭제 체크 - CheckGroupChildCodeInfo

        #region 코드 행추가 - btnCodeAdd_Click
        /// <summary>
        /// 코드 행추가
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCodeAdd_Click(object sender, EventArgs e)
        {
            grvCode.AddNewRow();
            grvCode.SetRowCellValue(grvCode.FocusedRowHandle, "CHK", "Y");
            grvCode.SetRowCellValue(grvCode.FocusedRowHandle, "IS_SAVE", "Y");
        }
        #endregion 코드 행추가 - btnCodeAdd_Click

        #region 코드 저장 - btnCodeSave_Click
        /// <summary>
        /// 코드 저장
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCodeSave_Click(object sender, EventArgs e)
        {
            if (grvCode.RowCount == 0)
            {
                MsgBox.Show("저장할 정보가 없습니다.", "경고");
                return;
            }

            if ((grdCode.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            {
                MsgBox.Show("저장할 정보를 선택하세요!", "경고");
                return;
            }

            DataTable dtCode = (grdCode.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();
            string[] paramnames = new string[] { "CDCLSS", "CDCODE", "CDNM", "CDNM2", "SORTCOL", "USER_ID", "LOGIN_USERID" };

            DataTable dtParam = new DataTable();
            for (int i = 0; i < paramnames.Length; i++)
            {
                dtParam.Columns.Add(paramnames[i]);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in dtParam.Columns)
            {
                string[] col1 = new string[dtCode.Rows.Count];
                for (int i = 0; i < dtCode.Rows.Count; i++)
                {
                    if (col.ColumnName.Equals("CDCODE"))
                    {
                        if (string.IsNullOrEmpty(dtCode.Rows[i][col.ColumnName].ToString()))
                        {
                            MsgBox.Show("코드는 필수 입력 입니다.", "경고");
                            return;
                        }
                    }

                    if (col.ColumnName.Equals("CDNM"))
                    {
                        if (string.IsNullOrWhiteSpace(dtCode.Rows[i][col.ColumnName].ToString()))
                        {
                            MsgBox.Show("분류코드명는 필수 입력 입니다.", "경고");
                            return;
                        }
                    }

                    if (col.ColumnName.Equals("CDCLSS"))
                    {
                        col1[i] = hdnCDCLSS;
                    }
                    else if (col.ColumnName.Equals("USER_ID"))
                    {
                        col1[i] = string.Empty;
                    }
                    else if (col.ColumnName.Equals("LOGIN_USERID"))
                    {
                        col1[i] = UserInfo == null ? "ADMIN" : UserInfo.UserID; // eve
                    }
                    else
                    {
                        col1[i] = dtCode.Rows[i][col.ColumnName].ToString();
                    }
                }

                parameter.DataList.Add(col.ColumnName, col1);
            }

            parameter.ArrayItemCount = dtCode.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            ArrayList requierdList = new ArrayList();
            requierdList.Add("CDCODE");
            requierdList.Add("CDNM");
            requierdList.Add("SORTCOL");

            if (ValidationRequired(grvCode, grdGroup, true, false, requierdList))
            {
                DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS011.SAVE_02", parameter);

                if (resultSet.IsSuccess)
                {
                    MsgBox.Show("저장되었습니다.", "확인");
                    grvGroup_FocusedRowChanged(null, null);
                }
                else
                {
                    MsgBox.Show(resultSet.ExceptionMessage);
                }
            }
        }
        #endregion 코드 저장 - btnCodeSave_Click

        #region 코드 삭제 - btnCodeDelete_Click
        /// <summary>
        /// 코드 삭제
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCodeDelete_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("삭제 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }

            if (grvCode.RowCount == 0)
            {
                MsgBox.Show("삭제할 정보가 없습니다.", "경고");
                return;
            }

            if ((grdCode.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            {
                MsgBox.Show("삭제할 정보를 선택하세요!", "경고");
                return;
            }

            DataTable dtCode = (grdCode.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();
            string[] paramnames = new string[] { "CDCLSS", "CDCODE" };

            DataTable dtParam = new DataTable();
            for (int i = 0; i < paramnames.Length; i++)
            {
                dtParam.Columns.Add(paramnames[i]);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in dtParam.Columns)
            {
                string[] col1 = new string[dtCode.Rows.Count];
                for (int i = 0; i < dtCode.Rows.Count; i++)
                {
                    if (col.ColumnName.Equals("CDCLSS"))
                    {
                        if (string.IsNullOrWhiteSpace(hdnCDCLSS))
                        {
                            MsgBox.Show("분류코드가 없습니다!", "경고");
                            return;
                        }
                    }

                    if (col.ColumnName.Equals("CDCODE"))
                    {
                        if (string.IsNullOrEmpty(dtCode.Rows[i][col.ColumnName].ToString()))
                        {
                            MsgBox.Show("코드는 필수 입력 입니다.", "경고");
                            return;
                        }
                    }

                    if (col.ColumnName.Equals("CDCLSS"))
                    {
                        col1[i] = hdnCDCLSS;
                    }
                    else
                    {
                        col1[i] = dtCode.Rows[i][col.ColumnName].ToString();
                    }
                }

                parameter.DataList.Add(col.ColumnName, col1);
            }

            parameter.ArrayItemCount = dtCode.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS011.DELETE_02", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("삭제 되었습니다.", "확인");
                grvGroup_FocusedRowChanged(null, null);
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 코드 삭제 - btnCodeDelete_Click

        private void grvGroup_ShowingEditor(object sender, CancelEventArgs e)
        {
            DataRow row = grvGroup.GetFocusedDataRow();
            if (row != null)
            {
                string strFieldName = grvGroup.FocusedColumn.FieldName;
                if (strFieldName.Equals("CODEGRP"))
                {
                    if (row["IS_SAVE"].ToString().Equals("Y"))
                        e.Cancel = true;
                    else
                        e.Cancel = false;
                }
            }
            
        }

        private void grvCode_ShowingEditor(object sender, CancelEventArgs e)
        {
            DataRow row = grvCode.GetFocusedDataRow();
            if (row != null)
            {
                string strFieldName = grvCode.FocusedColumn.FieldName;
                if (strFieldName.Equals("CDCODE"))
                {
                    if (row["IS_SAVE"].ToString().Equals("Y"))
                        e.Cancel = true;
                    else
                        e.Cancel = false;
                }
            }
        }

        #region 그리드 관련 메소드
        public bool ValidationRequired(GridView grvMaster, XtraGridControlExt grdMaster, bool IsMessagePrint, bool IsFocusedRowValidationCheck, ArrayList requiredColumns)
        {
            DataTable dt = (grdMaster.DataSource as DataTable);
            if (dt.Rows.Count == 0)
                return false;

            //ArrayList requiredColumns = GetRequiredColumns();
            

            //전체 DataRow에 대하여 Validation체크를 한다
            if (!IsFocusedRowValidationCheck)
            {
                //int RowCount = (grvMaster != null ? grvMaster.DataRowCount : InnerLayoutView.DataRowCount);
                int RowCount = grvMaster.DataRowCount;

                for (int i = 0; i < RowCount; i++)
                {
                    bool validationResult = RequiredValidationByRowHandle(grvMaster, IsMessagePrint, requiredColumns, i);

                    if (!validationResult)
                        return validationResult;
                }

                return true;
            }
            
            return false;
        }

        private bool RequiredValidationByRowHandle(GridView grvMaster, bool IsMessagePrint, ArrayList requiredColumns, int rowIndex)
        {
            //DataRow row = (InnerGridView != null ? InnerGridView.GetDataRow(rowIndex) : InnerLayoutView.GetDataRow(rowIndex));
            DataRow row = grvMaster.GetDataRow(rowIndex);
            bool IsValidationCheck = false;

            //선택된 행에 대하여
            if (row["CHK"].ToString().Equals("Y"))
                IsValidationCheck = true;

            if (IsValidationCheck)
            {
                foreach (string fieldName in requiredColumns)
                {
                    if (row[fieldName].ToString().Equals(""))
                    {
                        if (IsMessagePrint)
                        {
                            //string colCaption = InnerGridView != null ? InnerGridView.Columns[fieldName].Caption : InnerLayoutView.Columns[fieldName].Caption;
                            string colCaption = grvMaster.Columns[fieldName].Caption;
                            string message = string.Format("{0}은는필수입력입니다", colCaption);

                            //MessageBoxHelper.HiproMessageBoxShow(message);
                            //MsgBox.Show(message);

                            if (grvMaster != null)
                            {
                                grvMaster.ClearColumnErrors();
                                grvMaster.FocusedRowHandle = rowIndex;
                                grvMaster.SetColumnError(grvMaster.Columns[fieldName], message);
                            }
                            else
                            {
                                //InnerLayoutView.ClearColumnErrors();
                                //InnerLayoutView.FocusedRowHandle = rowIndex;
                                //InnerLayoutView.SetColumnError(InnerLayoutView.Columns[fieldName], message);
                            }
                        }
                        return false;
                    }
                }
            }
            return true;
        }
        #endregion

       
    }
}
