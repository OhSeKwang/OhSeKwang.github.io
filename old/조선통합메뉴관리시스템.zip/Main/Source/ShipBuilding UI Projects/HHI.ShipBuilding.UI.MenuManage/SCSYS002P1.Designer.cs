﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS002P1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SCSYS002P1));
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.cboSYSTEM_CODE = new HHI.ShipBuilding.Client.Controls.DXperience.XtraImageComboBoxEditExt();
            this.cboWORK_GUBUN = new HHI.ShipBuilding.Client.Controls.DXperience.XtraImageComboBoxEditExt();
            this.btnDeptPopUp = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnRowDelete = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnSave = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnAddRow = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.grdGroupUser = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvGroupUser = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.btnSearch_Group = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.txtGroup_Name = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.grdGroup = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvGroup = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpychkYN = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSYSTEM_CODE = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboSYSTEM_CODE = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.colDESCR = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colWORK_GUBUN = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboWORK_GUBUN = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.btnSearch_User = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.grdUser = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvUser = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpychkCheckYN = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.txtUser_Id = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtUser_Nm = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtDeptName = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnClose = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.splitterItem1 = new DevExpress.XtraLayout.SplitterItem();
            this.splitterItem2 = new DevExpress.XtraLayout.SplitterItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem16 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem5 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup4 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.stdValidationManager1 = new HHI.ShipBuilding.Controls.StdValidationManager(this.components);
            this.stdSecurityManager1 = new HHI.ShipBuilding.Windows.Forms.StdSecurityManager(this.components);
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboSYSTEM_CODE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboWORK_GUBUN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdGroupUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvGroupUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGroup_Name.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkYN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboSYSTEM_CODE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboWORK_GUBUN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkCheckYN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUser_Id.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUser_Nm.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDeptName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.cboSYSTEM_CODE);
            this.xtraLayoutControlExt1.Controls.Add(this.cboWORK_GUBUN);
            this.xtraLayoutControlExt1.Controls.Add(this.btnDeptPopUp);
            this.xtraLayoutControlExt1.Controls.Add(this.btnRowDelete);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSave);
            this.xtraLayoutControlExt1.Controls.Add(this.btnAddRow);
            this.xtraLayoutControlExt1.Controls.Add(this.grdGroupUser);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearch_Group);
            this.xtraLayoutControlExt1.Controls.Add(this.txtGroup_Name);
            this.xtraLayoutControlExt1.Controls.Add(this.grdGroup);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearch_User);
            this.xtraLayoutControlExt1.Controls.Add(this.grdUser);
            this.xtraLayoutControlExt1.Controls.Add(this.txtUser_Id);
            this.xtraLayoutControlExt1.Controls.Add(this.txtUser_Nm);
            this.xtraLayoutControlExt1.Controls.Add(this.txtDeptName);
            this.xtraLayoutControlExt1.Controls.Add(this.btnClose);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(514, 420, 374, 317);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(1308, 777);
            this.xtraLayoutControlExt1.TabIndex = 0;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // cboSYSTEM_CODE
            // 
            this.cboSYSTEM_CODE.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.cboSYSTEM_CODE.EditValue = "";
            this.cboSYSTEM_CODE.EnterExecuteButton = null;
            this.cboSYSTEM_CODE.FocusColor = System.Drawing.Color.Empty;
            this.cboSYSTEM_CODE.Key = "";
            this.cboSYSTEM_CODE.Location = new System.Drawing.Point(276, 74);
            this.cboSYSTEM_CODE.MinLength = 0;
            this.cboSYSTEM_CODE.Name = "cboSYSTEM_CODE";
            this.cboSYSTEM_CODE.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.cboSYSTEM_CODE.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.cboSYSTEM_CODE.Properties.Appearance.Options.UseBackColor = true;
            this.cboSYSTEM_CODE.Properties.Appearance.Options.UseForeColor = true;
            this.cboSYSTEM_CODE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboSYSTEM_CODE.Size = new System.Drawing.Size(150, 20);
            this.cboSYSTEM_CODE.StyleController = this.xtraLayoutControlExt1;
            this.cboSYSTEM_CODE.TabIndex = 14;
            this.cboSYSTEM_CODE.KeyDown += new System.Windows.Forms.KeyEventHandler(this.groupInfo_KeyDown);
            // 
            // cboWORK_GUBUN
            // 
            this.cboWORK_GUBUN.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.cboWORK_GUBUN.EditValue = "";
            this.cboWORK_GUBUN.EnterExecuteButton = null;
            this.cboWORK_GUBUN.FocusColor = System.Drawing.Color.Empty;
            this.cboWORK_GUBUN.Key = "";
            this.cboWORK_GUBUN.Location = new System.Drawing.Point(100, 74);
            this.cboWORK_GUBUN.MinLength = 0;
            this.cboWORK_GUBUN.Name = "cboWORK_GUBUN";
            this.cboWORK_GUBUN.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.cboWORK_GUBUN.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.cboWORK_GUBUN.Properties.Appearance.Options.UseBackColor = true;
            this.cboWORK_GUBUN.Properties.Appearance.Options.UseForeColor = true;
            this.cboWORK_GUBUN.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboWORK_GUBUN.Size = new System.Drawing.Size(96, 20);
            this.cboWORK_GUBUN.StyleController = this.xtraLayoutControlExt1;
            this.cboWORK_GUBUN.TabIndex = 15;
            this.cboWORK_GUBUN.KeyDown += new System.Windows.Forms.KeyEventHandler(this.groupInfo_KeyDown);
            // 
            // btnDeptPopUp
            // 
            this.btnDeptPopUp.Image = ((System.Drawing.Image)(resources.GetObject("btnDeptPopUp.Image")));
            this.btnDeptPopUp.IsExecuteWdworkerLog = true;
            this.btnDeptPopUp.Location = new System.Drawing.Point(1173, 74);
            this.btnDeptPopUp.Name = "btnDeptPopUp";
            this.btnDeptPopUp.Size = new System.Drawing.Size(26, 20);
            this.btnDeptPopUp.StyleController = this.xtraLayoutControlExt1;
            this.btnDeptPopUp.TabIndex = 20;
            this.btnDeptPopUp.Text = " ";
            this.btnDeptPopUp.UseSplasher = false;
            this.btnDeptPopUp.Click += new System.EventHandler(this.btnDeptPopUp_Click);
            // 
            // btnRowDelete
            // 
            this.btnRowDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnRowDelete.Image")));
            this.btnRowDelete.IsExecuteWdworkerLog = true;
            this.btnRowDelete.Location = new System.Drawing.Point(1138, 392);
            this.btnRowDelete.Name = "btnRowDelete";
            this.btnRowDelete.Size = new System.Drawing.Size(71, 22);
            this.btnRowDelete.StyleController = this.xtraLayoutControlExt1;
            this.btnRowDelete.TabIndex = 19;
            this.btnRowDelete.Text = "행삭제";
            this.btnRowDelete.UseSplasher = false;
            this.btnRowDelete.Click += new System.EventHandler(this.btnRowDelete_Click);
            // 
            // btnSave
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSave, new string[] {
            "SAVE"});
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.IsExecuteWdworkerLog = true;
            this.btnSave.Location = new System.Drawing.Point(1213, 392);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(71, 22);
            this.btnSave.StyleController = this.xtraLayoutControlExt1;
            this.btnSave.TabIndex = 18;
            this.btnSave.Text = "저장";
            this.btnSave.UseSplasher = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnAddRow
            // 
            this.btnAddRow.Image = ((System.Drawing.Image)(resources.GetObject("btnAddRow.Image")));
            this.btnAddRow.IsExecuteWdworkerLog = true;
            this.btnAddRow.Location = new System.Drawing.Point(1016, 392);
            this.btnAddRow.Name = "btnAddRow";
            this.btnAddRow.Size = new System.Drawing.Size(118, 22);
            this.btnAddRow.StyleController = this.xtraLayoutControlExt1;
            this.btnAddRow.TabIndex = 17;
            this.btnAddRow.Text = "그룹사용자 추가";
            this.btnAddRow.UseSplasher = false;
            this.btnAddRow.Click += new System.EventHandler(this.btnAddRow_Click);
            // 
            // grdGroupUser
            // 
            this.grdGroupUser.CheckBoxFieldName = "CHK";
            this.grdGroupUser.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdGroupUser.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdGroupUser.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdGroupUser.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdGroupUser.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdGroupUser.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdGroupUser.IsHeaderClickAllCheckedItem = false;
            this.grdGroupUser.Location = new System.Drawing.Point(24, 418);
            this.grdGroupUser.MainView = this.grvGroupUser;
            this.grdGroupUser.MinLength = 0;
            this.grdGroupUser.Name = "grdGroupUser";
            this.grdGroupUser.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit1});
            this.grdGroupUser.Size = new System.Drawing.Size(1260, 335);
            this.grdGroupUser.TabIndex = 12;
            this.grdGroupUser.UseEmbeddedNavigator = true;
            this.grdGroupUser.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvGroupUser});
            // 
            // grvGroupUser
            // 
            this.grvGroupUser.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn3,
            this.gridColumn13,
            this.gridColumn14,
            this.gridColumn15,
            this.gridColumn16,
            this.gridColumn17,
            this.gridColumn18,
            this.gridColumn10});
            this.grvGroupUser.GridControl = this.grdGroupUser;
            this.grvGroupUser.Name = "grvGroupUser";
            this.grvGroupUser.OptionsView.ColumnAutoWidth = false;
            this.grvGroupUser.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.Caption = "선택";
            this.gridColumn3.ColumnEdit = this.repositoryItemCheckEdit1;
            this.gridColumn3.FieldName = "CHK";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 0;
            this.gridColumn3.Width = 35;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Caption = "Check";
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.repositoryItemCheckEdit1.ValueChecked = "Y";
            this.repositoryItemCheckEdit1.ValueUnchecked = "N";
            // 
            // gridColumn13
            // 
            this.gridColumn13.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn13.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn13.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn13.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn13.Caption = "그룹ID";
            this.gridColumn13.FieldName = "GROUP_ID";
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.OptionsColumn.AllowEdit = false;
            this.gridColumn13.OptionsColumn.ReadOnly = true;
            // 
            // gridColumn14
            // 
            this.gridColumn14.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.Caption = "그룹명";
            this.gridColumn14.FieldName = "GROUP_NAME";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.OptionsColumn.AllowEdit = false;
            this.gridColumn14.OptionsColumn.ReadOnly = true;
            this.gridColumn14.Visible = true;
            this.gridColumn14.VisibleIndex = 1;
            this.gridColumn14.Width = 200;
            // 
            // gridColumn15
            // 
            this.gridColumn15.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.Caption = "사용자ID";
            this.gridColumn15.FieldName = "USER_ID";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.OptionsColumn.AllowEdit = false;
            this.gridColumn15.OptionsColumn.ReadOnly = true;
            this.gridColumn15.Visible = true;
            this.gridColumn15.VisibleIndex = 2;
            this.gridColumn15.Width = 90;
            // 
            // gridColumn16
            // 
            this.gridColumn16.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn16.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn16.Caption = "사용자명(한)";
            this.gridColumn16.FieldName = "KOR_NM";
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.OptionsColumn.AllowEdit = false;
            this.gridColumn16.OptionsColumn.ReadOnly = true;
            this.gridColumn16.Visible = true;
            this.gridColumn16.VisibleIndex = 3;
            this.gridColumn16.Width = 100;
            // 
            // gridColumn17
            // 
            this.gridColumn17.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn17.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn17.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn17.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn17.Caption = "직급";
            this.gridColumn17.FieldName = "JOB_TIT_NM";
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.OptionsColumn.AllowEdit = false;
            this.gridColumn17.OptionsColumn.ReadOnly = true;
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 4;
            // 
            // gridColumn18
            // 
            this.gridColumn18.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn18.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn18.Caption = "부서명";
            this.gridColumn18.FieldName = "DEPTNAME";
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.OptionsColumn.AllowEdit = false;
            this.gridColumn18.OptionsColumn.ReadOnly = true;
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 5;
            this.gridColumn18.Width = 150;
            // 
            // btnSearch_Group
            // 
            this.btnSearch_Group.IsExecuteWdworkerLog = true;
            this.btnSearch_Group.Location = new System.Drawing.Point(463, 74);
            this.btnSearch_Group.Name = "btnSearch_Group";
            this.btnSearch_Group.Size = new System.Drawing.Size(71, 22);
            this.btnSearch_Group.StyleController = this.xtraLayoutControlExt1;
            this.btnSearch_Group.TabIndex = 16;
            this.btnSearch_Group.Text = "그룹조회";
            this.btnSearch_Group.UseSplasher = false;
            this.btnSearch_Group.Click += new System.EventHandler(this.btnSearch_Group_Click);
            // 
            // txtGroup_Name
            // 
            this.txtGroup_Name.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtGroup_Name.EditValue = "";
            this.txtGroup_Name.EnterExecuteButton = null;
            this.txtGroup_Name.FocusColor = System.Drawing.Color.Empty;
            this.txtGroup_Name.IsValueTrim = true;
            this.txtGroup_Name.Key = "GROUP_NMAE";
            this.txtGroup_Name.Location = new System.Drawing.Point(100, 100);
            this.txtGroup_Name.MinLength = 0;
            this.txtGroup_Name.Name = "txtGroup_Name";
            this.txtGroup_Name.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtGroup_Name.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtGroup_Name.Properties.Appearance.Options.UseBackColor = true;
            this.txtGroup_Name.Properties.Appearance.Options.UseForeColor = true;
            this.txtGroup_Name.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGroup_Name.Size = new System.Drawing.Size(326, 20);
            this.txtGroup_Name.StyleController = this.xtraLayoutControlExt1;
            this.txtGroup_Name.TabIndex = 15;
            this.txtGroup_Name.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.txtGroup_Name.KeyDown += new System.Windows.Forms.KeyEventHandler(this.groupInfo_KeyDown);
            // 
            // grdGroup
            // 
            this.grdGroup.CheckBoxFieldName = "CHK";
            this.grdGroup.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdGroup.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdGroup.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdGroup.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdGroup.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdGroup.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdGroup.IsHeaderClickAllCheckedItem = false;
            this.grdGroup.Location = new System.Drawing.Point(24, 124);
            this.grdGroup.MainView = this.grvGroup;
            this.grdGroup.MinLength = 0;
            this.grdGroup.Name = "grdGroup";
            this.grdGroup.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpychkYN,
            this.rpsCboWORK_GUBUN,
            this.rpsCboSYSTEM_CODE});
            this.grdGroup.Size = new System.Drawing.Size(510, 211);
            this.grdGroup.TabIndex = 11;
            this.grdGroup.UseEmbeddedNavigator = true;
            this.grdGroup.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvGroup});
            // 
            // grvGroup
            // 
            this.grvGroup.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn12,
            this.gridColumn1,
            this.gridColumn2,
            this.colSYSTEM_CODE,
            this.colDESCR,
            this.colWORK_GUBUN});
            this.grvGroup.GridControl = this.grdGroup;
            this.grvGroup.GroupCount = 2;
            this.grvGroup.Name = "grvGroup";
            this.grvGroup.OptionsView.ColumnAutoWidth = false;
            this.grvGroup.OptionsView.ShowGroupPanel = false;
            this.grvGroup.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colWORK_GUBUN, DevExpress.Data.ColumnSortOrder.Ascending),
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colSYSTEM_CODE, DevExpress.Data.ColumnSortOrder.Ascending)});
            // 
            // gridColumn12
            // 
            this.gridColumn12.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.Caption = "선택";
            this.gridColumn12.ColumnEdit = this.rpychkYN;
            this.gridColumn12.FieldName = "CHK";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 0;
            this.gridColumn12.Width = 62;
            // 
            // rpychkYN
            // 
            this.rpychkYN.AutoHeight = false;
            this.rpychkYN.Caption = "Check";
            this.rpychkYN.Name = "rpychkYN";
            this.rpychkYN.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpychkYN.ValueChecked = "Y";
            this.rpychkYN.ValueUnchecked = "N";
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "그룹ID";
            this.gridColumn1.FieldName = "GROUP_ID";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.OptionsColumn.ReadOnly = true;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "그룹명";
            this.gridColumn2.FieldName = "GROUP_NAME";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.OptionsColumn.ReadOnly = true;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            this.gridColumn2.Width = 151;
            // 
            // colSYSTEM_CODE
            // 
            this.colSYSTEM_CODE.AppearanceHeader.Options.UseTextOptions = true;
            this.colSYSTEM_CODE.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSYSTEM_CODE.Caption = "시스템코드";
            this.colSYSTEM_CODE.ColumnEdit = this.rpsCboSYSTEM_CODE;
            this.colSYSTEM_CODE.FieldName = "SYSTEM_CODE";
            this.colSYSTEM_CODE.Name = "colSYSTEM_CODE";
            this.colSYSTEM_CODE.Visible = true;
            this.colSYSTEM_CODE.VisibleIndex = 2;
            this.colSYSTEM_CODE.Width = 99;
            // 
            // rpsCboSYSTEM_CODE
            // 
            this.rpsCboSYSTEM_CODE.AutoHeight = false;
            this.rpsCboSYSTEM_CODE.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboSYSTEM_CODE.Name = "rpsCboSYSTEM_CODE";
            // 
            // colDESCR
            // 
            this.colDESCR.AppearanceHeader.Options.UseTextOptions = true;
            this.colDESCR.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDESCR.Caption = "적요";
            this.colDESCR.FieldName = "DESCR";
            this.colDESCR.Name = "colDESCR";
            this.colDESCR.Visible = true;
            this.colDESCR.VisibleIndex = 2;
            this.colDESCR.Width = 183;
            // 
            // colWORK_GUBUN
            // 
            this.colWORK_GUBUN.Caption = "업무구분";
            this.colWORK_GUBUN.ColumnEdit = this.rpsCboWORK_GUBUN;
            this.colWORK_GUBUN.FieldName = "WORK_GUBUN";
            this.colWORK_GUBUN.Name = "colWORK_GUBUN";
            this.colWORK_GUBUN.Visible = true;
            this.colWORK_GUBUN.VisibleIndex = 4;
            // 
            // rpsCboWORK_GUBUN
            // 
            this.rpsCboWORK_GUBUN.AutoHeight = false;
            this.rpsCboWORK_GUBUN.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboWORK_GUBUN.Name = "rpsCboWORK_GUBUN";
            // 
            // btnSearch_User
            // 
            this.btnSearch_User.IsExecuteWdworkerLog = true;
            this.btnSearch_User.Location = new System.Drawing.Point(1213, 74);
            this.btnSearch_User.Name = "btnSearch_User";
            this.btnSearch_User.Size = new System.Drawing.Size(71, 22);
            this.btnSearch_User.StyleController = this.xtraLayoutControlExt1;
            this.btnSearch_User.TabIndex = 14;
            this.btnSearch_User.Text = "사용자조회";
            this.btnSearch_User.UseSplasher = false;
            this.btnSearch_User.Click += new System.EventHandler(this.btnSearch_User_Click);
            // 
            // grdUser
            // 
            this.grdUser.CheckBoxFieldName = "CHK";
            this.grdUser.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdUser.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdUser.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdUser.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdUser.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdUser.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdUser.IsHeaderClickAllCheckedItem = true;
            this.grdUser.Location = new System.Drawing.Point(567, 100);
            this.grdUser.MainView = this.grvUser;
            this.grdUser.MinLength = 0;
            this.grdUser.Name = "grdUser";
            this.grdUser.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpychkCheckYN});
            this.grdUser.Size = new System.Drawing.Size(717, 235);
            this.grdUser.TabIndex = 13;
            this.grdUser.UseEmbeddedNavigator = true;
            this.grdUser.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvUser});
            // 
            // grvUser
            // 
            this.grvUser.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn11,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn9,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn8});
            this.grvUser.GridControl = this.grdUser;
            this.grvUser.Name = "grvUser";
            this.grvUser.OptionsView.ColumnAutoWidth = false;
            this.grvUser.OptionsView.ShowGroupPanel = false;
            this.grvUser.DoubleClick += new System.EventHandler(this.grvUser_DoubleClick);
            // 
            // gridColumn11
            // 
            this.gridColumn11.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn11.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn11.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn11.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn11.Caption = "선택";
            this.gridColumn11.ColumnEdit = this.rpychkCheckYN;
            this.gridColumn11.FieldName = "CHK";
            this.gridColumn11.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 0;
            this.gridColumn11.Width = 35;
            // 
            // rpychkCheckYN
            // 
            this.rpychkCheckYN.AutoHeight = false;
            this.rpychkCheckYN.Caption = "Check";
            this.rpychkCheckYN.Name = "rpychkCheckYN";
            this.rpychkCheckYN.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpychkCheckYN.ValueChecked = "Y";
            this.rpychkCheckYN.ValueUnchecked = "N";
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.Caption = "사용자ID";
            this.gridColumn4.FieldName = "USER_ID";
            this.gridColumn4.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.AllowEdit = false;
            this.gridColumn4.OptionsColumn.ReadOnly = true;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 1;
            this.gridColumn4.Width = 90;
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.Caption = "사용자명(한)";
            this.gridColumn5.FieldName = "KOR_NM";
            this.gridColumn5.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.OptionsColumn.ReadOnly = true;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 2;
            this.gridColumn5.Width = 100;
            // 
            // gridColumn9
            // 
            this.gridColumn9.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.Caption = "사용자명(영)";
            this.gridColumn9.FieldName = "ENG_NM";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.AllowEdit = false;
            this.gridColumn9.OptionsColumn.ReadOnly = true;
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 3;
            this.gridColumn9.Width = 120;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.Caption = "직급";
            this.gridColumn6.FieldName = "JOB_TIT_NM";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.OptionsColumn.ReadOnly = true;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 4;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.Caption = "부서명";
            this.gridColumn7.FieldName = "DEPTNAME";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            this.gridColumn7.OptionsColumn.ReadOnly = true;
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 5;
            this.gridColumn7.Width = 150;
            // 
            // txtUser_Id
            // 
            this.txtUser_Id.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtUser_Id.EditValue = "";
            this.txtUser_Id.EnterExecuteButton = null;
            this.txtUser_Id.FocusColor = System.Drawing.Color.Empty;
            this.txtUser_Id.IsValueTrim = true;
            this.txtUser_Id.Key = "USER_ID";
            this.txtUser_Id.Location = new System.Drawing.Point(663, 74);
            this.txtUser_Id.MinLength = 0;
            this.txtUser_Id.Name = "txtUser_Id";
            this.txtUser_Id.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtUser_Id.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtUser_Id.Properties.Appearance.Options.UseBackColor = true;
            this.txtUser_Id.Properties.Appearance.Options.UseForeColor = true;
            this.txtUser_Id.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtUser_Id.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtUser_Id.Size = new System.Drawing.Size(131, 20);
            this.txtUser_Id.StyleController = this.xtraLayoutControlExt1;
            this.txtUser_Id.TabIndex = 7;
            this.txtUser_Id.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.txtUser_Id.KeyDown += new System.Windows.Forms.KeyEventHandler(this.userInfo_KeyDown);
            // 
            // txtUser_Nm
            // 
            this.txtUser_Nm.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtUser_Nm.EditValue = "";
            this.txtUser_Nm.EnterExecuteButton = null;
            this.txtUser_Nm.FocusColor = System.Drawing.Color.Empty;
            this.txtUser_Nm.IsValueTrim = true;
            this.txtUser_Nm.Key = "KOR_NM";
            this.txtUser_Nm.Location = new System.Drawing.Point(889, 74);
            this.txtUser_Nm.MinLength = 0;
            this.txtUser_Nm.Name = "txtUser_Nm";
            this.txtUser_Nm.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtUser_Nm.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtUser_Nm.Properties.Appearance.Options.UseBackColor = true;
            this.txtUser_Nm.Properties.Appearance.Options.UseForeColor = true;
            this.txtUser_Nm.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtUser_Nm.Size = new System.Drawing.Size(96, 20);
            this.txtUser_Nm.StyleController = this.xtraLayoutControlExt1;
            this.txtUser_Nm.TabIndex = 6;
            this.txtUser_Nm.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.txtUser_Nm.KeyDown += new System.Windows.Forms.KeyEventHandler(this.userInfo_KeyDown);
            // 
            // txtDeptName
            // 
            this.txtDeptName.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtDeptName.EditValue = "";
            this.txtDeptName.EnterExecuteButton = null;
            this.txtDeptName.FocusColor = System.Drawing.Color.Empty;
            this.txtDeptName.IsValueTrim = true;
            this.txtDeptName.Key = "DEPTNAME";
            this.txtDeptName.Location = new System.Drawing.Point(1080, 74);
            this.txtDeptName.MinLength = 0;
            this.txtDeptName.Name = "txtDeptName";
            this.txtDeptName.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtDeptName.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtDeptName.Properties.Appearance.Options.UseBackColor = true;
            this.txtDeptName.Properties.Appearance.Options.UseForeColor = true;
            this.txtDeptName.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtDeptName.Size = new System.Drawing.Size(89, 20);
            this.txtDeptName.StyleController = this.xtraLayoutControlExt1;
            this.txtDeptName.TabIndex = 5;
            this.txtDeptName.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.txtDeptName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.userInfo_KeyDown);
            // 
            // btnClose
            // 
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.IsExecuteWdworkerLog = true;
            this.btnClose.Location = new System.Drawing.Point(1225, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(71, 22);
            this.btnClose.StyleController = this.xtraLayoutControlExt1;
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "닫기";
            this.btnClose.UseSplasher = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "Root";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.emptySpaceItem2,
            this.splitterItem1,
            this.splitterItem2,
            this.layoutControlGroup2,
            this.layoutControlGroup3,
            this.layoutControlGroup4});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1308, 777);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.btnClose;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(1213, 0);
            this.layoutControlItem1.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(1213, 26);
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // splitterItem1
            // 
            this.splitterItem1.AllowHotTrack = true;
            this.splitterItem1.CustomizationFormText = "splitterItem1";
            this.splitterItem1.Location = new System.Drawing.Point(538, 26);
            this.splitterItem1.Name = "splitterItem1";
            this.splitterItem1.Size = new System.Drawing.Size(5, 313);
            // 
            // splitterItem2
            // 
            this.splitterItem2.AllowHotTrack = true;
            this.splitterItem2.CustomizationFormText = "splitterItem2";
            this.splitterItem2.Location = new System.Drawing.Point(0, 339);
            this.splitterItem2.Name = "splitterItem2";
            this.splitterItem2.Size = new System.Drawing.Size(1288, 5);
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.CaptionImage = ((System.Drawing.Image)(resources.GetObject("layoutControlGroup2.CaptionImage")));
            this.layoutControlGroup2.CustomizationFormText = "그룹정보";
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem9,
            this.emptySpaceItem3,
            this.layoutControlItem7,
            this.layoutControlItem15,
            this.layoutControlItem8,
            this.layoutControlItem16,
            this.emptySpaceItem5});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 26);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(538, 313);
            this.layoutControlGroup2.Text = "그룹정보";
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.btnSearch_Group;
            this.layoutControlItem9.CustomizationFormText = "layoutControlItem9";
            this.layoutControlItem9.Location = new System.Drawing.Point(439, 0);
            this.layoutControlItem9.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem9.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem9.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem9.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem9.TextVisible = false;
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.CustomizationFormText = "emptySpaceItem3";
            this.emptySpaceItem3.Location = new System.Drawing.Point(406, 0);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(33, 26);
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.grdGroup;
            this.layoutControlItem7.CustomizationFormText = "layoutControlItem7";
            this.layoutControlItem7.Location = new System.Drawing.Point(0, 50);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(514, 215);
            this.layoutControlItem7.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem7.TextVisible = false;
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.Control = this.cboWORK_GUBUN;
            this.layoutControlItem15.CustomizationFormText = "업무구분";
            this.layoutControlItem15.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem15.Image")));
            this.layoutControlItem15.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.Size = new System.Drawing.Size(176, 26);
            this.layoutControlItem15.Text = "업무구분";
            this.layoutControlItem15.TextSize = new System.Drawing.Size(73, 16);
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.txtGroup_Name;
            this.layoutControlItem8.CustomizationFormText = "그룹명";
            this.layoutControlItem8.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem8.Image")));
            this.layoutControlItem8.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(421, 24);
            this.layoutControlItem8.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 15, 0, 0);
            this.layoutControlItem8.Text = "그룹명";
            this.layoutControlItem8.TextSize = new System.Drawing.Size(73, 16);
            // 
            // layoutControlItem16
            // 
            this.layoutControlItem16.Control = this.cboSYSTEM_CODE;
            this.layoutControlItem16.CustomizationFormText = "시스템코드";
            this.layoutControlItem16.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem16.Image")));
            this.layoutControlItem16.Location = new System.Drawing.Point(176, 0);
            this.layoutControlItem16.Name = "layoutControlItem16";
            this.layoutControlItem16.Size = new System.Drawing.Size(230, 26);
            this.layoutControlItem16.Text = "시스템코드";
            this.layoutControlItem16.TextSize = new System.Drawing.Size(73, 16);
            // 
            // emptySpaceItem5
            // 
            this.emptySpaceItem5.AllowHotTrack = false;
            this.emptySpaceItem5.CustomizationFormText = "emptySpaceItem5";
            this.emptySpaceItem5.Location = new System.Drawing.Point(421, 26);
            this.emptySpaceItem5.Name = "emptySpaceItem5";
            this.emptySpaceItem5.Size = new System.Drawing.Size(93, 24);
            this.emptySpaceItem5.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup3.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup3.CaptionImage = ((System.Drawing.Image)(resources.GetObject("layoutControlGroup3.CaptionImage")));
            this.layoutControlGroup3.CustomizationFormText = "사용자정보";
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem6,
            this.layoutControlItem5,
            this.layoutControlItem4,
            this.layoutControlItem3,
            this.layoutControlItem2,
            this.emptySpaceItem1,
            this.layoutControlItem14});
            this.layoutControlGroup3.Location = new System.Drawing.Point(543, 26);
            this.layoutControlGroup3.Name = "layoutControlGroup3";
            this.layoutControlGroup3.Size = new System.Drawing.Size(745, 313);
            this.layoutControlGroup3.Text = "사용자정보";
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.btnSearch_User;
            this.layoutControlItem6.CustomizationFormText = "layoutControlItem6";
            this.layoutControlItem6.Location = new System.Drawing.Point(646, 0);
            this.layoutControlItem6.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem6.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem6.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextVisible = false;
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.grdUser;
            this.layoutControlItem5.CustomizationFormText = "layoutControlItem5";
            this.layoutControlItem5.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(721, 239);
            this.layoutControlItem5.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem5.TextVisible = false;
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem4.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem4.Control = this.txtUser_Id;
            this.layoutControlItem4.CustomizationFormText = "사번";
            this.layoutControlItem4.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem4.Image")));
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(246, 26);
            this.layoutControlItem4.Spacing = new DevExpress.XtraLayout.Utils.Padding(20, 15, 0, 0);
            this.layoutControlItem4.Text = "사용자ID";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(73, 16);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem3.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem3.Control = this.txtUser_Nm;
            this.layoutControlItem3.CustomizationFormText = "성명";
            this.layoutControlItem3.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem3.Image")));
            this.layoutControlItem3.Location = new System.Drawing.Point(246, 0);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(191, 26);
            this.layoutControlItem3.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 15, 0, 0);
            this.layoutControlItem3.Text = "사용자명";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(73, 16);
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem2.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem2.Control = this.txtDeptName;
            this.layoutControlItem2.CustomizationFormText = "부서명";
            this.layoutControlItem2.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem2.Image")));
            this.layoutControlItem2.Location = new System.Drawing.Point(437, 0);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(169, 26);
            this.layoutControlItem2.Text = "부서명";
            this.layoutControlItem2.TextSize = new System.Drawing.Size(73, 16);
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(636, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(10, 26);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.btnDeptPopUp;
            this.layoutControlItem14.CustomizationFormText = "layoutControlItem14";
            this.layoutControlItem14.Location = new System.Drawing.Point(606, 0);
            this.layoutControlItem14.MaxSize = new System.Drawing.Size(30, 24);
            this.layoutControlItem14.MinSize = new System.Drawing.Size(30, 24);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Size = new System.Drawing.Size(30, 26);
            this.layoutControlItem14.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem14.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem14.TextVisible = false;
            // 
            // layoutControlGroup4
            // 
            this.layoutControlGroup4.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup4.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup4.CaptionImage = ((System.Drawing.Image)(resources.GetObject("layoutControlGroup4.CaptionImage")));
            this.layoutControlGroup4.CustomizationFormText = "그룹사용자";
            this.layoutControlGroup4.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem11,
            this.layoutControlItem10,
            this.emptySpaceItem4,
            this.layoutControlItem12,
            this.layoutControlItem13});
            this.layoutControlGroup4.Location = new System.Drawing.Point(0, 344);
            this.layoutControlGroup4.Name = "layoutControlGroup4";
            this.layoutControlGroup4.Size = new System.Drawing.Size(1288, 413);
            this.layoutControlGroup4.Text = "그룹사용자";
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.btnAddRow;
            this.layoutControlItem11.CustomizationFormText = "layoutControlItem11";
            this.layoutControlItem11.Location = new System.Drawing.Point(992, 0);
            this.layoutControlItem11.MaxSize = new System.Drawing.Size(122, 26);
            this.layoutControlItem11.MinSize = new System.Drawing.Size(122, 26);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(122, 26);
            this.layoutControlItem11.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem11.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem11.TextVisible = false;
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.grdGroupUser;
            this.layoutControlItem10.CustomizationFormText = "layoutControlItem10";
            this.layoutControlItem10.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(1264, 339);
            this.layoutControlItem10.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem10.TextVisible = false;
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.CustomizationFormText = "emptySpaceItem4";
            this.emptySpaceItem4.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(992, 26);
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.btnSave;
            this.layoutControlItem12.CustomizationFormText = "layoutControlItem12";
            this.layoutControlItem12.Location = new System.Drawing.Point(1189, 0);
            this.layoutControlItem12.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem12.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem12.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem12.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem12.TextVisible = false;
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.btnRowDelete;
            this.layoutControlItem13.CustomizationFormText = "layoutControlItem13";
            this.layoutControlItem13.Location = new System.Drawing.Point(1114, 0);
            this.layoutControlItem13.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem13.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem13.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem13.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem13.TextVisible = false;
            // 
            // stdValidationManager1
            // 
            this.stdValidationManager1.IsNullorWhiteSpace = true;
            this.stdValidationManager1.IsShowErrorMessage = true;
            // 
            // gridColumn8
            // 
            this.gridColumn8.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.Caption = "과";
            this.gridColumn8.FieldName = "ASGN_NM";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsColumn.AllowEdit = false;
            this.gridColumn8.OptionsColumn.ReadOnly = true;
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 6;
            this.gridColumn8.Width = 150;
            // 
            // gridColumn10
            // 
            this.gridColumn10.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn10.Caption = "과";
            this.gridColumn10.FieldName = "ASGN_NM";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.OptionsColumn.AllowEdit = false;
            this.gridColumn10.OptionsColumn.ReadOnly = true;
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 6;
            this.gridColumn10.Width = 150;
            // 
            // SCSYS002P1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1308, 777);
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS002P1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "그룹 사용자 정보 저장";
            this.Load += new System.EventHandler(this.SCSYS002P1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cboSYSTEM_CODE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboWORK_GUBUN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdGroupUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvGroupUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGroup_Name.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkYN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboSYSTEM_CODE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboWORK_GUBUN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkCheckYN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUser_Id.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUser_Nm.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDeptName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private Client.Controls.DXperience.XtraButtonExt btnClose;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private Controls.StdValidationManager stdValidationManager1;
        private Client.Controls.DXperience.XtraTextEditExt txtUser_Id;
        private Client.Controls.DXperience.XtraTextEditExt txtUser_Nm;
        private Client.Controls.DXperience.XtraTextEditExt txtDeptName;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private Client.Controls.DXperience.XtraButtonExt btnSearch_User;
        private Client.Controls.DXperience.XtraGridControlExt grdUser;
        private DevExpress.XtraGrid.Views.Grid.GridView grvUser;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpychkCheckYN;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private Client.Controls.DXperience.XtraButtonExt btnSearch_Group;
        private Client.Controls.DXperience.XtraTextEditExt txtGroup_Name;
        private Client.Controls.DXperience.XtraGridControlExt grdGroup;
        private DevExpress.XtraGrid.Views.Grid.GridView grvGroup;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpychkYN;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.SplitterItem splitterItem1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private Client.Controls.DXperience.XtraButtonExt btnRowDelete;
        private Client.Controls.DXperience.XtraButtonExt btnSave;
        private Client.Controls.DXperience.XtraButtonExt btnAddRow;
        private Client.Controls.DXperience.XtraGridControlExt grdGroupUser;
        private DevExpress.XtraGrid.Views.Grid.GridView grvGroupUser;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraLayout.SplitterItem splitterItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup4;
        private Client.Controls.DXperience.XtraButtonExt btnDeptPopUp;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private Windows.Forms.StdSecurityManager stdSecurityManager1;
        private DevExpress.XtraGrid.Columns.GridColumn colSYSTEM_CODE;
        private DevExpress.XtraGrid.Columns.GridColumn colDESCR;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboSYSTEM_CODE;
        private DevExpress.XtraGrid.Columns.GridColumn colWORK_GUBUN;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboWORK_GUBUN;
        private Client.Controls.DXperience.XtraImageComboBoxEditExt cboWORK_GUBUN;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private Client.Controls.DXperience.XtraImageComboBoxEditExt cboSYSTEM_CODE;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem16;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
    }
}