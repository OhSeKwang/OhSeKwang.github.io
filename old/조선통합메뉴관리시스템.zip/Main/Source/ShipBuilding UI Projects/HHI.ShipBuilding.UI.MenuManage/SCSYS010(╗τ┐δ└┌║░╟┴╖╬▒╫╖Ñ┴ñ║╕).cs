﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;

using DevExpress.XtraGrid.Views.Grid;
using HHI.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS010 : StdUserControlBase
    {
        public SCSYS010()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }

        public override void InitControl(object args)
        {
            base.InitControl(args);

            if (args != null)
            {
                string sUserId = args.ToString();

                txtUser_Id.Text = sUserId;
                btnSearch.PerformClick();
            }
        }

        #region 화면 Load - SCSYS010_Load
        /// <summary>
        /// 화면 Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SCSYS010_Load(object sender, EventArgs e)
        {
            
        }
        #endregion 화면 Load - SCSYS010_Load

        #region SCSYS010_Shown
        private void SCSYS010_Shown(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                initPage();

                stdSecurityManager1.ApplySecurity(this.SecurityContext);
                stdButtonExecuteManager1.RegisterButtonExecEvent();

                this.grvGroup.DoubleClick -= grvGroup_DoubleClick;

            }
        }
        #endregion

        #region 화면 초기화 - initPage
        /// <summary>
        /// 화면 초기화
        /// </summary>
        private void initPage()
        { 

        }
        #endregion 화면 초기화 - initPage

        #region 조회 - btnSearch_Click
        /// <summary>
        /// 조회
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string strSearchCheck = txtUser_Id.Text + txtUser_Nm.Text + txtDeptName.Text;
            if (string.IsNullOrWhiteSpace(strSearchCheck))
            {
                MsgBox.Show("조회 조건중 하나 이상을 입력 하세요!", "경고");
                txtUser_Id.Focus();
                return;
            }

            DataResultSet resultSet = GetUserInfo(txtUser_Id.Text, txtUser_Nm.Text, txtDeptName.Text);

            if (resultSet.IsSuccess)
            {
                grdUser.DataSource = resultSet.QuerySet.Tables[0];

                //grvUser_DoubleClick(null, null);
                grvUser_FocusedRowChanged(null, null);
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }

           
        }
        #endregion 조회 - btnSearch_Click

        #region 사용자 조회 - GetUserInfo
        /// <summary>
        /// 그룹정보 조회
        /// </summary>
        /// <param name="strGroup_Nm"></param>
        /// <param name="strDescr"></param>
        /// <returns></returns>
        private DataResultSet GetUserInfo(string strUser_Id, string strUser_Nm, string strDeptName)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("USER_ID", strUser_Id);
            parameter.DataList.Add("USER_NM", strUser_Nm);
            parameter.DataList.Add("DEPTNAME", strDeptName);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS010.SEARCH_01", parameter);
        }
        #endregion 사용자 조회 - GetUserInfo

        #region 사용자 정보 그리드 더블 클릭 - grvUser_DoubleClick
        /// <summary>
        /// 사용자 정보 그리드 더블 클릭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void grvUser_DoubleClick(object sender, EventArgs e)
        {
            
        }
        #endregion 사용자 정보 그리드 더블 클릭 - grvUser_DoubleClick

        #region 그룹정보 조회 - GetUserGroupInfo
        /// <summary>
        /// 그룹정보 조회
        /// </summary>
        /// <param name="strUser_Id"></param>
        /// <returns></returns>
        private DataResultSet GetUserGroupInfo(string strUser_Id)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("USER_ID", strUser_Id);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS010.SEARCH_02", parameter);
        }
        #endregion 그룹정보 조회 - GetUserGroupInfo

        #region 그룹정보 그리드 더블 클릭 - grvGroup_DoubleClick
        /// <summary>
        /// 그룹정보 그리드 더블 클릭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void grvGroup_DoubleClick(object sender, EventArgs e)
        {
            DataRow row = grvGroup.GetFocusedDataRow();
            if (row == null)
                return;

            DataResultSet resultSet = GetProgramInfo(row["USER_ID"].ToString(), row["GROUP_ID"].ToString());

            if (resultSet.IsSuccess)
            {
                grdProgram.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 그룹정보 그리드 더블 클릭 - grvGroup_DoubleClick

        #region 프로그램 정보 조회 - GetProgramInfo
        /// <summary>
        /// 프로그램 정보 조회
        /// </summary>
        /// <param name="strUser_Id"></param>
        /// <param name="strGroup_Id"></param>
        /// <returns></returns>
        private DataResultSet GetProgramInfo(string strUser_Id, string strGroup_Id)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("USER_ID", strUser_Id);
            parameter.DataList.Add("GROUP_ID", strGroup_Id);
            
            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS010.SEARCH_03", parameter);
        }
        #endregion 프로그램 정보 조회 - GetProgramInfo

        #region HHI 조직도 - btnDeptPopUp_Click
        /// <summary>
        /// HHI 조직도
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDeptPopUp_Click(object sender, EventArgs e)
        {
            SCSYS002P2 scsys002p2 = new SCSYS002P2();

            if (scsys002p2.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtDeptName.EditValue = scsys002p2.hdnDEPT_NM;
            }
        }
        #endregion HHI 조직도 - btnDeptPopUp_Click

        private void grvUser_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            Splasher.Show();
            // 그리드 초기화
            grdGroup.InitDataRows();
            grdProgram.InitDataRows();

            DataRow row = grvUser.GetFocusedDataRow();
            if (row == null)
                return;

            DataResultSet resultSet = GetUserGroupInfo(row["USER_ID"].ToString());

            if (resultSet.IsSuccess)
            {
                grdGroup.DataSource = resultSet.QuerySet.Tables[0];

                grvGroup_DoubleClick(null, null);

                Splasher.Close();
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }

        private void btnSelectMenu_Click(object sender, EventArgs e)
        {
            DataRow row = grvUser.GetFocusedDataRow();
            if (row == null)
                return;
 
            SCSYS010P1 popup = new SCSYS010P1();
            StdPopupHost PopupHost = new StdPopupHost(popup, "사용자별 메뉴목록");
            popup.SetSecurityContext(this.SecurityContext);
            popup.SetUserInfoContext(this.UserInfo);
            popup.sUSER_ID = row["USER_ID"].ToString();

            PopupHost.ShowDialog();

            
            
        }

        private void btnExcel_Click(object sender, EventArgs e)
        {
            string sTYPE = cboTYPE.EditValue.ToString();
            string sPath = Path.GetTempPath() + @"ShipBuilding\";
            if (!Directory.Exists(sPath))
            {
                Directory.CreateDirectory(sPath);
            }

            string strFilePathFull = sPath + string.Format("{0}.xlsx", DateTime.Now.ToString("yyyyMMddHHmmss"));
            DevExpress.XtraGrid.GridControl Grid = null;
            GridView view = null;

            grvProgram.OptionsPrint.AutoWidth = false;


            if (sTYPE.Equals("A"))
            { Grid = grvUser.GridControl; view = grvUser; }
            else if (sTYPE.Equals("B"))
            { Grid = grvGroup.GridControl; view = grvGroup; }
            else
            { Grid = grvProgram.GridControl; view = grvProgram; }

            view.OptionsPrint.AutoWidth = false;
            view.ExportToXlsx(strFilePathFull);


            OpenFile(strFilePathFull);
        }

        #region 파일 실행 - OpenFile
        /// <summary>
        /// 파일 실행
        /// </summary>
        /// <param name="strFileFullName"></param>
        public static void OpenFile(string strFileFullName)
        {
            try
            {
                Process process = new Process();
                process.StartInfo.FileName = strFileFullName;
                process.StartInfo.Verb = "Open";
                process.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
                process.Start();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion 파일 실행 - OpenFile

       
    }
}
