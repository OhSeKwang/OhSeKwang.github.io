﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Views.Grid;
using System.IO;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS007 : StdUserControlBase//UserControl
    {
        #region 생성지 및 변수 선언
        public SCSYS007()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }
        #endregion

        #region 화면 Load
        private void SCSYS007_Load(object sender, EventArgs e)
        {
            
        }
        #endregion

        #region 화면 Shown
        private void SCSYS007_Shown(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                initPage();

                stdSecurityManager1.ApplySecurity(this.SecurityContext);
                stdButtonExecuteManager1.RegisterButtonExecEvent();

                ClientControlHelper.LookUpBind(rpsLookUpEdit1, ClientControlHelper.GetCodeInfo("SY006"), "CDNM", "CDCODE");

                //ClientControlHelper.LookUpBind(luSYSTEM_CODE, GetSystem_code(), "SYSTEM_NAME", "SYSTEM_CODE", true, "전체");
                DataTable dt = GetSystem_code();
                var allRow = dt.NewRow();
                allRow["SYSTEM_CODE"] = "";
                allRow["SYSTEM_NAME"] = "전체";
                dt.Rows.InsertAt(allRow, 0);
                dt.AcceptChanges();
                luSYSTEM_CODE.Properties.DataSource = dt;
                luSYSTEM_CODE.Properties.DisplayMember = "SYSTEM_NAME";
                luSYSTEM_CODE.Properties.ValueMember = "SYSTEM_CODE";
                luSYSTEM_CODE.Properties.DropDownRows = 15;
                luSYSTEM_CODE.ItemIndex = 0;
                //ClientControlHelper.LookUpBind(rpsLookUpSYSTEM_CODE, GetSystem_code(), "SYSTEM_NAME", "SYSTEM_CODE", false, "");

                ClientControlHelper.ImageComboBind(rpsCboSYSTEM_CODE, "SYSTEM_NAME", "SYSTEM_CODE", "{value}-{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, GetSystem_code());

                txtUserID.Text = UserInfo.UserID;
            }
        }
        #endregion

        #region 버튼이벤트

        #region 조회
        private void btnSearch_Click(object sender, EventArgs e)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("PROGRAM_ID", txtPROGRAM_ID.Text);
            parameter.DataList.Add("SYSTEM_CODE", luSYSTEM_CODE.EditValue != null ? luSYSTEM_CODE.EditValue.ToString() : string.Empty);

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS007.SEARCH_01", parameter);

            if (resultSet.IsSuccess)
            {
                grdMaster.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(this, resultSet.ExceptionMessage, "실패", MessageBoxButtons.OK, ImageKinds.Error);
            }

        }
        #endregion

        #region 신규
        private void btnNew_Click(object sender, EventArgs e)
        {
            // 현재 포커스로 된 row 복사.
            DataRow drFocus = grvMaster.GetFocusedDataRow();

            if (drFocus == null)
            {
                grvMaster.AddNewRow();
                
                grvMaster.SetFocusedRowCellValue("CHK", "Y");
                grvMaster.SetFocusedRowCellValue("IS_SAVE", "N");
                grvMaster.SetFocusedRowCellValue("APPLICATION_TYPE", "0");

                grvMaster.UpdateCurrentRow();
                grvMaster.Focus();
            }
            else
            {

                grvMaster.AddNewRow();
                DataRow dr = grvMaster.GetFocusedDataRow();

                grvMaster.SetFocusedRowCellValue("CHK", "Y");
                grvMaster.SetFocusedRowCellValue("SYSTEM_CODE", drFocus["SYSTEM_CODE"]);
                grvMaster.SetFocusedRowCellValue("URL", drFocus["URL"]);
                grvMaster.SetFocusedRowCellValue("CLASS_NAME", drFocus["CLASS_NAME"]);
                grvMaster.SetFocusedRowCellValue("PROGRAM_NAME", drFocus["PROGRAM_NAME"]);
                grvMaster.SetFocusedRowCellValue("APPLICATION_TYPE", drFocus["APPLICATION_TYPE"]);
                grvMaster.SetFocusedRowCellValue("PARAMETER", drFocus["PARAMETER"]);
                grvMaster.SetFocusedRowCellValue("NEW_AUTH_CHK", drFocus["NEW_AUTH_CHK"]);
                grvMaster.SetFocusedRowCellValue("FTP_SERVER_PATH", drFocus["FTP_SERVER_PATH"]);
                grvMaster.SetFocusedRowCellValue("USER_ID", drFocus["USER_ID"]);
                grvMaster.SetFocusedRowCellValue("PASSWORD", drFocus["PASSWORD"]);
                grvMaster.SetFocusedRowCellValue("FTP_IP", drFocus["FTP_IP"]);
                grvMaster.SetFocusedRowCellValue("IS_SAVE", "N");

                grvMaster.UpdateCurrentRow();
                grvMaster.Focus();
            }                       
        }
        #endregion

        #region 저장
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show(this, "저장 하시겠습니까?", "질의", MessageBoxButtons.OKCancel, ImageKinds.Question) == DialogResult.Cancel)
            {
                return;
            }
            if (grvMaster.RowCount == 0)
            { MsgBox.Show(this, "데이터를 조회하세요....", "알림", MessageBoxButtons.OK, ImageKinds.Information); return; }

            if ((grdMaster.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            { MsgBox.Show(this, "저장할 데이터를 선택하세요....", "알림", MessageBoxButtons.OK, ImageKinds.Information); return; }

            StringBuilder sb = new StringBuilder();
            foreach(DataRow dr in  (grdMaster.DataSource as DataTable).Select("CHK='Y'"))
            {
                if (!string.IsNullOrEmpty(dr["LOCAL_FILE_PATH"].ToString()))
                {
                    string val = UploadManual(dr);
                    if (string.IsNullOrWhiteSpace(val))
                    {
                        continue;
                    }
                    sb.AppendLine();
                    sb.Append(val);
                }
            }

            if (sb.Length > 0)
            {
                if (MsgBox.Show(this, "매뉴얼 업로드에 실패한 파일이 있습니다 무시하고 저장하시겠습니까?" + sb.ToString(), "알림", 
                    MessageBoxButtons.YesNo, ImageKinds.Question) == DialogResult.No)
                {
                    return;
                }
            }

            DataTable dtMaster = (grdMaster.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();

            string[] paramnames = new string[] { "PROGRAM_ID", "SYSTEM_CODE", "URL", "CLASS_NAME", "PROGRAM_NAME", "APPLICATION_TYPE", "PARAMETER", "NEW_AUTH_CHK", "LOGIN_USERID", "PIC1", "PIC2", "MANUAL_FILE" };

            DataTable controlParamInfo = new DataTable("controlParamInfo");
            for(int cnt = 0; cnt < paramnames.Length; cnt++)
            {
                controlParamInfo.Columns.Add(paramnames[cnt]);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in controlParamInfo.Columns)
            {
                //if (!dtMaster.Columns.Contains(col.ColumnName))
                //    throw new Exception(string.Format("필드명{0}을 찾을 수 없습니다."));
                                
                if (col.DataType.Equals(typeof(int)))
                {
                    int[] col1 = new int[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = 0;
                        }
                        else
                        {
                            col1[i] = int.Parse(string.IsNullOrWhiteSpace(dtMaster.Rows[i][col.ColumnName].ToString()) ? "0" : dtMaster.Rows[i][col.ColumnName].ToString());
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }
                else
                {
                    string[] col1 = new string[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (col.ColumnName.Equals("LOGIN_USERID"))
                        {
                            col1[i] = UserInfo == null ? "ADMIN" : UserInfo.UserID; // eve
                        }
                        else if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = string.Empty;
                        }
                        else
                        {
                            col1[i] = dtMaster.Rows[i][col.ColumnName].ToString();
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }

                #region 주석처리
                //    if (col.DataType.Equals(typeof(string)))
          //        dataPack.DataList.Add(col.ColumnName, ConvertArray<string>(controlParamInfo, col.ColumnName, string.Empty));
            //    else if (col.DataType.Equals(typeof(int)))
            //        dataPack.DataList.Add(col.ColumnName, ConvertArray<int>(controlParamInfo, col.ColumnName, 0));
            //    else if (col.DataType.Equals(typeof(double)))
            //        dataPack.DataList.Add(col.ColumnName, ConvertArray<double>(controlParamInfo, col.ColumnName, 0));
            //    else if (col.DataType.Equals(typeof(decimal)))
            //        dataPack.DataList.Add(col.ColumnName, ConvertArray<decimal>(controlParamInfo, col.ColumnName, 0));
            //    else if (col.DataType.Equals(typeof(short)))
            //        dataPack.DataList.Add(col.ColumnName, ConvertArray<short>(controlParamInfo, col.ColumnName, 0));
            //    else if (col.DataType.Equals(typeof(long)))
            //        dataPack.DataList.Add(col.ColumnName, ConvertArray<long>(controlParamInfo, col.ColumnName, 0));
            //    else if (col.DataType.Equals(typeof(DateTime)))
            //        dataPack.DataList.Add(col.ColumnName, ConvertArray<string>(controlParamInfo, col.ColumnName, string.Empty));
            //    else if (col.DataType.Equals(typeof(byte[])))
            //        dataPack.DataList.Add(col.ColumnName, ConvertArray<byte[]>(controlParamInfo, col.ColumnName, new byte[0]));
            //    else
                //        dataPack.DataList.Add(col.ColumnName, ConvertArray<string>(controlParamInfo, col.ColumnName, string.Empty));
                #endregion
            }
            
            parameter.ArrayItemCount = dtMaster.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            if(ValidationRequired(true, false))
            {
                DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS007.SAVE_01", parameter);

                if (resultSet.IsSuccess)
                {
                    MsgBox.Show(this, "저장되었습니다.", "알림", MessageBoxButtons.OK, ImageKinds.Information);
                    
                    btnSearch.PerformClick();
                }
                else
                {
                    MsgBox.Show(this, resultSet.ExceptionMessage, "실패", MessageBoxButtons.OK, ImageKinds.Error);
                }
            }

            
        }
        #endregion

        #region 삭제
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show(this, "삭제 하시겠습니까?", "경고", MessageBoxButtons.OKCancel, ImageKinds.Question) == DialogResult.Cancel)
            {
                return;
            }

            if (grvMaster.RowCount == 0)
            { MsgBox.Show(this, "데이터를 조회하세요....", "알림", MessageBoxButtons.OK, ImageKinds.Information); return; }

            if ((grdMaster.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            { MsgBox.Show(this, "삭제할 데이터를 선택하세요....", "알림", MessageBoxButtons.OK, ImageKinds.Information); return; }

            DataTable dtMaster = (grdMaster.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();

            string[] paramnames = new string[] { "PROGRAM_ID"};

            DataTable controlParamInfo = new DataTable("controlParamInfo");
            for (int cnt = 0; cnt < paramnames.Length; cnt++)
            {
                controlParamInfo.Columns.Add(paramnames[cnt], (grvMaster.GridControl.DataSource as DataTable).Columns[paramnames[cnt]].DataType);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in controlParamInfo.Columns)
            {


                if (!dtMaster.Columns.Contains(col.ColumnName))
                    throw new Exception(string.Format("필드명{0}을 찾을 수 없습니다."));

                if (col.DataType.Equals(typeof(int)))
                {
                    int[] col1 = new int[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = 0;
                        }
                        else
                        {
                            col1[i] = int.Parse(string.IsNullOrWhiteSpace(dtMaster.Rows[i][col.ColumnName].ToString()) ? "0" : dtMaster.Rows[i][col.ColumnName].ToString());
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }
                else
                {
                    string[] col1 = new string[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = string.Empty;
                        }
                        else
                        {
                            col1[i] = dtMaster.Rows[i][col.ColumnName].ToString();
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }

            }
            
            parameter.ArrayItemCount = dtMaster.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS007.DELETE_01", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show(this, "삭제되었습니다.", "알림", MessageBoxButtons.OK, ImageKinds.Information);

                btnSearch.PerformClick();
            }
            else
            {
                MsgBox.Show(this, resultSet.ExceptionMessage, "실패", MessageBoxButtons.OK, ImageKinds.Error);
            }
        }
        #endregion

        /// <summary>
        /// 적용(전산) 버튼
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPIC1_Click(object sender, EventArgs e)
        {
            ApplyUserID(btnPIC1.Tag.ToString());
        }

        /// <summary>
        /// 적용(업무) 버튼
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPIC2_Click(object sender, EventArgs e)
        {
            ApplyUserID(btnPIC2.Tag.ToString());
        }

        #endregion

        #region 그리드이벤트
        private void grvMaster_ShowingEditor(object sender, CancelEventArgs e)
        {
            DataRow row = grvMaster.GetFocusedDataRow();
            if (row != null)
            {
                string strFieldName = grvMaster.FocusedColumn.FieldName;
                if (strFieldName.Equals("PROGRAM_ID"))
                {
                    if (row["IS_SAVE"].ToString().Equals("Y"))
                        e.Cancel = true;
                    else
                        e.Cancel = false;
                }
            }
        }

        private void grvMaster_CellValueChanging(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            GridView gridView = (sender as GridView);
            if (gridView != null)
            {

                DataRow row = gridView.GetDataRow(e.RowHandle);
                if (row != null)
                {
                    if (gridView.Columns["CHK"] != null && gridView.Columns["CHK"].ColumnEdit != null && gridView.Columns["CHK"].ColumnEdit is RepositoryItemCheckEdit)
                    {
                        RepositoryItemCheckEdit chkEdit = (gridView.Columns["CHK"].ColumnEdit as RepositoryItemCheckEdit);
                        row["CHK"] = chkEdit.ValueChecked;
                    }
                }
            }
        }

        private void grvMaster_DoubleClick(object sender, EventArgs e)
        {
            DataRow row = grvMaster.GetFocusedDataRow();
            if (row != null)
            {
                string fieldName = grvMaster.FocusedColumn.FieldName;
                
                if (fieldName.Equals("PROGRAM_ID"))
                {
                    if (row["IS_SAVE"].ToString().Equals("Y"))
                    {
                        if (!row["HID_SYSTEM_CODE"].ToString().Equals(row["SYSTEM_CODE"].ToString()))
                        {
                            MsgBox.Show(this, "시스템코드를 저장한후 FTP 업로드하세요.", "알림", MessageBoxButtons.OK, ImageKinds.Information); return;
                        }
                        
                        if (string.IsNullOrWhiteSpace(row["FTP_IP"].ToString()))
                        {
                            MsgBox.Show("FTP 접속 가능한 시스템코드를 선택하세요.", "알림", MessageBoxButtons.OK, ImageKinds.Information); return;
                        }

                        SCSYS007P1 SCSYS007P1 = new SCSYS007P1();

                        SCSYS007P1.sPROGRAM_ID = row["PROGRAM_ID"].ToString();
                        SCSYS007P1.sPROGRAM_NAME = row["PROGRAM_NAME"].ToString();
                        SCSYS007P1.sLOGIN_USERID = UserInfo == null ? "ADMIN" : UserInfo.UserID;//eve
                        SCSYS007P1.sFTP_SERVER_PATH = row["FTP_SERVER_PATH"].ToString();
                        SCSYS007P1.sFTP_IP = row["FTP_IP"].ToString();
                        SCSYS007P1.sFTP_USER_ID = row["USER_ID"].ToString();
                        SCSYS007P1.sFTP_PASSWORD = row["PASSWORD"].ToString();

                        SCSYS007P1.ShowDialog(this);
                    }

                }
            }
        }


        private void grvMaster_CellValueChanged(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            DataRow row = grvMaster.GetFocusedDataRow();

            if (row != null)
            {
                string fieldName = grvMaster.FocusedColumn.FieldName;

                if (fieldName.Equals("SYSTEM_CODE"))
                {
                    
                    DataTable dtFTPInfo = GetFTPInfo(row["SYSTEM_CODE"].ToString());

                    if (dtFTPInfo.Rows.Count > 0)
                    {
                        row["FTP_SERVER_PATH"] = dtFTPInfo.Rows[0]["FTP_SERVER_PATH"].ToString();
                        row["USER_ID"] = dtFTPInfo.Rows[0]["USER_ID"].ToString();
                        row["FTP_IP"] = dtFTPInfo.Rows[0]["FTP_IP"].ToString();
                        row["PASSWORD"] = dtFTPInfo.Rows[0]["PASSWORD"].ToString();
                    }
                    else
                    {
                        row["FTP_SERVER_PATH"] = string.Empty;
                        row["USER_ID"] = string.Empty;
                        row["FTP_IP"] = string.Empty;
                        row["PASSWORD"] = string.Empty;
                    }
                }
            }
        }


        private void grvMaster_InitNewRow(object sender, InitNewRowEventArgs e)
        {
            DataRow dr = grvMaster.GetFocusedDataRow();

            grvMaster.SetFocusedRowCellValue("CHK", "Y");
            grvMaster.SetFocusedRowCellValue("IS_SAVE", "N");
            grvMaster.SetFocusedRowCellValue("APPLICATION_TYPE", "0");
        }
        #endregion

        #region 메서드
        private void initPage()
        {
            // 그리드 초기화
            DataTable dt = new DataTable();
            dt.Columns.Add("CHK");
            dt.Columns.Add("PROGRAM_ID");
            dt.Columns.Add("SYSTEM_CODE");
            dt.Columns.Add("URL");
            dt.Columns.Add("CLASS_NAME");
            dt.Columns.Add("PROGRAM_NAME");
            dt.Columns.Add("APPLICATION_TYPE");
            dt.Columns.Add("PARAMETER");
            dt.Columns.Add("NEW_AUTH_CHK");
            dt.Columns.Add("PIC1");
            dt.Columns.Add("PIC2");
            dt.Columns.Add("MANUAL_FILE");
            dt.Columns.Add("LOCAL_FILE_PATH");
            dt.Columns.Add("IS_SAVE");
            dt.Columns.Add("FTP_SERVER_PATH");
            dt.Columns.Add("USER_ID");
            dt.Columns.Add("FTP_IP");
            dt.Columns.Add("PASSWORD");

            grdMaster.DataSource = dt;

        }
        /// <summary>
        /// 콤보 - 시스템코드 정보 가져오기.
        /// </summary>
        /// <returns></returns>
        private DataTable GetSystem_code()
        {
            DataTable dt = new DataTable();

            DataPack parameter = new DataPack();

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS007.SEARCH_02", parameter);

            if (resultSet.IsSuccess)
            {
                dt = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(this, resultSet.ExceptionMessage, "알림", MessageBoxButtons.OK, ImageKinds.Information);
            }

            return dt;
        }

        /// <summary>
        /// 시스템코드별 FTP정보를 가져온다.
        /// </summary>
        /// <param name="strSYSTEM_CODE">시스템코드</param>
        /// <returns></returns>
        private DataTable GetFTPInfo(string strSYSTEM_CODE)
        {
            DataTable dt = new DataTable();

            DataPack parameter = new DataPack();
            parameter.DataList.Add("SYSTEM_CODE", strSYSTEM_CODE);

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS007.SEARCH_03", parameter);

            if (resultSet.IsSuccess)
            {
                dt = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(this, resultSet.ExceptionMessage, "알림", MessageBoxButtons.OK, ImageKinds.Information);
            }

            return dt;
        }

        #region 그리드 관련 메소드
        public bool ValidationRequired(bool IsMessagePrint, bool IsFocusedRowValidationCheck)
        {
            DataTable dt = (grdMaster.DataSource as DataTable);
            if (dt.Rows.Count == 0)
                return false;

            //ArrayList requiredColumns = GetRequiredColumns();
            ArrayList requiredColumns = new ArrayList();
            requiredColumns.Add("PROGRAM_ID");
            requiredColumns.Add("SYSTEM_CODE");
            requiredColumns.Add("URL");
            requiredColumns.Add("PROGRAM_NAME");

            //전체 DataRow에 대하여 Validation체크를 한다
            if (!IsFocusedRowValidationCheck)
            {
                //int RowCount = (grvMaster != null ? grvMaster.DataRowCount : InnerLayoutView.DataRowCount);
                int RowCount = grvMaster.DataRowCount;

                for (int i = 0; i < RowCount; i++)
                {
                    bool validationResult = RequiredValidationByRowHandle(IsMessagePrint, requiredColumns, i);

                    if (!validationResult)
                        return validationResult;
                }

                return true;
            }
            //else
            //{
            //    //int focusedRowHandle = (InnerGridView != null ? InnerGridView.FocusedRowHandle : InnerLayoutView.FocusedRowHandle);

            //    return RequiredValidationByRowHandle(IsMessagePrint, requiredColumns, focusedRowHandle);
            //}
            return false;
        }

        private bool RequiredValidationByRowHandle(bool IsMessagePrint, ArrayList requiredColumns, int rowIndex)
        {
            //DataRow row = (InnerGridView != null ? InnerGridView.GetDataRow(rowIndex) : InnerLayoutView.GetDataRow(rowIndex));
            DataRow row = grvMaster.GetDataRow(rowIndex);
            bool IsValidationCheck = false;

            //선택된 행에 대하여
            if (row["CHK"].ToString().Equals("Y"))
                IsValidationCheck = true;

            if (IsValidationCheck)
            {
                foreach (string fieldName in requiredColumns)
                {
                    if (row[fieldName].ToString().Equals(""))
                    {
                        if (IsMessagePrint)
                        {
                            //string colCaption = InnerGridView != null ? InnerGridView.Columns[fieldName].Caption : InnerLayoutView.Columns[fieldName].Caption;
                            string colCaption = grvMaster.Columns[fieldName].Caption;
                            string message = string.Format("{0}은는필수입력입니다", colCaption);

                            //MessageBoxHelper.HiproMessageBoxShow(message);
                            //MsgBox.Show(message);

                            if (grvMaster != null)
                            {
                                grvMaster.ClearColumnErrors();
                                grvMaster.FocusedRowHandle = rowIndex;
                                grvMaster.SetColumnError(grvMaster.Columns[fieldName], message);
                            }
                            else
                            {
                                //InnerLayoutView.ClearColumnErrors();
                                //InnerLayoutView.FocusedRowHandle = rowIndex;
                                //InnerLayoutView.SetColumnError(InnerLayoutView.Columns[fieldName], message);
                            }
                        }
                        return false;
                    }
                }
            }
            return true;
        }
        #endregion

        private void repositoryItemMRUEdit1_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Multiselect = true;

            // 필터막음
            openFileDialog.Filter = "모든문서및이미지" + "|*.xls,*.doc,*.rtf,*.ppt,*.xlsx,*.docx,*.pptx,*.pdf,*.txt,*.xml,*.htm,*.html,*.mht,*.hwp,*.msg,,*.exe,*.gif,*.jpg,*.jpeg,*.bmp,*.png,*.tiff,*.tif,*.ico".Replace(",", "; ");

            openFileDialog.ShowDialog(this);

            try
            {
                string[] dragFiles = openFileDialog.FileNames;
                if (dragFiles.Length > 0)
                {
                    foreach (string dragFile in dragFiles)
                    {
                        if (File.Exists(dragFile))
                        {
                            FileInfo fileInfo = new FileInfo(dragFile);

                            DataRow dr = grvMaster.GetFocusedDataRow();

                            dr["CHK"] = "Y";
                            dr["LOCAL_FILE_PATH"] = fileInfo.FullName;
                            dr["MANUAL_FILE"] = fileInfo.Name;
                            
                            grvMaster.UpdateCurrentRow();
                        }                        
                    }
                    
                }
            }
            catch (Exception ex)
            {
                MsgBox.Show(this, ex.Message, "오류", MessageBoxButtons.OK, ImageKinds.Error);
            }
        }

        private string UploadManual(DataRow dr)
        {
            HHI.ShipBuilding.Controls.Utils.FtpHelper2 ftp = new Controls.Utils.FtpHelper2("ftp://10.100.17.36", "hyspics", "hyspics");
            FileInfo fi= new FileInfo(dr["LOCAL_FILE_PATH"].ToString());
            if (fi.Exists)
            {
                try
                {
                    ftp.Upload("manual/" + dr["SYSTEM_CODE"].ToString() + "/" + dr["PROGRAM_ID"].ToString() + "/" + dr["MANUAL_FILE"].ToString(),
                    fi.FullName, true, ShipBuilding.Controls.Utils.FtpHelper2.SERVER_OS.Linux);
                    return string.Empty;
                }
                catch(Exception ex)
                {
                    dr["LOCAL_FILE_PATH"] = dr["LOCAL_FILE_PATH", DataRowVersion.Original];
                    dr["MANUAL_FILE"] = dr["MANUAL_FILE", DataRowVersion.Original];
                    return ex.Message;
                }
            }
            return string.Empty;
        }


        private void ApplyUserID(string sTYPE)
        {
            string sCol = string.Empty;

            if (sTYPE == "1") sCol = "PIC1";
            else sCol = "PIC2";
            
            // 데이타 체크
            if (grvMaster.RowCount == 0)
            { MsgBox.Show(this, "데이터를 조회하세요....", "알림", MessageBoxButtons.OK, ImageKinds.Information); return; }

            if (string.IsNullOrWhiteSpace(luSYSTEM_CODE.EditValue.ToString()))
            { MsgBox.Show(this, "적용할 시스템 코드를 선택 후 조회하세요.", "알림", MessageBoxButtons.OK, ImageKinds.Information); return; }
            
            if (string.IsNullOrWhiteSpace(txtUserID.Text.Trim()))
            { MsgBox.Show(this, "적용할 관리자 사번을 입력하세요.", "알림", MessageBoxButtons.OK, ImageKinds.Information); txtUserID.Focus(); return; }


            DataTable dt = GetIsUserID();
            if (dt.Rows.Count > 0)
            { 
                if(dt.Rows[0]["CHECK_YN"].ToString().Equals("N"))
                {
                    MsgBox.Show(this, "사번을 다시입력해주세요.", "알림", MessageBoxButtons.OK, ImageKinds.Information);
                    txtUserID.Focus();
                    return; 
                }
            }


            foreach (DataRow row in (grdMaster.DataSource as DataTable).Rows)
            {
                row["CHK"] = "Y";
                row[sCol] = txtUserID.Text;
            }
        }


        private DataTable GetIsUserID()
        {
            DataTable dt = new DataTable();

            DataPack parameter = new DataPack();
            parameter.DataList.Add("USERID", txtUserID.Text);

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS007.SEARCH_04", parameter);

            if (resultSet.IsSuccess)
            {
                dt = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(this, resultSet.ExceptionMessage, "알림", MessageBoxButtons.OK, ImageKinds.Information);
            }

            return dt;
        }

        #endregion

        private void luSYSTEM_CODE_EditValueChanged(object sender, EventArgs e)
        {
            if (grvMaster.DataSource != null && (grdMaster.DataSource is DataTable))
                (grdMaster.DataSource as DataTable).Rows.Clear(); 
        }

        


    }
}
