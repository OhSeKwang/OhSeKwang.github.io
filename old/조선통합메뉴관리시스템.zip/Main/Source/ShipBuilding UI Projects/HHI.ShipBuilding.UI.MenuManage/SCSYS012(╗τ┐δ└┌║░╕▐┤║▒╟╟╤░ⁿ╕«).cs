﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraTreeList.Nodes;
using DevExpress.XtraEditors;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS012 : StdUserControlBase// UserControl
    {

        #region 생성자 및 변수 선언
        public SCSYS012()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }

        private string sUSER_ID = string.Empty;

        /// <summary>
        /// 그리드 RepositoryItem의 PopupContainerEdit를 형변환해서 전역으로 선언한다
        /// </summary>
        PopupContainerEdit txtButtonRegisterPopupContainer = null;

        string sMENU_ID = string.Empty;
        #endregion

        #region 화면 Load
        private void SCSYS003_Load(object sender, EventArgs e)
        {
           
        }
        #endregion

        #region SCSYS012_Shown
        private void SCSYS012_Shown(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                stdSecurityManager1.ApplySecurity(this.SecurityContext);
                stdButtonExecuteManager1.RegisterButtonExecEvent();

                //ClientControlHelper.ImageComboBind(cboSYSTEM_CODE, "SYSTEM_NAME", "SYSTEM_CODE", "{value}-{text}", ComboDisplayTextOption.top, "전체", string.Empty, GetSystemCode());
            }
        }
        #endregion

        #region 버튼이벤트
        #region 조회
        /// <summary>
        /// 사용자그룹 조회[왼쪽그리드] 및 메뉴정보 조회[하단그리드]
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string sSearch = txtUSER_ID.Text + txtUSER_NM.Text + txtDEPTNAME.Text;

            if (string.IsNullOrWhiteSpace(sSearch))
            {
                MsgBox.Show("조회조건 하나라도 입력하세요!", "경고"); return;
            }
            
            DataResultSet resultSet = GetUserInfo(txtUSER_ID.Text, txtUSER_NM.Text, txtDEPTNAME.Text);

            if (resultSet.IsSuccess)
            {
                grdMaster.DataSource = resultSet.QuerySet.Tables[0];

            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }

            treeList1.DataSource = getMenuInfo();
            grvMaster_FocusedRowChanged(null, null);
        }
        #endregion

        #region 저장
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("저장 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            if (grvMaster1.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요....", "경고"); return; }

            if ((grdMaster1.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            { MsgBox.Show("저장할 데이터를 선택하세요....", "경고"); return; }

            DataTable dtMaster = (grdMaster1.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();

            string[] paramnames = new string[] { "USER_ID", "MENU_ID", "BASIC_ACLC", "BASIC_ACLR", "BASIC_ACLU", "BASIC_ACLD", "USE_YN" };

            DataTable controlParamInfo = new DataTable("controlParamInfo");
            for (int cnt = 0; cnt < paramnames.Length; cnt++)
            {
                controlParamInfo.Columns.Add(paramnames[cnt], (grvMaster1.GridControl.DataSource as DataTable).Columns[paramnames[cnt]].DataType);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in controlParamInfo.Columns)
            {
                if (!dtMaster.Columns.Contains(col.ColumnName))
                    throw new Exception(string.Format("필드명{0}을 찾을 수 없습니다."));

                if (col.DataType.Equals(typeof(int)))
                {
                    int[] col1 = new int[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = 0;
                        }
                        else
                        {
                            col1[i] = int.Parse(string.IsNullOrWhiteSpace(dtMaster.Rows[i][col.ColumnName].ToString()) ? "0" : dtMaster.Rows[i][col.ColumnName].ToString());
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }
                else
                {
                    string[] col1 = new string[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = string.Empty;
                        }
                        else
                        {
                            col1[i] = dtMaster.Rows[i][col.ColumnName].ToString();
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }

            }

            string[] col4 = new string[dtMaster.Rows.Count];

            for (int i = 0; i < dtMaster.Rows.Count; i++)
            {
                col4[i] = UserInfo == null ? "ADMIN" : UserInfo.UserID; //eve
            }

            parameter.DataList.Add("LOGIN_USERID", col4);

            parameter.ArrayItemCount = dtMaster.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            if (ValidationRequired(true, false))
            {
                DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS012.SAVE_01", parameter);

                if (resultSet.IsSuccess)
                {
                    MsgBox.Show("저장되었습니다", "확인");

                    grvMaster_FocusedRowChanged(null, null);
                }
                else
                {
                    MsgBox.Show(resultSet.ExceptionMessage);
                }
            }

        }
        #endregion
        
        #region 삭제
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("삭제 하시겠습니까?", "경고", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            if (grvMaster1.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요...."); return; }

            if ((grdMaster1.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            { MsgBox.Show("삭제할 데이터를 선택하세요...."); return; }

            DataTable dtMaster = (grdMaster1.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();

            string[] paramnames = new string[] { "USER_ID", "MENU_ID"};

            DataTable controlParamInfo = new DataTable("controlParamInfo");
            for (int cnt = 0; cnt < paramnames.Length; cnt++)
            {
                controlParamInfo.Columns.Add(paramnames[cnt], (grvMaster1.GridControl.DataSource as DataTable).Columns[paramnames[cnt]].DataType);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in controlParamInfo.Columns)
            {
                if (!dtMaster.Columns.Contains(col.ColumnName))
                    throw new Exception(string.Format("필드명{0}을 찾을 수 없습니다."));

                if (col.DataType.Equals(typeof(int)))
                {
                    int[] col1 = new int[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = 0;
                        }
                        else
                        {
                            col1[i] = int.Parse(string.IsNullOrWhiteSpace(dtMaster.Rows[i][col.ColumnName].ToString()) ? "0" : dtMaster.Rows[i][col.ColumnName].ToString());
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }
                else
                {
                    string[] col1 = new string[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = string.Empty;
                        }
                        else
                        {
                            col1[i] = dtMaster.Rows[i][col.ColumnName].ToString();
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }

            }
            parameter.ArrayItemCount = dtMaster.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            if (ValidationRequired(true, false))
            {
                DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS012.DELETE_01", parameter);

                if (resultSet.IsSuccess)
                {
                    MsgBox.Show("삭제되었습니다.", "확인");

                    grvMaster_FocusedRowChanged(null, null);
                }
                else
                {
                    MsgBox.Show(resultSet.ExceptionMessage);
                }
            }
        }
        #endregion

        /// <summary>
        /// 확장권한저장
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAuthButtonSave_Click(object sender, EventArgs e)
        {
            if (grvAuthButton.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요....", "경고"); return; }

            if ((grdAuthButton.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            { MsgBox.Show("저장할 데이터를 선택하세요....", "경고"); return; }

            DataTable dtMaster = (grdAuthButton.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();

            string[] paramnames = new string[] { "AUTH_ID", "USE_YN" };

            DataTable controlParamInfo = new DataTable("controlParamInfo");
            for (int cnt = 0; cnt < paramnames.Length; cnt++)
            {
                controlParamInfo.Columns.Add(paramnames[cnt], (grvAuthButton.GridControl.DataSource as DataTable).Columns[paramnames[cnt]].DataType);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in controlParamInfo.Columns)
            {
                if (!dtMaster.Columns.Contains(col.ColumnName))
                    throw new Exception(string.Format("필드명{0}을 찾을 수 없습니다."));

                if (col.DataType.Equals(typeof(int)))
                {
                    int[] col1 = new int[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = 0;
                        }
                        else
                        {
                            col1[i] = int.Parse(string.IsNullOrWhiteSpace(dtMaster.Rows[i][col.ColumnName].ToString()) ? "0" : dtMaster.Rows[i][col.ColumnName].ToString());
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }
                else
                {
                    string[] col1 = new string[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = string.Empty;
                        }
                        else
                        {
                            col1[i] = dtMaster.Rows[i][col.ColumnName].ToString();
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }

            }

            string[] col2 = new string[dtMaster.Rows.Count];
            string[] col3 = new string[dtMaster.Rows.Count];
            string[] col4 = new string[dtMaster.Rows.Count];

            for (int i = 0; i < dtMaster.Rows.Count; i++)
            {
                col2[i] = sUSER_ID;
                col3[i] = sMENU_ID;
                col4[i] = UserInfo == null ? "ADMIN" : UserInfo.UserID; //eve
            }

            parameter.DataList.Add("USER_ID", col2);
            parameter.DataList.Add("MENU_ID", col3);
            parameter.DataList.Add("LOGIN_USERID", col4);
            

            parameter.ArrayItemCount = dtMaster.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            if (ValidationRequired(true, false))
            {
                DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS012.SAVE_02", parameter);

                if (resultSet.IsSuccess)
                {
                    MsgBox.Show("삭제되었습니다.", "확인");

                    txtButtonRegisterPopupContainer.ClosePopup();
                }
                else
                {
                    MsgBox.Show(resultSet.ExceptionMessage);
                }
            }
        }

        /// <summary>
        /// 확장권한삭제
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAuthButtonDelete_Click(object sender, EventArgs e)
        {
            if (grvAuthButton.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요....", "경고"); return; }

            if ((grdAuthButton.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            { MsgBox.Show("삭제할 데이터를 선택하세요....", "경고"); return; }

            DataTable dtMaster = (grdAuthButton.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();

            string[] paramnames = new string[] { "USER_ID", "MENU_ID", "AUTH_ID" };

            DataTable controlParamInfo = new DataTable("controlParamInfo");
            for (int cnt = 0; cnt < paramnames.Length; cnt++)
            {
                controlParamInfo.Columns.Add(paramnames[cnt], (grvAuthButton.GridControl.DataSource as DataTable).Columns[paramnames[cnt]].DataType);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in controlParamInfo.Columns)
            {
                if (!dtMaster.Columns.Contains(col.ColumnName))
                    throw new Exception(string.Format("필드명{0}을 찾을 수 없습니다."));

                if (col.DataType.Equals(typeof(int)))
                {
                    int[] col1 = new int[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = 0;
                        }
                        else
                        {
                            col1[i] = int.Parse(string.IsNullOrWhiteSpace(dtMaster.Rows[i][col.ColumnName].ToString()) ? "0" : dtMaster.Rows[i][col.ColumnName].ToString());
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }
                else
                {
                    string[] col1 = new string[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = string.Empty;
                        }
                        else
                        {
                            col1[i] = dtMaster.Rows[i][col.ColumnName].ToString();
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }

            }
            parameter.ArrayItemCount = dtMaster.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            if (ValidationRequired(true, false))
            {
                DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS012.DELETE_02", parameter);

                if (resultSet.IsSuccess)
                {
                    MsgBox.Show("삭제되었습니다.", "확인");

                    txtButtonRegisterPopupContainer.ClosePopup();
                }
                else
                {
                    MsgBox.Show(resultSet.ExceptionMessage);
                }
            }
        }

        #endregion

        #region 그리드이벤트

        private void grvMaster_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            DataRow row = grvMaster.GetFocusedDataRow();

            if (row != null)
            {
                sUSER_ID = row["USER_ID"].ToString();

                DataPack parameter = new DataPack();
                parameter.DataList.Add("USER_ID", row["USER_ID"].ToString());


                DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS012.SEARCH_02", parameter);

                if (resultSet.IsSuccess)
                {
                    grdMaster1.DataSource = resultSet.QuerySet.Tables[0];
                }
                else
                {
                    MsgBox.Show(resultSet.ExceptionMessage);
                }
            }
            else
            {
                if (grvMaster1.DataSource != null && (grdMaster1.DataSource is DataTable))
                    (grdMaster1.DataSource as DataTable).Rows.Clear();
            }
        }

        private void grvMaster1_ShowingEditor(object sender, CancelEventArgs e)
        {
            //DataRow row = grvMaster1.GetFocusedDataRow();
            //if (row != null)
            //{
            //    string strFieldName = grvMaster1.FocusedColumn.FieldName;
            //    if (strFieldName.Equals("MENU_ID") || strFieldName.Equals("MENU_NAME"))
            //    {
            //        if (row["DIV"].ToString().Equals("S"))
            //            e.Cancel = true;
            //        else
            //            e.Cancel = false;
            //    }
            //}
        }

        private void grvMaster1_CellValueChanging(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            GridView gridView = (sender as GridView);
            if (gridView != null)
            {

                DataRow row = gridView.GetDataRow(e.RowHandle);
                if (row != null)
                {
                    if (gridView.Columns["CHK"] != null && gridView.Columns["CHK"].ColumnEdit != null && gridView.Columns["CHK"].ColumnEdit is RepositoryItemCheckEdit)
                    {
                        RepositoryItemCheckEdit chkEdit = (gridView.Columns["CHK"].ColumnEdit as RepositoryItemCheckEdit);
                        row["CHK"] = chkEdit.ValueChecked;
                    }
                }
            }
        }

        private void grdMaster1_DragDrop(object sender, DragEventArgs e)
        {
            //드래그한 메뉴정보를 가져온다
            DataRow row = GetDataRowFromNode(GetDragNode(e.Data));
            if (row != null)
            {
                DataTable dtMenuInfo = getgrvAddPgm(row["MENU_ID"].ToString());

                foreach (DataRow drMenu in dtMenuInfo.Rows)
                {                    
                    DataRow[] drMenuInfo = (grdMaster1.DataSource as DataTable).Select(string.Format("MENU_ID='{0}'", drMenu["MENU_ID"].ToString()));

                    if (drMenuInfo.Length.Equals(0))
                    {//메뉴아이디를 가져온다

                        grvMaster1.AddNewRow();
                        DataRow dr = grvMaster1.GetFocusedDataRow();

                        dr["CHK"] = "Y";
                        dr["USER_ID"] = sUSER_ID;
                        dr["MENU_ID"] = drMenu["MENU_ID"];
                        dr["MENU_NAME"] = drMenu["MENU_NAME"];
                        dr["BASIC_ACLC"] = drMenu["BASIC_ACLC"];
                        dr["BASIC_ACLR"] = "1";// drMenu["BASIC_ACLR"];
                        dr["BASIC_ACLU"] = drMenu["BASIC_ACLU"];
                        dr["BASIC_ACLD"] = drMenu["BASIC_ACLD"];
                        dr["USE_YN"] = "Y";
                        dr["DIV"] = "A";

                        grvMaster1.UpdateCurrentRow();
                        grvMaster1.Focus();
                    }
                    else
                    { 
                        if(drMenuInfo[0]["DIV"].ToString().Equals("A"))
                        {
                            drMenuInfo[0]["CHK"] = "Y";
                            drMenuInfo[0]["USER_ID"] = sUSER_ID;
                            drMenuInfo[0]["MENU_ID"] = drMenu["MENU_ID"];
                            drMenuInfo[0]["MENU_NAME"] = drMenu["MENU_NAME"];
                            drMenuInfo[0]["BASIC_ACLC"] = drMenu["BASIC_ACLC"];
                            drMenuInfo[0]["BASIC_ACLR"] = "1";//drMenu["BASIC_ACLR"];
                            drMenuInfo[0]["BASIC_ACLU"] = drMenu["BASIC_ACLU"];
                            drMenuInfo[0]["BASIC_ACLD"] = drMenu["BASIC_ACLD"];
                            drMenuInfo[0]["USE_YN"] = "Y";
                            drMenuInfo[0]["DIV"] = "A";
                        }                        
                    }


                }
            }
        }

        private void grdMaster1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }
        #endregion

        #region 컨트롤이벤트
        private void treeList1_DragDrop(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.None;
        }
        #endregion

        #region 메서드

        private void initPage()
        { 
            // 콤보 바인딩
            rpsCheckedCboAUTH.Items.Add("A", "AA", CheckState.Unchecked, true);
            rpsCheckedCboAUTH.Items.Add("B", "BB", CheckState.Unchecked, true);

        }


        /// <summary>
        /// 메뉴정보를 가져온다,
        /// </summary>
        /// <returns></returns>
        private DataTable getMenuInfo()
        {
            DataTable dt = new DataTable();

            DataPack parameter = new DataPack();            


            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS012.SEARCH_03", parameter);

            if (resultSet.IsSuccess)
            {
                dt = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }

            return dt;
        }
        /// <summary>
        /// 사용자정보를 가져온다.
        /// </summary>
        /// <param name="strUser_Id">사용자ID</param>
        /// <param name="strUser_Nm">사용자명</param>
        /// <param name="strDeptName">부서</param>
        /// <returns></returns>
        private DataResultSet GetUserInfo(string strUser_Id, string strUser_Nm, string strDeptName)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("USER_ID", strUser_Id);
            parameter.DataList.Add("USER_NM", strUser_Nm);
            parameter.DataList.Add("DEPTNAME", strDeptName);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS012.SEARCH_01", parameter);
        }

        /// <summary>
        /// 선택된 권한그룹및 drag/drop 한 메뉴에 대한 정보를 바인딩한다
        /// </summary>        
        /// <param name="sMENU_ID"></param>
        /// <returns></returns>
        private DataTable getgrvAddPgm(string strMENU_ID)
        {
            DataTable dt = new DataTable();
            DataRow row = grvMaster.GetFocusedDataRow();
            if (row != null)
            {
                DataPack parameter = new DataPack();                
                parameter.DataList.Add("MENU_ID", strMENU_ID);

                DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS012.SEARCH_04", parameter);

                if (resultSet.IsSuccess)
                {
                    dt = resultSet.QuerySet.Tables[0];
                }
                else
                {
                    MsgBox.Show(resultSet.ExceptionMessage);
                }
            }
            return dt;
        }

        public bool ValidationRequired(bool IsMessagePrint, bool IsFocusedRowValidationCheck)
        {
            DataTable dt = (grdMaster1.DataSource as DataTable);
            if (dt.Rows.Count == 0)
                return false;

            //ArrayList requiredColumns = GetRequiredColumns();
            ArrayList requiredColumns = new ArrayList();
            requiredColumns.Add("USER_ID");
            requiredColumns.Add("MENU_ID");
            
            //전체 DataRow에 대하여 Validation체크를 한다
            if (!IsFocusedRowValidationCheck)
            {
                int RowCount = grvMaster1.DataRowCount;

                for (int i = 0; i < RowCount; i++)
                {
                    bool validationResult = RequiredValidationByRowHandle(IsMessagePrint, requiredColumns, i);

                    if (!validationResult)
                        return validationResult;
                }

                return true;
            }
            
            return false;
        }

        private bool RequiredValidationByRowHandle(bool IsMessagePrint, ArrayList requiredColumns, int rowIndex)
        {
            DataRow row = grvMaster1.GetDataRow(rowIndex);
            bool IsValidationCheck = false;

            //선택된 행에 대하여
            if (row["CHK"].ToString().Equals("Y"))
                IsValidationCheck = true;

            if (IsValidationCheck)
            {
                foreach (string fieldName in requiredColumns)
                {
                    if (row[fieldName].ToString().Equals(""))
                    {
                        if (IsMessagePrint)
                        {
                            string colCaption = grvMaster1.Columns[fieldName].Caption;
                            string message = string.Format("{0}은는필수입력입니다", colCaption);

                            if (grvMaster1 != null)
                            {
                                grvMaster1.ClearColumnErrors();
                                grvMaster1.FocusedRowHandle = rowIndex;
                                grvMaster1.SetColumnError(grvMaster1.Columns[fieldName], message);
                            }
                            else
                            {
                                //InnerLayoutView.ClearColumnErrors();
                                //InnerLayoutView.FocusedRowHandle = rowIndex;
                                //InnerLayoutView.SetColumnError(InnerLayoutView.Columns[fieldName], message);
                            }
                        }
                        return false;
                    }
                }
            }
            return true;
        }

        #region 트리관련 메소드
        /// <summary>
        /// 트리노드로부터 DataRow를 구한다.
        /// </summary>
        /// <param name="node"></param>
        /// <returns></returns>
        private DataRow GetDataRowFromNode(TreeListNode node)
        {
            //if (node.HasChildren)
            //{                
            //    MsgBox.Show("하위메뉴가 존재합니다."); return null;             
            //}

            DataRowView drv = (DataRowView)treeList1.GetDataRecordByNode(node);
            return drv.Row;
        }

        /// <summary>
        /// 드래그드롭된 노드의 데이터 추출
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private TreeListNode GetDragNode(IDataObject data)
        {
            return data.GetData(typeof(TreeListNode)) as TreeListNode;
        }

        #endregion

        private void rpsPopupContainerEdit_Popup(object sender, EventArgs e)
        {
            if (txtButtonRegisterPopupContainer == null)
                txtButtonRegisterPopupContainer = sender as PopupContainerEdit;

            if (grvAuthButton.DataSource != null && (grdAuthButton.DataSource is DataTable))
                (grdAuthButton.DataSource as DataTable).Rows.Clear();

            DataRow row = grvMaster1.GetFocusedDataRow();
            if (row != null)
            {
                if (row["DIV"].ToString().Equals("A"))
                {
                    MsgBox.Show("메뉴권한을 저장후 확장권한을 조회하세요.", "경고"); return;
                }
                grdAuthButton.DataSource = getExtensionAuth(sUSER_ID, row["MENU_ID"].ToString());

                sMENU_ID = row["MENU_ID"].ToString();
            }
        }

        /// <summary>
        /// 사용자별 확장권한 정보를 가져온다
        /// </summary>
        /// <param name="strUSER_ID">사용자ID</param>
        /// <param name="strMENU_ID">메뉴ID</param>
        /// <returns></returns>
        private DataTable getExtensionAuth(string strUSER_ID, string strMENU_ID)
        {
            DataTable dt = new DataTable();

            DataPack parameter = new DataPack();
            parameter.DataList.Add("USER_ID", strUSER_ID);
            parameter.DataList.Add("MENU_ID", strMENU_ID);

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS012.SEARCH_05", parameter);

            if (resultSet.IsSuccess)
            {
                dt = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }


            return dt;
        }


        /// <summary>
        /// 시스템코드조회
        /// </summary>
        /// <returns></returns>
        private DataTable GetSystemCode()
        {
            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCCOMMON.SEARCH_SYSTEM").QuerySet.Tables[0];
        }


        #endregion

        #region HHI 조직도 - btnDeptPopUp_Click
        private void btnDeptPopUp_Click(object sender, EventArgs e)
        {
            SCSYS002P2 scsys002p2 = new SCSYS002P2();

            if (scsys002p2.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtDEPTNAME.Text = scsys002p2.hdnDEPT_NM;
            }
        }
        #endregion

        private void btnSearchMenuInfo_Click(object sender, EventArgs e)
        {
            treeList1.DataSource = getMenuInfo();
        }

        
    }
}
