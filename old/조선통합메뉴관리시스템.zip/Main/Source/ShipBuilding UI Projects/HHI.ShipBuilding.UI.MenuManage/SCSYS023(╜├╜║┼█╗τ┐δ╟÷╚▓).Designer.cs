﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS023
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SCSYS023));
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.grdProgram = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvProgram = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.grdUser = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvUser = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpychkYN = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.grdSystem = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvSystem = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpychkCheckYN = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.btnSearch = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.cboSYSTEM_CODE = new HHI.ShipBuilding.Client.Controls.DXperience.XtraImageComboBoxEditExt();
            this.txtSDate = new HHI.ShipBuilding.Client.Controls.DXperience.XtraDateEditExt();
            this.txtEDate = new HHI.ShipBuilding.Client.Controls.DXperience.XtraDateEditExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup4 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.splitterItem1 = new DevExpress.XtraLayout.SplitterItem();
            this.splitterItem2 = new DevExpress.XtraLayout.SplitterItem();
            this.layoutControlGroup5 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.stdButtonExecuteManager1 = new HHI.ShipBuilding.Controls.StdButtonExecuteManager(this.components);
            this.stdSecurityManager1 = new HHI.ShipBuilding.Windows.Forms.StdSecurityManager(this.components);
            this.stdValidationManager1 = new HHI.ShipBuilding.Controls.StdValidationManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdProgram)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvProgram)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkYN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdSystem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvSystem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkCheckYN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboSYSTEM_CODE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSDate.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEDate.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.grdProgram);
            this.xtraLayoutControlExt1.Controls.Add(this.grdUser);
            this.xtraLayoutControlExt1.Controls.Add(this.grdSystem);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearch);
            this.xtraLayoutControlExt1.Controls.Add(this.cboSYSTEM_CODE);
            this.xtraLayoutControlExt1.Controls.Add(this.txtSDate);
            this.xtraLayoutControlExt1.Controls.Add(this.txtEDate);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(600, 162, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(1000, 600);
            this.xtraLayoutControlExt1.TabIndex = 2;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // grdProgram
            // 
            this.grdProgram.CheckBoxFieldName = "CHK";
            this.grdProgram.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdProgram.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdProgram.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdProgram.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdProgram.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdProgram.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdProgram.IsHeaderClickAllCheckedItem = false;
            this.grdProgram.Location = new System.Drawing.Point(588, 122);
            this.grdProgram.MainView = this.grvProgram;
            this.grdProgram.MinLength = 0;
            this.grdProgram.Name = "grdProgram";
            this.grdProgram.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit1});
            this.grdProgram.Size = new System.Drawing.Size(388, 191);
            this.grdProgram.TabIndex = 18;
            this.grdProgram.UseEmbeddedNavigator = true;
            this.grdProgram.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvProgram});
            // 
            // grvProgram
            // 
            this.grvProgram.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn11,
            this.gridColumn12,
            this.gridColumn6,
            this.gridColumn7});
            this.grvProgram.GridControl = this.grdProgram;
            this.grvProgram.Name = "grvProgram";
            this.grvProgram.OptionsView.ColumnAutoWidth = false;
            this.grvProgram.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn11
            // 
            this.gridColumn11.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn11.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn11.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn11.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn11.Caption = "메뉴ID";
            this.gridColumn11.FieldName = "MENU_ID";
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.OptionsColumn.AllowEdit = false;
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 0;
            this.gridColumn11.Width = 90;
            // 
            // gridColumn12
            // 
            this.gridColumn12.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.Caption = "메뉴Display";
            this.gridColumn12.FieldName = "DISPLAY_TITLE";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.OptionsColumn.AllowEdit = false;
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 1;
            this.gridColumn12.Width = 150;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.Caption = "프로그램ID";
            this.gridColumn6.FieldName = "PROGRAM_ID";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 2;
            this.gridColumn6.Width = 90;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.Caption = "프로그램명";
            this.gridColumn7.FieldName = "TITLE";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 3;
            this.gridColumn7.Width = 150;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Caption = "Check";
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.repositoryItemCheckEdit1.ValueChecked = "Y";
            this.repositoryItemCheckEdit1.ValueUnchecked = "N";
            // 
            // grdUser
            // 
            this.grdUser.CheckBoxFieldName = "CHK";
            this.grdUser.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdUser.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdUser.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdUser.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdUser.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdUser.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdUser.IsHeaderClickAllCheckedItem = false;
            this.grdUser.Location = new System.Drawing.Point(588, 370);
            this.grdUser.MainView = this.grvUser;
            this.grdUser.MinLength = 0;
            this.grdUser.Name = "grdUser";
            this.grdUser.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpychkYN});
            this.grdUser.Size = new System.Drawing.Size(388, 206);
            this.grdUser.TabIndex = 11;
            this.grdUser.UseEmbeddedNavigator = true;
            this.grdUser.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvUser});
            // 
            // grvUser
            // 
            this.grvUser.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn8,
            this.gridColumn9,
            this.gridColumn10});
            this.grvUser.GridControl = this.grdUser;
            this.grvUser.Name = "grvUser";
            this.grvUser.OptionsView.ColumnAutoWidth = false;
            this.grvUser.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn8
            // 
            this.gridColumn8.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.Caption = "사용자ID";
            this.gridColumn8.FieldName = "USER_ID";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsColumn.AllowEdit = false;
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 0;
            this.gridColumn8.Width = 90;
            // 
            // gridColumn9
            // 
            this.gridColumn9.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.Caption = "사용자";
            this.gridColumn9.FieldName = "KOR_NM";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.AllowEdit = false;
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 1;
            this.gridColumn9.Width = 110;
            // 
            // gridColumn10
            // 
            this.gridColumn10.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn10.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn10.Caption = "부서";
            this.gridColumn10.FieldName = "ASGN_SHRT_NM";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.OptionsColumn.AllowEdit = false;
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 2;
            this.gridColumn10.Width = 150;
            // 
            // rpychkYN
            // 
            this.rpychkYN.AutoHeight = false;
            this.rpychkYN.Caption = "Check";
            this.rpychkYN.Name = "rpychkYN";
            this.rpychkYN.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpychkYN.ValueChecked = "Y";
            this.rpychkYN.ValueUnchecked = "N";
            // 
            // grdSystem
            // 
            this.grdSystem.CheckBoxFieldName = "CHK";
            this.grdSystem.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdSystem.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdSystem.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdSystem.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdSystem.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdSystem.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdSystem.IsHeaderClickAllCheckedItem = false;
            this.grdSystem.Location = new System.Drawing.Point(24, 122);
            this.grdSystem.MainView = this.grvSystem;
            this.grdSystem.MinLength = 0;
            this.grdSystem.Name = "grdSystem";
            this.grdSystem.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpychkCheckYN});
            this.grdSystem.Size = new System.Drawing.Size(531, 454);
            this.grdSystem.TabIndex = 17;
            this.grdSystem.UseEmbeddedNavigator = true;
            this.grdSystem.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvSystem});
            // 
            // grvSystem
            // 
            this.grvSystem.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn5});
            this.grvSystem.GridControl = this.grdSystem;
            this.grvSystem.Name = "grvSystem";
            this.grvSystem.OptionsView.ColumnAutoWidth = false;
            this.grvSystem.OptionsView.ShowGroupPanel = false;
            this.grvSystem.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.grvSystem_FocusedRowChanged);
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "구분";
            this.gridColumn1.FieldName = "GUB";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 60;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "시스템";
            this.gridColumn2.FieldName = "SYSTEM_CODE";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            this.gridColumn2.Width = 90;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.Caption = "시스템 명";
            this.gridColumn3.FieldName = "SYSTEM_NAME";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 2;
            this.gridColumn3.Width = 200;
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.Caption = "사용자수";
            this.gridColumn4.FieldName = "USER_CNT";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.AllowEdit = false;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 3;
            this.gridColumn4.Width = 90;
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.Caption = "서비스 화면수";
            this.gridColumn5.FieldName = "MENU_CNT";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 4;
            this.gridColumn5.Width = 90;
            // 
            // rpychkCheckYN
            // 
            this.rpychkCheckYN.AutoHeight = false;
            this.rpychkCheckYN.Caption = "Check";
            this.rpychkCheckYN.Name = "rpychkCheckYN";
            this.rpychkCheckYN.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpychkCheckYN.ValueChecked = "Y";
            this.rpychkCheckYN.ValueUnchecked = "N";
            // 
            // btnSearch
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSearch, new string[] {
            "SELECT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSearch, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSearch, true);
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.IsExecuteWdworkerLog = true;
            this.btnSearch.Location = new System.Drawing.Point(912, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(76, 22);
            this.btnSearch.StyleController = this.xtraLayoutControlExt1;
            this.btnSearch.TabIndex = 7;
            this.btnSearch.Text = "조회";
            this.btnSearch.UseSplasher = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // cboSYSTEM_CODE
            // 
            this.cboSYSTEM_CODE.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.cboSYSTEM_CODE.EditValue = "";
            this.cboSYSTEM_CODE.EnterExecuteButton = null;
            this.cboSYSTEM_CODE.FocusColor = System.Drawing.Color.Empty;
            this.cboSYSTEM_CODE.Key = "";
            this.cboSYSTEM_CODE.Location = new System.Drawing.Point(76, 50);
            this.cboSYSTEM_CODE.MinLength = 0;
            this.cboSYSTEM_CODE.Name = "cboSYSTEM_CODE";
            this.cboSYSTEM_CODE.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.cboSYSTEM_CODE.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.cboSYSTEM_CODE.Properties.Appearance.Options.UseBackColor = true;
            this.cboSYSTEM_CODE.Properties.Appearance.Options.UseForeColor = true;
            this.cboSYSTEM_CODE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboSYSTEM_CODE.Size = new System.Drawing.Size(194, 20);
            this.cboSYSTEM_CODE.StyleController = this.xtraLayoutControlExt1;
            this.cboSYSTEM_CODE.TabIndex = 10;
            // 
            // txtSDate
            // 
            this.txtSDate.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtSDate.EditValue = null;
            this.txtSDate.EnterExecuteButton = null;
            this.txtSDate.FocusColor = System.Drawing.Color.Empty;
            this.txtSDate.Key = "";
            this.txtSDate.Location = new System.Drawing.Point(329, 50);
            this.txtSDate.MinLength = 0;
            this.txtSDate.Name = "txtSDate";
            this.txtSDate.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtSDate.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtSDate.Properties.Appearance.Options.UseBackColor = true;
            this.txtSDate.Properties.Appearance.Options.UseForeColor = true;
            this.txtSDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtSDate.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtSDate.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Vista;
            this.txtSDate.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.txtSDate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSDate.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.True;
            this.txtSDate.Size = new System.Drawing.Size(101, 20);
            this.txtSDate.StyleController = this.xtraLayoutControlExt1;
            this.txtSDate.TabIndex = 11;
            this.stdValidationManager1.SetValidation(this.txtSDate, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // txtEDate
            // 
            this.txtEDate.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtEDate.EditValue = null;
            this.txtEDate.EnterExecuteButton = null;
            this.txtEDate.FocusColor = System.Drawing.Color.Empty;
            this.txtEDate.Key = "";
            this.txtEDate.Location = new System.Drawing.Point(448, 50);
            this.txtEDate.MinLength = 0;
            this.txtEDate.Name = "txtEDate";
            this.txtEDate.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtEDate.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtEDate.Properties.Appearance.Options.UseBackColor = true;
            this.txtEDate.Properties.Appearance.Options.UseForeColor = true;
            this.txtEDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtEDate.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtEDate.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Vista;
            this.txtEDate.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.txtEDate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtEDate.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.True;
            this.txtEDate.Size = new System.Drawing.Size(102, 20);
            this.txtEDate.StyleController = this.xtraLayoutControlExt1;
            this.txtEDate.TabIndex = 12;
            this.stdValidationManager1.SetValidation(this.txtEDate, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "Root";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup1, false);
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem2,
            this.layoutControlItem3,
            this.layoutControlGroup2,
            this.layoutControlGroup3,
            this.layoutControlGroup4,
            this.splitterItem1,
            this.splitterItem2,
            this.layoutControlGroup5});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1000, 600);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(900, 26);
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.btnSearch;
            this.layoutControlItem3.CustomizationFormText = "layoutControlItem3";
            this.layoutControlItem3.Location = new System.Drawing.Point(900, 0);
            this.layoutControlItem3.MaxSize = new System.Drawing.Size(80, 26);
            this.layoutControlItem3.MinSize = new System.Drawing.Size(80, 26);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(80, 26);
            this.layoutControlItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem3.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem3.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.CaptionImage = ((System.Drawing.Image)(resources.GetObject("layoutControlGroup2.CaptionImage")));
            this.layoutControlGroup2.CustomizationFormText = "사용자정보";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup2, false);
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem4});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 74);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(559, 506);
            this.layoutControlGroup2.Text = "시스템 정보";
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.grdSystem;
            this.layoutControlItem4.CustomizationFormText = "layoutControlItem4";
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(535, 458);
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextVisible = false;
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup3.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup3.CaptionImage = ((System.Drawing.Image)(resources.GetObject("layoutControlGroup3.CaptionImage")));
            this.layoutControlGroup3.CustomizationFormText = "그룹정보";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup3, false);
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem7});
            this.layoutControlGroup3.Location = new System.Drawing.Point(564, 74);
            this.layoutControlGroup3.Name = "layoutControlGroup3";
            this.layoutControlGroup3.Size = new System.Drawing.Size(416, 243);
            this.layoutControlGroup3.Text = "프로그램 정보";
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.grdProgram;
            this.layoutControlItem7.CustomizationFormText = "layoutControlItem7";
            this.layoutControlItem7.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(392, 195);
            this.layoutControlItem7.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem7.TextVisible = false;
            // 
            // layoutControlGroup4
            // 
            this.layoutControlGroup4.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup4.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup4.CaptionImage = ((System.Drawing.Image)(resources.GetObject("layoutControlGroup4.CaptionImage")));
            this.layoutControlGroup4.CustomizationFormText = "프로그램정보";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup4, false);
            this.layoutControlGroup4.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem6});
            this.layoutControlGroup4.Location = new System.Drawing.Point(564, 322);
            this.layoutControlGroup4.Name = "layoutControlGroup4";
            this.layoutControlGroup4.Size = new System.Drawing.Size(416, 258);
            this.layoutControlGroup4.Text = "사용자 정보";
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.grdUser;
            this.layoutControlItem6.CustomizationFormText = "layoutControlItem6";
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(392, 210);
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextVisible = false;
            // 
            // splitterItem1
            // 
            this.splitterItem1.AllowHotTrack = true;
            this.splitterItem1.CustomizationFormText = "splitterItem1";
            this.splitterItem1.Location = new System.Drawing.Point(564, 317);
            this.splitterItem1.Name = "splitterItem1";
            this.splitterItem1.Size = new System.Drawing.Size(416, 5);
            // 
            // splitterItem2
            // 
            this.splitterItem2.AllowHotTrack = true;
            this.splitterItem2.CustomizationFormText = "splitterItem2";
            this.splitterItem2.Location = new System.Drawing.Point(559, 74);
            this.splitterItem2.Name = "splitterItem2";
            this.splitterItem2.Size = new System.Drawing.Size(5, 506);
            // 
            // layoutControlGroup5
            // 
            this.layoutControlGroup5.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 1F);
            this.layoutControlGroup5.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup5.CustomizationFormText = " ";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup5, true);
            this.layoutControlGroup5.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem1,
            this.layoutControlItem9,
            this.layoutControlItem12,
            this.layoutControlItem13});
            this.layoutControlGroup5.Location = new System.Drawing.Point(0, 26);
            this.layoutControlGroup5.Name = "layoutControlGroup5";
            this.layoutControlGroup5.Size = new System.Drawing.Size(980, 48);
            this.layoutControlGroup5.Text = " ";
            this.layoutControlGroup5.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(530, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(426, 24);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.cboSYSTEM_CODE;
            this.layoutControlItem9.CustomizationFormText = "업무구분";
            this.layoutControlItem9.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem9.Image")));
            this.layoutControlItem9.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem9.MaxSize = new System.Drawing.Size(250, 24);
            this.layoutControlItem9.MinSize = new System.Drawing.Size(250, 24);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(250, 24);
            this.layoutControlItem9.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem9.Text = "시스템";
            this.layoutControlItem9.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem9.TextSize = new System.Drawing.Size(49, 16);
            this.layoutControlItem9.TextToControlDistance = 3;
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.txtSDate;
            this.layoutControlItem12.CustomizationFormText = "날짜";
            this.layoutControlItem12.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem12.Image")));
            this.layoutControlItem12.Location = new System.Drawing.Point(250, 0);
            this.layoutControlItem12.MaxSize = new System.Drawing.Size(160, 24);
            this.layoutControlItem12.MinSize = new System.Drawing.Size(160, 24);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(160, 24);
            this.layoutControlItem12.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem12.Spacing = new DevExpress.XtraLayout.Utils.Padding(15, 0, 0, 0);
            this.layoutControlItem12.Text = "날짜";
            this.layoutControlItem12.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem12.TextSize = new System.Drawing.Size(37, 16);
            this.layoutControlItem12.TextToControlDistance = 3;
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.txtEDate;
            this.layoutControlItem13.CustomizationFormText = "종료일자";
            this.layoutControlItem13.Location = new System.Drawing.Point(410, 0);
            this.layoutControlItem13.MaxSize = new System.Drawing.Size(120, 24);
            this.layoutControlItem13.MinSize = new System.Drawing.Size(120, 24);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(120, 24);
            this.layoutControlItem13.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem13.Text = "~";
            this.layoutControlItem13.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem13.TextSize = new System.Drawing.Size(9, 20);
            this.layoutControlItem13.TextToControlDistance = 5;
            // 
            // stdValidationManager1
            // 
            this.stdValidationManager1.IsNullorWhiteSpace = true;
            this.stdValidationManager1.IsShowErrorMessage = true;
            // 
            // SCSYS023
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS023";
            this.Size = new System.Drawing.Size(1000, 600);
            this.Shown += new System.EventHandler(this.SCSYS023_Shown);
            this.Load += new System.EventHandler(this.SCSYS023_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdProgram)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvProgram)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkYN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdSystem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvSystem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkCheckYN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboSYSTEM_CODE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSDate.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEDate.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private Client.Controls.DXperience.XtraButtonExt btnSearch;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private Controls.StdButtonExecuteManager stdButtonExecuteManager1;
        private Client.Controls.DXperience.XtraGridControlExt grdSystem;
        private DevExpress.XtraGrid.Views.Grid.GridView grvSystem;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpychkCheckYN;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private Client.Controls.DXperience.XtraGridControlExt grdUser;
        private DevExpress.XtraGrid.Views.Grid.GridView grvUser;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpychkYN;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private Client.Controls.DXperience.XtraGridControlExt grdProgram;
        private DevExpress.XtraGrid.Views.Grid.GridView grvProgram;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.SplitterItem splitterItem1;
        private DevExpress.XtraLayout.SplitterItem splitterItem2;
        private Windows.Forms.StdSecurityManager stdSecurityManager1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup5;
        private Client.Controls.DXperience.XtraImageComboBoxEditExt cboSYSTEM_CODE;
        private Client.Controls.DXperience.XtraDateEditExt txtSDate;
        private Controls.StdValidationManager stdValidationManager1;
        private Client.Controls.DXperience.XtraDateEditExt txtEDate;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
    }
}
