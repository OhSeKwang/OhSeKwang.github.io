﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using DevExpress.XtraGrid.Views.Grid;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS006 : StdUserControlBase
    {
        public SCSYS006()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }

        #region 화면 Load - SCSYS006_Load
        /// <summary>
        /// 화면 Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SCSYS006_Load(object sender, EventArgs e)
        {
            
        }
        #endregion 화면 Load - SCSYS006_Load

        #region SCSYS006_Shown
        private void SCSYS006_Shown(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                initPage();

                stdSecurityManager1.ApplySecurity(this.SecurityContext);
                stdButtonExecuteManager1.RegisterButtonExecEvent();
            }
        }
        #endregion

        #region 화면 초기화 - initPage
        /// <summary>
        /// 화면 초기화
        /// </summary>
        private void initPage()
        { 
        
        }
        #endregion 화면 초기화 - initPage

        #region 신규 - btnNew_Click
        /// <summary>
        /// 신규
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNew_Click(object sender, EventArgs e)
        {
            SCSYS006P1 scsys006p1 = new SCSYS006P1();
            scsys006p1.hdnRow = null;
            scsys006p1.sUSERID = UserInfo == null ? "ADMIN" : UserInfo.UserID; // eve

            if (scsys006p1.ShowDialog() == DialogResult.OK)
            {
                btnSearch.PerformClick();
            }
        }
        #endregion 신규 - btnNew_Click

        #region 조회 - btnSearch_Click
        /// <summary>
        /// 조회
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            DataResultSet resultSet = GetUserInfo(txtUser_Nm.Text, txtDeptName.Text, chkUse_Yn.Checked ? "Y" : "N");

            if (resultSet.IsSuccess)
            {
                resultSet.QuerySet.Tables[0].DefaultView.Sort = "KOR_NM";
                grdMain.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 조회 - btnSearch_Click

        #region 사용자정보 조회 - GetUserInfo
        /// <summary>
        /// 사용자정보 조회
        /// </summary>
        /// <param name="strGroup_Name"></param>
        /// <param name="strDescr"></param>
        /// <returns></returns>
        private DataResultSet GetUserInfo(string strUser_Nm, string strDeptName, string strUse_Yn)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("USER_NM", strUser_Nm);
            parameter.DataList.Add("DEPTNAME", strDeptName);
            parameter.DataList.Add("USE_YN", strUse_Yn);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS006.SEARCH_01", parameter);
        }
        #endregion 사용자정보 조회 - GetUserInfo

        #region 삭제 - btnDelete_Click
        /// <summary>
        /// 삭제
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("삭제 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }

            if (grvMain.RowCount == 0)
            {
                MsgBox.Show("삭제할 정보가 없습니다.", "경고");
                return;
            }

            if ((grdMain.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            {
                MsgBox.Show("삭제할 정보를 선택하세요!", "경고");
                return;
            }

            DataTable dtMain = (grdMain.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();
            string[] paramnames = new string[] { "USER_ID" };

            DataTable dtParam = new DataTable();
            for (int i = 0; i < paramnames.Length; i++)
            {
                dtParam.Columns.Add(paramnames[i]);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in dtParam.Columns)
            {
                string[] col1 = new string[dtMain.Rows.Count];
                for (int i = 0; i < dtMain.Rows.Count; i++)
                {
                    col1[i] = dtMain.Rows[i][col.ColumnName].ToString();
                }

                parameter.DataList.Add(col.ColumnName, col1);
            }

            parameter.ArrayItemCount = dtMain.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS006.DELETE_01", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("삭제 되었습니다.", "확인");
                btnSearch.PerformClick();
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 삭제 - btnDelete_Click

        #region 그리드 더블 클릭 - grvMain_DoubleClick
        /// <summary>
        /// 그리드 더블 클릭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void grvMain_DoubleClick(object sender, EventArgs e)
        {
            DataRow row = ((GridView)sender).GetFocusedDataRow();
            if (row == null)
                return;

            SCSYS006P1 scsys006p1 = new SCSYS006P1();
            scsys006p1.hdnRow = row;
            scsys006p1.sUSERID = UserInfo == null ? "ADMIN" : UserInfo.UserID; // eve

            if (scsys006p1.ShowDialog() == DialogResult.OK)
            {
                btnSearch.PerformClick();
            }
        }
        #endregion 그리드 더블 클릭 - grvMain_DoubleClick

        #region HHI 조직도 - btnDeptPopUp_Click
        /// <summary>
        /// HHI 조직도
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDeptPopUp_Click(object sender, EventArgs e)
        {
            SCSYS002P2 scsys002p2 = new SCSYS002P2();

            if (scsys002p2.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtDeptName.EditValue = scsys002p2.hdnDEPT_NM;
            }
        }
        #endregion HHI 조직도 - btnDeptPopUp_Click

        
    }
}
