﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;

using DevExpress.XtraGrid.Views.Grid;

using HHI.ServiceModel;
using HHI.Windows.Forms;

//using BIZWORKCommon.Helpers;
//using BIZWORKCommon.Security;
//using BIZWORKCommon.WcfService.SystemChannel;

using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Controls;

namespace HHI.ShipBuilding.UI.MenuManage
{
    public partial class SCSYS024P2 : DevExpress.XtraEditors.XtraForm
    {
        #region 전역변수
        
        /// <summary>
        /// 결과 
        /// </summary>
        public bool pRESULT { get; set; }

        /// <summary>
        /// ID
        /// </summary>
        public string pUSERID { get; set; }

        public string pUSER_NAME { get; set; }
        public string pDEPT_CD { get; set; }
        public string pDEPT_DESC { get; set; }

        public string pTEL_NO { get; set; }
       

        #endregion 전역변수

        public SCSYS024P2()
        {
            InitializeComponent();
        }

        private void QUICK01P1_Load(object sender, EventArgs e)
        {
            InitForm();
        }

        #region 화면 초기 설정 - InitForm
        /// <summary>
        /// 화면 초기 설정
        /// </summary>
        private void InitForm()
        {
            pRESULT = false;

            // 그리드 DataSource 초기화
            SetGridDataSource();

            // COMBO BIND
            ClientControlHelper.ImageComboBind(cboDEPT, "NAME", "CODE", "{value}-{text}", ComboDisplayTextOption.top, "전체", string.Empty, GetDept());            


            if (pDEPT_CD != "")
            {
                cboDEPT.EditValue = pDEPT_CD;
                btnSearch.PerformClick();
            }

        }
        #endregion 화면 초기 설정 - InitForm

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(cboDEPT.EditValue.ToString()) && string.IsNullOrWhiteSpace(cboASGN.EditValue.ToString())
                && string.IsNullOrWhiteSpace(txtNAME.Text))
            {
                MsgBox.Show("조회조건중 하나 선택 또는 입력하세요.");
                return;
            }

            GetMainDetailInfo();
        }

        #region 닫기 - btnClose_Click
        /// <summary>
        /// 닫기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }
        #endregion 닫기 - btnClose_Click

        #region 그리드 DataSource 초기화 - SetGridDataSource
        /// <summary>
        /// 그리드 DataSource 초기화
        /// </summary>
        private void SetGridDataSource()
        {

            //Helpers.SetGridDataSourceDefault(grvList);
           
        }
        #endregion 그리드 DataSource 초기화 - SetGridDataSource

        /// <summary>
        /// Detail 조회
        /// </summary>
        /// <param name="strID"></param>
        private void GetMainDetailInfo()
        {
            string strQueryId = "MENUMANGE.SCSYS024.GET_USER_INFO";

            DataPack parameter = new DataPack();
            parameter.DataList.Add("DEPT_CD", cboDEPT.EditValue.ToString());
            parameter.DataList.Add("ASGN_CD", cboASGN.EditValue.ToString());
            parameter.DataList.Add("NAME", txtNAME.Text);

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.C35aDataSource, false, strQueryId, parameter);
            if (resultSet.IsSuccess)
            {
                grdList.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        
        private DataTable GetDept()
        {
            DataTable dt = new DataTable();           
            DataPack parameter = new DataPack();

            string strQueryId = "MENUMANGE.SCSYS024.SEARCH_GET_DEPT";

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.C35aDataSource, false, strQueryId, parameter);
            if (resultSet.IsSuccess)
            {
                dt = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }

            return dt;
        }

        private DataTable GetAsgn(string sDEPT_CD)
        {
            DataTable dt = new DataTable();
            DataPack parameter = new DataPack();

            string strQueryId = "MENUMANGE.SCSYS024.SEARCH_GET_ASGN";

            parameter.DataList.Add("DEPT_CD", sDEPT_CD);

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.C35aDataSource, false, strQueryId, parameter);
            if (resultSet.IsSuccess)
            {
                dt = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }

            return dt;
        }

        private void cboDEPT_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboDEPT.EditValue == null) return;

            ClientControlHelper.ImageComboBind(cboASGN, "NAME", "CODE", "{value}-{text}", ComboDisplayTextOption.top, "전체", string.Empty, GetAsgn(cboDEPT.EditValue.ToString()));            
        }

        private void grvList_DoubleClick(object sender, EventArgs e)
        {
            DataRow row = grvList.GetFocusedDataRow();

            if (row == null) return;

            pUSERID = row["EMP_NO"].ToString();
            pUSER_NAME = row["KOR_NM"].ToString();
            pDEPT_CD = row["DEPT_CD"].ToString();
            pDEPT_DESC = row["HHINAME"].ToString();
            pTEL_NO = row["OFFI_TEL"].ToString();


            pRESULT = true;

            this.Close();
        }

    }
}