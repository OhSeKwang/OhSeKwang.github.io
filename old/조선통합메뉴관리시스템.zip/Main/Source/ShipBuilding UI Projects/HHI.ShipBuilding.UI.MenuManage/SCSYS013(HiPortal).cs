﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraTreeList.Nodes;
using DevExpress.XtraEditors;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS013 : StdUserControlBase// UserControl
    {

        #region 생성자 및 변수 선언
        public SCSYS013()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();



            #endregion
        }

        private string sUSER_ID = string.Empty;

        /// <summary>
        /// 그리드 RepositoryItem의 PopupContainerEdit를 형변환해서 전역으로 선언한다
        /// </summary>
        PopupContainerEdit txtButtonRegisterPopupContainer = null;

        string sMENU_ID = string.Empty;
        #endregion

        #region 화면 Load
        private void SCSYS013_Load(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                
            }
        }

        private void SCSYS013_Shown(object sender, EventArgs e)
        {
            string strUrl = HHI.Configuration.AppSectionFactory.AppSection["BIZSAP_GUI"].ToString();
            
            // 파라메터 GUBUN - 1 : Hi Portal 메인화면, 2 : SAP TCODE 화면, 3 : SAP 메인 화면(사용안함)
            //strUrl += string.Format(@"?USER_ID={0}&GUBUN={1}&TCODE={2}", "A401226", "0", string.Empty);
            //테스트 ID : A401226
            strUrl += string.Format(@"?TCODE={0}", "HIPORT");
            
            object obj = null;

            axWebBrowser1.Navigate(strUrl, ref obj, ref obj, ref obj, ref obj);
        }
        #endregion

       

        private void axWebBrowser1_NewWindow2(object sender, AxSHDocVw.DWebBrowserEvents2_NewWindow2Event e)
        {
            SCSYS013P1 SCSYS013P1 = new SCSYS013P1();
            SCSYS013P1.Show(this);
            

            e.ppDisp = SCSYS013P1.WebBrower.Application;
            SCSYS013P1.WebBrower.RegisterAsBrowser = true;
        }

    }
}
