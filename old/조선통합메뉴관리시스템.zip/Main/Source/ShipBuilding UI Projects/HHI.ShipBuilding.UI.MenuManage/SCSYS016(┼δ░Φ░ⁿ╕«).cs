﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Views.Grid;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS016 : StdUserControlBase//UserControl
    {
        #region 생성자
        public SCSYS016()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }
        #endregion

        #region 화면 Load
        
        #endregion

        #region SCSYS016_Shown
        private void SCSYS016_Shown(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                initPage();

                stdSecurityManager1.ApplySecurity(this.SecurityContext);
                stdButtonExecuteManager1.RegisterButtonExecEvent();
            }
        }
        #endregion

        #region 버튼 이벤트

        #region 조회
        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (!stdValidationManager1.Validation())
            {
                return;
            }

            if (DateTime.Compare(Convert.ToDateTime(dteDATE_FROM.EditValue), Convert.ToDateTime(dteDATE_TO.EditValue)) > 0)
            {
                MsgBox.Show("날짜는 시작일자보다 커야합니다.", "경고"); return;
            }

            DataPack parameter = new DataPack();
            parameter.DataList.Add("SYSTEM_CODE",   cboSYSTEM_CODE.EditValue.ToString());
            parameter.DataList.Add("USER_ID", txtUSER_ID.Text);
            parameter.DataList.Add("MENU_ID", txtMENU_ID.Text);
            parameter.DataList.Add("DATE_FROM", dteDATE_FROM.EditValue == null ? DateTime.Today.ToString("yyyyMMdd") : Convert.ToDateTime(dteDATE_FROM.EditValue).ToString("yyyyMMdd"));
            parameter.DataList.Add("DATE_TO", dteDATE_TO.EditValue == null ? DateTime.Today.ToString("yyyyMMdd") : Convert.ToDateTime(dteDATE_TO.EditValue).ToString("yyyyMMdd"));

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS016.SEARCH_01", parameter);

            if (resultSet.IsSuccess)
            {
                grdMaster.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }

        }
        #endregion

        /// <summary>
        /// 메뉴ID 가져오기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnMENUID_S_Click(object sender, EventArgs e)
        {
            SCSYS016P1 GetMenuId = new SCSYS016P1();
            StdPopupHost PopupHost = new StdPopupHost(GetMenuId, "메뉴ID 가져오기");
            GetMenuId.SetSecurityContext(this.SecurityContext);
            GetMenuId.SetUserInfoContext(this.UserInfo);
            GetMenuId.sSYSTEM_CODE = cboSYSTEM_CODE.EditValue.ToString();
            GetMenuId.sMENU_ID = txtMENU_ID.Text;


            PopupHost.ShowDialog();

            if (GetMenuId.sGUBUN.Equals("Y"))
            {
                txtMENU_ID.Text = GetMenuId.sMENU_ID;
                cboSYSTEM_CODE.EditValue = GetMenuId.sSYSTEM_CODE;
            }
        }
        #endregion

        #region 그리드 이벤트
       
        #endregion

        #region 컨트롤 이벤트
        #endregion

        #region 메서드

        private void initPage()
        {
            // 콤보 바인딩
            ClientControlHelper.ImageComboBind(cboSYSTEM_CODE, "SYSTEM_NAME", "SYSTEM_CODE", "{value}-{text}", ComboDisplayTextOption.top, "전체", string.Empty, GetSystemCode());
            ClientControlHelper.ImageComboBind(rpsCboSystemCode, "SYSTEM_NAME", "SYSTEM_CODE", "{value}-{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, GetSystemCode());

            dteDATE_FROM.EditValue = DateTime.Now.AddDays(-7);
            dteDATE_TO.EditValue = DateTime.Now;


            // 그리드 초기화
            DataTable dt = new DataTable();
            
        }
        
        /// <summary>
        /// 시스템코드조회
        /// </summary>
        /// <returns></returns>
        private DataTable GetSystemCode()
        {
            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCCOMMON.SEARCH_SYSTEM").QuerySet.Tables[0];
        }

        #endregion

    }
}
