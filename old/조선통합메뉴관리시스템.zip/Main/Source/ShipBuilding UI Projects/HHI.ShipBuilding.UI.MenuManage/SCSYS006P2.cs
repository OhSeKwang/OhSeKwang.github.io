﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using DevExpress.XtraTreeList.Nodes;
using DevExpress.XtraTreeList;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    public partial class SCSYS006P2 : DevExpress.XtraEditors.XtraForm
    {
        public DataRow hdnRow { get; set; }

        public SCSYS006P2()
        {
            InitializeComponent();
        }

        #region 화면 Load - SCSYS006P2_Load
        /// <summary>
        /// 화면 Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SCSYS006P2_Load(object sender, EventArgs e)
        {
            initPage();
        }
        #endregion 화면 Load - SCSYS006P2_Load

        #region 화면 초기화 - initPage
        /// <summary>
        /// 화면 초기화
        /// </summary>
        private void initPage()
        {
            GetHHIDeptInfo("ROOT");
        }
        #endregion 화면 초기화 - initPage

        #region 닫기 - btnClose_Click
        /// <summary>
        /// 닫기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }
        #endregion 닫기 - btnClose_Click

        #region 트리 조회 - GetHHIDeptInfo
        /// <summary>
        /// 트리 조회
        /// </summary>
        /// <param name="strPRNT_CD"></param>
        private void GetHHIDeptInfo(string strPRNT_CD)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("PRNT_CD", strPRNT_CD);

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS002.SEARCH_04", parameter);

            if (resultSet.IsSuccess)
            {
                treeDept.DataSource = resultSet.QuerySet.Tables[0];

                treeDept.ExpandAll();
                treeDept.VertScrollVisibility = DevExpress.XtraTreeList.ScrollVisibility.Always;
                treeDept.HorzScrollVisibility = DevExpress.XtraTreeList.ScrollVisibility.Always;
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 트리 조회 - GetHHIDeptInfo

        #region 트리 노드 더블 클릭 - treeDept_DoubleClick
        /// <summary>
        /// 트리 노드 더블 클릭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void treeDept_DoubleClick(object sender, EventArgs e)
        {
            TreeListNode node = treeDept.FocusedNode;

            if(!node.HasChildren)
            {
                grdUser_Bind("DEPT", node.GetValue("ASGN_SHRT_NM").ToString(), node.GetValue("ASGN_SHRT_NM").ToString());
            }
        }
        #endregion 트리 노드 더블 클릭 - treeDept_DoubleClick

        #region 사용자 그리드 바인딩 - grd_User_Bind
        /// <summary>
        /// 사용자 그리드 바인딩
        /// </summary>
        /// <param name="strGubun"></param>
        /// <param name="strValue"></param>
        private void grdUser_Bind(string strGubun, string strValue, string strDeptName)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("GUBUN", strGubun);
            parameter.DataList.Add("VALUE", strValue);

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS006.SEARCH_02", parameter);

            if (resultSet.IsSuccess)
            {
                DataTable dt = resultSet.QuerySet.Tables[0];
                grdUser.DataSource = dt;

                // 우측 부서명 표시
                empDeptNm.Text = string.Format("{0} [ {1} ]", strDeptName.Trim(), dt == null ? "0" : dt.Rows.Count.ToString());
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 사용자 그리드 바인딩 - grd_User_Bind

        #region 조회 - btnSearch_Click
        /// <summary>
        /// 조회
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            grdUser_Bind(cboGubun.EditValue.ToString(), txtValue.Text, "총");
        }
        #endregion 조회 - btnSearch_Click

        #region 사용자 그리드 더블 클릭 - grvUser_DoubleClick
        /// <summary>
        /// 사용자 그리드 더블 클릭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void grvUser_DoubleClick(object sender, EventArgs e)
        {
            DataRow row = grvUser.GetFocusedDataRow();
            if (row == null)
                return;

            hdnRow = row;
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }
        #endregion 사용자 그리드 더블 클릭 - grvUser_DoubleClick
    }
}
