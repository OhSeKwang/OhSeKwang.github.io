﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;

using DevExpress.XtraGrid.Views.Grid;
using HHI.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(false)]
    public partial class SCSYS023 : StdUserControlBase
    {
        string hdnSDate = string.Empty;
        string hdnEDate = string.Empty;

        public SCSYS023()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }

        public override void InitControl(object args)
        {
            base.InitControl(args);

            if (args != null)
            {
                string sUserId = args.ToString();

                btnSearch.PerformClick();
            }
        }

        #region 화면 Load - SCSYS023_Load
        /// <summary>
        /// 화면 Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SCSYS023_Load(object sender, EventArgs e)
        {
            
        }
        #endregion 화면 Load - SCSYS023_Load

        #region 화면 Shown - SCSYS023_Shown
        /// <summary>
        /// 화면 Shown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SCSYS023_Shown(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                InitForm();

                stdSecurityManager1.ApplySecurity(this.SecurityContext);
                stdButtonExecuteManager1.RegisterButtonExecEvent();
            }
        }
        #endregion 화면 Shown - SCSYS023_Shown

        #region 화면 초기 설정 - InitForm
        /// <summary>
        /// 화면 초기 설정
        /// </summary>
        private void InitForm()
        {
            cboSYSTEM_CODE_Bind();

            txtSDate.EditValue = DateTime.Now.AddDays(-7);
            txtEDate.EditValue = DateTime.Now;
        }
        #endregion 화면 초기 설정 - InitForm

        #region 시스템 combo 바인딩 - cboSYSTEM_CODE_Bind
        /// <summary>
        /// 시스템 combo 바인딩
        /// </summary>
        /// <returns></returns>
        private void cboSYSTEM_CODE_Bind()
        {
            string strQueryId = "MENUMANGE.SCCOMMON.SEARCH_SYSTEM";
            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, strQueryId);
            if (resultSet.IsSuccess)
            {
                // 콤보 바인딩
                ClientControlHelper.ImageComboBind(cboSYSTEM_CODE, "SYSTEM_NAME", "SYSTEM_CODE", "{value}-{text}", ComboDisplayTextOption.top, "전체", string.Empty, resultSet.QuerySet.Tables[0]);
            }
        }
        #endregion 시스템 combo 바인딩 - cboSYSTEM_CODE_Bind

        #region 조회 - btnSearch_Click
        /// <summary>
        /// 조회
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            Splasher.Show();

            hdnSDate = txtSDate.Text.Replace("-", string.Empty);
            hdnEDate = txtEDate.Text.Replace("-", string.Empty);

            string strQueryId = "MENUMANGE.SCSYS023.SEARCH_01";
            
            DataPack parameter = new DataPack();
            parameter.DataList.Add("SYSTEM_CODE", cboSYSTEM_CODE.EditValue == null ? string.Empty : cboSYSTEM_CODE.EditValue.ToString());
            parameter.DataList.Add("SDATE", hdnSDate);
            parameter.DataList.Add("EDATE", hdnEDate);

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, strQueryId, parameter);
            if (resultSet.IsSuccess)
            {
                grdSystem.DataSource = resultSet.QuerySet.Tables[0];

                if (grvSystem.RowCount == 1)
                {
                    grvSystem.FocusedRowHandle = 0;
                    grvSystem_FocusedRowChanged(null, null);
                }
            }
            else
            {
                MsgBox.Show(this, resultSet.ExceptionMessage, "시스템 정보", MessageBoxButtons.OK, ImageKinds.Error);
            }

            Splasher.Close();
        }
        #endregion 조회 - btnSearch_Click

        #region 시스템 정보 Row 변경 - grvSystem_FocusedRowChanged
        /// <summary>
        /// 시스템 정보 Row 변경
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void grvSystem_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            DataRow row = null;

            if (grvSystem.RowCount == 1)
            {
                row = grvSystem.GetDataRow(0);
            }
            else
            {
                row = grvSystem.GetFocusedDataRow();
            }

            if (row == null)
            {
                return;
            }

            grdProgram.DataSource = null;
            grdUser.DataSource = null;

            string system_Code = row["SYSTEM_CODE"].ToString();

            grdProgram_Bind(system_Code);
            grdUser_Bind(system_Code);
        }
        #endregion 시스템 정보 Row 변경 - grvSystem_FocusedRowChanged

        #region 프로그램 정보 바인딩 - grdProgram_Bind
        /// <summary>
        /// 프로그램 정보 바인딩
        /// </summary>
        /// <param name="system_Code"></param>
        private void grdProgram_Bind(string system_Code)
        {
            string strQueryId = "MENUMANGE.SCSYS023.SEARCH_02";

            DataPack parameter = new DataPack();
            parameter.DataList.Add("SYSTEM_CODE", system_Code);
            parameter.DataList.Add("SDATE", hdnSDate);
            parameter.DataList.Add("EDATE", hdnEDate);

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, strQueryId, parameter);
            if (resultSet.IsSuccess)
            {
                grdProgram.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(this, resultSet.ExceptionMessage, "프로그램 정보", MessageBoxButtons.OK, ImageKinds.Error);
            }
        }
        #endregion 프로그램 정보 바인딩 - grdProgram_Bind

        #region 사용자 정보 바인딩 - grdUser_Bind
        /// <summary>
        /// 사용자 정보 바인딩
        /// </summary>
        /// <param name="system_Code"></param>
        private void grdUser_Bind(string system_Code)
        {
            string strQueryId = "MENUMANGE.SCSYS023.SEARCH_03";

            DataPack parameter = new DataPack();
            parameter.DataList.Add("SYSTEM_CODE", system_Code);
            parameter.DataList.Add("SDATE", hdnSDate);
            parameter.DataList.Add("EDATE", hdnEDate);

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, strQueryId, parameter);
            if (resultSet.IsSuccess)
            {
                grdUser.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(this, resultSet.ExceptionMessage, "사용자 정보", MessageBoxButtons.OK, ImageKinds.Error);
            }
        }
        #endregion 사용자 정보 바인딩 - grdUser_Bind
    }
}
