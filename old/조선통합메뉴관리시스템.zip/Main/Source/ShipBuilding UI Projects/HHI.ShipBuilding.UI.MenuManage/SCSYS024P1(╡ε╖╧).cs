﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using HHI.Windows.Forms;
using DevExpress.XtraGrid.Views.Grid;
using System.IO;
using DevExpress.XtraGrid;
using System.Diagnostics;

namespace HHI.ShipBuilding.UI.MenuManage
{
    public partial class SCSYS024P1 : DevExpress.XtraEditors.XtraForm
    {
        /// <summary>
        /// 사용자 정보 DataRow
        /// </summary>
        public DataRow hdnRow { get; set; }

        public string sUSERID { get; set; }

        public string sUSER_NAME { get; set; }

        public string sUSER_CONTACT { get; set; }

        public string sUSER_DEPT { get; set; }

        public string sUSER_DEPTDESC { get; set; }

        private string pAFILECODE = string.Empty;
        private string pRCV_USERNO = string.Empty;
        private string pRCV_USERDEPTCD = string.Empty;
        private string[] _afilecode = new string[] {"", ""};

        public SCSYS024P1()
        {
            InitializeComponent();
        }

        #region 화면 Load - SCSYS006P1_Load
        /// <summary>
        /// 화면 Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SCSYS006P1_Load(object sender, EventArgs e)
        {

            // set combo 
            // 처리상태
            ClientControlHelper.ImageComboBind(cboPROCESS, "CDNM", "CDCODE", "{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, ClientControlHelper.GetCodeInfo("SY013"));

            cboPROCESS.Properties.Items.Remove(cboPROCESS.Properties.Items.GetItem("R"));  // 반려 item 은 안보이게...

            // 구분
            ClientControlHelper.ImageComboBind(cboGUBUN, "CDNM", "CDCODE", "{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, ClientControlHelper.GetCodeInfo("SY014"));


            MngHelpers.SetGridDataSourceDefault(grvFILE);
            MngHelpers.SetGridDataSourceDefault(grvFile2);

            initPage();

            

        }
        #endregion 화면 Load - SCSYS006P1_Load

        #region 화면 초기화 - initPage
        /// <summary>
        /// 화면 초기화
        /// </summary>
        private void initPage()
        {
            if (hdnRow != null)
            {                
                // 컨트롤 바인딩
                ClientControlHelper.CtrlNestedDataBind(hdnRow, layoutControlGroup1);

                memCONTENT.Text = hdnRow["CONTENT"].ToString();
                memCS_CONTENT.Text = hdnRow["CS_CONTENT"].ToString();
                memREMARK.Text = hdnRow["REMARK"].ToString();
                txtRCV_TELNO.Text = hdnRow["RCV_TELNO"].ToString();
                txtRCV_USERDEPTDESC.Text = hdnRow["RCV_USERDEPTDESC"].ToString();

                stdValidationManager1.SetValidation(txtTELNO, new ValidationType[] { });

                pRCV_USERNO = hdnRow["RCV_USERNO"].ToString();
                pRCV_USERDEPTCD = hdnRow["RCV_USERDEPTCD"].ToString();

                txtPROGRAM_ID.Properties.ReadOnly = true;
                txtPROGRAM_NAME.Properties.ReadOnly = true;
                txtSUBJECT.Properties.ReadOnly = true;
                memCONTENT.Properties.ReadOnly = true;
                cboGUBUN.Properties.ReadOnly = true;

                if (cboPROCESS.EditValue.ToString().Equals("C"))
                    cboPROCESS.Properties.ReadOnly = true;

                /* AFILECODE */
                // 요청
                _afilecode[0] = hdnRow["AFILECODE"].ToString();
                SET_AFILECODE(_afilecode[0], grdFILE);
                // 회신
                _afilecode[1] = hdnRow["AFILECODE2"].ToString();
                SET_AFILECODE(_afilecode[1], grdFile2);


                if (sUSERID == hdnRow["USERNO"].ToString() || sUSER_DEPT == "CX90")
                {
                    if (sUSERID == hdnRow["USERNO"].ToString())
                    {                        
                        btnAttach2.Enabled = false;
                        btnFileDelete2.Enabled = false;

                        if (cboPROCESS.EditValue.ToString().Equals("P"))
                        {
                            txtSUBJECT.Properties.ReadOnly = false;
                            memCONTENT.Properties.ReadOnly = false;
                            cboGUBUN.Properties.ReadOnly = true;
                        }
                    }                    
                }
                else
                {
                    // 요청자가 작성한 글이 아니거나 조선정보부(관리자) 소속이 아니면 버튼 제한
                    btnSave.Enabled = false;
                    btnAttach.Enabled = false;
                    btnFileDelete.Enabled = false;
                    btnAttach2.Enabled = false;
                    btnFileDelete2.Enabled = false;
                }
            }
            else
            {
                txtHNAME.Text = sUSER_NAME;
                txtREQ_DEPTDESC.Text = sUSER_DEPTDESC;

                txtSUBJECT.Text = string.Empty;
                memCONTENT.Text = string.Empty;
                memCS_CONTENT.Text = string.Empty;

                txtPROGRAM_NAME.EditValue = string.Empty;
                txtRCV_USERDEPTDESC.EditValue = string.Empty;
                
                dteIDATE.EditValue = DateTime.Today.ToShortDateString();

                cboPROCESS.EditValue = "N"; // 미처리
                cboPROCESS.Properties.ReadOnly = true;

                btnAttach2.Enabled = false;
                btnFileDelete2.Enabled = false;
            }
        }
        #endregion 화면 초기화 - initPage

        #region 저장 - btnSave_Click
        /// <summary>
        /// 저장
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("저장하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }

            if (!stdValidationManager1.Validation())
            {
                return;
            }


            //요청 첨부파일
            if (!FileSave(ref _afilecode[0], grdFILE))
            {
                MsgBox.Show("파일 업로드에 실패했습니다.");
                return;
            }

            // 회신 첨부파일
            if (!FileSave(ref _afilecode[1], grdFile2))
            {
                MsgBox.Show("파일 업로드에 실패했습니다.");
                return;
            }


            DataPack parameter = new DataPack();
            
            parameter.DataList.Add("CODE", txtCODE.Text );
            parameter.DataList.Add("USERNO", sUSERID);
            parameter.DataList.Add("HNAME", txtHNAME.Text);
            parameter.DataList.Add("DEPTDESC", txtREQ_DEPTDESC.Text);
            parameter.DataList.Add("SUBJECT", txtSUBJECT.Text);
            parameter.DataList.Add("PROCESS", cboPROCESS.EditValue.ToString());
            parameter.DataList.Add("CONTENT", memCONTENT.Text);
            parameter.DataList.Add("CS_CONTENT", memCS_CONTENT.Text);
            parameter.DataList.Add("PROGRAM_ID", txtPROGRAM_ID.Text);
            parameter.DataList.Add("PROGRAM_NAME", txtPROGRAM_NAME.Text);
            parameter.DataList.Add("TELNO", txtTELNO.Text);

            parameter.DataList.Add("GUBUN", cboGUBUN.EditValue.ToString());
            parameter.DataList.Add("RCV_USERNO", pRCV_USERNO);
            parameter.DataList.Add("RCV_USERNAME", txtRCV_USERNAME.Text);
            parameter.DataList.Add("RCV_USERDEPTCD", pRCV_USERDEPTCD);
            parameter.DataList.Add("RCV_USERDEPTDESC", txtRCV_USERDEPTDESC.Text);
            parameter.DataList.Add("RCV_TELNO", txtRCV_TELNO.Text);
            parameter.DataList.Add("REMARK", memREMARK.Text);

            parameter.DataList.Add("AFILECODE", _afilecode[0]);
            parameter.DataList.Add("AFILECODE2", _afilecode[1]);


            //'parameter.ArrayItemCount = 1;

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.C35aDataSource, true, "MENUMANGE.SCSYS024.SAVE_01", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("저장되었습니다.", "확인");

                this.DialogResult = System.Windows.Forms.DialogResult.OK;
                this.Close();
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 저장 - btnSave_Click

        #region 비밀번호 변경
        private void btnPassword_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTELNO.Text))
            {
                MsgBox.Show("비밀번호를 입력하세요!", "경고"); return;
            }

            DataPack parameter = new DataPack();
            parameter.DataList.Add("USER_ID", new string[] { txtREQ_DEPTDESC.Text });
            parameter.DataList.Add("PASSWORD", new string[] { txtTELNO.Text });
            parameter.DataList.Add("LOGIN_USERID", new string[] { sUSERID });

            parameter.ArrayItemCount = 1;

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS006.SAVE_02", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("변경되었습니다.", "확인");
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }

        }
        #endregion

        #region 닫기 - btnClose_Click
        /// <summary>
        /// 닫기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }
        #endregion 닫기 - btnClose_Click

        #region HHI 사용자 팝업 - btnHHIUserPopUp_Click
        /// <summary>
        /// HHI 사용자 팝업
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnHHIUserPopUp_Click(object sender, EventArgs e)
        {

        }
        #endregion HHI 사용자 팝업 - btnHHIUserPopUp_Click

        #region HHI 조직도 - btnDeptPopUp_Click
        /// <summary>
        /// HHI 조직도
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDeptPopUp_Click(object sender, EventArgs e)
        {
            SCSYS002P2 scsys002p2 = new SCSYS002P2();

            if (scsys002p2.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtRCV_USERDEPTDESC.EditValue = scsys002p2.hdnDEPT_CD;
                txtRCV_USERNAME.EditValue = scsys002p2.hdnDEPT_NM;
            }
        }
        #endregion HHI 조직도 - btnDeptPopUp_Click


        #region 첨부파일 조회
        private void SET_AFILECODE(string _afilecode, GridControl grid)
        {
            string strQueryId = "MENUMANGE.SCSYS024.GET_FILE_AFILECODE";

            DataPack parameter = new DataPack();
            parameter.DataList.Add("AFILECODE", _afilecode);
            parameter.DataList.Add("GUBN", "Y");

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.C35aDataSource, false, strQueryId, parameter);
            if (resultSet.IsSuccess)
            {
                grid.DataSource = resultSet.QuerySet.Tables[0];                
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
                return;
            }

        }
        #endregion


        private void btnGetRCVPopup_Click(object sender, EventArgs e)
        {
            SCSYS024P2 popup = new SCSYS024P2();
            popup.pDEPT_CD = "CX90";
            popup.ShowDialog();

            if (popup.pRESULT)
            {
                pRCV_USERNO = popup.pUSERID;
                pRCV_USERDEPTCD = popup.pDEPT_CD;
                txtRCV_USERDEPTDESC.Text = popup.pDEPT_DESC;
                txtRCV_TELNO.Text = popup.pTEL_NO;
                txtRCV_USERNAME.Text = popup.pUSER_NAME;
            }
        }

        private void btnAsgnPopup_Click(object sender, EventArgs e)
        {
            SCSYS006P3 pop = new SCSYS006P3();
            pop.sDEPT_CD = txtRCV_USERDEPTDESC.Text;

            if (pop.ShowDialog() == DialogResult.OK)
            {
                if (pop.hdnRow != null)
                {
                    ClientControlHelper.CtrlNestedDataBind(pop.hdnRow, layoutControlGroup1);
                }
            }
        }

        private void btnAttach_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Multiselect = true;

            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                FileListBinding_InGrid(ofd.FileNames, grvFILE);
            }
        }

        private void btnAttach2_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Multiselect = true;

            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                FileListBinding_InGrid(ofd.FileNames, grvFile2);
            }
        }

        #region 첨부할 파일 목록 그리드에 바인딩하기
        private void FileListBinding_InGrid(string[] files, GridView gridview)
        {
            if (files != null)
            {
                GridView view = gridview;
                DataRow dr;

                foreach (string file in files)
                {
                    FileInfo fi = new FileInfo(file);

                    view.AddNewRow();

                    dr = view.GetFocusedDataRow();
                    dr["CHK"] = "Y";
                    dr["FILENAME2"] = fi.Name;
                    dr["SNO"] = "N";
                    dr["FILEINFO"] = fi.FullName;
                }

                view.UpdateCurrentRow();

            }
        }
        #endregion

        #region 파일명 컬럼 클릭시 이미지일 경우 미리보기 팝업 띄움
        private void grvFILE_RowCellClick(object sender, DevExpress.XtraGrid.Views.Grid.RowCellClickEventArgs e)
        {
            GridView view = sender as GridView;
            
            if (e.Column.FieldName.Equals("FILENAME2") || e.Column.FieldName.Equals("STATUS"))
            {
                ProcessStartInfo startInfo = new ProcessStartInfo("IExplore.exe");

                //string NAS_WEBLINK = HHI.Configuration.AppSectionFactory.AppSection[sGBN + "_NAS_WEBLINK"];
                string NAS_WEBLINK = "http://eas.hhishipas.com/attach/";
                if (view.GetDataRow(e.RowHandle)["FILEPATH"].ToString().ToUpper() == "/HICIMS/C35A/ATTACH")
                { startInfo.Arguments = NAS_WEBLINK + view.GetDataRow(e.RowHandle)["REALFILE"].ToString(); }
                else
                { startInfo.Arguments = NAS_WEBLINK + view.GetDataRow(e.RowHandle)["FILEPATH"].ToString().ToUpper().Replace("/HICIMS/C35A/ATTACH/", "") + "/" + view.GetDataRow(e.RowHandle)["REALFILE"].ToString(); }
                //startInfo.Arguments = NAS_WEBLINK + view.GetDataRow(e.RowHandle)["FILEPATH"].ToString().ToUpper().Replace("/HICIMS/C35A/ATTACH","") + view.GetDataRow(e.RowHandle)["REALFILE"].ToString();

                Process browser = new Process();
                browser.StartInfo = startInfo;
                browser.Start();
            }
        }
        #endregion


        #region 파일 저장
        private bool FileSave(ref string afilecode, GridControl grid)
        {
            bool isReturn;
            DataTable procDt = grid.DataSource as DataTable;
            
            if (procDt.Rows.Count == 0)
            {
                //MsgBox.Show("저장할 데이터가 없습니다.");
                return true;
            }

            DataRow[] newFileRow = procDt.Select("CHK = 'Y'");
            if (newFileRow.Length > 0)
            {
                string savePath = string.Empty;
                for (int i = 0; i < newFileRow.Length; i++)
                {
                    DataTable dt = getAfileSno(afilecode);
                    afilecode = dt.Rows[0]["AFILECODE"].ToString();

                    string in_sno = string.Empty;
                    string in_filename = string.Empty;
                    string in_realfile = string.Empty;
                    string in_filepath = string.Empty;

                    if (newFileRow[i]["SNO"].ToString().Equals("N"))
                    {
                        FileInfo fi = new FileInfo(newFileRow[i]["FILEINFO"].ToString());

                        in_sno = dt.Rows[0]["SNO"].ToString();
                        in_realfile = afilecode + in_sno + fi.Extension;
                        in_filename = newFileRow[i]["FILENAME2"].ToString();

                        in_filepath = "/hicims/c35a/attach";

                        MngHelpers.NASFileUpLoad(NASInfo.DEFAULT, @"CA02R\resin1.2.0\doc\hicims\c35a\attach", in_realfile, File.ReadAllBytes(fi.FullName));                        
                    }
                    else
                    {
                        in_sno = newFileRow[i]["SNO"].ToString();
                        in_filename = newFileRow[i]["FILENAME2"].ToString();
                        in_filepath = newFileRow[i]["FILEPATH"].ToString();
                    }


                    string strQueryId = string.Empty;
                    DataPack parameter = new DataPack();
                    strQueryId = "MENUMANGE.SCSYS024.R35AS_AFILECODE_SAVE";

                    parameter.DataList.Add("AFILECODE", afilecode);
                    parameter.DataList.Add("SNO", in_sno);
                    parameter.DataList.Add("REALFILE", in_realfile);
                    parameter.DataList.Add("FILENAME", in_filename);
                    parameter.DataList.Add("FILEPATH", in_filepath);                    
                      
                    parameter.DataList.Add("DEPT", hdnRow == null ? sUSER_DEPT : pRCV_USERDEPTCD);    
                    parameter.DataList.Add("DESC1", "");
                    parameter.DataList.Add("STATUS", "");

                    DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.C35aDataSource, true, strQueryId, parameter);

                    if (!resultSet.IsSuccess)
                    {
                        MsgBox.Show(resultSet.ExceptionMessage);
                        return false;
                    }

                }

                return true;
            }

            return true;
        }
        #endregion

        #region afilecode, sno 가져오기
        public static DataTable getAfileSno(string afilecode)
        {
            string strQueryId = string.Empty;
            DataPack parameter = new DataPack();
            DataTable dt = new DataTable();
            DataResultSet resultSet = new DataResultSet();

            try
            {
                if (!string.IsNullOrEmpty(afilecode))
                {
                    strQueryId = "MENUMANGE.SCSYS024.R35AS_AFILECODE_CH2";
                    parameter.DataList.Add("AFILECODE", afilecode);
                    resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.C35aDataSource, false, strQueryId, parameter);
                    if (resultSet.IsSuccess)
                    {
                        dt = resultSet.QuerySet.Tables[0];
                        if (dt.Rows.Count == 0)
                        {
                            DataRow dr = dt.NewRow();

                            dr["AFILECODE"] = afilecode;
                            dr["SNO"] = "01";

                            dt.Rows.Add(dr);
                        }
                    }
                    else
                    {
                        throw new Exception(resultSet.ExceptionMessage);
                    }
                }
                else
                {
                    strQueryId = "MENUMANGE.SCSYS024.R35AS_AFILECODE_CH";
                    resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.C35aDataSource, false, strQueryId, parameter);
                    if (resultSet.IsSuccess)
                    {
                        dt = resultSet.QuerySet.Tables[0];
                    }
                    else
                    {
                        throw new Exception(resultSet.ExceptionMessage);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }
        #endregion

        private void btnSearchProgramPopup_Click(object sender, EventArgs e)
        {

            SCSYS024P3 popup = new SCSYS024P3();
            popup.pUSERID = sUSERID;

            popup.ShowDialog();

            if (popup.pRESULT)
            {
                txtPROGRAM_ID.Text = popup.pPROGRAM_ID;
                txtPROGRAM_NAME.Text = popup.pPROGRAM_NAME;
            }

        }

        private void btnFileDelete_Click(object sender, EventArgs e)
        {
            if ((grdFILE.DataSource as DataTable).Select("CHK = 'Y'").Length > 0)
            {
                if (MsgBox.Show("선택한 내용을 삭제하시겠습니까?", "첨부파일삭제", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                    return;

                DataRow[] arrDr1 = (grdFILE.DataSource as DataTable).Select("CHK = 'Y' AND SNO <> 'N'");
                if (arrDr1.Length > 0)
                {
                    string strQueryId = "MENUMANGE.SCSYS024.R35AS_AFILECODE_DELETE";
                    Hashtable hParams = new Hashtable();

                    for (int i = 0; i < arrDr1.Length; i++)
                    {
                        DataPack parameter = new DataPack();
                        //Helpers.DataTableToDataPack(ref parameter, arrDr1.CopyToDataTable(), arrParamNames);
                        parameter.DataList.Add("AFILECODE", arrDr1[i]["AFILECODE"].ToString());
                        parameter.DataList.Add("SNO", arrDr1[i]["SNO"].ToString());

                        parameter.DataList.Add("GUBUN", "REQ");

                        DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.C35aDataSource, true, strQueryId, parameter);

                        if (!resultSet.IsSuccess)
                        {
                            MsgBox.Show(resultSet.ExceptionMessage);
                            return;
                        }
                    }
                }

                DataRow[] arrDr2 = (grdFILE.DataSource as DataTable).Select("CHK <> 'Y'");

                //getFileinfo(_afilecode[0]);
                DataTable comDt = (grdFILE.DataSource as DataTable).Clone();
                if (arrDr2.Length > 0)
                {
                    foreach (DataRow dr in arrDr2)
                    {
                        if (dr["SNO"].ToString().Equals("N"))
                            dr["CHK"] = "Y";
                    }
                    comDt = arrDr2.CopyToDataTable();
                }
                else
                {
                    _afilecode[1] = "";
                    comDt.Clear();

                    //DataRowView drView = _parentGridView.GetRow(sROWINDX) as DataRowView;
                    //if (drView != null)
                    //{
                    //    drView["DAM"] = "0";
                    //}

                }

                grdFILE.DataSource = comDt;

            }
        }

        private void btnFileDelete2_Click(object sender, EventArgs e)
        {
            if ((grdFile2.DataSource as DataTable).Select("CHK = 'Y'").Length > 0)
            {
                if (MsgBox.Show("선택한 내용을 삭제하시겠습니까?", "첨부파일삭제", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                    return;

                DataRow[] arrDr1 = (grdFile2.DataSource as DataTable).Select("CHK = 'Y' AND SNO <> 'N'");
                if (arrDr1.Length > 0)
                {
                    string strQueryId = "MENUMANGE.SCSYS024.R35AS_AFILECODE_DELETE";
                    Hashtable hParams = new Hashtable();

                    for (int i = 0; i < arrDr1.Length; i++)
                    {
                        DataPack parameter = new DataPack();
                        //Helpers.DataTableToDataPack(ref parameter, arrDr1.CopyToDataTable(), arrParamNames);
                        parameter.DataList.Add("AFILECODE", arrDr1[i]["AFILECODE"].ToString());
                        parameter.DataList.Add("SNO", arrDr1[i]["SNO"].ToString());

                        parameter.DataList.Add("GUBUN", "RCV");

                        DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.C35aDataSource, true, strQueryId, parameter);

                        if (!resultSet.IsSuccess)
                        {
                            MsgBox.Show(resultSet.ExceptionMessage);
                            return;
                        }
                    }
                }

                DataRow[] arrDr2 = (grdFile2.DataSource as DataTable).Select("CHK <> 'Y'");

                //getFileinfo(_afilecode[0]);
                DataTable comDt = (grdFile2.DataSource as DataTable).Clone();
                if (arrDr2.Length > 0)
                {
                    foreach (DataRow dr in arrDr2)
                    {
                        if (dr["SNO"].ToString().Equals("N"))
                            dr["CHK"] = "Y";
                    }
                    comDt = arrDr2.CopyToDataTable();
                }
                else
                {
                    _afilecode[0] = "";
                    comDt.Clear();

                    //DataRowView drView = _parentGridView.GetRow(sROWINDX) as DataRowView;
                    //if (drView != null)
                    //{
                    //    drView["DAM"] = "0";
                    //}

                }

                grdFile2.DataSource = comDt;
            }
        }

        
    
    }
}
