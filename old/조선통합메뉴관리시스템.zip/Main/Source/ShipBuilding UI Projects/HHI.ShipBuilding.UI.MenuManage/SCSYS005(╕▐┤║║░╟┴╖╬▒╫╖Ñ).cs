﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using DevExpress.XtraTreeList.Nodes;
using HHI.Windows.Forms;
using System.Collections;
using DevExpress.XtraEditors;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS005 : StdUserControlBase
    {
        DataTable dtTreeMenu = null;
        TreeListNode currentNode = null;

        Dictionary<string, DataRow> dicNodeCacheKey = new Dictionary<string, DataRow>();
        DataTable dtNodeCache = null;

        string PrevMenuId = string.Empty;

        public SCSYS005()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }

        #region 화면 Load - SCSYS005_Load
        /// <summary>
        /// 화면 Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SCSYS005_Load(object sender, EventArgs e)
        {
            
        }
        #endregion 화면 Load - SCSYS005_Load

        #region SCSYS005_Shown
        private void SCSYS005_Shown(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                initPage();

                stdSecurityManager1.ApplySecurity(this.SecurityContext);
            }
        }
        #endregion

        #region 화면 초기화 - initPage
        /// <summary>
        /// 화면 초기화
        /// </summary>
        private void initPage()
        {
            CreatedtNodeCache();

            //txtMenu_Id.EditValueChanged += TextEdit_EditValueChanged;
            //txtProgram_Id.EditValueChanged += TextEdit_EditValueChanged;
            //txtTitle.EditValueChanged += TextEdit_EditValueChanged;
            //txtDisplay_Title.EditValueChanged += TextEdit_EditValueChanged;
            //txtExtra_Info.EditValueChanged += TextEdit_EditValueChanged;
            //txtMenu_Order.EditValueChanged += TextEdit_EditValueChanged;

            txtMenu_Id.Leave += txt_Leave;
            txtProgram_Id.Leave += txt_Leave;
            txtTitle.Leave += txt_Leave;
            txtDisplay_Title.Leave += txt_Leave;
            txtExtra_Info.Leave += txt_Leave;
            txtMenu_Order.Leave += txt_Leave;

            luCustom_Action.EditValueChanged += LookUpEdit_EditValueChanged;
            luMenu_Action.EditValueChanged += LookUpEdit_EditValueChanged;

            chkExpanded.CheckedChanged += CheckEdit_CheckedChanged;
            chkMenu_Hide.CheckedChanged += CheckEdit_CheckedChanged;
            chkUse_Yn.CheckedChanged += CheckEdit_CheckedChanged;

            // 시스템
            //ClientControlHelper.LookUpBind(luSystem, GetSystemLookUpData(), "SYSTEM_NAME", "SYSTEM_CODE");
            // 메뉴 Action
            ClientControlHelper.LookUpBind(luMenu_Action, ClientControlHelper.GetCodeInfo("SY004"), "CDNM", "CDCODE");
            // 커스텀액션
            ClientControlHelper.LookUpBind(luCustom_Action, ClientControlHelper.GetCodeInfo("SY005"), "CDNM", "CDCODE");

            DataTable dt = GetTopMenuList();
            var allRow = dt.NewRow();
            allRow["SYSTEM_CODE"] = "";
            allRow["SYSTEM_NAME"] = "전체";
            dt.Rows.InsertAt(allRow, 0);
            dt.AcceptChanges();
            luSYSTEM_CODE.Properties.DataSource = dt;
            luSYSTEM_CODE.Properties.DisplayMember = "SYSTEM_NAME";
            luSYSTEM_CODE.Properties.ValueMember = "SYSTEM_CODE";
            luSYSTEM_CODE.Properties.DropDownRows = 15;
            luSYSTEM_CODE.ItemIndex = 0;

            //btnSearch.PerformClick();
        }

        void txt_Leave(object sender, EventArgs e)
        {
            DevExpress.XtraEditors.TextEdit textEdit = sender as DevExpress.XtraEditors.TextEdit;

            string strKey = ClientControlHelper.GetControlKeyValue((Control)sender);

            if (currentNode != null)
            {
                if (!textEdit.EditValue.ToString().Equals(currentNode.GetValue(strKey).ToString()))
                {
                    SetNodesCacheData(strKey, textEdit.EditValue.ToString());
                }
            }

            if (textEdit == txtMenu_Id)
            {
                DataTable dt = treeMenu.DataSource as DataTable;

                DataRow[] dr = dt.Select("MENU_ID = '" + txtMenu_Id.Text + "'");

                if (dr != null && dr.Length > 0)
                {
                    if (dr.Length > 1)
                    {
                        MsgBox.Show(this, "존재하는 메뉴 아이디 입니다.", "오류", MessageBoxButtons.OK, ImageKinds.Error);
                        txtMenu_Id.Focus();
                    }
                }
            }
        }

        

        #region CheckEdit 변경 - CheckEdit_CheckedChanged
        /// <summary>
        /// CheckEdit 변경
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckEdit_CheckedChanged(object sender, EventArgs e)
        {
            DevExpress.XtraEditors.CheckEdit checkEdit = sender as DevExpress.XtraEditors.CheckEdit;

            string strKey = ClientControlHelper.GetControlKeyValue((Control)sender);

            if (currentNode != null)
            {
                string strVal = checkEdit.Checked ? "Y" : "N";
                if (!strVal.Equals(currentNode.GetValue(strKey).ToString()))
                {
                    SetNodesCacheData(strKey, checkEdit.EditValue.ToString());
                }
            }
        }
        #endregion CheckEdit 변경 - CheckEdit_CheckedChanged

        #region LookUpEdit 변경 - LookUpEdit_EditValueChanged
        /// <summary>
        /// LookUpEdit 변경
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LookUpEdit_EditValueChanged(object sender, EventArgs e)
        {
            DevExpress.XtraEditors.LookUpEdit lookUpEdit = sender as DevExpress.XtraEditors.LookUpEdit;

            string strKey = ClientControlHelper.GetControlKeyValue((Control)sender);

            if (currentNode != null)
            {
                if (!lookUpEdit.EditValue.ToString().Equals(currentNode.GetValue(strKey).ToString()))
                {
                    SetNodesCacheData(strKey, lookUpEdit.EditValue.ToString());
                }
            }
        }
        #endregion LookUpEdit 변경 - LookUpEdit_EditValueChanged

        #region TextEdit Value 변경 - TextEdit_EditValueChanged
        
        /// <summary>
        /// TextEdit Value 변경
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TextEdit_EditValueChanged(object sender, EventArgs e)
        {
            //DevExpress.XtraEditors.TextEdit textEdit = sender as DevExpress.XtraEditors.TextEdit;

            //string strKey = ClientControlHelper.GetControlKeyValue((Control)sender);

            //if (currentNode != null)
            //{
            //    if (!textEdit.EditValue.ToString().Equals(currentNode.GetValue(strKey).ToString()))
            //    {
            //        SetNodesCacheData(strKey, textEdit.EditValue.ToString());
            //    }
            //}
        }
        #endregion TextEdit Value 변경 - TextEdit_EditValueChanged


        #region 트리 노드 신규/수정 캐시 테이블 저장
        /// <summary>
        /// 트리 노드 신규/수정 캐시 테이블 저장
        /// </summary>
        /// <param name="strKey"></param>
        /// <param name="strVal"></param>
        private void SetNodesCacheData(string strKey, string strVal)
        {
            BeforeInvokeServer();

            if(strKey.Equals("MENU_ID"))
            {
                if (dicNodeCacheKey.ContainsKey(currentNode.GetValue("MENU_ID").ToString()))
                {
                    dicNodeCacheKey.Remove(currentNode.GetValue("MENU_ID").ToString());
                }
            }

            currentNode.SetValue(strKey, strVal);
            TreeListNode parentNode = currentNode.ParentNode;

            //string rootNode = currentNode.RootNode.GetValue("MENU_ID").ToString();

            int iOrder = 0;
            if (parentNode != null && parentNode.HasChildren)
            {
                foreach (TreeListNode node in parentNode.Nodes)
                {
                    node.SetValue("MENU_ORDER", iOrder);
                    
                    DataRow rowNode = ((DataRowView)treeMenu.GetDataRecordByNode(node)).Row;

                    if (dicNodeCacheKey.ContainsKey(rowNode["MENU_ID"].ToString()))
                    {
                        dicNodeCacheKey.Remove(rowNode["MENU_ID"].ToString());
                    }
                                        
                    DataRow newRow = dtNodeCache.NewRow();
                    newRow["MENU_ID"] = rowNode["MENU_ID"];
                    newRow["SYSTEM_CODE"] = node.RootNode.GetValue("MENU_ID").ToString();//rowNode["SYSTEM_CODE"];
                    newRow["SYSTEM_NAME"] = rowNode["SYSTEM_NAME"];
                    newRow["PARENT_ID"] = node.GetValue("PARENT_ID").ToString();
                    newRow["PARENT_TITLE"] = node.GetValue("PARENT_TITLE").ToString();
                    newRow["PROGRAM_ID"] = rowNode["PROGRAM_ID"];
                    newRow["PROGRAM_NAME"] = rowNode["PROGRAM_NAME"];
                    newRow["TITLE"] = rowNode["TITLE"];
                    newRow["DISPLAY_TITLE"] = rowNode["DISPLAY_TITLE"];
                    newRow["MENU_ACTION"] = rowNode["MENU_ACTION"];
                    newRow["EXTRA_INFO"] = rowNode["EXTRA_INFO"];
                    newRow["CUSTOM_ACTION"] = rowNode["CUSTOM_ACTION"];
                    newRow["MENU_ORDER"] = rowNode["MENU_ORDER"];
                    newRow["EXPANDED"] = rowNode["EXPANDED"];
                    newRow["MENU_HIDE"] = rowNode["MENU_HIDE"];
                    newRow["USE_YN"] = rowNode["USE_YN"];
                    newRow["ROW_STATUS"] = rowNode.RowState == DataRowState.Added ? "ADD" : "UPD";

                    dicNodeCacheKey.Add(rowNode["MENU_ID"].ToString(), newRow);
                    
                    iOrder++;
                }
            }
            else
            {
                foreach (TreeListNode node in treeMenu.Nodes)
                {
                    node.SetValue("MENU_ORDER", iOrder);

                    DataRow rowNode = ((DataRowView)treeMenu.GetDataRecordByNode(node)).Row;

                    if (dicNodeCacheKey.ContainsKey(rowNode["MENU_ID"].ToString()))
                    {
                        dicNodeCacheKey.Remove(rowNode["MENU_ID"].ToString());
                    }

                    DataRow newRow = dtNodeCache.NewRow();
                    newRow["MENU_ID"] = rowNode["MENU_ID"];
                    newRow["SYSTEM_CODE"] = node.RootNode.GetValue("MENU_ID").ToString(); //rowNode["SYSTEM_CODE"];
                    newRow["SYSTEM_NAME"] = rowNode["SYSTEM_NAME"];
                    newRow["PARENT_ID"] = node.GetValue("PARENT_ID").ToString();
                    newRow["PARENT_TITLE"] = node.GetValue("PARENT_TITLE").ToString();
                    newRow["PROGRAM_ID"] = rowNode["PROGRAM_ID"];
                    newRow["PROGRAM_NAME"] = rowNode["PROGRAM_NAME"];
                    newRow["TITLE"] = rowNode["TITLE"];
                    newRow["DISPLAY_TITLE"] = rowNode["DISPLAY_TITLE"];
                    newRow["MENU_ACTION"] = rowNode["MENU_ACTION"];
                    newRow["EXTRA_INFO"] = rowNode["EXTRA_INFO"];
                    newRow["CUSTOM_ACTION"] = rowNode["CUSTOM_ACTION"];
                    newRow["MENU_ORDER"] = rowNode["MENU_ORDER"];
                    newRow["EXPANDED"] = rowNode["EXPANDED"];
                    newRow["MENU_HIDE"] = rowNode["MENU_HIDE"];
                    newRow["USE_YN"] = rowNode["USE_YN"];
                    newRow["ROW_STATUS"] = rowNode.RowState == DataRowState.Added ? "ADD" : "UPD";

                    dicNodeCacheKey.Add(rowNode["MENU_ID"].ToString(), newRow);

                    iOrder++;
                }
            }

            AfterInvokeServer();
        }
        #endregion 트리 노드 신규/수정 캐시 테이블 저장

        #region 트리 캐시 DataTable 초기화 - CreatedtNodeCache
        /// <summary>
        /// 트리 캐시 DataTable 초기화
        /// </summary>
        private void CreatedtNodeCache()
        {
            dtNodeCache = new DataTable();
            dtNodeCache.Columns.Add("MENU_ID");
            dtNodeCache.Columns.Add("SYSTEM_CODE");
            dtNodeCache.Columns.Add("SYSTEM_NAME");
            dtNodeCache.Columns.Add("PARENT_ID");
            dtNodeCache.Columns.Add("PARENT_TITLE");
            dtNodeCache.Columns.Add("PROGRAM_ID");
            dtNodeCache.Columns.Add("PROGRAM_NAME");
            dtNodeCache.Columns.Add("TITLE");
            dtNodeCache.Columns.Add("DISPLAY_TITLE");
            dtNodeCache.Columns.Add("MENU_ACTION");
            dtNodeCache.Columns.Add("EXTRA_INFO");
            dtNodeCache.Columns.Add("CUSTOM_ACTION");
            dtNodeCache.Columns.Add("MENU_ORDER");
            dtNodeCache.Columns.Add("EXPANDED");
            dtNodeCache.Columns.Add("MENU_HIDE");
            dtNodeCache.Columns.Add("USE_YN");
            dtNodeCache.Columns.Add("ROW_STATUS");
        }
        #endregion 트리 캐시 DataTable 초기화 - CreatedtNodeCache

        #region 시스템 조회 - GetSystemLookUpData
        /// <summary>
        /// 시스템 조회
        /// </summary>
        /// <returns></returns>
        private DataTable GetSystemLookUpData()
        {
            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCCOMMON.SEARCH_SYSTEM").QuerySet.Tables[0];
        }

        private DataTable GetTopMenuList()
        {
            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS005.TOP_MENU_LIST").QuerySet.Tables[0];
        }

        #endregion 시스템 조회 - GetSystemLookUpData

        #endregion 화면 초기화 - initPage

        #region 조회 - btnSearch_Click
        /// <summary>
        /// 조회
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            System.Data.DataRowView dr = (System.Data.DataRowView)treeMenu.GetDataRecordByNode(treeMenu.FocusedNode);
            if (dr != null)
            {
                PrevMenuId = Convert.ToString(dr["MENU_ID"]);
            }

            DataResultSet resultSet = GetMenuInfo();
            dicNodeCacheKey.Clear();
            if (resultSet.IsSuccess)
            {
                var rows = resultSet.QuerySet.Tables[0].Select("", "MENU_ORDER");

                if (rows != null && rows.Length > 0)
                {
                    treeMenu.DataSource = rows.CopyToDataTable();
                    treeMenu.RefreshDataSource();
                }
                else
                {
                    treeMenu.DataSource = resultSet.QuerySet.Tables[0];
                    treeMenu.RefreshDataSource();
                }

                
                treeMenu.CollapseAll();
                //treeMenu.ExpandAll();
                //if(treeMenu.Nodes.Count > 0)
                //    treeMen.Expanded = true;
                treeMenu.VertScrollVisibility = DevExpress.XtraTreeList.ScrollVisibility.Always;
                treeMenu.HorzScrollVisibility = DevExpress.XtraTreeList.ScrollVisibility.Always;
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }

            try
            {
                TreeListNode fnode = treeMenu.FindNodeByFieldValue("MENU_ID", PrevMenuId);

                if (fnode != null)
                {
                    SelectNode(fnode);
                }
                else if (string.IsNullOrEmpty(currentDeletedNodeParentId) == false)
                {
                    fnode = treeMenu.FindNodeByFieldValue("MENU_ID", currentDeletedNodeParentId);
                    SelectNode(fnode);
                    currentDeletedNodeParentId = string.Empty;
                    fnode.Expanded = true;
                }
                else
                {
                    treeMenu.MoveFirst();
                }
            }
            catch
            {

            }
            finally
            {
                PrevMenuId = string.Empty;
            }
            
        }
        #endregion 조회 - btnSearch_Click

        #region 메뉴정보 조회 - GetMenuInfo
        /// <summary>
        /// 메뉴정보 조회
        /// </summary>
        /// <param name="strSystem_Code"></param>
        /// <param name="strMenu_Id"></param>
        /// <param name="strMenu_Nm"></param>
        /// <returns></returns>
        private DataResultSet GetMenuInfo()
        {
            DataPack parameter = new DataPack();

            if (radioGroup1.SelectedIndex == 0)
            {
                parameter.DataList.Add("SYSTEM_CODE", null);
                parameter.DataList.Add("TOP_MENU_ID", luSYSTEM_CODE.EditValue.ToString());
            }   
            else
            {
                parameter.DataList.Add("SYSTEM_CODE", luSYSTEM_CODE.EditValue.ToString());
                parameter.DataList.Add("TOP_MENU_ID", null);
            }
                
                
            BeforeInvokeServer();

            try
            {
                return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS005.SEARCH_01", parameter);
            }
            catch
            {
                throw;
            }
            finally
            {
                AfterInvokeServer();
            }
            
        }
        #endregion 메뉴정보 조회 - GetMenuInfo

        #region 저장 - btnSave_Click
        /// <summary>
        /// 저장
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {
            DataTable dtNodes = null;
            if (dicNodeCacheKey.Count > 0)
            {
                dtNodes = dicNodeCacheKey.Values.CopyToDataTable();
            }

            #region 트리 노드 정보 유효성 체크

            if (dtNodes == null || dtNodes.Rows.Count == 0)
            {
                MsgBox.Show("저장할 정보가 없습니다!", "경고");
                return;
            }

            foreach (DataRow rowCheck in dtNodes.Rows)
            {
                TreeListNode nodeCheck = treeMenu.FindNodeByFieldValue("MENU_ID", rowCheck["MENU_ID"].ToString());

                if (string.IsNullOrWhiteSpace(rowCheck["MENU_ID"].ToString()))
                {
                    MsgBox.Show("메뉴ID 는 필수 입력 입니다!", "경고");
                    treeMenu.FocusedNode = nodeCheck;
                    return;
                }

                if (rowCheck["MENU_ID"].ToString().Length > 15)
                {
                    MsgBox.Show("메뉴ID 자리수는 15자리이하여야합니다.", "경고");
                    treeMenu.FocusedNode = nodeCheck;
                    return;
                }

                //if (string.IsNullOrWhiteSpace(rowCheck["SYSTEM_CODE"].ToString()))
                //{
                //    MsgBox.Show("시스템을 선택 하세요!", "경고");
                //    treeMenu.FocusedNode = nodeCheck;
                //    return;
                //}

                if (string.IsNullOrWhiteSpace(rowCheck["TITLE"].ToString()))
                {
                    MsgBox.Show("메뉴 Title 은 필수 입력 입니다!", "경고");
                    treeMenu.FocusedNode = nodeCheck;
                    return;
                }

                if (string.IsNullOrWhiteSpace(rowCheck["MENU_ACTION"].ToString()))
                {
                    MsgBox.Show("메뉴 Action을 선택 하세요!", "경고");
                    treeMenu.FocusedNode = nodeCheck;
                    return;
                }

                if (string.IsNullOrWhiteSpace(rowCheck["CUSTOM_ACTION"].ToString()))
                {
                    MsgBox.Show("커스텀액션을 선택 하세요!", "경고");
                    treeMenu.FocusedNode = nodeCheck;
                    return;
                }

                // openUI or customaction 일 경우 프로그램id 체크
                if ((rowCheck["MENU_ACTION"].ToString().Equals("2") || rowCheck["MENU_ACTION"].ToString().Equals("4096")) && string.IsNullOrWhiteSpace(rowCheck["PROGRAM_ID"].ToString()))
                {
                    MsgBox.Show("프로그램을 등록하세요!", "경고");
                    treeMenu.FocusedNode = nodeCheck;
                    return;
                }
                if ((!rowCheck["MENU_ACTION"].ToString().Equals("3") && !rowCheck["MENU_ACTION"].ToString().Equals("0")) && rowCheck["PARENT_ID"].ToString().Equals("ROOT"))
                {
                    MsgBox.Show("최상위엔 프로그램을 등록할수 없습니다.시스템폴더를 생성후 등록하세요!", "경고");
                    treeMenu.FocusedNode = nodeCheck;
                    return;
                }
            }

            #endregion 트리 노드 정보 유효성 체크

            string[] paramnames = new string[] { "MENU_ID", "SYSTEM_CODE", "PARENT_ID", "PROGRAM_ID", "TITLE", "DISPLAY_TITLE", "MENU_ACTION", "EXTRA_INFO", "CUSTOM_ACTION", "MENU_ORDER", "EXPANDED", "MENU_HIDE", "USE_YN", "ROW_STATUS", "LOGIN_USERID" };

            DataTable dtParam = new DataTable();
            for (int i = 0; i < paramnames.Length; i++)
            {
                dtParam.Columns.Add(paramnames[i]);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in dtParam.Columns)
            {
                string[] col1 = new string[dtNodes.Rows.Count];
                for (int i = 0; i < dtNodes.Rows.Count; i++)
                {
                    if (col.ColumnName.Equals("LOGIN_USERID"))
                    {
                        col1[i] = UserInfo == null ? "ADMIN" : UserInfo.UserID; //eve
                    }
                    else
                    {
                        col1[i] = dtNodes.Rows[i][col.ColumnName].ToString();
                    }
                }

                parameter.DataList.Add(col.ColumnName, col1);
            }

            parameter.ArrayItemCount = dtNodes.Rows.Count;

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS005.SAVE_01", parameter);

            if (resultSet.IsSuccess)
            {
                dicNodeCacheKey.Clear();

                MsgBox.Show("저장되었습니다.", "확인");

                btnSearch.PerformClick();
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 저장 - btnSave_Click

        #region 저장하는 트리 노드의 MENU_ORDER 업데이트 - TreeMenuOrderUpDate
        /// <summary>
        /// 저장하는 트리 노드의 MENU_ORDER 업데이트
        /// </summary>
        private void TreeMenuOrderUpDate()
        {
            if (treeMenu.Nodes.Count > 0)
            {
                string[] paramnames = new string[] { "MENU_ID", "MENU_ORDER" };

                DataTable dtParam = new DataTable();
                for (int i = 0; i < paramnames.Length; i++)
                {
                    dtParam.Columns.Add(paramnames[i]);
                }

                DataPack parameter = new DataPack();

                foreach (DataColumn col in dtParam.Columns)
                {
                    TreeListNode parentNode = currentNode.ParentNode;
                    if (parentNode.HasChildren)
                    {
                        string[] col1 = new string[parentNode.Nodes.Count];

                        for (int iNode = 0; iNode < parentNode.Nodes.Count; iNode++)
                        {
                            DataRow row = ((DataRowView)treeMenu.GetDataRecordByNode(parentNode.Nodes[iNode])).Row;

                            if (col.ColumnName.Equals("MENU_ORDER"))
                            {
                                col1[iNode] = (iNode + 1).ToString();
                            }
                            else
                            {
                                col1[iNode] = row[col.ColumnName].ToString();
                            }
                        }

                        parameter.DataList.Add(col.ColumnName, col1);
                    }
                }

                parameter.ArrayItemCount = currentNode.ParentNode.Nodes.Count; //==> ArrayBind 처리시... 항상 지정해야함...

                DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS005.UPDATE_01", parameter);

                if (resultSet.IsSuccess)
                {
                    //MsgBox.Show("저장 되었습니다.");
                    //btnSearch.PerformClick();
                }
                else
                {
                    MsgBox.Show(resultSet.ExceptionMessage);
                }
            }
        }
        #endregion 저장하는 트리 노드의 MENU_ORDER 업데이트 - TreeMenuOrderUpDate

        #region 삭제 - btnDelete_Click

        private string currentDeletedNodeParentId = null;
        /// <summary>
        /// 삭제
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (currentNode != null)
            {
                if (currentNode.HasChildren)
                {
                    MsgBox.Show("하위 메뉴가 존재 합니다.\r\n하위 메뉴을 먼저 삭제 하세요!", "경고");
                    return;
                }

                var res = MsgBox.Show(this, 
                    string.Format("선택된 메뉴 [{0}] 을 삭제 하시겠습니까?", currentNode.GetDisplayText("TITLE")), "메뉴삭제", 
                    MessageBoxButtons.YesNo, ImageKinds.Question);

                if (res != DialogResult.Yes)
                    return;

                DataPack parameter = new DataPack();
                parameter.DataList.Add("MENU_ID", new string[] { txtMenu_Id.Text });

                parameter.ArrayItemCount = 1;
                if (currentNode.ParentNode != null)
                {
                    System.Data.DataRowView dr = (System.Data.DataRowView)treeMenu.GetDataRecordByNode(currentNode.ParentNode);

                    if (dr != null)
                    {
                        currentDeletedNodeParentId = dr["MENU_ID"].ToString();
                    }
                    else
                    {
                        currentDeletedNodeParentId = string.Empty;
                    }
                }

                DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS005.DELETE_01", parameter);

                if (resultSet.IsSuccess)
                {
                    MsgBox.Show("삭제 되었습니다.", "확인");

                    btnSearch.PerformClick();
                }
                else
                {
                    MsgBox.Show(resultSet.ExceptionMessage);
                }
            }
        }
        #endregion 삭제 - btnDelete_Click

        #region 트리 노드 변경 - treeMenu_FocusedNodeChanged
        /// <summary>
        /// 트리 노드 변경
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void treeMenu_FocusedNodeChanged(object sender, DevExpress.XtraTreeList.FocusedNodeChangedEventArgs e)
        {
            if (treeMenu.FocusedNode == null)
            {
                return;
            }

            DataRow row = ((DataRowView)treeMenu.GetDataRecordByNode(treeMenu.FocusedNode)).Row;
            if (row == null)
                return;
            
            currentNode = treeMenu.FocusedNode;

            // 컨트롤 바인딩
            ClientControlHelper.CtrlNestedDataBind(row, layoutControlGroup2);
            if (row["MENU_ID"].ToString().Equals("ROOT"))
            {
                layoutControlGroup2.Enabled = false;
            }
            else
            {
                layoutControlGroup2.Enabled = true;
            }

            if (row["IS_SAVE"].ToString().Equals("Y"))
                txtMenu_Id.Properties.ReadOnly = true;
            else
                txtMenu_Id.Properties.ReadOnly = false;

        }
        #endregion 트리 노드 변경 - treeMenu_FocusedNodeChanged

        #region 트리 우클릭 메뉴 

        #region 트리 우클릭 메뉴 TOP - topToolStripMenuItem_Click
        /// <summary>
        /// 트리 우클릭 메뉴 TOP
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void topToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*
             * 노드 리스트가 없으면 신규 추가
             * 노드를 선택되었는지 체크
             * 선택된 노드와 같은 레벨에서 노드 추가후 index 는 0으로 지정
             */

            if (treeMenu.Nodes.Count == 0)
            {
                TreeMenuRootNodeAppen(0);
            }
            else
            {
                if (treeMenu.FocusedNode != null)
                {
                    //if (treeMenu.FocusedNode["MENU_ID"].ToString().Equals("ROOT"))
                    //{
                    //    MsgBox.Show("최상위 노드와 같은 레벨의 노드를 추가 할 수 없습니다.");
                    //    return;
                    //}

                    CreateEmptyTreeDataSource();

                    string strParentMenu_Id = treeMenu.FocusedNode.ParentNode != null ? treeMenu.FocusedNode.ParentNode["MENU_ID"].ToString() : "ROOT";
                    string strParentMenu_Title = treeMenu.FocusedNode.ParentNode != null ? treeMenu.FocusedNode.ParentNode["TITLE"].ToString() : "조선 통합 메뉴";

                    DataRow newMenuRow = CreateNewNodeData(strParentMenu_Id, strParentMenu_Title);

                    TreeListNode newNode = treeMenu.AppendNode(newMenuRow.ItemArray, treeMenu.FocusedNode.ParentNode);
                    treeMenu.SetNodeIndex(newNode, 0);

                    //신규로 추가된 ROW 캐쉬테이블에 담는다.
                    SetNodesCacheData("PARENT_ID", strParentMenu_Id);
                }
                else
                {
                    MsgBox.Show("노드를 선택 하세요!", "경고");
                }
            }
        }
        #endregion 트리 우클릭 메뉴 TOP - topToolStripMenuItem_Click

        #region 트리 우클릭 메뉴 Bottom - bottomToolStripMenuItem_Click
        /// <summary>
        /// 트리 우클릭 메뉴 Bottom
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bottomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (treeMenu.Nodes.Count == 0)
                TreeMenuRootNodeAppen(0);
            else
            {
                if (treeMenu.FocusedNode != null)
                {
                    if (treeMenu.FocusedNode["MENU_ID"].ToString().Equals("ROOT"))
                    {
                        MsgBox.Show("최상위 노드와 같은 레벨의 노드를 추가 할 수 없습니다.", "경고");
                        return;
                    }

                    CreateEmptyTreeDataSource();

                    string strParentMenu_Id = treeMenu.FocusedNode.ParentNode != null ? treeMenu.FocusedNode.ParentNode["MENU_ID"].ToString() : "ROOT";
                    string strParentMenu_Title = treeMenu.FocusedNode.ParentNode != null ? treeMenu.FocusedNode.ParentNode["TITLE"].ToString() : "HISPICS";

                    DataRow newMenuRow = CreateNewNodeData(strParentMenu_Id, strParentMenu_Title);

                    TreeListNode newNode = treeMenu.AppendNode(newMenuRow.ItemArray, treeMenu.FocusedNode.ParentNode);

                    int iCurrentNodeBottomIndex = treeMenu.FocusedNode.ParentNode != null ? treeMenu.FocusedNode.ParentNode.Nodes.Count : treeMenu.Nodes.Count;
                    treeMenu.SetNodeIndex(newNode, iCurrentNodeBottomIndex);

                    //신규로 추가된 ROW 캐쉬테이블에 담는다.
                    SetNodesCacheData("PARENT_ID", strParentMenu_Id);
                }
                else
                {
                    MsgBox.Show("노드를 선택 하세요!", "경고");
                }
            }
        }
        #endregion 트리 우클릭 메뉴 Bottom - bottomToolStripMenuItem_Click

        #region 트리 우클릭 메뉴 Tree Expand - treeExpandToolStripMenuItem_Click
        /// <summary>
        /// 트리 우클릭 메뉴 Tree Expand
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void treeExpandToolStripMenuItem_Click(object sender, EventArgs e)
        {
            treeMenu.ExpandAll();
        }
        #endregion 트리 우클릭 메뉴 Tree Expand - treeExpandToolStripMenuItem_Click

        #region 트리 우클릭 메뉴 Tree Collapse - treeCollapseToolStripMenuItem_Click
        /// <summary>
        /// 트리 우클릭 메뉴 Tree Collapse
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void treeCollapseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            treeMenu.CollapseAll();
        }
        #endregion 트리 우클릭 메뉴 Tree Collapse - treeCollapseToolStripMenuItem_Click

        #region Root Node 추가 - TreeMenuRootNodeAppen
        /// <summary>
        /// Root Node 추가
        /// </summary>
        /// <param name="rootNodeIndex"></param>
        private void TreeMenuRootNodeAppen(int rootNodeIndex)
        { 
            // 트리 데이터 소스 초기화
            CreateEmptyTreeDataSource();

            DataRow newMenuRow = CreateNewNodeData("ROOT", "조선 통합 메뉴");

            TreeListNode newNode = treeMenu.AppendNode(new object[] { }, null);
            treeMenu.SetNodeIndex(newNode, rootNodeIndex);

            //신규로 추가된 ROW 캐쉬테이블에 담는다.
            SetNodesCacheData("PARENT_ID", "ROOT");

        }
        #endregion Root Node 추가 - TreeMenuRootNodeAppen

        #region 트리 DataSource 초기화 - CreateEmptyTreeDataSource
        /// <summary>
        /// 트리 DataSource 초기화
        /// </summary>
        private void CreateEmptyTreeDataSource()
        {
            if (treeMenu.DataSource == null)
            {
                DataTable dtTree = new DataTable();
                dtTree.Columns.Add("MENU_ID");
                dtTree.Columns.Add("SYSTEM_CODE");
                dtTree.Columns.Add("SYSTEM_NAME");
                dtTree.Columns.Add("PARENT_ID");
                dtTree.Columns.Add("PARENT_TITLE");
                dtTree.Columns.Add("PROGRAM_ID");
                dtTree.Columns.Add("PROGRAM_NAME");
                dtTree.Columns.Add("TITLE");
                dtTree.Columns.Add("DISPLAY_TITLE");
                dtTree.Columns.Add("MENU_ACTION");
                dtTree.Columns.Add("EXTRA_INFO");
                dtTree.Columns.Add("CUSTOM_ACTION");
                dtTree.Columns.Add("MENU_ORDER");
                dtTree.Columns.Add("EXPANDED");
                dtTree.Columns.Add("MENU_HIDE");
                dtTree.Columns.Add("USE_YN");

                treeMenu.DataSource = dtTree;
            }
        }
        #endregion 트리 DataSource 초기화 - CreateEmptyTreeDataSource

        #region 트리 노드 추가 - CreateNewNodeData
        /// <summary>
        /// 트리 노드 추가
        /// </summary>
        /// <param name="strParent_Id"></param>
        /// <param name="strParent_Title"></param>
        /// <returns></returns>
        private DataRow CreateNewNodeData(string strParent_Id, string strParent_Title)
        {
            DataRow newRow = null;
            dtTreeMenu = treeMenu.DataSource as DataTable;
            if (dtTreeMenu != null)
            {
                //string strNewMenuId = Guid.NewGuid().ToString().ToUpper().Substring(0, 7);

                newRow = dtTreeMenu.NewRow();
                newRow["MENU_ID"] = string.Empty;// strNewMenuId;
                newRow["SYSTEM_CODE"] = string.Empty;
                newRow["SYSTEM_NAME"] = string.Empty;
                newRow["PARENT_ID"] = strParent_Id;
                newRow["PARENT_TITLE"] = strParent_Title;
                newRow["PROGRAM_ID"] = string.Empty;
                newRow["PROGRAM_NAME"] = string.Empty;
                newRow["TITLE"] = "메뉴명를 입력 하세요!";
                newRow["DISPLAY_TITLE"] = "Display 메뉴명을 입력 하세요!";
                newRow["MENU_ACTION"] = 0;
                newRow["EXTRA_INFO"] = string.Empty;
                newRow["CUSTOM_ACTION"] = 0;
                newRow["MENU_ORDER"] = 0;
                newRow["EXPANDED"] = "N";
                newRow["MENU_HIDE"] = "N";
                newRow["USE_YN"] = "Y";
                
                newRow["IS_SAVE"] = "N";
                //newRow["TEMP_ID"] = strNewMenuId;

                //dtTreeMenu.Rows.Add(newRow);

                

            }

            return newRow;
        }
        #endregion 트리 노드 추가 - CreateNewNodeData

        #region 프로그램 정보 팝업 - btnProgram_Click
        /// <summary>
        /// 프로그램 정보 팝업
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnProgram_Click(object sender, EventArgs e)
        {
            SCSYS005P1 scsys005p1 = new SCSYS005P1();            
            scsys005p1.hdnRow = null;
            scsys005p1.sSYSTEM_CODE = luSYSTEM_CODE.EditValue == null ? string.Empty : luSYSTEM_CODE.EditValue.ToString();

            if (scsys005p1.ShowDialog() == DialogResult.OK)
            {
                txtProgram_Id.EditValue = scsys005p1.hdnRow["PROGRAM_ID"].ToString();
                txtProgram_Name.EditValue = scsys005p1.hdnRow["PROGRAM_NAME"].ToString();
                txt_Leave(txtProgram_Id, new EventArgs());
            }
        }
        #endregion 프로그램 정보 팝업 - btnProgram_Click

        #endregion 트리 우클릭 메뉴

        #region 트리 노드 AfterDragNode - treeMenu_AfterDragNode
        /// <summary>
        /// 트리 노드 AfterDragNode
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void treeMenu_AfterDragNode(object sender, DevExpress.XtraTreeList.NodeEventArgs e)
        {
            if (currentNode != null)
            {
                SetNodesCacheData("MENU_ID", currentNode.GetValue("MENU_ID").ToString());
            }
        }
        #endregion 트리 노드 AfterDragNode - treeMenu_AfterDragNode

        private void contextMenuStrip_TreeMenu_Opening(object sender, CancelEventArgs e)
        {
            Point pt = treeMenu.PointToClient(MousePosition);
            TreeListNode node = treeMenu.CalcHitInfo(pt).Node;

            if (node == null)
            {
                e.Cancel = true;
                return;
            }

            SelectNode(node);
        }

        private void SelectNode(TreeListNode node)
        {
            treeMenu.FocusedNode = node;
            node.Selected = true;
        }

        private void txtMenu_Id_Leave(object sender, EventArgs e)
        {
            DataTable dt = treeMenu.DataSource as DataTable;

            DataRow[] dr = dt.Select("MENU_ID = '" + txtMenu_Id.Text + "'");

            if (dr != null && dr.Length > 0)
            {
                if (dr.Length > 1)
                {
                    MsgBox.Show(this, "존재하는 메뉴 아이디 입니다.", "오류", MessageBoxButtons.OK, ImageKinds.Error);
                    txtMenu_Id.Focus();
                }
            }
        }

        private void btnTitleCopy_Click(object sender, EventArgs e)
        {
            txtDisplay_Title.Text = txtTitle.Text;
            txt_Leave(txtDisplay_Title, new EventArgs());
        }

        private void radioGroup1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (radioGroup1.SelectedIndex == 0)
            {
                DataTable dt = GetTopMenuList(); 
                var allRow = dt.NewRow();
                allRow["SYSTEM_CODE"] = "";
                allRow["SYSTEM_NAME"] = "전체";
                dt.Rows.InsertAt(allRow, 0);
                dt.AcceptChanges();
                luSYSTEM_CODE.Properties.DataSource = dt;
                luSYSTEM_CODE.Properties.DisplayMember = "SYSTEM_NAME";
                luSYSTEM_CODE.Properties.ValueMember = "SYSTEM_CODE";
                luSYSTEM_CODE.Properties.DropDownRows = 15;
                luSYSTEM_CODE.ItemIndex = 0;

                
                
            }
            else
            {
                DataTable dt = GetSystemLookUpData();
                var allRow = dt.NewRow();
                allRow["SYSTEM_CODE"] = "";
                allRow["SYSTEM_NAME"] = "전체";
                dt.Rows.InsertAt(allRow, 0);
                dt.AcceptChanges();
                luSYSTEM_CODE.Properties.DataSource = dt;
                luSYSTEM_CODE.Properties.DisplayMember = "SYSTEM_NAME";
                luSYSTEM_CODE.Properties.ValueMember = "SYSTEM_CODE";
                luSYSTEM_CODE.Properties.DropDownRows = 15;
                luSYSTEM_CODE.ItemIndex = 0;
            }

            dicNodeCacheKey.Clear();
            treeMenu.ClearNodes();
        }
    }
}
