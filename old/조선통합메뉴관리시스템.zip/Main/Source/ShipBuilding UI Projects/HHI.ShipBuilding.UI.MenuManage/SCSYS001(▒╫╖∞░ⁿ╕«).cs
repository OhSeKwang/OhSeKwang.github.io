﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraEditors.Repository;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS001 : StdUserControlBase
    {
        public SCSYS001()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }

        #region SCSYS001_Load - 화면 Load
        /// <summary>
        /// 화면 Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SCSYS001_Load(object sender, EventArgs e)
        {
            
        }
        #endregion SCSYS001_Load - 화면 Load

        #region SCSYS001_Shown
        private void SCSYS001_Shown(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                initPage();

                stdSecurityManager1.ApplySecurity(this.SecurityContext);
                stdButtonExecuteManager1.RegisterButtonExecEvent();
            }
        }
        #endregion

        #region 화면 초기화 - initPage
        /// <summary>
        /// 화면 초기화
        /// </summary>
        private void initPage()
        {
            // 콤보 바인딩
            ClientControlHelper.ImageComboBind(rpsCboWORK_GUBUN, "CDNM", "CDCODE", "{value}-{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, ClientControlHelper.GetCodeInfo("SY001"));
            ClientControlHelper.ImageComboBind(rpsCboSYSTEM_CODE, "SYSTEM_NAME", "SYSTEM_CODE", "{value}-{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, GetSystemCode());
            ClientControlHelper.ImageComboBind(cboWORK_GUBUN, "CDNM", "CDCODE", "{value}-{text}", ComboDisplayTextOption.top, "전체", string.Empty, ClientControlHelper.GetCodeInfo("SY001"));

            rpsCboWORK_GUBUN.DropDownRows = rpsCboWORK_GUBUN.Items.Count;

            // 그리드 초기화
            DataTable dt = new DataTable();
            dt.Columns.Add("CHK");
            dt.Columns.Add("GROUP_ID");
            dt.Columns.Add("GROUP_NAME");
            dt.Columns.Add("USE_YN");
            dt.Columns.Add("COMMON_GROUP_YN");
            dt.Columns.Add("DESCR");
            dt.Columns.Add("WORK_GUBUN");
            dt.Columns.Add("SYSTEM_CODE");
            dt.Columns.Add("GROUP_AUTH_INFO");

            grdMain.DataSource = dt;
        }
        #endregion 화면 초기화 - initPage

        #region 신규 - btnNew_Click
        /// <summary>
        /// 신규
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNew_Click(object sender, EventArgs e)
        {
            grvMain.AddNewRow();
            grvMain.SetFocusedRowCellValue("CHK", "Y");
            grvMain.SetFocusedRowCellValue("USE_YN", "Y");
        }
        #endregion 신규 - btnNew_Click

        #region 조회 - btnSearch_Click
        /// <summary>
        /// 조회
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string sWORK_GUBUN = cboWORK_GUBUN.EditValue == null ? string.Empty : cboWORK_GUBUN.EditValue.ToString();
            DataResultSet resultSet = GetGroupInfo(sWORK_GUBUN, txtGroup_Name.Text, txtDescr.Text, chkUse_Yn.Checked ? "Y" : "N");

            if (resultSet.IsSuccess)
            {
                grdMain.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 조회 - btnSearch_Click

        #region 그룹정보 조회 - GetGroupInfo
        /// <summary>
        /// 그룹정보 조회
        /// </summary>
        /// <param name="strGroup_Name"></param>
        /// <param name="strDescr"></param>
        /// <returns></returns>
        private DataResultSet GetGroupInfo(string strWORK_GUBUN, string strGroup_Name, string strDescr, string strUse_Yn)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("WORK_GUBUN", strWORK_GUBUN);
            parameter.DataList.Add("GROUP_NAME", strGroup_Name);
            parameter.DataList.Add("DESCR", strDescr);
            parameter.DataList.Add("USE_YN", strUse_Yn);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS001.SEARCH_01", parameter);
        }
        #endregion 그룹정보 조회 - GetGroupInfo

        #region 저장 - btnSave_Click
        /// <summary>
        /// 저장
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("저장 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            
            if (grvMain.RowCount == 0)
            {
                MsgBox.Show("저장할 정보가 없습니다.", "경고"); 
                return; 
            }

            if ((grdMain.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            {
                MsgBox.Show("저장할 정보를 선택하세요!", "경고"); 
                return; 
            }

            DataTable dtMain = (grdMain.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();
            string[] paramnames = new string[] { "GROUP_ID", "GROUP_NAME", "USE_YN", "COMMON_GROUP_YN", "DESCR", "WORK_GUBUN", "SYSTEM_CODE", "GROUP_AUTH_INFO", "LOGIN_USERID" };

            DataTable dtParam = new DataTable();
            for (int i = 0; i < paramnames.Length; i++)
            {
                dtParam.Columns.Add(paramnames[i]);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in dtParam.Columns)
            {
                string[] col1 = new string[dtMain.Rows.Count];
                for (int i = 0; i < dtMain.Rows.Count; i++)
                {
                    if (col.ColumnName.Equals("GROUP_NAME"))
                    {
                        if(string.IsNullOrWhiteSpace(dtMain.Rows[i][col.ColumnName].ToString()))
                        {
                            MsgBox.Show("그룹명은 필수 입력 입니다.", "경고");
                            return;
                        }
                    }
                    else if (col.ColumnName.Equals("WORK_GUBUN"))
                    {
                        if(string.IsNullOrWhiteSpace(dtMain.Rows[i][col.ColumnName].ToString()))
                        {
                            MsgBox.Show("업무구분은 필수 입력 입니다.", "경고");
                            return;
                        }
                    }
                    else if (col.ColumnName.Equals("SYSTEM_CODE"))
                    {
                        if (string.IsNullOrWhiteSpace(dtMain.Rows[i][col.ColumnName].ToString()))
                        {
                            MsgBox.Show("시스템코드는 필수 입력 입니다.", "경고");
                            return;
                        }
                    }

                    if (col.ColumnName.Equals("LOGIN_USERID"))
                    {
                        col1[i] = UserInfo == null ? "ADMIN" : UserInfo.UserID; // eve
                    }
                    else
                    {
                        col1[i] = dtMain.Rows[i][col.ColumnName].ToString();
                    }
                }

                parameter.DataList.Add(col.ColumnName, col1);
            }

            parameter.ArrayItemCount = dtMain.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS001.SAVE_01", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("저장되었습니다.", "확인");
                btnSearch.PerformClick();
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 저장 - btnSave_Click

        #region 삭제 - btnDelete_Click
        /// <summary>
        /// 삭제
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            // 그룹정보와 연관되어있는 사용자정보 메뉴권한정보 체크
            int iGroupRelation = 0;
            
            foreach (DataRow row in (grdMain.DataSource as DataTable).Select("CHK='Y'"))
            { 
                if(int.Parse(row["GROUP_RELATION"].ToString()) > 0)
                {
                    iGroupRelation++;        
                }
            }

            if(iGroupRelation > 0)
            {
                if (MsgBox.Show("그룹정보에 연관되어 있는 사용자정보 또는 메뉴권한정보가 존재합니다. \r\n관련정보가 모두 함께 삭제됩니다. \r\n삭제 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                { return; }
            }
            else 
            {
                if (MsgBox.Show("삭제 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                { return; }
            }

            if (grvMain.RowCount == 0)
            {
                MsgBox.Show("삭제할 정보가 없습니다.", "경고");
                return;
            }

            if ((grdMain.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            {
                MsgBox.Show("삭제할 정보를 선택하세요!", "경고");
                return;
            }

            DataTable dtMain = (grdMain.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();
            string[] paramnames = new string[] { "GROUP_ID" };

            DataTable dtParam = new DataTable();
            for (int i = 0; i < paramnames.Length; i++)
            {
                dtParam.Columns.Add(paramnames[i]);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in dtParam.Columns)
            {
                string[] col1 = new string[dtMain.Rows.Count];
                for (int i = 0; i < dtMain.Rows.Count; i++)
                {
                    if (col.ColumnName.Equals("USER_ID"))
                    {
                        if (string.IsNullOrWhiteSpace(dtMain.Rows[i][col.ColumnName].ToString()))
                        {
                            MsgBox.Show("사용자ID는 필수 입력 입니다.", "경고");
                            return;
                        }
                    }

                    if (col.ColumnName.Equals("GROUP_ID"))
                    {
                        if (string.IsNullOrWhiteSpace(dtMain.Rows[i][col.ColumnName].ToString()))
                        {
                            MsgBox.Show("그룹ID는 필수 입력 입니다.", "경고");
                            return;
                        }
                    }

                    
                    col1[i] = dtMain.Rows[i][col.ColumnName].ToString();
                }

                parameter.DataList.Add(col.ColumnName, col1);
            }

            
            parameter.ArrayItemCount = dtMain.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS001.DELETE_01", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("삭제 되었습니다.", "확인");
                btnSearch.PerformClick();
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 삭제 - btnDelete_Click

        #region 그리드 이벤트

        private void grvMain_ShowingEditor(object sender, CancelEventArgs e)
        {
            DataRow row = grvMain.GetFocusedDataRow();
            if (row != null)
            {
                string strFieldName = grvMain.FocusedColumn.FieldName;
                if (strFieldName.Equals("WORK_GUBUN"))
                {
                    if (!string.IsNullOrWhiteSpace(row["GROUP_ID"].ToString()))
                        e.Cancel = true;
                    else
                        e.Cancel = false;
                }
            }
        }

        private void grvMain_CellValueChanging(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            GridView gridView = (sender as GridView);
            if (gridView != null)
            {

                DataRow row = gridView.GetDataRow(e.RowHandle);
                if (row != null)
                {
                    if (gridView.Columns["CHK"] != null && gridView.Columns["CHK"].ColumnEdit != null && gridView.Columns["CHK"].ColumnEdit is RepositoryItemCheckEdit)
                    {
                        RepositoryItemCheckEdit chkEdit = (gridView.Columns["CHK"].ColumnEdit as RepositoryItemCheckEdit);
                        row["CHK"] = chkEdit.ValueChecked;
                    }
                }
            }
        }
        #endregion

        #region 메서드
        /// <summary>
        /// 시스템코드조회
        /// </summary>
        /// <returns></returns>
        private DataTable GetSystemCode()
        {
            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCCOMMON.SEARCH_SYSTEM").QuerySet.Tables[0];
        }

        private DataResultSet GetGroupCount(string strGROUP_ID)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("GROUP_ID", strGROUP_ID);
            
            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS001.SEARCH_02", parameter);
        }
        #endregion

        

    }
}
