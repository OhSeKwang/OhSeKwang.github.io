﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS007
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SCSYS007));
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.btnPIC2 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnPIC1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.txtUserID = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.luSYSTEM_CODE = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLookUpEditExt();
            this.btnNew = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnDelete = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.grdMaster = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvMaster = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCHK = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsTextUpp30 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboSYSTEM_CODE = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsMemoEdit = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPIC1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsTextUpp7 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.colPIC2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colMANUAL_FILE = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMRUEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMRUEdit();
            this.colFTP_SERVER_PATH = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colFTP_IP = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colUSER_ID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPASSWORD = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colHID_SYSTEM_CODE = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colIS_SAVE = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colH_LOCAL_FILE_PATH = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsTextUpp10 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.rpsNum1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.rpsLookUpSYSTEM_CODE = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.txtPROGRAM_ID = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnSave = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnSearch = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.stdButtonExecuteManager1 = new HHI.ShipBuilding.Controls.StdButtonExecuteManager(this.components);
            this.stdValidationManager1 = new HHI.ShipBuilding.Controls.StdValidationManager(this.components);
            this.stdSecurityManager1 = new HHI.ShipBuilding.Windows.Forms.StdSecurityManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtUserID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.luSYSTEM_CODE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMaster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMaster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsTextUpp30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboSYSTEM_CODE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsMemoEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsLookUpEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsTextUpp7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMRUEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsTextUpp10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsNum1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsLookUpSYSTEM_CODE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPROGRAM_ID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.btnPIC2);
            this.xtraLayoutControlExt1.Controls.Add(this.btnPIC1);
            this.xtraLayoutControlExt1.Controls.Add(this.txtUserID);
            this.xtraLayoutControlExt1.Controls.Add(this.luSYSTEM_CODE);
            this.xtraLayoutControlExt1.Controls.Add(this.btnNew);
            this.xtraLayoutControlExt1.Controls.Add(this.btnDelete);
            this.xtraLayoutControlExt1.Controls.Add(this.grdMaster);
            this.xtraLayoutControlExt1.Controls.Add(this.txtPROGRAM_ID);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSave);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearch);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(974, 624);
            this.xtraLayoutControlExt1.TabIndex = 0;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // btnPIC2
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnPIC2, new string[] {
            ""});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnPIC2, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnPIC2, false);
            this.btnPIC2.IsExecuteWdworkerLog = true;
            this.btnPIC2.Location = new System.Drawing.Point(881, 68);
            this.btnPIC2.Name = "btnPIC2";
            this.btnPIC2.Size = new System.Drawing.Size(69, 22);
            this.btnPIC2.StyleController = this.xtraLayoutControlExt1;
            this.btnPIC2.TabIndex = 5;
            this.btnPIC2.Tag = "2";
            this.btnPIC2.Text = "적용(업무)";
            this.btnPIC2.UseSplasher = true;
            this.btnPIC2.Click += new System.EventHandler(this.btnPIC2_Click);
            // 
            // btnPIC1
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnPIC1, new string[] {
            ""});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnPIC1, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnPIC1, false);
            this.btnPIC1.IsExecuteWdworkerLog = true;
            this.btnPIC1.Location = new System.Drawing.Point(808, 68);
            this.btnPIC1.Name = "btnPIC1";
            this.btnPIC1.Size = new System.Drawing.Size(69, 22);
            this.btnPIC1.StyleController = this.xtraLayoutControlExt1;
            this.btnPIC1.TabIndex = 5;
            this.btnPIC1.Tag = "1";
            this.btnPIC1.Text = "적용(전산)";
            this.btnPIC1.UseSplasher = true;
            this.btnPIC1.Click += new System.EventHandler(this.btnPIC1_Click);
            // 
            // txtUserID
            // 
            this.txtUserID.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtUserID.EditValue = "";
            this.txtUserID.EnterExecuteButton = null;
            this.txtUserID.FocusColor = System.Drawing.Color.Empty;
            this.txtUserID.IsValueTrim = true;
            this.txtUserID.Key = "";
            this.txtUserID.Location = new System.Drawing.Point(657, 68);
            this.txtUserID.MinLength = 0;
            this.txtUserID.Name = "txtUserID";
            this.txtUserID.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtUserID.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtUserID.Properties.Appearance.Options.UseBackColor = true;
            this.txtUserID.Properties.Appearance.Options.UseForeColor = true;
            this.txtUserID.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtUserID.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtUserID.Size = new System.Drawing.Size(147, 20);
            this.txtUserID.StyleController = this.xtraLayoutControlExt1;
            this.txtUserID.TabIndex = 7;
            this.txtUserID.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // luSYSTEM_CODE
            // 
            this.luSYSTEM_CODE.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.luSYSTEM_CODE.EnterExecuteButton = null;
            this.luSYSTEM_CODE.FocusColor = System.Drawing.Color.Empty;
            this.luSYSTEM_CODE.Key = "";
            this.luSYSTEM_CODE.Location = new System.Drawing.Point(104, 68);
            this.luSYSTEM_CODE.MinLength = 0;
            this.luSYSTEM_CODE.Name = "luSYSTEM_CODE";
            this.luSYSTEM_CODE.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.luSYSTEM_CODE.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.luSYSTEM_CODE.Properties.Appearance.Options.UseBackColor = true;
            this.luSYSTEM_CODE.Properties.Appearance.Options.UseForeColor = true;
            this.luSYSTEM_CODE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.luSYSTEM_CODE.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("SYSTEM_CODE", 80, "코드"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("SYSTEM_NAME", 150, "명칭")});
            this.luSYSTEM_CODE.Properties.NullText = "";
            this.luSYSTEM_CODE.Size = new System.Drawing.Size(182, 20);
            this.luSYSTEM_CODE.StyleController = this.xtraLayoutControlExt1;
            this.luSYSTEM_CODE.TabIndex = 10;
            this.luSYSTEM_CODE.EditValueChanged += new System.EventHandler(this.luSYSTEM_CODE_EditValueChanged);
            // 
            // btnNew
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnNew, new string[] {
            "INSERT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnNew, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnNew, false);
            this.btnNew.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_신규;
            this.btnNew.IsExecuteWdworkerLog = true;
            this.btnNew.Location = new System.Drawing.Point(792, 12);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(54, 22);
            this.btnNew.StyleController = this.xtraLayoutControlExt1;
            this.btnNew.TabIndex = 5;
            this.btnNew.Text = "신규";
            this.btnNew.UseSplasher = false;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnDelete
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnDelete, new string[] {
            "DELETE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnDelete, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnDelete, false);
            this.btnDelete.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_삭제;
            this.btnDelete.IsExecuteWdworkerLog = true;
            this.btnDelete.Location = new System.Drawing.Point(908, 12);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(54, 22);
            this.btnDelete.StyleController = this.xtraLayoutControlExt1;
            this.btnDelete.TabIndex = 5;
            this.btnDelete.Text = "삭제";
            this.btnDelete.UseSplasher = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // grdMaster
            // 
            this.grdMaster.CheckBoxFieldName = "CHK";
            this.grdMaster.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdMaster.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdMaster.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdMaster.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdMaster.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default_ButtonAppend;
            this.grdMaster.IsHeaderClickAllCheckedItem = true;
            this.grdMaster.Location = new System.Drawing.Point(24, 142);
            this.grdMaster.MainView = this.grvMaster;
            this.grdMaster.MinLength = 0;
            this.grdMaster.Name = "grdMaster";
            this.grdMaster.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpsCHK,
            this.rpsMemoEdit,
            this.rpsTextUpp10,
            this.rpsTextUpp30,
            this.rpsNum1,
            this.rpsLookUpEdit1,
            this.rpsLookUpSYSTEM_CODE,
            this.rpsCboSYSTEM_CODE,
            this.rpsTextUpp7,
            this.repositoryItemMRUEdit1});
            this.grdMaster.Size = new System.Drawing.Size(926, 458);
            this.grdMaster.TabIndex = 9;
            this.grdMaster.UseEmbeddedNavigator = true;
            this.grdMaster.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvMaster});
            // 
            // grvMaster
            // 
            this.grvMaster.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn5,
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn4,
            this.gridColumn9,
            this.gridColumn3,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn8,
            this.colPIC1,
            this.colPIC2,
            this.colMANUAL_FILE,
            this.colFTP_SERVER_PATH,
            this.colFTP_IP,
            this.colUSER_ID,
            this.colPASSWORD,
            this.colHID_SYSTEM_CODE,
            this.colIS_SAVE,
            this.colH_LOCAL_FILE_PATH});
            this.grvMaster.GridControl = this.grdMaster;
            this.grvMaster.GroupCount = 1;
            this.grvMaster.Name = "grvMaster";
            this.grvMaster.OptionsView.ColumnAutoWidth = false;
            this.grvMaster.OptionsView.ShowGroupedColumns = true;
            this.grvMaster.OptionsView.ShowGroupPanel = false;
            this.grvMaster.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumn2, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.grvMaster.ShowingEditor += new System.ComponentModel.CancelEventHandler(this.grvMaster_ShowingEditor);
            this.grvMaster.InitNewRow += new DevExpress.XtraGrid.Views.Grid.InitNewRowEventHandler(this.grvMaster_InitNewRow);
            this.grvMaster.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.grvMaster_CellValueChanged);
            this.grvMaster.CellValueChanging += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.grvMaster_CellValueChanging);
            this.grvMaster.DoubleClick += new System.EventHandler(this.grvMaster_DoubleClick);
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.Caption = "Chk";
            this.gridColumn5.ColumnEdit = this.rpsCHK;
            this.gridColumn5.FieldName = "CHK";
            this.gridColumn5.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 0;
            this.gridColumn5.Width = 41;
            // 
            // rpsCHK
            // 
            this.rpsCHK.AutoHeight = false;
            this.rpsCHK.Caption = "Check";
            this.rpsCHK.Name = "rpsCHK";
            this.rpsCHK.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpsCHK.ValueChecked = "Y";
            this.rpsCHK.ValueUnchecked = "N";
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.BackColor = System.Drawing.Color.Ivory;
            this.gridColumn1.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.gridColumn1.AppearanceCell.Options.UseBackColor = true;
            this.gridColumn1.AppearanceCell.Options.UseFont = true;
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "프로그램 ID";
            this.gridColumn1.ColumnEdit = this.rpsTextUpp30;
            this.gridColumn1.FieldName = "PROGRAM_ID";
            this.gridColumn1.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 1;
            this.gridColumn1.Width = 97;
            // 
            // rpsTextUpp30
            // 
            this.rpsTextUpp30.AutoHeight = false;
            this.rpsTextUpp30.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.rpsTextUpp30.MaxLength = 30;
            this.rpsTextUpp30.Name = "rpsTextUpp30";
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceCell.BackColor = System.Drawing.Color.Ivory;
            this.gridColumn2.AppearanceCell.Options.UseBackColor = true;
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "System Code";
            this.gridColumn2.ColumnEdit = this.rpsCboSYSTEM_CODE;
            this.gridColumn2.FieldName = "SYSTEM_CODE";
            this.gridColumn2.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 2;
            this.gridColumn2.Width = 131;
            // 
            // rpsCboSYSTEM_CODE
            // 
            this.rpsCboSYSTEM_CODE.AutoHeight = false;
            this.rpsCboSYSTEM_CODE.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboSYSTEM_CODE.Name = "rpsCboSYSTEM_CODE";
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.BackColor = System.Drawing.Color.Ivory;
            this.gridColumn4.AppearanceCell.Options.UseBackColor = true;
            this.gridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.Caption = "Program Name";
            this.gridColumn4.ColumnEdit = this.rpsMemoEdit;
            this.gridColumn4.FieldName = "PROGRAM_NAME";
            this.gridColumn4.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 3;
            this.gridColumn4.Width = 177;
            // 
            // rpsMemoEdit
            // 
            this.rpsMemoEdit.AutoHeight = false;
            this.rpsMemoEdit.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsMemoEdit.Name = "rpsMemoEdit";
            this.rpsMemoEdit.ShowIcon = false;
            // 
            // gridColumn9
            // 
            this.gridColumn9.AppearanceCell.BackColor = System.Drawing.Color.Ivory;
            this.gridColumn9.AppearanceCell.Options.UseBackColor = true;
            this.gridColumn9.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.Caption = "Url";
            this.gridColumn9.ColumnEdit = this.rpsMemoEdit;
            this.gridColumn9.FieldName = "URL";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 4;
            this.gridColumn9.Width = 133;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.Caption = "Class Name";
            this.gridColumn3.ColumnEdit = this.rpsMemoEdit;
            this.gridColumn3.FieldName = "CLASS_NAME";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 5;
            this.gridColumn3.Width = 136;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.Caption = "Application Type";
            this.gridColumn6.ColumnEdit = this.rpsLookUpEdit1;
            this.gridColumn6.FieldName = "APPLICATION_TYPE";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 6;
            this.gridColumn6.Width = 121;
            // 
            // rpsLookUpEdit1
            // 
            this.rpsLookUpEdit1.AutoHeight = false;
            this.rpsLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsLookUpEdit1.Name = "rpsLookUpEdit1";
            this.rpsLookUpEdit1.NullText = "";
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.Caption = "Parameter";
            this.gridColumn7.FieldName = "PARAMETER";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 7;
            this.gridColumn7.Width = 110;
            // 
            // gridColumn8
            // 
            this.gridColumn8.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.Caption = "Auth CHK";
            this.gridColumn8.ColumnEdit = this.rpsCHK;
            this.gridColumn8.FieldName = "NEW_AUTH_CHK";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 8;
            // 
            // colPIC1
            // 
            this.colPIC1.AppearanceHeader.Options.UseTextOptions = true;
            this.colPIC1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colPIC1.Caption = "전산관리자";
            this.colPIC1.ColumnEdit = this.rpsTextUpp7;
            this.colPIC1.FieldName = "PIC1";
            this.colPIC1.Name = "colPIC1";
            this.colPIC1.Visible = true;
            this.colPIC1.VisibleIndex = 9;
            // 
            // rpsTextUpp7
            // 
            this.rpsTextUpp7.AutoHeight = false;
            this.rpsTextUpp7.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.rpsTextUpp7.MaxLength = 7;
            this.rpsTextUpp7.Name = "rpsTextUpp7";
            // 
            // colPIC2
            // 
            this.colPIC2.AppearanceHeader.Options.UseTextOptions = true;
            this.colPIC2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colPIC2.Caption = "업무관리자";
            this.colPIC2.ColumnEdit = this.rpsTextUpp7;
            this.colPIC2.FieldName = "PIC2";
            this.colPIC2.Name = "colPIC2";
            this.colPIC2.Visible = true;
            this.colPIC2.VisibleIndex = 10;
            // 
            // colMANUAL_FILE
            // 
            this.colMANUAL_FILE.AppearanceHeader.Options.UseTextOptions = true;
            this.colMANUAL_FILE.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMANUAL_FILE.Caption = "메뉴얼";
            this.colMANUAL_FILE.ColumnEdit = this.repositoryItemMRUEdit1;
            this.colMANUAL_FILE.FieldName = "MANUAL_FILE";
            this.colMANUAL_FILE.Name = "colMANUAL_FILE";
            this.colMANUAL_FILE.Visible = true;
            this.colMANUAL_FILE.VisibleIndex = 11;
            this.colMANUAL_FILE.Width = 100;
            // 
            // repositoryItemMRUEdit1
            // 
            this.repositoryItemMRUEdit1.AutoHeight = false;
            this.repositoryItemMRUEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, ((System.Drawing.Image)(resources.GetObject("repositoryItemMRUEdit1.Buttons"))), new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, "", null, null, true)});
            this.repositoryItemMRUEdit1.Name = "repositoryItemMRUEdit1";
            this.repositoryItemMRUEdit1.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemMRUEdit1_ButtonClick);
            // 
            // colFTP_SERVER_PATH
            // 
            this.colFTP_SERVER_PATH.AppearanceHeader.Options.UseTextOptions = true;
            this.colFTP_SERVER_PATH.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colFTP_SERVER_PATH.Caption = "FTP 서버경로";
            this.colFTP_SERVER_PATH.ColumnEdit = this.rpsMemoEdit;
            this.colFTP_SERVER_PATH.FieldName = "FTP_SERVER_PATH";
            this.colFTP_SERVER_PATH.Name = "colFTP_SERVER_PATH";
            this.colFTP_SERVER_PATH.OptionsColumn.ReadOnly = true;
            this.colFTP_SERVER_PATH.Visible = true;
            this.colFTP_SERVER_PATH.VisibleIndex = 12;
            this.colFTP_SERVER_PATH.Width = 85;
            // 
            // colFTP_IP
            // 
            this.colFTP_IP.AppearanceHeader.Options.UseTextOptions = true;
            this.colFTP_IP.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colFTP_IP.Caption = "FTP IP";
            this.colFTP_IP.ColumnEdit = this.rpsMemoEdit;
            this.colFTP_IP.FieldName = "FTP_IP";
            this.colFTP_IP.Name = "colFTP_IP";
            this.colFTP_IP.OptionsColumn.ReadOnly = true;
            this.colFTP_IP.Visible = true;
            this.colFTP_IP.VisibleIndex = 13;
            this.colFTP_IP.Width = 80;
            // 
            // colUSER_ID
            // 
            this.colUSER_ID.AppearanceHeader.Options.UseTextOptions = true;
            this.colUSER_ID.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colUSER_ID.Caption = "FTP 사용자ID";
            this.colUSER_ID.FieldName = "USER_ID";
            this.colUSER_ID.Name = "colUSER_ID";
            this.colUSER_ID.OptionsColumn.AllowEdit = false;
            this.colUSER_ID.OptionsColumn.ReadOnly = true;
            this.colUSER_ID.Visible = true;
            this.colUSER_ID.VisibleIndex = 14;
            // 
            // colPASSWORD
            // 
            this.colPASSWORD.AppearanceHeader.Options.UseTextOptions = true;
            this.colPASSWORD.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colPASSWORD.Caption = "FTP 패스워드";
            this.colPASSWORD.FieldName = "PASSWORD";
            this.colPASSWORD.Name = "colPASSWORD";
            this.colPASSWORD.OptionsColumn.AllowEdit = false;
            this.colPASSWORD.OptionsColumn.ReadOnly = true;
            this.colPASSWORD.Visible = true;
            this.colPASSWORD.VisibleIndex = 15;
            // 
            // colHID_SYSTEM_CODE
            // 
            this.colHID_SYSTEM_CODE.Caption = "HID_SYSTEM_CODE";
            this.colHID_SYSTEM_CODE.FieldName = "HID_SYSTEM_CODE";
            this.colHID_SYSTEM_CODE.Name = "colHID_SYSTEM_CODE";
            this.colHID_SYSTEM_CODE.OptionsColumn.AllowEdit = false;
            this.colHID_SYSTEM_CODE.OptionsColumn.ReadOnly = true;
            // 
            // colIS_SAVE
            // 
            this.colIS_SAVE.Caption = "IS_SAVE";
            this.colIS_SAVE.FieldName = "IS_SAVE";
            this.colIS_SAVE.Name = "colIS_SAVE";
            this.colIS_SAVE.OptionsColumn.AllowEdit = false;
            this.colIS_SAVE.OptionsColumn.ReadOnly = true;
            // 
            // colH_LOCAL_FILE_PATH
            // 
            this.colH_LOCAL_FILE_PATH.Caption = "메뉴얼로컬경로";
            this.colH_LOCAL_FILE_PATH.FieldName = "LOCAL_FILE_PATH";
            this.colH_LOCAL_FILE_PATH.Name = "colH_LOCAL_FILE_PATH";
            // 
            // rpsTextUpp10
            // 
            this.rpsTextUpp10.AutoHeight = false;
            this.rpsTextUpp10.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.rpsTextUpp10.MaxLength = 10;
            this.rpsTextUpp10.Name = "rpsTextUpp10";
            // 
            // rpsNum1
            // 
            this.rpsNum1.AutoHeight = false;
            this.rpsNum1.Mask.EditMask = "0";
            this.rpsNum1.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.rpsNum1.Mask.UseMaskAsDisplayFormat = true;
            this.rpsNum1.MaxLength = 1;
            this.rpsNum1.Name = "rpsNum1";
            // 
            // rpsLookUpSYSTEM_CODE
            // 
            this.rpsLookUpSYSTEM_CODE.AutoHeight = false;
            this.rpsLookUpSYSTEM_CODE.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsLookUpSYSTEM_CODE.Name = "rpsLookUpSYSTEM_CODE";
            this.rpsLookUpSYSTEM_CODE.NullText = "";
            // 
            // txtPROGRAM_ID
            // 
            this.txtPROGRAM_ID.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtPROGRAM_ID.EditValue = "";
            this.txtPROGRAM_ID.EnterExecuteButton = null;
            this.txtPROGRAM_ID.FocusColor = System.Drawing.Color.Empty;
            this.txtPROGRAM_ID.IsValueTrim = true;
            this.txtPROGRAM_ID.Key = "";
            this.txtPROGRAM_ID.Location = new System.Drawing.Point(370, 68);
            this.txtPROGRAM_ID.MinLength = 0;
            this.txtPROGRAM_ID.Name = "txtPROGRAM_ID";
            this.txtPROGRAM_ID.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtPROGRAM_ID.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtPROGRAM_ID.Properties.Appearance.Options.UseBackColor = true;
            this.txtPROGRAM_ID.Properties.Appearance.Options.UseForeColor = true;
            this.txtPROGRAM_ID.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPROGRAM_ID.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtPROGRAM_ID.Size = new System.Drawing.Size(137, 20);
            this.txtPROGRAM_ID.StyleController = this.xtraLayoutControlExt1;
            this.txtPROGRAM_ID.TabIndex = 6;
            this.txtPROGRAM_ID.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // btnSave
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSave, new string[] {
            "UPDATE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSave, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSave, false);
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.IsExecuteWdworkerLog = true;
            this.btnSave.Location = new System.Drawing.Point(850, 12);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(54, 22);
            this.btnSave.StyleController = this.xtraLayoutControlExt1;
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "저장";
            this.btnSave.UseSplasher = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnSearch
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSearch, new string[] {
            "SELECT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSearch, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSearch, true);
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.IsExecuteWdworkerLog = true;
            this.btnSearch.Location = new System.Drawing.Point(734, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(54, 22);
            this.btnSearch.StyleController = this.xtraLayoutControlExt1;
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "조회";
            this.btnSearch.UseSplasher = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "layoutControlGroup1";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup1, false);
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem1,
            this.layoutControlItem1,
            this.layoutControlItem2,
            this.layoutControlItem7,
            this.layoutControlItem8,
            this.layoutControlGroup2,
            this.layoutControlGroup3});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "layoutControlGroup1";
            this.layoutControlGroup1.Size = new System.Drawing.Size(974, 624);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(722, 26);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.btnSearch;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(722, 0);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.btnSave;
            this.layoutControlItem2.CustomizationFormText = "layoutControlItem2";
            this.layoutControlItem2.Location = new System.Drawing.Point(838, 0);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextVisible = false;
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.btnDelete;
            this.layoutControlItem7.CustomizationFormText = "layoutControlItem7";
            this.layoutControlItem7.Location = new System.Drawing.Point(896, 0);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem7.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem7.TextVisible = false;
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.btnNew;
            this.layoutControlItem8.CustomizationFormText = "layoutControlItem8";
            this.layoutControlItem8.Location = new System.Drawing.Point(780, 0);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem8.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem8.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.CaptionImage = ((System.Drawing.Image)(resources.GetObject("layoutControlGroup2.CaptionImage")));
            this.layoutControlGroup2.CustomizationFormText = "List";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup2, false);
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem6});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 94);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(954, 510);
            this.layoutControlGroup2.Text = "프로그램정보";
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.grdMaster;
            this.layoutControlItem6.CustomizationFormText = "layoutControlItem6";
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(930, 462);
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextVisible = false;
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 1F);
            this.layoutControlGroup3.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup3.CustomizationFormText = " ";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup3, true);
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem2,
            this.layoutControlItem3,
            this.layoutControlItem5,
            this.layoutControlItem4,
            this.layoutControlItem9,
            this.layoutControlItem10});
            this.layoutControlGroup3.Location = new System.Drawing.Point(0, 26);
            this.layoutControlGroup3.Name = "layoutControlGroup3";
            this.layoutControlGroup3.Size = new System.Drawing.Size(954, 68);
            this.layoutControlGroup3.Text = " ";
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(487, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(146, 26);
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.txtPROGRAM_ID;
            this.layoutControlItem3.CustomizationFormText = "AuthName";
            this.layoutControlItem3.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem3.Image")));
            this.layoutControlItem3.Location = new System.Drawing.Point(266, 0);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(221, 26);
            this.layoutControlItem3.Text = "프로그램 ID";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(77, 16);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.luSYSTEM_CODE;
            this.layoutControlItem5.CustomizationFormText = "시스템 코드";
            this.layoutControlItem5.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem5.Image")));
            this.layoutControlItem5.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(266, 26);
            this.layoutControlItem5.Text = "시스템 코드";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(77, 16);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.txtUserID;
            this.layoutControlItem4.CustomizationFormText = "사번";
            this.layoutControlItem4.Location = new System.Drawing.Point(633, 0);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(151, 26);
            this.layoutControlItem4.Text = "사번";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextVisible = false;
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.btnPIC1;
            this.layoutControlItem9.CustomizationFormText = "layoutControlItem9";
            this.layoutControlItem9.Location = new System.Drawing.Point(784, 0);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(73, 26);
            this.layoutControlItem9.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem9.TextVisible = false;
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.btnPIC2;
            this.layoutControlItem10.CustomizationFormText = "layoutControlItem10";
            this.layoutControlItem10.Location = new System.Drawing.Point(857, 0);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(73, 26);
            this.layoutControlItem10.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem10.TextVisible = false;
            // 
            // stdValidationManager1
            // 
            this.stdValidationManager1.IsNullorWhiteSpace = true;
            this.stdValidationManager1.IsShowErrorMessage = true;
            // 
            // SCSYS007
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS007";
            this.Size = new System.Drawing.Size(974, 624);
            this.Shown += new System.EventHandler(this.SCSYS007_Shown);
            this.Load += new System.EventHandler(this.SCSYS007_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtUserID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.luSYSTEM_CODE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMaster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMaster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsTextUpp30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboSYSTEM_CODE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsMemoEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsLookUpEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsTextUpp7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMRUEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsTextUpp10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsNum1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsLookUpSYSTEM_CODE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPROGRAM_ID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private Client.Controls.DXperience.XtraGridControlExt grdMaster;
        private DevExpress.XtraGrid.Views.Grid.GridView grvMaster;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpsCHK;
        private Client.Controls.DXperience.XtraTextEditExt txtPROGRAM_ID;
        private Client.Controls.DXperience.XtraButtonExt btnSave;
        private Client.Controls.DXperience.XtraButtonExt btnSearch;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private Client.Controls.DXperience.XtraButtonExt btnNew;
        private Client.Controls.DXperience.XtraButtonExt btnDelete;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit rpsMemoEdit;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private Controls.StdButtonExecuteManager stdButtonExecuteManager1;
        private Controls.StdValidationManager stdValidationManager1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit rpsTextUpp30;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit rpsTextUpp10;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit rpsNum1;
        private DevExpress.XtraGrid.Columns.GridColumn colIS_SAVE;
        private DevExpress.XtraGrid.Columns.GridColumn colFTP_SERVER_PATH;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit rpsLookUpEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit rpsLookUpSYSTEM_CODE;
        private Client.Controls.DXperience.XtraLookUpEditExt luSYSTEM_CODE;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private Windows.Forms.StdSecurityManager stdSecurityManager1;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboSYSTEM_CODE;
        private DevExpress.XtraGrid.Columns.GridColumn colFTP_IP;
        private DevExpress.XtraGrid.Columns.GridColumn colUSER_ID;
        private DevExpress.XtraGrid.Columns.GridColumn colPASSWORD;
        private DevExpress.XtraGrid.Columns.GridColumn colHID_SYSTEM_CODE;
        private DevExpress.XtraGrid.Columns.GridColumn colPIC1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit rpsTextUpp7;
        private DevExpress.XtraGrid.Columns.GridColumn colPIC2;
        private DevExpress.XtraGrid.Columns.GridColumn colMANUAL_FILE;
        private DevExpress.XtraEditors.Repository.RepositoryItemMRUEdit repositoryItemMRUEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn colH_LOCAL_FILE_PATH;
        private Client.Controls.DXperience.XtraButtonExt btnPIC2;
        private Client.Controls.DXperience.XtraButtonExt btnPIC1;
        private Client.Controls.DXperience.XtraTextEditExt txtUserID;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
    }
}
