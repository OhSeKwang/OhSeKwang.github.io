﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS024P1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SCSYS024P1));
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.rpsCboImg2 = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.btnFileDelete2 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnFileDelete = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnAttach2 = new DevExpress.XtraEditors.SimpleButton();
            this.grdFile2 = new DevExpress.XtraGrid.GridControl();
            this.grvFile2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn20 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn21 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn22 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn23 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn24 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn25 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn26 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.btnGetRCVPopup = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnAttach = new DevExpress.XtraEditors.SimpleButton();
            this.txtRCV_TELNO = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.cboPROCESS = new HHI.ShipBuilding.Client.Controls.DXperience.XtraImageComboBoxEditExt();
            this.cboGUBUN = new HHI.ShipBuilding.Client.Controls.DXperience.XtraImageComboBoxEditExt();
            this.grdFILE = new DevExpress.XtraGrid.GridControl();
            this.grvFILE = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCHK = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboImg = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.memREMARK = new DevExpress.XtraEditors.MemoEdit();
            this.memCS_CONTENT = new DevExpress.XtraEditors.MemoEdit();
            this.memCONTENT = new DevExpress.XtraEditors.MemoEdit();
            this.dteCDATE = new HHI.ShipBuilding.Client.Controls.DXperience.XtraDateEditExt();
            this.dteIDATE = new HHI.ShipBuilding.Client.Controls.DXperience.XtraDateEditExt();
            this.txtCODE = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnSearchProgramPopup = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.txtTELNO = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtRCV_USERNAME = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtRCV_USERDEPTDESC = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtPROGRAM_NAME = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtPROGRAM_ID = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtSUBJECT = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtHNAME = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtREQ_DEPTDESC = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnSave = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnClose = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem12 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem13 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem17 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem23 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem20 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem26 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem10 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem25 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem24 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem5 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem21 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem16 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem18 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem19 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem6 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem22 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem27 = new DevExpress.XtraLayout.LayoutControlItem();
            this.stdValidationManager1 = new HHI.ShipBuilding.Controls.StdValidationManager(this.components);
            this.stdSecurityManager1 = new HHI.ShipBuilding.Windows.Forms.StdSecurityManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboImg2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdFile2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvFile2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRCV_TELNO.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboPROCESS.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboGUBUN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdFILE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvFILE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.memREMARK.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.memCS_CONTENT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.memCONTENT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteCDATE.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteCDATE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteIDATE.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteIDATE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCODE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTELNO.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRCV_USERNAME.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRCV_USERDEPTDESC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPROGRAM_NAME.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPROGRAM_ID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSUBJECT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHNAME.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtREQ_DEPTDESC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem27)).BeginInit();
            this.SuspendLayout();
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.repositoryItemCheckEdit1.ValueChecked = "Y";
            this.repositoryItemCheckEdit1.ValueUnchecked = "N";
            // 
            // rpsCboImg2
            // 
            this.rpsCboImg2.AutoHeight = false;
            this.rpsCboImg2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboImg2.GlyphAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.rpsCboImg2.Items.AddRange(new DevExpress.XtraEditors.Controls.ImageComboBoxItem[] {
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", "0", 0),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", "1", 1),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", "2", 2),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", "3", 3),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", "4", 4),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", "5", 5),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", "6", 6)});
            this.rpsCboImg2.Name = "rpsCboImg2";
            this.rpsCboImg2.SmallImages = this.imageList1;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "icon_pdf.gif");
            this.imageList1.Images.SetKeyName(1, "icon_doc.gif");
            this.imageList1.Images.SetKeyName(2, "icon_xls.gif");
            this.imageList1.Images.SetKeyName(3, "icon_ppt.gif");
            this.imageList1.Images.SetKeyName(4, "icon_hun.gif");
            this.imageList1.Images.SetKeyName(5, "icon_image.gif");
            this.imageList1.Images.SetKeyName(6, "icon_etc.gif");
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.btnFileDelete2);
            this.xtraLayoutControlExt1.Controls.Add(this.btnFileDelete);
            this.xtraLayoutControlExt1.Controls.Add(this.btnAttach2);
            this.xtraLayoutControlExt1.Controls.Add(this.grdFile2);
            this.xtraLayoutControlExt1.Controls.Add(this.btnGetRCVPopup);
            this.xtraLayoutControlExt1.Controls.Add(this.btnAttach);
            this.xtraLayoutControlExt1.Controls.Add(this.txtRCV_TELNO);
            this.xtraLayoutControlExt1.Controls.Add(this.cboPROCESS);
            this.xtraLayoutControlExt1.Controls.Add(this.cboGUBUN);
            this.xtraLayoutControlExt1.Controls.Add(this.grdFILE);
            this.xtraLayoutControlExt1.Controls.Add(this.memREMARK);
            this.xtraLayoutControlExt1.Controls.Add(this.memCS_CONTENT);
            this.xtraLayoutControlExt1.Controls.Add(this.memCONTENT);
            this.xtraLayoutControlExt1.Controls.Add(this.dteCDATE);
            this.xtraLayoutControlExt1.Controls.Add(this.dteIDATE);
            this.xtraLayoutControlExt1.Controls.Add(this.txtCODE);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearchProgramPopup);
            this.xtraLayoutControlExt1.Controls.Add(this.txtTELNO);
            this.xtraLayoutControlExt1.Controls.Add(this.txtRCV_USERNAME);
            this.xtraLayoutControlExt1.Controls.Add(this.txtRCV_USERDEPTDESC);
            this.xtraLayoutControlExt1.Controls.Add(this.txtPROGRAM_NAME);
            this.xtraLayoutControlExt1.Controls.Add(this.txtPROGRAM_ID);
            this.xtraLayoutControlExt1.Controls.Add(this.txtSUBJECT);
            this.xtraLayoutControlExt1.Controls.Add(this.txtHNAME);
            this.xtraLayoutControlExt1.Controls.Add(this.txtREQ_DEPTDESC);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSave);
            this.xtraLayoutControlExt1.Controls.Add(this.btnClose);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(1214, 287, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(606, 823);
            this.xtraLayoutControlExt1.TabIndex = 0;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // btnFileDelete2
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnFileDelete2, new string[] {
            "DELETE"});
            this.btnFileDelete2.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_삭제;
            this.btnFileDelete2.IsExecuteWdworkerLog = true;
            this.btnFileDelete2.Location = new System.Drawing.Point(528, 671);
            this.btnFileDelete2.Name = "btnFileDelete2";
            this.btnFileDelete2.Size = new System.Drawing.Size(54, 22);
            this.btnFileDelete2.StyleController = this.xtraLayoutControlExt1;
            this.btnFileDelete2.TabIndex = 39;
            this.btnFileDelete2.Text = "삭제";
            this.btnFileDelete2.UseSplasher = true;
            this.btnFileDelete2.Click += new System.EventHandler(this.btnFileDelete2_Click);
            // 
            // btnFileDelete
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnFileDelete, new string[] {
            "DELETE"});
            this.btnFileDelete.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_삭제;
            this.btnFileDelete.IsExecuteWdworkerLog = true;
            this.btnFileDelete.Location = new System.Drawing.Point(528, 506);
            this.btnFileDelete.Name = "btnFileDelete";
            this.btnFileDelete.Size = new System.Drawing.Size(54, 22);
            this.btnFileDelete.StyleController = this.xtraLayoutControlExt1;
            this.btnFileDelete.TabIndex = 38;
            this.btnFileDelete.Text = "삭제";
            this.btnFileDelete.UseSplasher = true;
            this.btnFileDelete.Click += new System.EventHandler(this.btnFileDelete_Click);
            // 
            // btnAttach2
            // 
            this.btnAttach2.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_첨부;
            this.btnAttach2.Location = new System.Drawing.Point(446, 671);
            this.btnAttach2.Name = "btnAttach2";
            this.btnAttach2.Size = new System.Drawing.Size(78, 22);
            this.btnAttach2.StyleController = this.xtraLayoutControlExt1;
            this.btnAttach2.TabIndex = 37;
            this.btnAttach2.Text = "파일첨부";
            this.btnAttach2.Click += new System.EventHandler(this.btnAttach2_Click);
            // 
            // grdFile2
            // 
            this.grdFile2.Location = new System.Drawing.Point(24, 697);
            this.grdFile2.MainView = this.grvFile2;
            this.grdFile2.Name = "grdFile2";
            this.grdFile2.Size = new System.Drawing.Size(558, 102);
            this.grdFile2.TabIndex = 36;
            this.grdFile2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvFile2});
            // 
            // grvFile2
            // 
            this.grvFile2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn14,
            this.gridColumn15,
            this.gridColumn16,
            this.gridColumn17,
            this.gridColumn18,
            this.gridColumn19,
            this.gridColumn20,
            this.gridColumn21,
            this.gridColumn22,
            this.gridColumn23,
            this.gridColumn24,
            this.gridColumn25,
            this.gridColumn26});
            this.grvFile2.GridControl = this.grdFile2;
            this.grvFile2.Name = "grvFile2";
            this.grvFile2.OptionsView.ColumnAutoWidth = false;
            this.grvFile2.OptionsView.ShowGroupPanel = false;
            this.grvFile2.OptionsView.ShowIndicator = false;
            // 
            // gridColumn14
            // 
            this.gridColumn14.Caption = " ";
            this.gridColumn14.ColumnEdit = this.repositoryItemCheckEdit1;
            this.gridColumn14.FieldName = "CHK";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.Visible = true;
            this.gridColumn14.VisibleIndex = 0;
            this.gridColumn14.Width = 23;
            // 
            // gridColumn15
            // 
            this.gridColumn15.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.Caption = "No";
            this.gridColumn15.FieldName = "SNO";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.OptionsColumn.AllowEdit = false;
            this.gridColumn15.OptionsFilter.AllowFilter = false;
            this.gridColumn15.Visible = true;
            this.gridColumn15.VisibleIndex = 1;
            this.gridColumn15.Width = 35;
            // 
            // gridColumn16
            // 
            this.gridColumn16.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn16.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn16.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn16.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn16.Caption = "형태";
            this.gridColumn16.ColumnEdit = this.rpsCboImg2;
            this.gridColumn16.FieldName = "STATUS";
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.OptionsColumn.AllowEdit = false;
            this.gridColumn16.OptionsFilter.AllowFilter = false;
            this.gridColumn16.Visible = true;
            this.gridColumn16.VisibleIndex = 2;
            this.gridColumn16.Width = 35;
            // 
            // gridColumn17
            // 
            this.gridColumn17.AppearanceCell.Options.UseImage = true;
            this.gridColumn17.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn17.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn17.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn17.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn17.Caption = " ";
            this.gridColumn17.FieldName = "IMGCHK";
            this.gridColumn17.ImageAlignment = System.Drawing.StringAlignment.Center;
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.OptionsColumn.AllowEdit = false;
            this.gridColumn17.OptionsFilter.AllowFilter = false;
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 3;
            this.gridColumn17.Width = 35;
            // 
            // gridColumn18
            // 
            this.gridColumn18.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn18.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gridColumn18.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn18.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn18.Caption = "첨부파일";
            this.gridColumn18.FieldName = "FILENAME2";
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.OptionsColumn.AllowEdit = false;
            this.gridColumn18.OptionsFilter.AllowFilter = false;
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 4;
            this.gridColumn18.Width = 160;
            // 
            // gridColumn19
            // 
            this.gridColumn19.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn19.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gridColumn19.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn19.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn19.Caption = "DESC";
            this.gridColumn19.FieldName = "DESC1";
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.OptionsColumn.AllowEdit = false;
            this.gridColumn19.OptionsFilter.AllowFilter = false;
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 5;
            this.gridColumn19.Width = 150;
            // 
            // gridColumn20
            // 
            this.gridColumn20.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn20.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn20.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn20.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn20.Caption = "입력일자";
            this.gridColumn20.FieldName = "IDATE";
            this.gridColumn20.Name = "gridColumn20";
            this.gridColumn20.OptionsColumn.AllowEdit = false;
            this.gridColumn20.OptionsFilter.AllowFilter = false;
            this.gridColumn20.Visible = true;
            this.gridColumn20.VisibleIndex = 6;
            this.gridColumn20.Width = 80;
            // 
            // gridColumn21
            // 
            this.gridColumn21.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn21.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn21.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn21.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn21.Caption = "부서명";
            this.gridColumn21.FieldName = "DEPT";
            this.gridColumn21.Name = "gridColumn21";
            this.gridColumn21.OptionsColumn.AllowEdit = false;
            this.gridColumn21.OptionsFilter.AllowFilter = false;
            this.gridColumn21.Visible = true;
            this.gridColumn21.VisibleIndex = 7;
            this.gridColumn21.Width = 120;
            // 
            // gridColumn22
            // 
            this.gridColumn22.Caption = "REALFILE";
            this.gridColumn22.FieldName = "REALFILE";
            this.gridColumn22.Name = "gridColumn22";
            this.gridColumn22.OptionsColumn.AllowEdit = false;
            this.gridColumn22.OptionsFilter.AllowFilter = false;
            // 
            // gridColumn23
            // 
            this.gridColumn23.Caption = "FILEPATH";
            this.gridColumn23.FieldName = "FILEPATH";
            this.gridColumn23.Name = "gridColumn23";
            this.gridColumn23.OptionsColumn.AllowEdit = false;
            this.gridColumn23.OptionsFilter.AllowFilter = false;
            // 
            // gridColumn24
            // 
            this.gridColumn24.Caption = "AFILECODE";
            this.gridColumn24.FieldName = "AFILECODE";
            this.gridColumn24.Name = "gridColumn24";
            this.gridColumn24.OptionsColumn.AllowEdit = false;
            this.gridColumn24.OptionsFilter.AllowFilter = false;
            // 
            // gridColumn25
            // 
            this.gridColumn25.Caption = "FILEGBN";
            this.gridColumn25.FieldName = "FILEGBN";
            this.gridColumn25.Name = "gridColumn25";
            this.gridColumn25.OptionsColumn.AllowEdit = false;
            this.gridColumn25.OptionsFilter.AllowFilter = false;
            // 
            // gridColumn26
            // 
            this.gridColumn26.Caption = "FILEINFO";
            this.gridColumn26.FieldName = "FILEINFO";
            this.gridColumn26.Name = "gridColumn26";
            // 
            // btnGetRCVPopup
            // 
            this.btnGetRCVPopup.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_조회;
            this.btnGetRCVPopup.IsExecuteWdworkerLog = true;
            this.btnGetRCVPopup.Location = new System.Drawing.Point(568, 110);
            this.btnGetRCVPopup.Name = "btnGetRCVPopup";
            this.btnGetRCVPopup.Size = new System.Drawing.Size(26, 22);
            this.btnGetRCVPopup.StyleController = this.xtraLayoutControlExt1;
            this.btnGetRCVPopup.TabIndex = 35;
            this.btnGetRCVPopup.Text = " ";
            this.btnGetRCVPopup.UseSplasher = false;
            this.btnGetRCVPopup.Click += new System.EventHandler(this.btnGetRCVPopup_Click);
            // 
            // btnAttach
            // 
            this.btnAttach.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_첨부;
            this.btnAttach.Location = new System.Drawing.Point(446, 506);
            this.btnAttach.Name = "btnAttach";
            this.btnAttach.Size = new System.Drawing.Size(78, 22);
            this.btnAttach.StyleController = this.xtraLayoutControlExt1;
            this.btnAttach.TabIndex = 29;
            this.btnAttach.Text = "파일첨부";
            this.btnAttach.Click += new System.EventHandler(this.btnAttach_Click);
            // 
            // txtRCV_TELNO
            // 
            this.txtRCV_TELNO.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.txtRCV_TELNO.EditValue = "";
            this.txtRCV_TELNO.EnterExecuteButton = null;
            this.txtRCV_TELNO.FocusColor = System.Drawing.Color.Empty;
            this.txtRCV_TELNO.IsValueTrim = true;
            this.txtRCV_TELNO.Key = "RCV_TELNO";
            this.txtRCV_TELNO.Location = new System.Drawing.Point(104, 136);
            this.txtRCV_TELNO.MinLength = 0;
            this.txtRCV_TELNO.Name = "txtRCV_TELNO";
            this.txtRCV_TELNO.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.txtRCV_TELNO.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtRCV_TELNO.Properties.Appearance.Options.UseBackColor = true;
            this.txtRCV_TELNO.Properties.Appearance.Options.UseForeColor = true;
            this.txtRCV_TELNO.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtRCV_TELNO.Size = new System.Drawing.Size(218, 20);
            this.txtRCV_TELNO.StyleController = this.xtraLayoutControlExt1;
            this.txtRCV_TELNO.TabIndex = 34;
            this.txtRCV_TELNO.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtRCV_TELNO, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // cboPROCESS
            // 
            this.cboPROCESS.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.cboPROCESS.EditValue = "";
            this.cboPROCESS.EnterExecuteButton = null;
            this.cboPROCESS.FocusColor = System.Drawing.Color.Empty;
            this.cboPROCESS.Key = "PROCESS";
            this.cboPROCESS.Location = new System.Drawing.Point(104, 160);
            this.cboPROCESS.MinLength = 0;
            this.cboPROCESS.Name = "cboPROCESS";
            this.cboPROCESS.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.cboPROCESS.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.cboPROCESS.Properties.Appearance.Options.UseBackColor = true;
            this.cboPROCESS.Properties.Appearance.Options.UseForeColor = true;
            this.cboPROCESS.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboPROCESS.Size = new System.Drawing.Size(133, 20);
            this.cboPROCESS.StyleController = this.xtraLayoutControlExt1;
            this.cboPROCESS.TabIndex = 33;
            this.stdValidationManager1.SetValidation(this.cboPROCESS, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // cboGUBUN
            // 
            this.cboGUBUN.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.cboGUBUN.EditValue = "";
            this.cboGUBUN.EnterExecuteButton = null;
            this.cboGUBUN.FocusColor = System.Drawing.Color.Empty;
            this.cboGUBUN.Key = "GUBUN";
            this.cboGUBUN.Location = new System.Drawing.Point(418, 160);
            this.cboGUBUN.MinLength = 0;
            this.cboGUBUN.Name = "cboGUBUN";
            this.cboGUBUN.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.cboGUBUN.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.cboGUBUN.Properties.Appearance.Options.UseBackColor = true;
            this.cboGUBUN.Properties.Appearance.Options.UseForeColor = true;
            this.cboGUBUN.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboGUBUN.Size = new System.Drawing.Size(122, 20);
            this.cboGUBUN.StyleController = this.xtraLayoutControlExt1;
            this.cboGUBUN.TabIndex = 32;
            this.stdValidationManager1.SetValidation(this.cboGUBUN, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // grdFILE
            // 
            this.grdFILE.Location = new System.Drawing.Point(24, 532);
            this.grdFILE.MainView = this.grvFILE;
            this.grdFILE.Name = "grdFILE";
            this.grdFILE.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpsCboImg,
            this.rpsCHK});
            this.grdFILE.Size = new System.Drawing.Size(558, 92);
            this.grdFILE.TabIndex = 31;
            this.grdFILE.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvFILE});
            // 
            // grvFILE
            // 
            this.grvFILE.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn12,
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn8,
            this.gridColumn9,
            this.gridColumn10,
            this.gridColumn11,
            this.gridColumn13});
            this.grvFILE.GridControl = this.grdFILE;
            this.grvFILE.Name = "grvFILE";
            this.grvFILE.OptionsView.ColumnAutoWidth = false;
            this.grvFILE.OptionsView.ShowGroupPanel = false;
            this.grvFILE.OptionsView.ShowIndicator = false;
            this.grvFILE.RowCellClick += new DevExpress.XtraGrid.Views.Grid.RowCellClickEventHandler(this.grvFILE_RowCellClick);
            // 
            // gridColumn12
            // 
            this.gridColumn12.Caption = " ";
            this.gridColumn12.ColumnEdit = this.rpsCHK;
            this.gridColumn12.FieldName = "CHK";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 0;
            this.gridColumn12.Width = 23;
            // 
            // rpsCHK
            // 
            this.rpsCHK.AutoHeight = false;
            this.rpsCHK.Name = "rpsCHK";
            this.rpsCHK.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpsCHK.ValueChecked = "Y";
            this.rpsCHK.ValueUnchecked = "N";
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "No";
            this.gridColumn1.FieldName = "SNO";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.OptionsFilter.AllowFilter = false;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 1;
            this.gridColumn1.Width = 35;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "형태";
            this.gridColumn2.ColumnEdit = this.rpsCboImg;
            this.gridColumn2.FieldName = "STATUS";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.OptionsFilter.AllowFilter = false;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 2;
            this.gridColumn2.Width = 35;
            // 
            // rpsCboImg
            // 
            this.rpsCboImg.AutoHeight = false;
            this.rpsCboImg.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboImg.GlyphAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.rpsCboImg.Items.AddRange(new DevExpress.XtraEditors.Controls.ImageComboBoxItem[] {
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", "0", 0),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", "1", 1),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", "2", 2),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", "3", 3),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", "4", 4),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", "5", 5),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", "6", 6)});
            this.rpsCboImg.Name = "rpsCboImg";
            this.rpsCboImg.SmallImages = this.imageList1;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceCell.Options.UseImage = true;
            this.gridColumn3.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.Caption = " ";
            this.gridColumn3.FieldName = "IMGCHK";
            this.gridColumn3.ImageAlignment = System.Drawing.StringAlignment.Center;
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.OptionsFilter.AllowFilter = false;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 3;
            this.gridColumn3.Width = 35;
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.Caption = "첨부파일";
            this.gridColumn4.FieldName = "FILENAME2";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.AllowEdit = false;
            this.gridColumn4.OptionsFilter.AllowFilter = false;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 4;
            this.gridColumn4.Width = 160;
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.Caption = "DESC";
            this.gridColumn5.FieldName = "DESC1";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.OptionsFilter.AllowFilter = false;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 5;
            this.gridColumn5.Width = 150;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.Caption = "입력일자";
            this.gridColumn6.FieldName = "IDATE";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.OptionsFilter.AllowFilter = false;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 6;
            this.gridColumn6.Width = 80;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.Caption = "부서명";
            this.gridColumn7.FieldName = "DEPT";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            this.gridColumn7.OptionsFilter.AllowFilter = false;
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 7;
            this.gridColumn7.Width = 120;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "REALFILE";
            this.gridColumn8.FieldName = "REALFILE";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsColumn.AllowEdit = false;
            this.gridColumn8.OptionsFilter.AllowFilter = false;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "FILEPATH";
            this.gridColumn9.FieldName = "FILEPATH";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.AllowEdit = false;
            this.gridColumn9.OptionsFilter.AllowFilter = false;
            // 
            // gridColumn10
            // 
            this.gridColumn10.Caption = "AFILECODE";
            this.gridColumn10.FieldName = "AFILECODE";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.OptionsColumn.AllowEdit = false;
            this.gridColumn10.OptionsFilter.AllowFilter = false;
            // 
            // gridColumn11
            // 
            this.gridColumn11.Caption = "FILEGBN";
            this.gridColumn11.FieldName = "FILEGBN";
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.OptionsColumn.AllowEdit = false;
            this.gridColumn11.OptionsFilter.AllowFilter = false;
            // 
            // gridColumn13
            // 
            this.gridColumn13.Caption = "FILEINFO";
            this.gridColumn13.FieldName = "FILEINFO";
            this.gridColumn13.Name = "gridColumn13";
            // 
            // memREMARK
            // 
            this.memREMARK.Location = new System.Drawing.Point(104, 410);
            this.memREMARK.Name = "memREMARK";
            this.memREMARK.Size = new System.Drawing.Size(490, 61);
            this.memREMARK.StyleController = this.xtraLayoutControlExt1;
            this.memREMARK.TabIndex = 30;
            // 
            // memCS_CONTENT
            // 
            this.memCS_CONTENT.Location = new System.Drawing.Point(104, 314);
            this.memCS_CONTENT.Name = "memCS_CONTENT";
            this.memCS_CONTENT.Size = new System.Drawing.Size(490, 92);
            this.memCS_CONTENT.StyleController = this.xtraLayoutControlExt1;
            this.memCS_CONTENT.TabIndex = 27;
            // 
            // memCONTENT
            // 
            this.memCONTENT.Location = new System.Drawing.Point(104, 232);
            this.memCONTENT.Name = "memCONTENT";
            this.memCONTENT.Size = new System.Drawing.Size(490, 78);
            this.memCONTENT.StyleController = this.xtraLayoutControlExt1;
            this.memCONTENT.TabIndex = 26;
            this.stdValidationManager1.SetValidation(this.memCONTENT, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // dteCDATE
            // 
            this.dteCDATE.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.ReadOnly;
            this.dteCDATE.EditValue = null;
            this.dteCDATE.EnterExecuteButton = null;
            this.dteCDATE.FocusColor = System.Drawing.Color.Empty;
            this.dteCDATE.Key = "CDATE";
            this.dteCDATE.Location = new System.Drawing.Point(418, 136);
            this.dteCDATE.MinLength = 0;
            this.dteCDATE.Name = "dteCDATE";
            this.dteCDATE.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(233)))), ((int)(((byte)(206)))));
            this.dteCDATE.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(95)))), ((int)(((byte)(3)))));
            this.dteCDATE.Properties.Appearance.Options.UseBackColor = true;
            this.dteCDATE.Properties.Appearance.Options.UseForeColor = true;
            this.dteCDATE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteCDATE.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteCDATE.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Vista;
            this.dteCDATE.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.dteCDATE.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dteCDATE.Properties.ReadOnly = true;
            this.dteCDATE.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.True;
            this.dteCDATE.Size = new System.Drawing.Size(122, 20);
            this.dteCDATE.StyleController = this.xtraLayoutControlExt1;
            this.dteCDATE.TabIndex = 24;
            this.stdValidationManager1.SetValidation(this.dteCDATE, new HHI.ShipBuilding.Controls.ValidationType[0]);
            // 
            // dteIDATE
            // 
            this.dteIDATE.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.ReadOnly;
            this.dteIDATE.EditValue = null;
            this.dteIDATE.EnterExecuteButton = null;
            this.dteIDATE.FocusColor = System.Drawing.Color.Empty;
            this.dteIDATE.Key = "IDATE";
            this.dteIDATE.Location = new System.Drawing.Point(418, 86);
            this.dteIDATE.MinLength = 0;
            this.dteIDATE.Name = "dteIDATE";
            this.dteIDATE.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(233)))), ((int)(((byte)(206)))));
            this.dteIDATE.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(95)))), ((int)(((byte)(3)))));
            this.dteIDATE.Properties.Appearance.Options.UseBackColor = true;
            this.dteIDATE.Properties.Appearance.Options.UseForeColor = true;
            this.dteIDATE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteIDATE.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteIDATE.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Vista;
            this.dteIDATE.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.dteIDATE.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dteIDATE.Properties.ReadOnly = true;
            this.dteIDATE.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.True;
            this.dteIDATE.Size = new System.Drawing.Size(122, 20);
            this.dteIDATE.StyleController = this.xtraLayoutControlExt1;
            this.dteIDATE.TabIndex = 23;
            this.stdValidationManager1.SetValidation(this.dteIDATE, new HHI.ShipBuilding.Controls.ValidationType[0]);
            // 
            // txtCODE
            // 
            this.txtCODE.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.ReadOnly;
            this.txtCODE.EditValue = "";
            this.txtCODE.EnterExecuteButton = null;
            this.txtCODE.FocusColor = System.Drawing.Color.Empty;
            this.txtCODE.IsValueTrim = true;
            this.txtCODE.Key = "CODE";
            this.txtCODE.Location = new System.Drawing.Point(104, 38);
            this.txtCODE.MinLength = 0;
            this.txtCODE.Name = "txtCODE";
            this.txtCODE.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(233)))), ((int)(((byte)(206)))));
            this.txtCODE.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(95)))), ((int)(((byte)(3)))));
            this.txtCODE.Properties.Appearance.Options.UseBackColor = true;
            this.txtCODE.Properties.Appearance.Options.UseForeColor = true;
            this.txtCODE.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtCODE.Properties.ReadOnly = true;
            this.txtCODE.Size = new System.Drawing.Size(92, 20);
            this.txtCODE.StyleController = this.xtraLayoutControlExt1;
            this.txtCODE.TabIndex = 16;
            this.txtCODE.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // btnSearchProgramPopup
            // 
            this.btnSearchProgramPopup.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_조회;
            this.btnSearchProgramPopup.IsExecuteWdworkerLog = true;
            this.btnSearchProgramPopup.Location = new System.Drawing.Point(568, 184);
            this.btnSearchProgramPopup.Name = "btnSearchProgramPopup";
            this.btnSearchProgramPopup.Size = new System.Drawing.Size(26, 20);
            this.btnSearchProgramPopup.StyleController = this.xtraLayoutControlExt1;
            this.btnSearchProgramPopup.TabIndex = 15;
            this.btnSearchProgramPopup.Text = " ";
            this.btnSearchProgramPopup.UseSplasher = false;
            this.btnSearchProgramPopup.Click += new System.EventHandler(this.btnSearchProgramPopup_Click);
            // 
            // txtTELNO
            // 
            this.txtTELNO.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.txtTELNO.EditValue = "";
            this.txtTELNO.EnterExecuteButton = null;
            this.txtTELNO.FocusColor = System.Drawing.Color.Empty;
            this.txtTELNO.IsValueTrim = true;
            this.txtTELNO.Key = "TELNO";
            this.txtTELNO.Location = new System.Drawing.Point(104, 86);
            this.txtTELNO.MinLength = 0;
            this.txtTELNO.Name = "txtTELNO";
            this.txtTELNO.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.txtTELNO.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtTELNO.Properties.Appearance.Options.UseBackColor = true;
            this.txtTELNO.Properties.Appearance.Options.UseForeColor = true;
            this.txtTELNO.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtTELNO.Size = new System.Drawing.Size(218, 20);
            this.txtTELNO.StyleController = this.xtraLayoutControlExt1;
            this.txtTELNO.TabIndex = 13;
            this.txtTELNO.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtTELNO, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // txtRCV_USERNAME
            // 
            this.txtRCV_USERNAME.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.txtRCV_USERNAME.EditValue = "";
            this.txtRCV_USERNAME.EnterExecuteButton = null;
            this.txtRCV_USERNAME.FocusColor = System.Drawing.Color.Empty;
            this.txtRCV_USERNAME.IsValueTrim = true;
            this.txtRCV_USERNAME.Key = "RCV_USERNAME";
            this.txtRCV_USERNAME.Location = new System.Drawing.Point(418, 110);
            this.txtRCV_USERNAME.MinLength = 0;
            this.txtRCV_USERNAME.Name = "txtRCV_USERNAME";
            this.txtRCV_USERNAME.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.txtRCV_USERNAME.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtRCV_USERNAME.Properties.Appearance.Options.UseBackColor = true;
            this.txtRCV_USERNAME.Properties.Appearance.Options.UseForeColor = true;
            this.txtRCV_USERNAME.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtRCV_USERNAME.Size = new System.Drawing.Size(146, 20);
            this.txtRCV_USERNAME.StyleController = this.xtraLayoutControlExt1;
            this.txtRCV_USERNAME.TabIndex = 12;
            this.txtRCV_USERNAME.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtRCV_USERNAME, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // txtRCV_USERDEPTDESC
            // 
            this.txtRCV_USERDEPTDESC.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.txtRCV_USERDEPTDESC.EditValue = "";
            this.txtRCV_USERDEPTDESC.EnterExecuteButton = null;
            this.txtRCV_USERDEPTDESC.FocusColor = System.Drawing.Color.Empty;
            this.txtRCV_USERDEPTDESC.IsValueTrim = true;
            this.txtRCV_USERDEPTDESC.Key = "RCV_USERDEPTDESC";
            this.txtRCV_USERDEPTDESC.Location = new System.Drawing.Point(104, 110);
            this.txtRCV_USERDEPTDESC.MinLength = 0;
            this.txtRCV_USERDEPTDESC.Name = "txtRCV_USERDEPTDESC";
            this.txtRCV_USERDEPTDESC.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.txtRCV_USERDEPTDESC.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtRCV_USERDEPTDESC.Properties.Appearance.Options.UseBackColor = true;
            this.txtRCV_USERDEPTDESC.Properties.Appearance.Options.UseForeColor = true;
            this.txtRCV_USERDEPTDESC.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtRCV_USERDEPTDESC.Properties.ReadOnly = true;
            this.txtRCV_USERDEPTDESC.Size = new System.Drawing.Size(218, 20);
            this.txtRCV_USERDEPTDESC.StyleController = this.xtraLayoutControlExt1;
            this.txtRCV_USERDEPTDESC.TabIndex = 11;
            this.txtRCV_USERDEPTDESC.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtRCV_USERDEPTDESC, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // txtPROGRAM_NAME
            // 
            this.txtPROGRAM_NAME.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.ReadOnly;
            this.txtPROGRAM_NAME.EditValue = "";
            this.txtPROGRAM_NAME.EnterExecuteButton = null;
            this.txtPROGRAM_NAME.FocusColor = System.Drawing.Color.Empty;
            this.txtPROGRAM_NAME.IsValueTrim = true;
            this.txtPROGRAM_NAME.Key = "PROGRAM_NAME";
            this.txtPROGRAM_NAME.Location = new System.Drawing.Point(418, 184);
            this.txtPROGRAM_NAME.MinLength = 0;
            this.txtPROGRAM_NAME.Name = "txtPROGRAM_NAME";
            this.txtPROGRAM_NAME.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(233)))), ((int)(((byte)(206)))));
            this.txtPROGRAM_NAME.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(95)))), ((int)(((byte)(3)))));
            this.txtPROGRAM_NAME.Properties.Appearance.Options.UseBackColor = true;
            this.txtPROGRAM_NAME.Properties.Appearance.Options.UseForeColor = true;
            this.txtPROGRAM_NAME.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtPROGRAM_NAME.Properties.ReadOnly = true;
            this.txtPROGRAM_NAME.Size = new System.Drawing.Size(146, 20);
            this.txtPROGRAM_NAME.StyleController = this.xtraLayoutControlExt1;
            this.txtPROGRAM_NAME.TabIndex = 10;
            this.txtPROGRAM_NAME.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtPROGRAM_NAME, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // txtPROGRAM_ID
            // 
            this.txtPROGRAM_ID.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.ReadOnly;
            this.txtPROGRAM_ID.EditValue = "";
            this.txtPROGRAM_ID.EnterExecuteButton = null;
            this.txtPROGRAM_ID.FocusColor = System.Drawing.Color.Empty;
            this.txtPROGRAM_ID.IsValueTrim = true;
            this.txtPROGRAM_ID.Key = "PROGRAM_ID";
            this.txtPROGRAM_ID.Location = new System.Drawing.Point(104, 184);
            this.txtPROGRAM_ID.MinLength = 0;
            this.txtPROGRAM_ID.Name = "txtPROGRAM_ID";
            this.txtPROGRAM_ID.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(233)))), ((int)(((byte)(206)))));
            this.txtPROGRAM_ID.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(95)))), ((int)(((byte)(3)))));
            this.txtPROGRAM_ID.Properties.Appearance.Options.UseBackColor = true;
            this.txtPROGRAM_ID.Properties.Appearance.Options.UseForeColor = true;
            this.txtPROGRAM_ID.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtPROGRAM_ID.Properties.ReadOnly = true;
            this.txtPROGRAM_ID.Size = new System.Drawing.Size(218, 20);
            this.txtPROGRAM_ID.StyleController = this.xtraLayoutControlExt1;
            this.txtPROGRAM_ID.TabIndex = 9;
            this.txtPROGRAM_ID.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtPROGRAM_ID, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // txtSUBJECT
            // 
            this.txtSUBJECT.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtSUBJECT.EditValue = "";
            this.txtSUBJECT.EnterExecuteButton = null;
            this.txtSUBJECT.FocusColor = System.Drawing.Color.Empty;
            this.txtSUBJECT.IsValueTrim = true;
            this.txtSUBJECT.Key = "SUBJECT";
            this.txtSUBJECT.Location = new System.Drawing.Point(104, 208);
            this.txtSUBJECT.MinLength = 0;
            this.txtSUBJECT.Name = "txtSUBJECT";
            this.txtSUBJECT.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtSUBJECT.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtSUBJECT.Properties.Appearance.Options.UseBackColor = true;
            this.txtSUBJECT.Properties.Appearance.Options.UseForeColor = true;
            this.txtSUBJECT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSUBJECT.Size = new System.Drawing.Size(490, 20);
            this.txtSUBJECT.StyleController = this.xtraLayoutControlExt1;
            this.txtSUBJECT.TabIndex = 8;
            this.txtSUBJECT.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtSUBJECT, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // txtHNAME
            // 
            this.txtHNAME.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.txtHNAME.EditValue = "";
            this.txtHNAME.EnterExecuteButton = null;
            this.txtHNAME.FocusColor = System.Drawing.Color.Empty;
            this.txtHNAME.IsValueTrim = true;
            this.txtHNAME.Key = "HNAME";
            this.txtHNAME.Location = new System.Drawing.Point(418, 62);
            this.txtHNAME.MinLength = 0;
            this.txtHNAME.Name = "txtHNAME";
            this.txtHNAME.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.txtHNAME.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtHNAME.Properties.Appearance.Options.UseBackColor = true;
            this.txtHNAME.Properties.Appearance.Options.UseForeColor = true;
            this.txtHNAME.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtHNAME.Properties.ReadOnly = true;
            this.txtHNAME.Size = new System.Drawing.Size(122, 20);
            this.txtHNAME.StyleController = this.xtraLayoutControlExt1;
            this.txtHNAME.TabIndex = 7;
            this.txtHNAME.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtHNAME, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // txtREQ_DEPTDESC
            // 
            this.txtREQ_DEPTDESC.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.txtREQ_DEPTDESC.EditValue = "";
            this.txtREQ_DEPTDESC.EnterExecuteButton = null;
            this.txtREQ_DEPTDESC.FocusColor = System.Drawing.Color.Empty;
            this.txtREQ_DEPTDESC.IsValueTrim = true;
            this.txtREQ_DEPTDESC.Key = "DEPTDESC";
            this.txtREQ_DEPTDESC.Location = new System.Drawing.Point(104, 62);
            this.txtREQ_DEPTDESC.MinLength = 0;
            this.txtREQ_DEPTDESC.Name = "txtREQ_DEPTDESC";
            this.txtREQ_DEPTDESC.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.txtREQ_DEPTDESC.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtREQ_DEPTDESC.Properties.Appearance.Options.UseBackColor = true;
            this.txtREQ_DEPTDESC.Properties.Appearance.Options.UseForeColor = true;
            this.txtREQ_DEPTDESC.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtREQ_DEPTDESC.Properties.ReadOnly = true;
            this.txtREQ_DEPTDESC.Size = new System.Drawing.Size(218, 20);
            this.txtREQ_DEPTDESC.StyleController = this.xtraLayoutControlExt1;
            this.txtREQ_DEPTDESC.TabIndex = 6;
            this.txtREQ_DEPTDESC.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtREQ_DEPTDESC, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // btnSave
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSave, new string[] {
            "SAVE"});
            this.btnSave.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_저장;
            this.btnSave.IsExecuteWdworkerLog = true;
            this.btnSave.Location = new System.Drawing.Point(448, 12);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(71, 22);
            this.btnSave.StyleController = this.xtraLayoutControlExt1;
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "저장";
            this.btnSave.UseSplasher = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_닫기;
            this.btnClose.IsExecuteWdworkerLog = true;
            this.btnClose.Location = new System.Drawing.Point(523, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(71, 22);
            this.btnClose.StyleController = this.xtraLayoutControlExt1;
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "닫기";
            this.btnClose.UseSplasher = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "Root";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.layoutControlItem2,
            this.emptySpaceItem2,
            this.layoutControlItem3,
            this.layoutControlItem10,
            this.emptySpaceItem4,
            this.emptySpaceItem12,
            this.emptySpaceItem13,
            this.layoutControlItem4,
            this.layoutControlItem15,
            this.layoutControlItem11,
            this.layoutControlItem5,
            this.layoutControlItem17,
            this.layoutControlItem6,
            this.layoutControlItem7,
            this.layoutControlItem23,
            this.layoutControlItem12,
            this.layoutControlItem13,
            this.layoutControlGroup2,
            this.emptySpaceItem10,
            this.layoutControlItem25,
            this.layoutControlItem24,
            this.emptySpaceItem5,
            this.emptySpaceItem1,
            this.layoutControlItem21,
            this.layoutControlItem16,
            this.layoutControlItem8,
            this.layoutControlItem9,
            this.layoutControlItem18,
            this.layoutControlGroup3});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(606, 823);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.btnClose;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(511, 0);
            this.layoutControlItem1.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.btnSave;
            this.layoutControlItem2.CustomizationFormText = "layoutControlItem2";
            this.layoutControlItem2.Location = new System.Drawing.Point(436, 0);
            this.layoutControlItem2.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem2.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(436, 26);
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem3.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem3.Control = this.txtREQ_DEPTDESC;
            this.layoutControlItem3.CustomizationFormText = "시스템코드";
            this.layoutControlItem3.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 50);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(314, 24);
            this.layoutControlItem3.Text = "요청부서";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(89, 16);
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem10.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem10.Control = this.txtTELNO;
            this.layoutControlItem10.CustomizationFormText = "Password";
            this.layoutControlItem10.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem10.Location = new System.Drawing.Point(0, 74);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(314, 24);
            this.layoutControlItem10.Text = "연락처";
            this.layoutControlItem10.TextSize = new System.Drawing.Size(89, 16);
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.CustomizationFormText = "emptySpaceItem4";
            this.emptySpaceItem4.Location = new System.Drawing.Point(532, 74);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(54, 24);
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem12
            // 
            this.emptySpaceItem12.AllowHotTrack = false;
            this.emptySpaceItem12.Location = new System.Drawing.Point(188, 26);
            this.emptySpaceItem12.Name = "emptySpaceItem12";
            this.emptySpaceItem12.Size = new System.Drawing.Size(398, 24);
            this.emptySpaceItem12.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem13
            // 
            this.emptySpaceItem13.AllowHotTrack = false;
            this.emptySpaceItem13.Location = new System.Drawing.Point(532, 50);
            this.emptySpaceItem13.Name = "emptySpaceItem13";
            this.emptySpaceItem13.Size = new System.Drawing.Size(54, 24);
            this.emptySpaceItem13.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem4.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem4.Control = this.txtHNAME;
            this.layoutControlItem4.CustomizationFormText = "시스템명";
            this.layoutControlItem4.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem4.Location = new System.Drawing.Point(314, 50);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(218, 24);
            this.layoutControlItem4.Text = "요청자";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(89, 16);
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem15.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem15.Control = this.dteIDATE;
            this.layoutControlItem15.CustomizationFormText = "유효일자";
            this.layoutControlItem15.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem15.Location = new System.Drawing.Point(314, 74);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.Size = new System.Drawing.Size(218, 24);
            this.layoutControlItem15.Text = "요청일";
            this.layoutControlItem15.TextSize = new System.Drawing.Size(89, 16);
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem11.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem11.Control = this.memCONTENT;
            this.layoutControlItem11.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem11.Location = new System.Drawing.Point(0, 220);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(586, 82);
            this.layoutControlItem11.Text = "요청내용";
            this.layoutControlItem11.TextSize = new System.Drawing.Size(89, 16);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem5.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem5.Control = this.txtSUBJECT;
            this.layoutControlItem5.CustomizationFormText = "다운로드 경로";
            this.layoutControlItem5.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem5.Location = new System.Drawing.Point(0, 196);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(586, 24);
            this.layoutControlItem5.Text = "제목";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(89, 16);
            // 
            // layoutControlItem17
            // 
            this.layoutControlItem17.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem17.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem17.Control = this.memCS_CONTENT;
            this.layoutControlItem17.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem17.Location = new System.Drawing.Point(0, 302);
            this.layoutControlItem17.Name = "layoutControlItem17";
            this.layoutControlItem17.Size = new System.Drawing.Size(586, 96);
            this.layoutControlItem17.Text = "처리내용";
            this.layoutControlItem17.TextSize = new System.Drawing.Size(89, 16);
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem6.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem6.Control = this.txtPROGRAM_ID;
            this.layoutControlItem6.CustomizationFormText = "모듈정보";
            this.layoutControlItem6.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 172);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(314, 24);
            this.layoutControlItem6.Text = "프로그램ID";
            this.layoutControlItem6.TextSize = new System.Drawing.Size(89, 16);
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem7.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem7.Control = this.txtPROGRAM_NAME;
            this.layoutControlItem7.CustomizationFormText = "Class 정보";
            this.layoutControlItem7.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem7.Location = new System.Drawing.Point(314, 172);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(242, 24);
            this.layoutControlItem7.Text = "프로그램명";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(89, 16);
            // 
            // layoutControlItem23
            // 
            this.layoutControlItem23.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem23.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem23.Control = this.memREMARK;
            this.layoutControlItem23.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem23.Location = new System.Drawing.Point(0, 398);
            this.layoutControlItem23.Name = "layoutControlItem23";
            this.layoutControlItem23.Size = new System.Drawing.Size(586, 65);
            this.layoutControlItem23.Text = "비고";
            this.layoutControlItem23.TextSize = new System.Drawing.Size(89, 16);
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.btnSearchProgramPopup;
            this.layoutControlItem12.CustomizationFormText = "layoutControlItem12";
            this.layoutControlItem12.Location = new System.Drawing.Point(556, 172);
            this.layoutControlItem12.MaxSize = new System.Drawing.Size(30, 24);
            this.layoutControlItem12.MinSize = new System.Drawing.Size(30, 24);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(30, 24);
            this.layoutControlItem12.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem12.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem12.TextVisible = false;
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem13.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem13.Control = this.txtCODE;
            this.layoutControlItem13.CustomizationFormText = "과코드";
            this.layoutControlItem13.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem13.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(188, 24);
            this.layoutControlItem13.Text = "No";
            this.layoutControlItem13.TextSize = new System.Drawing.Size(89, 16);
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem20,
            this.layoutControlItem14,
            this.emptySpaceItem3,
            this.layoutControlItem26});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 463);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(586, 165);
            this.layoutControlGroup2.Text = "요청첨부";
            // 
            // layoutControlItem20
            // 
            this.layoutControlItem20.Control = this.grdFILE;
            this.layoutControlItem20.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem20.Name = "layoutControlItem20";
            this.layoutControlItem20.Size = new System.Drawing.Size(562, 96);
            this.layoutControlItem20.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem20.TextVisible = false;
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.btnAttach;
            this.layoutControlItem14.Location = new System.Drawing.Point(422, 0);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Size = new System.Drawing.Size(82, 26);
            this.layoutControlItem14.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem14.TextVisible = false;
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(422, 26);
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem26
            // 
            this.layoutControlItem26.Control = this.btnFileDelete;
            this.layoutControlItem26.Location = new System.Drawing.Point(504, 0);
            this.layoutControlItem26.Name = "layoutControlItem26";
            this.layoutControlItem26.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem26.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem26.TextVisible = false;
            // 
            // emptySpaceItem10
            // 
            this.emptySpaceItem10.AllowHotTrack = false;
            this.emptySpaceItem10.Location = new System.Drawing.Point(532, 148);
            this.emptySpaceItem10.Name = "emptySpaceItem10";
            this.emptySpaceItem10.Size = new System.Drawing.Size(54, 24);
            this.emptySpaceItem10.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem25
            // 
            this.layoutControlItem25.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem25.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem25.Control = this.cboPROCESS;
            this.layoutControlItem25.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem25.Location = new System.Drawing.Point(0, 148);
            this.layoutControlItem25.Name = "layoutControlItem25";
            this.layoutControlItem25.Size = new System.Drawing.Size(229, 24);
            this.layoutControlItem25.Text = "처리상태";
            this.layoutControlItem25.TextSize = new System.Drawing.Size(89, 16);
            // 
            // layoutControlItem24
            // 
            this.layoutControlItem24.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem24.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem24.Control = this.cboGUBUN;
            this.layoutControlItem24.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem24.Location = new System.Drawing.Point(314, 148);
            this.layoutControlItem24.Name = "layoutControlItem24";
            this.layoutControlItem24.Size = new System.Drawing.Size(218, 24);
            this.layoutControlItem24.Text = "내용구분";
            this.layoutControlItem24.TextSize = new System.Drawing.Size(89, 16);
            // 
            // emptySpaceItem5
            // 
            this.emptySpaceItem5.AllowHotTrack = false;
            this.emptySpaceItem5.Location = new System.Drawing.Point(229, 148);
            this.emptySpaceItem5.Name = "emptySpaceItem5";
            this.emptySpaceItem5.Size = new System.Drawing.Size(85, 24);
            this.emptySpaceItem5.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.Location = new System.Drawing.Point(532, 124);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(54, 24);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem21
            // 
            this.layoutControlItem21.Control = this.txtRCV_TELNO;
            this.layoutControlItem21.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem21.Location = new System.Drawing.Point(0, 124);
            this.layoutControlItem21.Name = "layoutControlItem21";
            this.layoutControlItem21.Size = new System.Drawing.Size(314, 24);
            this.layoutControlItem21.Text = "담당자 연락처";
            this.layoutControlItem21.TextSize = new System.Drawing.Size(89, 16);
            // 
            // layoutControlItem16
            // 
            this.layoutControlItem16.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem16.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem16.Control = this.dteCDATE;
            this.layoutControlItem16.CustomizationFormText = "유효일자";
            this.layoutControlItem16.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem16.Location = new System.Drawing.Point(314, 124);
            this.layoutControlItem16.Name = "layoutControlItem16";
            this.layoutControlItem16.Size = new System.Drawing.Size(218, 24);
            this.layoutControlItem16.Text = "완료일";
            this.layoutControlItem16.TextSize = new System.Drawing.Size(89, 16);
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem8.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem8.Control = this.txtRCV_USERDEPTDESC;
            this.layoutControlItem8.CustomizationFormText = "FTP 서버 경로";
            this.layoutControlItem8.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem8.Location = new System.Drawing.Point(0, 98);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(314, 26);
            this.layoutControlItem8.Text = "담당부서";
            this.layoutControlItem8.TextSize = new System.Drawing.Size(89, 16);
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem9.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem9.Control = this.txtRCV_USERNAME;
            this.layoutControlItem9.CustomizationFormText = "사용자ID";
            this.layoutControlItem9.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem9.Location = new System.Drawing.Point(314, 98);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(242, 26);
            this.layoutControlItem9.Text = "담당자";
            this.layoutControlItem9.TextSize = new System.Drawing.Size(89, 16);
            // 
            // layoutControlItem18
            // 
            this.layoutControlItem18.Control = this.btnGetRCVPopup;
            this.layoutControlItem18.Location = new System.Drawing.Point(556, 98);
            this.layoutControlItem18.MaxSize = new System.Drawing.Size(30, 26);
            this.layoutControlItem18.MinSize = new System.Drawing.Size(30, 26);
            this.layoutControlItem18.Name = "layoutControlItem18";
            this.layoutControlItem18.Size = new System.Drawing.Size(30, 26);
            this.layoutControlItem18.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem18.Text = " ";
            this.layoutControlItem18.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem18.TextVisible = false;
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup3.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem19,
            this.emptySpaceItem6,
            this.layoutControlItem22,
            this.layoutControlItem27});
            this.layoutControlGroup3.Location = new System.Drawing.Point(0, 628);
            this.layoutControlGroup3.Name = "layoutControlGroup3";
            this.layoutControlGroup3.Size = new System.Drawing.Size(586, 175);
            this.layoutControlGroup3.Text = "회신첨부";
            // 
            // layoutControlItem19
            // 
            this.layoutControlItem19.Control = this.grdFile2;
            this.layoutControlItem19.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem19.Name = "layoutControlItem19";
            this.layoutControlItem19.Size = new System.Drawing.Size(562, 106);
            this.layoutControlItem19.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem19.TextVisible = false;
            // 
            // emptySpaceItem6
            // 
            this.emptySpaceItem6.AllowHotTrack = false;
            this.emptySpaceItem6.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem6.Name = "emptySpaceItem6";
            this.emptySpaceItem6.Size = new System.Drawing.Size(422, 26);
            this.emptySpaceItem6.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem22
            // 
            this.layoutControlItem22.Control = this.btnAttach2;
            this.layoutControlItem22.Location = new System.Drawing.Point(422, 0);
            this.layoutControlItem22.Name = "layoutControlItem22";
            this.layoutControlItem22.Size = new System.Drawing.Size(82, 26);
            this.layoutControlItem22.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem22.TextVisible = false;
            // 
            // layoutControlItem27
            // 
            this.layoutControlItem27.Control = this.btnFileDelete2;
            this.layoutControlItem27.Location = new System.Drawing.Point(504, 0);
            this.layoutControlItem27.Name = "layoutControlItem27";
            this.layoutControlItem27.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem27.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem27.TextVisible = false;
            // 
            // stdValidationManager1
            // 
            this.stdValidationManager1.IsNullorWhiteSpace = true;
            this.stdValidationManager1.IsShowErrorMessage = true;
            // 
            // SCSYS024P1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(606, 823);
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS024P1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "정보 저장";
            this.Load += new System.EventHandler(this.SCSYS006P1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboImg2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdFile2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvFile2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRCV_TELNO.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboPROCESS.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboGUBUN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdFILE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvFILE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.memREMARK.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.memCS_CONTENT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.memCONTENT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteCDATE.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteCDATE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteIDATE.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteIDATE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCODE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTELNO.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRCV_USERNAME.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRCV_USERDEPTDESC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPROGRAM_NAME.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPROGRAM_ID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSUBJECT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHNAME.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtREQ_DEPTDESC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem27)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private Client.Controls.DXperience.XtraTextEditExt txtTELNO;
        private Client.Controls.DXperience.XtraTextEditExt txtRCV_USERNAME;
        private Client.Controls.DXperience.XtraTextEditExt txtRCV_USERDEPTDESC;
        private Client.Controls.DXperience.XtraTextEditExt txtPROGRAM_NAME;
        private Client.Controls.DXperience.XtraTextEditExt txtPROGRAM_ID;
        private Client.Controls.DXperience.XtraTextEditExt txtSUBJECT;
        private Client.Controls.DXperience.XtraTextEditExt txtHNAME;
        private Client.Controls.DXperience.XtraTextEditExt txtREQ_DEPTDESC;
        private Client.Controls.DXperience.XtraButtonExt btnSave;
        private Client.Controls.DXperience.XtraButtonExt btnClose;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private Controls.StdValidationManager stdValidationManager1;
        private Client.Controls.DXperience.XtraButtonExt btnSearchProgramPopup;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private Client.Controls.DXperience.XtraTextEditExt txtCODE;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private Client.Controls.DXperience.XtraDateEditExt dteIDATE;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private Windows.Forms.StdSecurityManager stdSecurityManager1;
        private Client.Controls.DXperience.XtraDateEditExt dteCDATE;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem16;
        private DevExpress.XtraEditors.MemoEdit memREMARK;
        private DevExpress.XtraEditors.MemoEdit memCS_CONTENT;
        private DevExpress.XtraEditors.MemoEdit memCONTENT;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem12;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem13;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem17;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem23;
        private DevExpress.XtraGrid.GridControl grdFILE;
        private DevExpress.XtraGrid.Views.Grid.GridView grvFILE;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboImg;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem20;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem10;
        private Client.Controls.DXperience.XtraImageComboBoxEditExt cboPROCESS;
        private Client.Controls.DXperience.XtraImageComboBoxEditExt cboGUBUN;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem25;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem24;
        private Client.Controls.DXperience.XtraTextEditExt txtRCV_TELNO;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem5;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem21;
        private DevExpress.XtraEditors.SimpleButton btnAttach;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private Client.Controls.DXperience.XtraButtonExt btnGetRCVPopup;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem18;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpsCHK;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraEditors.SimpleButton btnAttach2;
        private DevExpress.XtraGrid.GridControl grdFile2;
        private DevExpress.XtraGrid.Views.Grid.GridView grvFile2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn20;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn21;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn22;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn23;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn24;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn25;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn26;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem19;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem6;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem22;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboImg2;
        private System.Windows.Forms.ImageList imageList1;
        private Client.Controls.DXperience.XtraButtonExt btnFileDelete2;
        private Client.Controls.DXperience.XtraButtonExt btnFileDelete;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem26;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem27;
    }
}