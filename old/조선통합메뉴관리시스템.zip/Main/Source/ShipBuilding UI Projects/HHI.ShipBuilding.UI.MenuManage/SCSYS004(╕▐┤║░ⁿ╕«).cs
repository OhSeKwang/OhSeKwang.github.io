﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using DevExpress.XtraTreeList.Nodes;
using System.Collections;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS004 : StdUserControlBase// UserControl
    {
        /// <summary>
        /// 메뉴리스트를 담고있는 cache객체
        /// </summary>
        Hashtable menuListTable = new Hashtable();

        public SCSYS004()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }

        private void SCSYS004_Load(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                ClientControlHelper.LookUpBind(rpsLookUpMENU_ACTION, ClientControlHelper.GetCodeInfo("SY004"), "CDNM", "CDCODE");
                //rpsLookUpMENU_ACTION.Columns["CDCODE"].Visible = true;
            }
        }

        #region 버튼이벤트
        #region 조회
        private void btnSearch_Click(object sender, EventArgs e)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("MENU_ID", txtMENU_ID.Text);
            parameter.DataList.Add("TITLE", txtTITLE.Text);


            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS004.SEARCH_01", parameter);

            if (resultSet.IsSuccess)
            {
                treeList1.DataSource = resultSet.QuerySet.Tables[0];
                treeList1.ExpandAll();
                treeList1.VertScrollVisibility = DevExpress.XtraTreeList.ScrollVisibility.Always;
                treeList1.HorzScrollVisibility = DevExpress.XtraTreeList.ScrollVisibility.Always;
            }
            else
            {
                MessageBox.Show(resultSet.ExceptionMessage);
            }

            //TreeListNode parentNode = treeList1.Nodes[0];

            //// insert a new node as the first child within its parent

            //TreeListNode newNode = treeList1.AppendNode(new object[] { "New first child" }, parentNode);

            //treeList1.SetNodeIndex(newNode, 0);



        }
        #endregion
        /// <summary>
        /// TreeList에 Empty DataTable을 추가한다
        /// </summary>
        private void CreateEmptyTreeDataSource()
        {
            if (treeList1.DataSource == null)
            {
                DataTable treeSource = new DataTable();
                treeSource.Columns.Add("MENU_ID");
                treeSource.Columns.Add("SYSTEM_CODE");
                treeSource.Columns.Add("PARENT_ID");
                treeSource.Columns.Add("USE_YN");
                
                
                //treeSource.Columns.Add("EXPANDED");

                treeList1.DataSource = treeSource;
            }
        }

        private DataRow CreateNewNodeData(string parentId, string systemcode)
        {
            DataTable menuListInfo = null;
            menuListInfo = (treeList1.DataSource as DataTable).Clone();
            DataRow newRow = null;
            if (menuListInfo != null)
            {
                string newMenuID = Guid.NewGuid().ToString();

                //cache정보 생성

                newRow = menuListInfo.NewRow();
                //기본값 설정
                //newRow["SYSTEM_CODE"] = cboSYSTEM_CODE.EditValue.ToString();                
                newRow["MENU_ID"] = "";
                newRow["SYSTEM_CODE"] = systemcode;

                newRow["PARENT_ID"] = parentId;
                newRow["PROGRAM_ID"] = "";
                newRow["TITLE"] = "cccc";
                newRow["DISPLAY_TITLE"] = "";
                newRow["MENU_ACTION"] = 0;
                newRow["EXTRA_INFO"] = "";
                newRow["CUSTOM_ACTION"] = 0;
                newRow["MENU_ORDER"] = 0;
                newRow["EXPANDED"] = 0;
                newRow["MENU_HIDE"] = 0;
                newRow["USE_YN"] = "Y";
                newRow["DIV"] = "A";
                
                
                menuListTable.Add(newMenuID, newRow);
            }

            return newRow;
        }
        #region 최상위 Root생성

        /// <summary>
        /// Root Node를 신규로 추가한다
        /// </summary>
        /// <param name="rootNodeIndex"></param>
        private void TreeMenuRootNodeAppend(int rootNodeIndex)
        {
            CreateEmptyTreeDataSource();

            DataRow newMenuRow = CreateNewNodeData("", "");


            TreeListNode newNode = treeList1.AppendNode(new object[] { newMenuRow["MENU_ID"].ToString(), newMenuRow["SYSTEM_CODE"].ToString(), newMenuRow["PARENT_ID"].ToString(), "Y"}, null);
            treeList1.SetNodeIndex(newNode, rootNodeIndex);
        }

        #endregion

        private void btnNew_Click(object sender, EventArgs e)
        {

            DataTable dt = treeList1.DataSource as DataTable;

            /* 
             * 노드리스트가 없으면 신규추가
             * 노드를 선택되었는지 체크
             * 선택된 노드와 같은 레벨에서 노드추가후 index는 0으로 지정
             */
            if (treeList1.Nodes.Count == 0)
                TreeMenuRootNodeAppend(0);
            else
            {
                if (treeList1.FocusedNode != null)
                {
                    CreateEmptyTreeDataSource();

                    string parentMenuID = treeList1.FocusedNode.ParentNode != null ? treeList1.FocusedNode.ParentNode["MENU_ID"].ToString() : "";

                    string systemcode = treeList1.FocusedNode.ParentNode != null ? treeList1.FocusedNode.ParentNode.GetValue("SYSTEM_CODE").ToString() : ""; 

                    DataRow newMenuRow = CreateNewNodeData(parentMenuID, systemcode);

                    TreeListNode node = treeList1.FocusedNode;



                    TreeListNode newNode = treeList1.AppendNode(new object[] { newMenuRow["MENU_ID"].ToString(), newMenuRow["SYSTEM_CODE"].ToString(),parentMenuID
                                                                        , newMenuRow["PROGRAM_ID"].ToString(), newMenuRow["TITLE"].ToString(), newMenuRow["DISPLAY_TITLE"].ToString()
                                                                        , newMenuRow["MENU_ACTION"].ToString(), newMenuRow["EXTRA_INFO"].ToString(), newMenuRow["CUSTOM_ACTION"].ToString()
                                                                        , newMenuRow["MENU_ORDER"].ToString(), newMenuRow["EXPANDED"].ToString(), newMenuRow["MENU_HIDE"].ToString()
                                                                        , newMenuRow["USE_YN"].ToString()}, treeList1.FocusedNode.ParentNode);
                    

                    newNode.Checked = true;

                    treeList1.SetNodeIndex(newNode, 0);
                }
                else
                {
                    MessageBox.Show("노드를 선택하세요!!!");
                }
            }
        }
        #endregion

        private void treeList1_ShowingEditor(object sender, CancelEventArgs e)
        {
            TreeListNode node = treeList1.FocusedNode;
            if (node != null)
            {
                string strFieldName = treeList1.FocusedColumn.FieldName;
                if (strFieldName.Equals("MENU_ID") || strFieldName.Equals("SYSTEM_CODE") || strFieldName.Equals("PARENT_ID"))
                {
                    if (node.GetValue("DIV").ToString().Equals("S"))
                        e.Cancel = true;
                    else
                        e.Cancel = false;
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (treeList1.Nodes.Count == 0)
            { MessageBox.Show("데이터를 조회하세요...."); return; }

            List<TreeListNode> checkedlist = treeList1.GetAllCheckedNodes();

            if (checkedlist.Count  == 0)
            { MessageBox.Show("저장할 데이터를 선택하세요...."); return; }


            
            



            //DataTable dtMaster = (treeList1.DataSource as DataTable).Clone();

            

            string[] paramnames = new string[] { "MENU_ID", "SYSTEM_CODE", "PARENT_ID", "PROGRAM_ID", "TITLE", "DISPLAY_TITLE", "MENU_ACTION"
                 , "EXTRA_INFO", "CUSTOM_ACTION", "MENU_ORDER", "EXPANDED", "MENU_HIDE", "USE_YN"};



            DataTable controlParamInfo = new DataTable("controlParamInfo");
            for (int cnt = 0; cnt < paramnames.Length; cnt++)
            {
                controlParamInfo.Columns.Add(paramnames[cnt], (treeList1.DataSource as DataTable).Columns[paramnames[cnt]].DataType);
            }

            DataPack parameter = new DataPack();

            

            foreach (DataColumn col in controlParamInfo.Columns)
            {
                string[] col1 = new string[checkedlist.Count];
                for (int i = 0; i < checkedlist.Count; i++)
                {
                    if (checkedlist[i][col.ColumnName] == System.DBNull.Value)
                    {
                        col1[i] = string.Empty;
                    }
                    else
                    {
                        col1[i] = checkedlist[i][col.ColumnName].ToString();
                    }
                }
                parameter.DataList.Add(col.ColumnName, col1);

            }
                parameter.ArrayItemCount = checkedlist.Count; //==> ArrayBind 처리시... 항상 지정해야함...


                DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS004.SAVE_01", parameter);

                if (resultSet.IsSuccess)
                {
                    MessageBox.Show("OK....");
                    //btnSearch.PerformClick();
                }
                else
                {
                    MessageBox.Show(resultSet.ExceptionMessage);
                }

            //    if (!dtMaster.Columns.Contains(col.ColumnName))
            //        throw new Exception(string.Format("필드명{0}을 찾을 수 없습니다."));

            //    if (col.DataType.Equals(typeof(int)))
            //    {
            //        int[] col1 = new int[dtMaster.Rows.Count];

            //        for (int i = 0; i < dtMaster.Rows.Count; i++)
            //        {
            //            if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
            //            {
            //                col1[i] = 0;
            //            }
            //            else
            //            {
            //                col1[i] = int.Parse(string.IsNullOrWhiteSpace(dtMaster.Rows[i][col.ColumnName].ToString()) ? "0" : dtMaster.Rows[i][col.ColumnName].ToString());
            //            }
            //        }

            //        parameter.DataList.Add(col.ColumnName, col1);
            //    }
            //    else
            //    {
                    //string[] col1 = new string[dtMaster.Rows.Count];

            //        for (int i = 0; i < dtMaster.Rows.Count; i++)
            //        {
            //            if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
            //            {
            //                col1[i] = string.Empty;
            //            }
            //            else
            //            {
            //                col1[i] = dtMaster.Rows[i][col.ColumnName].ToString();
            //            }
            //        }

            //        parameter.DataList.Add(col.ColumnName, col1);
            //    }

                
            
            ////dataPack.ArrayItemCount = controlParamInfo.Rows.Count;
            ////dataPack.DataList.ItemCount = controlParamInfo.Rows.Count;

            //parameter.ArrayItemCount = dtMaster.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            
            //    DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS007.SAVE_01", parameter);

            //    if (resultSet.IsSuccess)
            //    {
            //        MessageBox.Show("OK....");
            //        //btnSearch.PerformClick();
            //    }
            //    else
            //    {
            //        MessageBox.Show(resultSet.ExceptionMessage);
            //    }
            

            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (treeList1.Nodes.Count == 0)
            { MessageBox.Show("데이터를 조회하세요...."); return; }

            List<TreeListNode> checkedlist = treeList1.GetAllCheckedNodes();

            if (checkedlist.Count  == 0)
            { MessageBox.Show("삭제할 데이터를 선택하세요...."); return; }


            string[] paramnames = new string[] {"MENU_ID"};


            DataTable controlParamInfo = new DataTable("controlParamInfo");
            for (int cnt = 0; cnt < paramnames.Length; cnt++)
            {
                controlParamInfo.Columns.Add(paramnames[cnt], (treeList1.DataSource as DataTable).Columns[paramnames[cnt]].DataType);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in controlParamInfo.Columns)
            {
                string[] col1 = new string[checkedlist.Count];
                for (int i = 0; i < checkedlist.Count; i++)
                {
                    if (checkedlist[i][col.ColumnName] == System.DBNull.Value)
                    {
                        col1[i] = string.Empty;
                    }
                    else
                    {
                        col1[i] = checkedlist[i][col.ColumnName].ToString();
                    }
                }
                parameter.DataList.Add(col.ColumnName, col1);

            }
            parameter.ArrayItemCount = checkedlist.Count; //==> ArrayBind 처리시... 항상 지정해야함...


            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS004.DELETE_01", parameter);

            if (resultSet.IsSuccess)
            {
                MessageBox.Show("OK....");
                //재조회
                btnSearch.PerformClick();
            }
            else
            {
                MessageBox.Show(resultSet.ExceptionMessage);
            }
                 
        }

        private void btnChildNodeAdd_Click(object sender, EventArgs e)
        {
            

            CreateEmptyTreeDataSource();

            string parentMenuID = treeList1.FocusedNode != null ? treeList1.FocusedNode["MENU_ID"].ToString() : "";

            string systemcode = treeList1.FocusedNode != null ? treeList1.FocusedNode.GetValue("SYSTEM_CODE").ToString() : "";

            DataRow newMenuRow = CreateNewNodeData(parentMenuID, systemcode);

            // 추가된 노드에 자식노드를 추가한경우 RETURN
            if (treeList1.FocusedNode.GetValue("DIV").ToString().Equals("A"))
            {
                MessageBox.Show("노드를 저장후 추가하세요."); return;
            }


            TreeListNode newNode = treeList1.AppendNode(new object[] { newMenuRow["MENU_ID"].ToString(), newMenuRow["SYSTEM_CODE"].ToString(),newMenuRow["PARENT_ID"].ToString()
                                                                        , newMenuRow["PROGRAM_ID"].ToString(), newMenuRow["TITLE"].ToString(), newMenuRow["DISPLAY_TITLE"].ToString()
                                                                        , newMenuRow["MENU_ACTION"].ToString(), newMenuRow["EXTRA_INFO"].ToString(), newMenuRow["CUSTOM_ACTION"].ToString()
                                                                        , newMenuRow["MENU_ORDER"].ToString(), newMenuRow["EXPANDED"].ToString(), newMenuRow["MENU_HIDE"].ToString()
                                                                        , newMenuRow["USE_YN"].ToString(), newMenuRow["MENU_ID"].ToString(), "A"}, treeList1.FocusedNode);
            newNode.Checked = true;
            
            treeList1.SetNodeIndex(newNode, 0);

            //treeList1.FocusedNode = newNode;

            //treeList1.FocusedNode["PARENT_ID"] = parentMenuID;


        }

        
    }
}
