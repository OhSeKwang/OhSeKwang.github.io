﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS016
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SCSYS016));
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.btnMENUID_S = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.dteDATE_TO = new HHI.ShipBuilding.Client.Controls.DXperience.XtraDateEditExt();
            this.dteDATE_FROM = new HHI.ShipBuilding.Client.Controls.DXperience.XtraDateEditExt();
            this.cboSYSTEM_CODE = new HHI.ShipBuilding.Client.Controls.DXperience.XtraImageComboBoxEditExt();
            this.grdMaster = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvMaster = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colCHK = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCHK = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.colDEPTNAME = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colUSER_ID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCNNT_DATE = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSYSTEM_CODE = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboSystemCode = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.colMENU_ID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colMENU_NAME = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCNNT_CNT = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDIV = new DevExpress.XtraGrid.Columns.GridColumn();
            this.txtMENU_ID = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtUSER_ID = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnSearch = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem5 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.stdSecurityManager1 = new HHI.ShipBuilding.Windows.Forms.StdSecurityManager(this.components);
            this.stdButtonExecuteManager1 = new HHI.ShipBuilding.Controls.StdButtonExecuteManager(this.components);
            this.stdValidationManager1 = new HHI.ShipBuilding.Controls.StdValidationManager(this.components);
            this.colKOR_NM = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colJOB_TIT_NM = new DevExpress.XtraGrid.Columns.GridColumn();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dteDATE_TO.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteDATE_TO.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteDATE_FROM.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteDATE_FROM.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboSYSTEM_CODE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMaster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMaster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboSystemCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMENU_ID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUSER_ID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.btnMENUID_S);
            this.xtraLayoutControlExt1.Controls.Add(this.dteDATE_TO);
            this.xtraLayoutControlExt1.Controls.Add(this.dteDATE_FROM);
            this.xtraLayoutControlExt1.Controls.Add(this.cboSYSTEM_CODE);
            this.xtraLayoutControlExt1.Controls.Add(this.grdMaster);
            this.xtraLayoutControlExt1.Controls.Add(this.txtMENU_ID);
            this.xtraLayoutControlExt1.Controls.Add(this.txtUSER_ID);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearch);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(770, 395, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(974, 624);
            this.xtraLayoutControlExt1.TabIndex = 0;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // btnMENUID_S
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnMENUID_S, new string[] {
            "SELECT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnMENUID_S, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnMENUID_S, true);
            this.btnMENUID_S.Image = ((System.Drawing.Image)(resources.GetObject("btnMENUID_S.Image")));
            this.btnMENUID_S.IsExecuteWdworkerLog = true;
            this.btnMENUID_S.Location = new System.Drawing.Point(475, 83);
            this.btnMENUID_S.Name = "btnMENUID_S";
            this.btnMENUID_S.Size = new System.Drawing.Size(26, 22);
            this.btnMENUID_S.StyleController = this.xtraLayoutControlExt1;
            this.btnMENUID_S.TabIndex = 5;
            this.btnMENUID_S.UseSplasher = true;
            this.btnMENUID_S.Click += new System.EventHandler(this.btnMENUID_S_Click);
            // 
            // dteDATE_TO
            // 
            this.dteDATE_TO.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.dteDATE_TO.EditValue = null;
            this.dteDATE_TO.EnterExecuteButton = null;
            this.dteDATE_TO.FocusColor = System.Drawing.Color.Empty;
            this.dteDATE_TO.Key = "";
            this.dteDATE_TO.Location = new System.Drawing.Point(488, 59);
            this.dteDATE_TO.MinLength = 0;
            this.dteDATE_TO.Name = "dteDATE_TO";
            this.dteDATE_TO.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.dteDATE_TO.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.dteDATE_TO.Properties.Appearance.Options.UseBackColor = true;
            this.dteDATE_TO.Properties.Appearance.Options.UseForeColor = true;
            this.dteDATE_TO.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteDATE_TO.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteDATE_TO.Properties.CalendarTimeProperties.CloseUpKey = new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.F4);
            this.dteDATE_TO.Properties.CalendarTimeProperties.PopupBorderStyle = DevExpress.XtraEditors.Controls.PopupBorderStyles.Default;
            this.dteDATE_TO.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Vista;
            this.dteDATE_TO.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.dteDATE_TO.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dteDATE_TO.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.True;
            this.dteDATE_TO.Size = new System.Drawing.Size(118, 20);
            this.dteDATE_TO.StyleController = this.xtraLayoutControlExt1;
            this.dteDATE_TO.TabIndex = 12;
            this.stdValidationManager1.SetValidation(this.dteDATE_TO, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // dteDATE_FROM
            // 
            this.dteDATE_FROM.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.dteDATE_FROM.EditValue = null;
            this.dteDATE_FROM.EnterExecuteButton = null;
            this.dteDATE_FROM.FocusColor = System.Drawing.Color.Empty;
            this.dteDATE_FROM.Key = "";
            this.dteDATE_FROM.Location = new System.Drawing.Point(347, 59);
            this.dteDATE_FROM.MinLength = 0;
            this.dteDATE_FROM.Name = "dteDATE_FROM";
            this.dteDATE_FROM.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.dteDATE_FROM.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.dteDATE_FROM.Properties.Appearance.Options.UseBackColor = true;
            this.dteDATE_FROM.Properties.Appearance.Options.UseForeColor = true;
            this.dteDATE_FROM.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteDATE_FROM.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteDATE_FROM.Properties.CalendarTimeProperties.CloseUpKey = new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.F4);
            this.dteDATE_FROM.Properties.CalendarTimeProperties.PopupBorderStyle = DevExpress.XtraEditors.Controls.PopupBorderStyles.Default;
            this.dteDATE_FROM.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Vista;
            this.dteDATE_FROM.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.dteDATE_FROM.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dteDATE_FROM.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.True;
            this.dteDATE_FROM.Size = new System.Drawing.Size(127, 20);
            this.dteDATE_FROM.StyleController = this.xtraLayoutControlExt1;
            this.dteDATE_FROM.TabIndex = 11;
            this.stdValidationManager1.SetValidation(this.dteDATE_FROM, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // cboSYSTEM_CODE
            // 
            this.cboSYSTEM_CODE.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.cboSYSTEM_CODE.EditValue = "";
            this.cboSYSTEM_CODE.EnterExecuteButton = null;
            this.cboSYSTEM_CODE.FocusColor = System.Drawing.Color.Empty;
            this.cboSYSTEM_CODE.Key = "";
            this.cboSYSTEM_CODE.Location = new System.Drawing.Point(100, 59);
            this.cboSYSTEM_CODE.MinLength = 0;
            this.cboSYSTEM_CODE.Name = "cboSYSTEM_CODE";
            this.cboSYSTEM_CODE.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.cboSYSTEM_CODE.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.cboSYSTEM_CODE.Properties.Appearance.Options.UseBackColor = true;
            this.cboSYSTEM_CODE.Properties.Appearance.Options.UseForeColor = true;
            this.cboSYSTEM_CODE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboSYSTEM_CODE.Size = new System.Drawing.Size(167, 20);
            this.cboSYSTEM_CODE.StyleController = this.xtraLayoutControlExt1;
            this.cboSYSTEM_CODE.TabIndex = 10;
            // 
            // grdMaster
            // 
            this.grdMaster.CheckBoxFieldName = "CHK";
            this.grdMaster.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdMaster.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdMaster.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdMaster.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdMaster.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdMaster.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdMaster.IsHeaderClickAllCheckedItem = true;
            this.grdMaster.Location = new System.Drawing.Point(24, 153);
            this.grdMaster.MainView = this.grvMaster;
            this.grdMaster.MinLength = 0;
            this.grdMaster.Name = "grdMaster";
            this.grdMaster.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpsCHK,
            this.rpsCboSystemCode});
            this.grdMaster.Size = new System.Drawing.Size(926, 447);
            this.grdMaster.TabIndex = 9;
            this.grdMaster.UseEmbeddedNavigator = true;
            this.grdMaster.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvMaster});
            // 
            // grvMaster
            // 
            this.grvMaster.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colCHK,
            this.colDEPTNAME,
            this.colJOB_TIT_NM,
            this.colKOR_NM,
            this.colUSER_ID,
            this.colCNNT_DATE,
            this.colSYSTEM_CODE,
            this.colMENU_ID,
            this.colMENU_NAME,
            this.colCNNT_CNT,
            this.colDIV});
            this.grvMaster.GridControl = this.grdMaster;
            this.grvMaster.GroupCount = 1;
            this.grvMaster.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "CNNT_CNT", this.colCNNT_CNT, "Sum={0:n0}")});
            this.grvMaster.Name = "grvMaster";
            this.grvMaster.OptionsBehavior.AutoExpandAllGroups = true;
            this.grvMaster.OptionsBehavior.Editable = false;
            this.grvMaster.OptionsView.ColumnAutoWidth = false;
            this.grvMaster.OptionsView.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.grvMaster.OptionsView.ShowFooter = true;
            this.grvMaster.OptionsView.ShowGroupedColumns = true;
            this.grvMaster.OptionsView.ShowGroupPanel = false;
            this.grvMaster.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colCNNT_DATE, DevExpress.Data.ColumnSortOrder.Ascending)});
            // 
            // colCHK
            // 
            this.colCHK.AppearanceHeader.Options.UseTextOptions = true;
            this.colCHK.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colCHK.Caption = "선택";
            this.colCHK.ColumnEdit = this.rpsCHK;
            this.colCHK.FieldName = "CHK";
            this.colCHK.Name = "colCHK";
            this.colCHK.Width = 56;
            // 
            // rpsCHK
            // 
            this.rpsCHK.AutoHeight = false;
            this.rpsCHK.Caption = "Check";
            this.rpsCHK.Name = "rpsCHK";
            this.rpsCHK.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpsCHK.ValueChecked = "Y";
            this.rpsCHK.ValueUnchecked = "N";
            // 
            // colDEPTNAME
            // 
            this.colDEPTNAME.AppearanceHeader.Options.UseTextOptions = true;
            this.colDEPTNAME.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDEPTNAME.Caption = "부서명";
            this.colDEPTNAME.FieldName = "DEPTNAME";
            this.colDEPTNAME.Name = "colDEPTNAME";
            this.colDEPTNAME.Visible = true;
            this.colDEPTNAME.VisibleIndex = 0;
            this.colDEPTNAME.Width = 165;
            // 
            // colUSER_ID
            // 
            this.colUSER_ID.AppearanceHeader.Options.UseTextOptions = true;
            this.colUSER_ID.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colUSER_ID.Caption = "사용자ID";
            this.colUSER_ID.FieldName = "USER_ID";
            this.colUSER_ID.Name = "colUSER_ID";
            this.colUSER_ID.Visible = true;
            this.colUSER_ID.VisibleIndex = 3;
            // 
            // colCNNT_DATE
            // 
            this.colCNNT_DATE.AppearanceCell.Options.UseTextOptions = true;
            this.colCNNT_DATE.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colCNNT_DATE.AppearanceHeader.Options.UseTextOptions = true;
            this.colCNNT_DATE.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colCNNT_DATE.Caption = "접속날짜";
            this.colCNNT_DATE.FieldName = "CNNT_DATE";
            this.colCNNT_DATE.Name = "colCNNT_DATE";
            this.colCNNT_DATE.UnboundType = DevExpress.Data.UnboundColumnType.DateTime;
            this.colCNNT_DATE.Visible = true;
            this.colCNNT_DATE.VisibleIndex = 4;
            this.colCNNT_DATE.Width = 90;
            // 
            // colSYSTEM_CODE
            // 
            this.colSYSTEM_CODE.AppearanceHeader.Options.UseTextOptions = true;
            this.colSYSTEM_CODE.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSYSTEM_CODE.Caption = "시스템코드";
            this.colSYSTEM_CODE.ColumnEdit = this.rpsCboSystemCode;
            this.colSYSTEM_CODE.FieldName = "SYSTEM_CODE";
            this.colSYSTEM_CODE.Name = "colSYSTEM_CODE";
            this.colSYSTEM_CODE.Visible = true;
            this.colSYSTEM_CODE.VisibleIndex = 5;
            this.colSYSTEM_CODE.Width = 180;
            // 
            // rpsCboSystemCode
            // 
            this.rpsCboSystemCode.AutoHeight = false;
            this.rpsCboSystemCode.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboSystemCode.Name = "rpsCboSystemCode";
            // 
            // colMENU_ID
            // 
            this.colMENU_ID.AppearanceHeader.Options.UseTextOptions = true;
            this.colMENU_ID.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMENU_ID.Caption = "메뉴ID";
            this.colMENU_ID.FieldName = "MENU_ID";
            this.colMENU_ID.Name = "colMENU_ID";
            this.colMENU_ID.Visible = true;
            this.colMENU_ID.VisibleIndex = 6;
            // 
            // colMENU_NAME
            // 
            this.colMENU_NAME.AppearanceHeader.Options.UseTextOptions = true;
            this.colMENU_NAME.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMENU_NAME.Caption = "메뉴명";
            this.colMENU_NAME.FieldName = "MENU_NAME";
            this.colMENU_NAME.Name = "colMENU_NAME";
            this.colMENU_NAME.Visible = true;
            this.colMENU_NAME.VisibleIndex = 7;
            this.colMENU_NAME.Width = 180;
            // 
            // colCNNT_CNT
            // 
            this.colCNNT_CNT.AppearanceCell.Options.UseTextOptions = true;
            this.colCNNT_CNT.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.colCNNT_CNT.AppearanceHeader.Options.UseTextOptions = true;
            this.colCNNT_CNT.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colCNNT_CNT.Caption = "접속카운트";
            this.colCNNT_CNT.FieldName = "CNNT_CNT";
            this.colCNNT_CNT.Name = "colCNNT_CNT";
            this.colCNNT_CNT.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "CNNT_CNT", "{0:n0}")});
            this.colCNNT_CNT.Visible = true;
            this.colCNNT_CNT.VisibleIndex = 8;
            this.colCNNT_CNT.Width = 96;
            // 
            // colDIV
            // 
            this.colDIV.Caption = "DIV";
            this.colDIV.FieldName = "DIV";
            this.colDIV.Name = "colDIV";
            // 
            // txtMENU_ID
            // 
            this.txtMENU_ID.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtMENU_ID.EditValue = "";
            this.txtMENU_ID.EnterExecuteButton = null;
            this.txtMENU_ID.FocusColor = System.Drawing.Color.Empty;
            this.txtMENU_ID.IsValueTrim = true;
            this.txtMENU_ID.Key = "";
            this.txtMENU_ID.Location = new System.Drawing.Point(347, 83);
            this.txtMENU_ID.MinLength = 0;
            this.txtMENU_ID.Name = "txtMENU_ID";
            this.txtMENU_ID.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtMENU_ID.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtMENU_ID.Properties.Appearance.Options.UseBackColor = true;
            this.txtMENU_ID.Properties.Appearance.Options.UseForeColor = true;
            this.txtMENU_ID.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtMENU_ID.Size = new System.Drawing.Size(124, 20);
            this.txtMENU_ID.StyleController = this.xtraLayoutControlExt1;
            this.txtMENU_ID.TabIndex = 7;
            this.txtMENU_ID.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtUSER_ID
            // 
            this.txtUSER_ID.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtUSER_ID.EditValue = "";
            this.txtUSER_ID.EnterExecuteButton = null;
            this.txtUSER_ID.FocusColor = System.Drawing.Color.Empty;
            this.txtUSER_ID.IsValueTrim = true;
            this.txtUSER_ID.Key = "";
            this.txtUSER_ID.Location = new System.Drawing.Point(100, 83);
            this.txtUSER_ID.MinLength = 0;
            this.txtUSER_ID.Name = "txtUSER_ID";
            this.txtUSER_ID.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtUSER_ID.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtUSER_ID.Properties.Appearance.Options.UseBackColor = true;
            this.txtUSER_ID.Properties.Appearance.Options.UseForeColor = true;
            this.txtUSER_ID.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtUSER_ID.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtUSER_ID.Size = new System.Drawing.Size(118, 20);
            this.txtUSER_ID.StyleController = this.xtraLayoutControlExt1;
            this.txtUSER_ID.TabIndex = 6;
            this.txtUSER_ID.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // btnSearch
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSearch, new string[] {
            "SELECT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSearch, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSearch, true);
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.IsExecuteWdworkerLog = true;
            this.btnSearch.Location = new System.Drawing.Point(892, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(70, 22);
            this.btnSearch.StyleController = this.xtraLayoutControlExt1;
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "조회";
            this.btnSearch.UseSplasher = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "layoutControlGroup1";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup1, false);
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem1,
            this.layoutControlItem1,
            this.layoutControlGroup2,
            this.layoutControlGroup3});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(974, 624);
            this.layoutControlGroup1.Text = "Root";
            this.layoutControlGroup1.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(880, 26);
            this.emptySpaceItem1.Text = "emptySpaceItem1";
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.btnSearch;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(880, 0);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(74, 26);
            this.layoutControlItem1.Text = "layoutControlItem1";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextToControlDistance = 0;
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.CustomizationFormText = "List";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup2, false);
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem6});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 109);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(954, 495);
            this.layoutControlGroup2.Text = "List";
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.grdMaster;
            this.layoutControlItem6.CustomizationFormText = "layoutControlItem6";
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(930, 451);
            this.layoutControlItem6.Text = "layoutControlItem6";
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextToControlDistance = 0;
            this.layoutControlItem6.TextVisible = false;
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 1F);
            this.layoutControlGroup3.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup3.CustomizationFormText = " ";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup3, true);
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem2,
            this.layoutControlItem8,
            this.emptySpaceItem3,
            this.layoutControlItem3,
            this.layoutControlItem4,
            this.layoutControlItem2,
            this.layoutControlItem5,
            this.emptySpaceItem4,
            this.emptySpaceItem5,
            this.layoutControlItem7});
            this.layoutControlGroup3.Location = new System.Drawing.Point(0, 26);
            this.layoutControlGroup3.Name = "layoutControlGroup3";
            this.layoutControlGroup3.Size = new System.Drawing.Size(954, 83);
            this.layoutControlGroup3.Text = " ";
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(586, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(344, 24);
            this.emptySpaceItem2.Text = "emptySpaceItem2";
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.cboSYSTEM_CODE;
            this.layoutControlItem8.CustomizationFormText = "업무구분";
            this.layoutControlItem8.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem8.Image")));
            this.layoutControlItem8.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(247, 24);
            this.layoutControlItem8.Text = "시스템코드";
            this.layoutControlItem8.TextSize = new System.Drawing.Size(73, 16);
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.CustomizationFormText = "emptySpaceItem3";
            this.emptySpaceItem3.Location = new System.Drawing.Point(481, 24);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(449, 26);
            this.emptySpaceItem3.Text = "emptySpaceItem3";
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.txtUSER_ID;
            this.layoutControlItem3.CustomizationFormText = "AuthName";
            this.layoutControlItem3.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem3.Image")));
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 24);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(198, 26);
            this.layoutControlItem3.Text = "사용자 ID";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(73, 16);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.txtMENU_ID;
            this.layoutControlItem4.CustomizationFormText = "Note";
            this.layoutControlItem4.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem4.Image")));
            this.layoutControlItem4.Location = new System.Drawing.Point(247, 24);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(204, 26);
            this.layoutControlItem4.Text = "메뉴ID";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(73, 16);
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.dteDATE_FROM;
            this.layoutControlItem2.CustomizationFormText = "날짜";
            this.layoutControlItem2.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_blue;
            this.layoutControlItem2.Location = new System.Drawing.Point(247, 0);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(207, 24);
            this.layoutControlItem2.Text = "날짜";
            this.layoutControlItem2.TextSize = new System.Drawing.Size(73, 16);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.dteDATE_TO;
            this.layoutControlItem5.CustomizationFormText = "종료일자";
            this.layoutControlItem5.Location = new System.Drawing.Point(464, 0);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(122, 24);
            this.layoutControlItem5.Text = "종료일자";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem5.TextToControlDistance = 0;
            this.layoutControlItem5.TextVisible = false;
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.CustomizationFormText = "~";
            this.emptySpaceItem4.Location = new System.Drawing.Point(454, 0);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(10, 24);
            this.emptySpaceItem4.Text = "~";
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(73, 0);
            this.emptySpaceItem4.TextVisible = true;
            // 
            // emptySpaceItem5
            // 
            this.emptySpaceItem5.AllowHotTrack = false;
            this.emptySpaceItem5.CustomizationFormText = "emptySpaceItem5";
            this.emptySpaceItem5.Location = new System.Drawing.Point(198, 24);
            this.emptySpaceItem5.Name = "emptySpaceItem5";
            this.emptySpaceItem5.Size = new System.Drawing.Size(49, 26);
            this.emptySpaceItem5.Text = "emptySpaceItem5";
            this.emptySpaceItem5.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.btnMENUID_S;
            this.layoutControlItem7.CustomizationFormText = "layoutControlItem7";
            this.layoutControlItem7.Location = new System.Drawing.Point(451, 24);
            this.layoutControlItem7.MaxSize = new System.Drawing.Size(30, 26);
            this.layoutControlItem7.MinSize = new System.Drawing.Size(30, 26);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(30, 26);
            this.layoutControlItem7.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem7.Text = "layoutControlItem7";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem7.TextToControlDistance = 0;
            this.layoutControlItem7.TextVisible = false;
            // 
            // stdValidationManager1
            // 
            this.stdValidationManager1.IsNullorWhiteSpace = true;
            this.stdValidationManager1.IsShowErrorMessage = true;
            // 
            // colKOR_NM
            // 
            this.colKOR_NM.AppearanceHeader.Options.UseTextOptions = true;
            this.colKOR_NM.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colKOR_NM.Caption = "사용자명";
            this.colKOR_NM.FieldName = "KOR_NM";
            this.colKOR_NM.Name = "colKOR_NM";
            this.colKOR_NM.Visible = true;
            this.colKOR_NM.VisibleIndex = 2;
            this.colKOR_NM.Width = 100;
            // 
            // colJOB_TIT_NM
            // 
            this.colJOB_TIT_NM.AppearanceHeader.Options.UseTextOptions = true;
            this.colJOB_TIT_NM.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colJOB_TIT_NM.Caption = "직위";
            this.colJOB_TIT_NM.FieldName = "JOB_TIT_NM";
            this.colJOB_TIT_NM.Name = "colJOB_TIT_NM";
            this.colJOB_TIT_NM.Visible = true;
            this.colJOB_TIT_NM.VisibleIndex = 1;
            this.colJOB_TIT_NM.Width = 90;
            // 
            // SCSYS016
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS016";
            this.Size = new System.Drawing.Size(974, 624);
            this.Shown += new System.EventHandler(this.SCSYS016_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dteDATE_TO.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteDATE_TO.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteDATE_FROM.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteDATE_FROM.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboSYSTEM_CODE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMaster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMaster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboSystemCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMENU_ID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUSER_ID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private Client.Controls.DXperience.XtraGridControlExt grdMaster;
        private DevExpress.XtraGrid.Views.Grid.GridView grvMaster;
        private DevExpress.XtraGrid.Columns.GridColumn colCHK;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpsCHK;
        private Client.Controls.DXperience.XtraTextEditExt txtMENU_ID;
        private Client.Controls.DXperience.XtraTextEditExt txtUSER_ID;
        private Client.Controls.DXperience.XtraButtonExt btnSearch;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraGrid.Columns.GridColumn colDIV;
        private Client.Controls.DXperience.XtraImageComboBoxEditExt cboSYSTEM_CODE;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private Windows.Forms.StdSecurityManager stdSecurityManager1;
        private Controls.StdButtonExecuteManager stdButtonExecuteManager1;
        private DevExpress.XtraGrid.Columns.GridColumn colUSER_ID;
        private DevExpress.XtraGrid.Columns.GridColumn colMENU_ID;
        private DevExpress.XtraGrid.Columns.GridColumn colCNNT_DATE;
        private DevExpress.XtraGrid.Columns.GridColumn colSYSTEM_CODE;
        private DevExpress.XtraGrid.Columns.GridColumn colCNNT_CNT;
        private Client.Controls.DXperience.XtraDateEditExt dteDATE_TO;
        private Client.Controls.DXperience.XtraDateEditExt dteDATE_FROM;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private Controls.StdValidationManager stdValidationManager1;
        private DevExpress.XtraGrid.Columns.GridColumn colMENU_NAME;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboSystemCode;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem5;
        private Client.Controls.DXperience.XtraButtonExt btnMENUID_S;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraGrid.Columns.GridColumn colDEPTNAME;
        private DevExpress.XtraGrid.Columns.GridColumn colJOB_TIT_NM;
        private DevExpress.XtraGrid.Columns.GridColumn colKOR_NM;
    }
}
