﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS022
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject3 = new DevExpress.Utils.SerializableAppearanceObject();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SCSYS022));
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.grdInput = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvInput = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemButtonEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.repositoryItemDateEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.lueROOT_MENU = new DevExpress.XtraEditors.LookUpEdit();
            this.grdSub = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvSub = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colSel = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.colSystemCode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSystemName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemButtonEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.repositoryItemDateEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.chkUSEYN = new HHI.ShipBuilding.Client.Controls.DXperience.XtraCheckEditExt();
            this.btnModify = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.txtIAFILE = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonEditExt();
            this.txtICAPTION = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.dteITDATE = new HHI.ShipBuilding.Client.Controls.DXperience.XtraDateEditExt();
            this.dteIFDATE = new HHI.ShipBuilding.Client.Controls.DXperience.XtraDateEditExt();
            this.btnInsert = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.dteTDATE = new DevExpress.XtraEditors.DateEdit();
            this.dteFDATE = new DevExpress.XtraEditors.DateEdit();
            this.grdMain = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvMain = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colChk = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpyChkUseYN = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.colFrom = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.colTo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colHeaderText = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.colAfile = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.colUseYN = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colWriter = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colUpdater = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colROOT_MENUS = new DevExpress.XtraGrid.Columns.GridColumn();
            this.btnSearch = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnDelete = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.splitterItem1 = new DevExpress.XtraLayout.SplitterItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup4 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem5 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem6 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.simpleSeparator2 = new DevExpress.XtraLayout.SimpleSeparator();
            this.simpleSeparator3 = new DevExpress.XtraLayout.SimpleSeparator();
            this.simpleSeparator4 = new DevExpress.XtraLayout.SimpleSeparator();
            this.simpleSeparator1 = new DevExpress.XtraLayout.SimpleSeparator();
            this.splitterItem2 = new DevExpress.XtraLayout.SplitterItem();
            this.stdButtonExecuteManager1 = new HHI.ShipBuilding.Controls.StdButtonExecuteManager(this.components);
            this.stdSecurityManager1 = new HHI.ShipBuilding.Windows.Forms.StdSecurityManager(this.components);
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdInput)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvInput)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit3.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueROOT_MENU.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdSub)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvSub)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkUSEYN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIAFILE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtICAPTION.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteITDATE.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteITDATE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteIFDATE.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteIFDATE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteTDATE.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteTDATE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteFDATE.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteFDATE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpyChkUseYN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem2)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.grdInput);
            this.xtraLayoutControlExt1.Controls.Add(this.lueROOT_MENU);
            this.xtraLayoutControlExt1.Controls.Add(this.grdSub);
            this.xtraLayoutControlExt1.Controls.Add(this.chkUSEYN);
            this.xtraLayoutControlExt1.Controls.Add(this.btnModify);
            this.xtraLayoutControlExt1.Controls.Add(this.txtIAFILE);
            this.xtraLayoutControlExt1.Controls.Add(this.txtICAPTION);
            this.xtraLayoutControlExt1.Controls.Add(this.dteITDATE);
            this.xtraLayoutControlExt1.Controls.Add(this.dteIFDATE);
            this.xtraLayoutControlExt1.Controls.Add(this.btnInsert);
            this.xtraLayoutControlExt1.Controls.Add(this.dteTDATE);
            this.xtraLayoutControlExt1.Controls.Add(this.dteFDATE);
            this.xtraLayoutControlExt1.Controls.Add(this.grdMain);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearch);
            this.xtraLayoutControlExt1.Controls.Add(this.btnDelete);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(785, 268, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(1135, 600);
            this.xtraLayoutControlExt1.TabIndex = 1;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // grdInput
            // 
            this.grdInput.CheckBoxFieldName = "CHK";
            this.grdInput.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdInput.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdInput.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdInput.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdInput.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdInput.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdInput.IsHeaderClickAllCheckedItem = true;
            this.grdInput.Location = new System.Drawing.Point(24, 237);
            this.grdInput.MainView = this.grvInput;
            this.grdInput.MinLength = 0;
            this.grdInput.Name = "grdInput";
            this.grdInput.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit2,
            this.repositoryItemTextEdit3,
            this.repositoryItemButtonEdit3,
            this.repositoryItemDateEdit3});
            this.grdInput.Size = new System.Drawing.Size(328, 339);
            this.grdInput.TabIndex = 24;
            this.grdInput.UseEmbeddedNavigator = true;
            this.grdInput.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvInput});
            // 
            // grvInput
            // 
            this.grvInput.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3});
            this.grvInput.GridControl = this.grdInput;
            this.grvInput.Name = "grvInput";
            this.grvInput.OptionsBehavior.Editable = false;
            this.grvInput.OptionsView.ShowGroupPanel = false;
            this.grvInput.RowClick += new DevExpress.XtraGrid.Views.Grid.RowClickEventHandler(this.grvInput_RowClick);
            this.grvInput.RowCellStyle += new DevExpress.XtraGrid.Views.Grid.RowCellStyleEventHandler(this.grv_RowCellStyle);
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "선택";
            this.gridColumn1.ColumnEdit = this.repositoryItemCheckEdit2;
            this.gridColumn1.FieldName = "CHK";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 35;
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.Caption = "Check";
            this.repositoryItemCheckEdit2.CheckStyle = DevExpress.XtraEditors.Controls.CheckStyles.Style1;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            this.repositoryItemCheckEdit2.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.repositoryItemCheckEdit2.ValueChecked = "Y";
            this.repositoryItemCheckEdit2.ValueUnchecked = "N";
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "메뉴 ID";
            this.gridColumn2.FieldName = "MENU_ID";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            this.gridColumn2.Width = 70;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.Caption = "최상위 메뉴명";
            this.gridColumn3.FieldName = "DISPLAY_TITLE";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 2;
            this.gridColumn3.Width = 200;
            // 
            // repositoryItemTextEdit3
            // 
            this.repositoryItemTextEdit3.AutoHeight = false;
            this.repositoryItemTextEdit3.MaxLength = 20;
            this.repositoryItemTextEdit3.Name = "repositoryItemTextEdit3";
            // 
            // repositoryItemButtonEdit3
            // 
            this.repositoryItemButtonEdit3.AutoHeight = false;
            this.repositoryItemButtonEdit3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Ellipsis, "...", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, "", null, null, true)});
            this.repositoryItemButtonEdit3.Name = "repositoryItemButtonEdit3";
            this.repositoryItemButtonEdit3.ReadOnly = true;
            // 
            // repositoryItemDateEdit3
            // 
            this.repositoryItemDateEdit3.AutoHeight = false;
            this.repositoryItemDateEdit3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit3.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit3.CalendarTimeProperties.CloseUpKey = new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.F4);
            this.repositoryItemDateEdit3.CalendarTimeProperties.PopupBorderStyle = DevExpress.XtraEditors.Controls.PopupBorderStyles.Default;
            this.repositoryItemDateEdit3.Name = "repositoryItemDateEdit3";
            // 
            // lueROOT_MENU
            // 
            this.lueROOT_MENU.Location = new System.Drawing.Point(909, 59);
            this.lueROOT_MENU.Name = "lueROOT_MENU";
            this.lueROOT_MENU.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lueROOT_MENU.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("MENU_ID", 80, "메뉴 ID"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("DISPLAY_TITLE", 200, "최상위 메뉴명")});
            this.lueROOT_MENU.Properties.DropDownRows = 10;
            this.lueROOT_MENU.Properties.NullText = "";
            this.lueROOT_MENU.Size = new System.Drawing.Size(138, 20);
            this.lueROOT_MENU.StyleController = this.xtraLayoutControlExt1;
            this.lueROOT_MENU.TabIndex = 24;
            // 
            // grdSub
            // 
            this.grdSub.CheckBoxFieldName = "CHK";
            this.grdSub.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdSub.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdSub.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdSub.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdSub.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdSub.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdSub.IsHeaderClickAllCheckedItem = true;
            this.grdSub.Location = new System.Drawing.Point(873, 132);
            this.grdSub.MainView = this.grvSub;
            this.grdSub.MinLength = 0;
            this.grdSub.Name = "grdSub";
            this.grdSub.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit1,
            this.repositoryItemTextEdit2,
            this.repositoryItemButtonEdit2,
            this.repositoryItemDateEdit2});
            this.grdSub.Size = new System.Drawing.Size(238, 444);
            this.grdSub.TabIndex = 23;
            this.grdSub.UseEmbeddedNavigator = true;
            this.grdSub.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvSub});
            // 
            // grvSub
            // 
            this.grvSub.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colSel,
            this.colSystemCode,
            this.colSystemName});
            this.grvSub.GridControl = this.grdSub;
            this.grvSub.Name = "grvSub";
            this.grvSub.OptionsBehavior.Editable = false;
            this.grvSub.OptionsView.ShowGroupPanel = false;
            this.grvSub.RowClick += new DevExpress.XtraGrid.Views.Grid.RowClickEventHandler(this.grvSub_RowClick);
            this.grvSub.RowCellStyle += new DevExpress.XtraGrid.Views.Grid.RowCellStyleEventHandler(this.grv_RowCellStyle);
            // 
            // colSel
            // 
            this.colSel.AppearanceCell.Options.UseTextOptions = true;
            this.colSel.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSel.AppearanceHeader.Options.UseTextOptions = true;
            this.colSel.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSel.Caption = "선택";
            this.colSel.ColumnEdit = this.repositoryItemCheckEdit1;
            this.colSel.FieldName = "CHK";
            this.colSel.Name = "colSel";
            this.colSel.Visible = true;
            this.colSel.VisibleIndex = 0;
            this.colSel.Width = 35;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Caption = "Check";
            this.repositoryItemCheckEdit1.CheckStyle = DevExpress.XtraEditors.Controls.CheckStyles.Style1;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.repositoryItemCheckEdit1.ValueChecked = "Y";
            this.repositoryItemCheckEdit1.ValueUnchecked = "N";
            // 
            // colSystemCode
            // 
            this.colSystemCode.AppearanceCell.Options.UseTextOptions = true;
            this.colSystemCode.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colSystemCode.AppearanceHeader.Options.UseTextOptions = true;
            this.colSystemCode.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSystemCode.Caption = "메뉴 ID";
            this.colSystemCode.FieldName = "MENU_ID";
            this.colSystemCode.Name = "colSystemCode";
            this.colSystemCode.OptionsColumn.AllowEdit = false;
            this.colSystemCode.Visible = true;
            this.colSystemCode.VisibleIndex = 1;
            this.colSystemCode.Width = 70;
            // 
            // colSystemName
            // 
            this.colSystemName.AppearanceCell.Options.UseTextOptions = true;
            this.colSystemName.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colSystemName.AppearanceHeader.Options.UseTextOptions = true;
            this.colSystemName.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSystemName.Caption = "최상위 메뉴명";
            this.colSystemName.FieldName = "DISPLAY_TITLE";
            this.colSystemName.Name = "colSystemName";
            this.colSystemName.OptionsColumn.AllowEdit = false;
            this.colSystemName.Visible = true;
            this.colSystemName.VisibleIndex = 2;
            this.colSystemName.Width = 150;
            // 
            // repositoryItemTextEdit2
            // 
            this.repositoryItemTextEdit2.AutoHeight = false;
            this.repositoryItemTextEdit2.MaxLength = 20;
            this.repositoryItemTextEdit2.Name = "repositoryItemTextEdit2";
            // 
            // repositoryItemButtonEdit2
            // 
            this.repositoryItemButtonEdit2.AutoHeight = false;
            this.repositoryItemButtonEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Ellipsis, "...", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject2, "", null, null, true)});
            this.repositoryItemButtonEdit2.Name = "repositoryItemButtonEdit2";
            this.repositoryItemButtonEdit2.ReadOnly = true;
            // 
            // repositoryItemDateEdit2
            // 
            this.repositoryItemDateEdit2.AutoHeight = false;
            this.repositoryItemDateEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit2.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit2.CalendarTimeProperties.CloseUpKey = new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.F4);
            this.repositoryItemDateEdit2.CalendarTimeProperties.PopupBorderStyle = DevExpress.XtraEditors.Controls.PopupBorderStyles.Default;
            this.repositoryItemDateEdit2.Name = "repositoryItemDateEdit2";
            // 
            // chkUSEYN
            // 
            this.chkUSEYN.EditValue = true;
            this.chkUSEYN.EnterExecuteButton = null;
            this.chkUSEYN.Key = "";
            this.chkUSEYN.Location = new System.Drawing.Point(93, 183);
            this.chkUSEYN.MinLength = 0;
            this.chkUSEYN.Name = "chkUSEYN";
            this.chkUSEYN.Properties.Caption = "";
            this.chkUSEYN.Size = new System.Drawing.Size(259, 19);
            this.chkUSEYN.StyleController = this.xtraLayoutControlExt1;
            this.chkUSEYN.TabIndex = 22;
            // 
            // btnModify
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnModify, new string[] {
            "UPDATE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnModify, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnModify, true);
            this.btnModify.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_저장;
            this.btnModify.IsExecuteWdworkerLog = true;
            this.btnModify.Location = new System.Drawing.Point(977, 12);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(71, 22);
            this.btnModify.StyleController = this.xtraLayoutControlExt1;
            this.btnModify.TabIndex = 21;
            this.btnModify.Text = "수정";
            this.btnModify.UseSplasher = true;
            this.btnModify.Click += new System.EventHandler(this.btnModify_Click);
            // 
            // txtIAFILE
            // 
            this.txtIAFILE.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtIAFILE.EditValue = "";
            this.txtIAFILE.EnterExecuteButton = null;
            this.txtIAFILE.FocusColor = System.Drawing.Color.Empty;
            this.txtIAFILE.IsValueTrim = true;
            this.txtIAFILE.Key = "";
            this.txtIAFILE.Location = new System.Drawing.Point(93, 157);
            this.txtIAFILE.MinLength = 0;
            this.txtIAFILE.Name = "txtIAFILE";
            this.txtIAFILE.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtIAFILE.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtIAFILE.Properties.Appearance.Options.UseBackColor = true;
            this.txtIAFILE.Properties.Appearance.Options.UseForeColor = true;
            this.txtIAFILE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.txtIAFILE.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtIAFILE.Properties.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.txtIAFILE_Properties_ButtonClick);
            this.txtIAFILE.Size = new System.Drawing.Size(259, 20);
            this.txtIAFILE.StyleController = this.xtraLayoutControlExt1;
            this.txtIAFILE.TabIndex = 20;
            this.txtIAFILE.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtICAPTION
            // 
            this.txtICAPTION.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtICAPTION.EditValue = "";
            this.txtICAPTION.EnterExecuteButton = null;
            this.txtICAPTION.FocusColor = System.Drawing.Color.Empty;
            this.txtICAPTION.IsValueTrim = true;
            this.txtICAPTION.Key = "";
            this.txtICAPTION.Location = new System.Drawing.Point(93, 131);
            this.txtICAPTION.MinLength = 0;
            this.txtICAPTION.Name = "txtICAPTION";
            this.txtICAPTION.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtICAPTION.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtICAPTION.Properties.Appearance.Options.UseBackColor = true;
            this.txtICAPTION.Properties.Appearance.Options.UseForeColor = true;
            this.txtICAPTION.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtICAPTION.Properties.MaxLength = 20;
            this.txtICAPTION.Size = new System.Drawing.Size(245, 20);
            this.txtICAPTION.StyleController = this.xtraLayoutControlExt1;
            this.txtICAPTION.TabIndex = 19;
            this.txtICAPTION.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // dteITDATE
            // 
            this.dteITDATE.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.dteITDATE.EditValue = null;
            this.dteITDATE.EnterExecuteButton = null;
            this.dteITDATE.FocusColor = System.Drawing.Color.Empty;
            this.dteITDATE.Key = "";
            this.dteITDATE.Location = new System.Drawing.Point(238, 105);
            this.dteITDATE.MinLength = 0;
            this.dteITDATE.Name = "dteITDATE";
            this.dteITDATE.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.dteITDATE.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.dteITDATE.Properties.Appearance.Options.UseBackColor = true;
            this.dteITDATE.Properties.Appearance.Options.UseForeColor = true;
            this.dteITDATE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteITDATE.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteITDATE.Properties.CalendarTimeProperties.CloseUpKey = new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.F4);
            this.dteITDATE.Properties.CalendarTimeProperties.PopupBorderStyle = DevExpress.XtraEditors.Controls.PopupBorderStyles.Default;
            this.dteITDATE.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Vista;
            this.dteITDATE.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.dteITDATE.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dteITDATE.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.True;
            this.dteITDATE.Size = new System.Drawing.Size(100, 20);
            this.dteITDATE.StyleController = this.xtraLayoutControlExt1;
            this.dteITDATE.TabIndex = 18;
            // 
            // dteIFDATE
            // 
            this.dteIFDATE.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.dteIFDATE.EditValue = null;
            this.dteIFDATE.EnterExecuteButton = null;
            this.dteIFDATE.FocusColor = System.Drawing.Color.Empty;
            this.dteIFDATE.Key = "";
            this.dteIFDATE.Location = new System.Drawing.Point(93, 105);
            this.dteIFDATE.MinLength = 0;
            this.dteIFDATE.Name = "dteIFDATE";
            this.dteIFDATE.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.dteIFDATE.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.dteIFDATE.Properties.Appearance.Options.UseBackColor = true;
            this.dteIFDATE.Properties.Appearance.Options.UseForeColor = true;
            this.dteIFDATE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteIFDATE.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteIFDATE.Properties.CalendarTimeProperties.CloseUpKey = new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.F4);
            this.dteIFDATE.Properties.CalendarTimeProperties.PopupBorderStyle = DevExpress.XtraEditors.Controls.PopupBorderStyles.Default;
            this.dteIFDATE.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Vista;
            this.dteIFDATE.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.dteIFDATE.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dteIFDATE.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.True;
            this.dteIFDATE.Size = new System.Drawing.Size(100, 20);
            this.dteIFDATE.StyleController = this.xtraLayoutControlExt1;
            this.dteIFDATE.TabIndex = 17;
            // 
            // btnInsert
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnInsert, new string[] {
            "INSERT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnInsert, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnInsert, true);
            this.btnInsert.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.btnicon_plus;
            this.btnInsert.IsExecuteWdworkerLog = true;
            this.btnInsert.Location = new System.Drawing.Point(252, 75);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(100, 26);
            this.btnInsert.StyleController = this.xtraLayoutControlExt1;
            this.btnInsert.TabIndex = 16;
            this.btnInsert.Text = "공지 등록";
            this.btnInsert.UseSplasher = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // dteTDATE
            // 
            this.dteTDATE.EditValue = null;
            this.dteTDATE.Location = new System.Drawing.Point(670, 59);
            this.dteTDATE.Name = "dteTDATE";
            this.dteTDATE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteTDATE.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteTDATE.Properties.CalendarTimeProperties.CloseUpKey = new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.F4);
            this.dteTDATE.Properties.CalendarTimeProperties.PopupBorderStyle = DevExpress.XtraEditors.Controls.PopupBorderStyles.Default;
            this.dteTDATE.Size = new System.Drawing.Size(118, 20);
            this.dteTDATE.StyleController = this.xtraLayoutControlExt1;
            this.dteTDATE.TabIndex = 15;
            // 
            // dteFDATE
            // 
            this.dteFDATE.EditValue = null;
            this.dteFDATE.Location = new System.Drawing.Point(459, 59);
            this.dteFDATE.Name = "dteFDATE";
            this.dteFDATE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteFDATE.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteFDATE.Properties.CalendarTimeProperties.CloseUpKey = new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.F4);
            this.dteFDATE.Properties.CalendarTimeProperties.PopupBorderStyle = DevExpress.XtraEditors.Controls.PopupBorderStyles.Default;
            this.dteFDATE.Size = new System.Drawing.Size(118, 20);
            this.dteFDATE.StyleController = this.xtraLayoutControlExt1;
            this.dteFDATE.TabIndex = 14;
            // 
            // grdMain
            // 
            this.grdMain.CheckBoxFieldName = "CHK";
            this.grdMain.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdMain.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdMain.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdMain.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdMain.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdMain.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdMain.IsHeaderClickAllCheckedItem = true;
            this.grdMain.Location = new System.Drawing.Point(385, 132);
            this.grdMain.MainView = this.grvMain;
            this.grdMain.MinLength = 0;
            this.grdMain.Name = "grdMain";
            this.grdMain.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpyChkUseYN,
            this.repositoryItemTextEdit1,
            this.repositoryItemButtonEdit1,
            this.repositoryItemDateEdit1});
            this.grdMain.Size = new System.Drawing.Size(479, 444);
            this.grdMain.TabIndex = 13;
            this.grdMain.UseEmbeddedNavigator = true;
            this.grdMain.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvMain});
            // 
            // grvMain
            // 
            this.grvMain.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colChk,
            this.colFrom,
            this.colTo,
            this.colHeaderText,
            this.colAfile,
            this.colUseYN,
            this.colWriter,
            this.colUpdater,
            this.colROOT_MENUS});
            this.grvMain.GridControl = this.grdMain;
            this.grvMain.Name = "grvMain";
            this.grvMain.OptionsView.ColumnAutoWidth = false;
            this.grvMain.OptionsView.ShowGroupPanel = false;
            this.grvMain.RowClick += new DevExpress.XtraGrid.Views.Grid.RowClickEventHandler(this.grvMain_RowClick);
            this.grvMain.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.grvMain_FocusedRowChanged);
            this.grvMain.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.grvMain_CellValueChanged);
            // 
            // colChk
            // 
            this.colChk.AppearanceCell.Options.UseTextOptions = true;
            this.colChk.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colChk.AppearanceHeader.Options.UseTextOptions = true;
            this.colChk.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colChk.Caption = "선택";
            this.colChk.ColumnEdit = this.rpyChkUseYN;
            this.colChk.FieldName = "CHK";
            this.colChk.Name = "colChk";
            this.colChk.Visible = true;
            this.colChk.VisibleIndex = 0;
            this.colChk.Width = 35;
            // 
            // rpyChkUseYN
            // 
            this.rpyChkUseYN.AutoHeight = false;
            this.rpyChkUseYN.Caption = "Check";
            this.rpyChkUseYN.CheckStyle = DevExpress.XtraEditors.Controls.CheckStyles.Style1;
            this.rpyChkUseYN.Name = "rpyChkUseYN";
            this.rpyChkUseYN.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpyChkUseYN.ValueChecked = "Y";
            this.rpyChkUseYN.ValueUnchecked = "N";
            // 
            // colFrom
            // 
            this.colFrom.AppearanceCell.Options.UseTextOptions = true;
            this.colFrom.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colFrom.AppearanceHeader.Options.UseTextOptions = true;
            this.colFrom.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colFrom.Caption = "시작일";
            this.colFrom.ColumnEdit = this.repositoryItemDateEdit1;
            this.colFrom.DisplayFormat.FormatString = "yyyy-MM-dd";
            this.colFrom.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.colFrom.FieldName = "FDATE";
            this.colFrom.Name = "colFrom";
            this.colFrom.Visible = true;
            this.colFrom.VisibleIndex = 1;
            this.colFrom.Width = 90;
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.CalendarTimeProperties.CloseUpKey = new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.F4);
            this.repositoryItemDateEdit1.CalendarTimeProperties.PopupBorderStyle = DevExpress.XtraEditors.Controls.PopupBorderStyles.Default;
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            // 
            // colTo
            // 
            this.colTo.AppearanceCell.Options.UseTextOptions = true;
            this.colTo.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colTo.AppearanceHeader.Options.UseTextOptions = true;
            this.colTo.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colTo.Caption = "종료일";
            this.colTo.ColumnEdit = this.repositoryItemDateEdit1;
            this.colTo.DisplayFormat.FormatString = "yyyy-MM-dd";
            this.colTo.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.colTo.FieldName = "TDATE";
            this.colTo.Name = "colTo";
            this.colTo.Visible = true;
            this.colTo.VisibleIndex = 2;
            this.colTo.Width = 90;
            // 
            // colHeaderText
            // 
            this.colHeaderText.AppearanceHeader.Options.UseTextOptions = true;
            this.colHeaderText.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colHeaderText.Caption = "팝업 타이틀";
            this.colHeaderText.ColumnEdit = this.repositoryItemTextEdit1;
            this.colHeaderText.FieldName = "CAPTION";
            this.colHeaderText.Name = "colHeaderText";
            this.colHeaderText.Visible = true;
            this.colHeaderText.VisibleIndex = 3;
            this.colHeaderText.Width = 200;
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AutoHeight = false;
            this.repositoryItemTextEdit1.MaxLength = 20;
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // colAfile
            // 
            this.colAfile.AppearanceHeader.Options.UseTextOptions = true;
            this.colAfile.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colAfile.Caption = "PDF 파일";
            this.colAfile.ColumnEdit = this.repositoryItemButtonEdit1;
            this.colAfile.FieldName = "AFILE";
            this.colAfile.Name = "colAfile";
            this.colAfile.Visible = true;
            this.colAfile.VisibleIndex = 4;
            this.colAfile.Width = 200;
            // 
            // repositoryItemButtonEdit1
            // 
            this.repositoryItemButtonEdit1.AutoHeight = false;
            this.repositoryItemButtonEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Ellipsis, "...", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject3, "", null, null, true)});
            this.repositoryItemButtonEdit1.Name = "repositoryItemButtonEdit1";
            this.repositoryItemButtonEdit1.ReadOnly = true;
            this.repositoryItemButtonEdit1.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEdit1_ButtonClick);
            // 
            // colUseYN
            // 
            this.colUseYN.AppearanceCell.Options.UseTextOptions = true;
            this.colUseYN.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colUseYN.AppearanceHeader.Options.UseTextOptions = true;
            this.colUseYN.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colUseYN.Caption = "사용여부";
            this.colUseYN.ColumnEdit = this.rpyChkUseYN;
            this.colUseYN.FieldName = "USEYN";
            this.colUseYN.Name = "colUseYN";
            this.colUseYN.Visible = true;
            this.colUseYN.VisibleIndex = 5;
            // 
            // colWriter
            // 
            this.colWriter.AppearanceCell.Options.UseTextOptions = true;
            this.colWriter.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colWriter.AppearanceHeader.Options.UseTextOptions = true;
            this.colWriter.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colWriter.Caption = "작성자";
            this.colWriter.FieldName = "IUSER_NM";
            this.colWriter.Name = "colWriter";
            this.colWriter.OptionsColumn.AllowEdit = false;
            this.colWriter.Visible = true;
            this.colWriter.VisibleIndex = 6;
            this.colWriter.Width = 100;
            // 
            // colUpdater
            // 
            this.colUpdater.AppearanceCell.Options.UseTextOptions = true;
            this.colUpdater.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colUpdater.AppearanceHeader.Options.UseTextOptions = true;
            this.colUpdater.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colUpdater.Caption = "수정자";
            this.colUpdater.FieldName = "UUSER_NM";
            this.colUpdater.Name = "colUpdater";
            this.colUpdater.OptionsColumn.AllowEdit = false;
            this.colUpdater.Visible = true;
            this.colUpdater.VisibleIndex = 7;
            this.colUpdater.Width = 100;
            // 
            // colROOT_MENUS
            // 
            this.colROOT_MENUS.Caption = "gridColumn4";
            this.colROOT_MENUS.FieldName = "ROOT_MENUS";
            this.colROOT_MENUS.Name = "colROOT_MENUS";
            this.colROOT_MENUS.Visible = true;
            this.colROOT_MENUS.VisibleIndex = 8;
            // 
            // btnSearch
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSearch, new string[] {
            "SELECT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSearch, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSearch, true);
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.IsExecuteWdworkerLog = true;
            this.btnSearch.Location = new System.Drawing.Point(902, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(71, 22);
            this.btnSearch.StyleController = this.xtraLayoutControlExt1;
            this.btnSearch.TabIndex = 7;
            this.btnSearch.Text = "조회";
            this.btnSearch.UseSplasher = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnDelete
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnDelete, new string[] {
            "DELETE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnDelete, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnDelete, false);
            this.btnDelete.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_삭제;
            this.btnDelete.IsExecuteWdworkerLog = true;
            this.btnDelete.Location = new System.Drawing.Point(1052, 12);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(71, 22);
            this.btnDelete.StyleController = this.xtraLayoutControlExt1;
            this.btnDelete.TabIndex = 6;
            this.btnDelete.Text = "삭제";
            this.btnDelete.UseSplasher = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "Root";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup1, false);
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem2,
            this.layoutControlItem1,
            this.layoutControlItem3,
            this.layoutControlGroup3,
            this.layoutControlItem13,
            this.layoutControlGroup2,
            this.layoutControlGroup4,
            this.splitterItem2});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1135, 600);
            this.layoutControlGroup1.Text = "Root";
            this.layoutControlGroup1.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(890, 26);
            this.emptySpaceItem2.Text = "emptySpaceItem2";
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.btnDelete;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(1040, 0);
            this.layoutControlItem1.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem1.Text = "layoutControlItem1";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextToControlDistance = 0;
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.btnSearch;
            this.layoutControlItem3.CustomizationFormText = "layoutControlItem3";
            this.layoutControlItem3.Location = new System.Drawing.Point(890, 0);
            this.layoutControlItem3.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem3.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem3.Text = "layoutControlItem3";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem3.TextToControlDistance = 0;
            this.layoutControlItem3.TextVisible = false;
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup3.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup3.CaptionImage = ((System.Drawing.Image)(resources.GetObject("layoutControlGroup3.CaptionImage")));
            this.layoutControlGroup3.CustomizationFormText = "사용자정보";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup3, false);
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem6,
            this.layoutControlItem7,
            this.splitterItem1});
            this.layoutControlGroup3.Location = new System.Drawing.Point(361, 83);
            this.layoutControlGroup3.Name = "layoutControlGroup3";
            this.layoutControlGroup3.Size = new System.Drawing.Size(754, 497);
            this.layoutControlGroup3.Text = "공지 목록";
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.grdMain;
            this.layoutControlItem6.CustomizationFormText = "layoutControlItem6";
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(483, 448);
            this.layoutControlItem6.Text = "layoutControlItem6";
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextToControlDistance = 0;
            this.layoutControlItem6.TextVisible = false;
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.grdSub;
            this.layoutControlItem7.CustomizationFormText = "layoutControlItem7";
            this.layoutControlItem7.Location = new System.Drawing.Point(488, 0);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(242, 448);
            this.layoutControlItem7.Text = "layoutControlItem7";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem7.TextToControlDistance = 0;
            this.layoutControlItem7.TextVisible = false;
            // 
            // splitterItem1
            // 
            this.splitterItem1.AllowHotTrack = true;
            this.splitterItem1.CustomizationFormText = "splitterItem1";
            this.splitterItem1.Location = new System.Drawing.Point(483, 0);
            this.splitterItem1.Name = "splitterItem1";
            this.splitterItem1.Size = new System.Drawing.Size(5, 448);
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.btnModify;
            this.layoutControlItem13.CustomizationFormText = "수정";
            this.layoutControlItem13.Location = new System.Drawing.Point(965, 0);
            this.layoutControlItem13.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem13.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem13.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem13.Text = "수정";
            this.layoutControlItem13.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem13.TextToControlDistance = 0;
            this.layoutControlItem13.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 1F);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.CustomizationFormText = " ";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup2, true);
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem1,
            this.layoutControlItem2,
            this.layoutControlItem5,
            this.layoutControlItem8});
            this.layoutControlGroup2.Location = new System.Drawing.Point(361, 26);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(754, 57);
            this.layoutControlGroup2.Text = " ";
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(681, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(49, 24);
            this.emptySpaceItem1.Text = "emptySpaceItem1";
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.dteFDATE;
            this.layoutControlItem2.CustomizationFormText = "시작일";
            this.layoutControlItem2.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_blue;
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem2.MaxSize = new System.Drawing.Size(211, 24);
            this.layoutControlItem2.MinSize = new System.Drawing.Size(211, 24);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(211, 24);
            this.layoutControlItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem2.Spacing = new DevExpress.XtraLayout.Utils.Padding(20, 15, 0, 0);
            this.layoutControlItem2.Text = "시작일";
            this.layoutControlItem2.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem2.TextSize = new System.Drawing.Size(49, 16);
            this.layoutControlItem2.TextToControlDistance = 5;
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.dteTDATE;
            this.layoutControlItem5.CustomizationFormText = "종료일";
            this.layoutControlItem5.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_blue;
            this.layoutControlItem5.Location = new System.Drawing.Point(211, 0);
            this.layoutControlItem5.MaxSize = new System.Drawing.Size(211, 24);
            this.layoutControlItem5.MinSize = new System.Drawing.Size(211, 24);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(211, 24);
            this.layoutControlItem5.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem5.Spacing = new DevExpress.XtraLayout.Utils.Padding(20, 15, 0, 0);
            this.layoutControlItem5.Text = "종료일";
            this.layoutControlItem5.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem5.TextSize = new System.Drawing.Size(49, 16);
            this.layoutControlItem5.TextToControlDistance = 5;
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.lueROOT_MENU;
            this.layoutControlItem8.CustomizationFormText = "최상위 메뉴";
            this.layoutControlItem8.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_blue;
            this.layoutControlItem8.Location = new System.Drawing.Point(422, 0);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(259, 24);
            this.layoutControlItem8.Spacing = new DevExpress.XtraLayout.Utils.Padding(20, 15, 0, 0);
            this.layoutControlItem8.Text = "최상위 메뉴";
            this.layoutControlItem8.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem8.TextSize = new System.Drawing.Size(77, 16);
            this.layoutControlItem8.TextToControlDistance = 5;
            // 
            // layoutControlGroup4
            // 
            this.layoutControlGroup4.AppearanceGroup.Font = new System.Drawing.Font("맑은 고딕", 10F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup4.AppearanceGroup.ForeColor = System.Drawing.Color.MidnightBlue;
            this.layoutControlGroup4.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup4.AppearanceGroup.Options.UseForeColor = true;
            this.layoutControlGroup4.CaptionImage = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.btnicon_plus;
            this.layoutControlGroup4.CustomizationFormText = "공지 사항 등록";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup4, true);
            this.layoutControlGroup4.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem4,
            this.layoutControlItem9,
            this.emptySpaceItem3,
            this.layoutControlItem11,
            this.emptySpaceItem5,
            this.layoutControlItem4,
            this.layoutControlItem12,
            this.layoutControlItem15,
            this.layoutControlItem10,
            this.layoutControlItem14,
            this.emptySpaceItem6,
            this.simpleSeparator2,
            this.simpleSeparator3,
            this.simpleSeparator4,
            this.simpleSeparator1});
            this.layoutControlGroup4.Location = new System.Drawing.Point(0, 26);
            this.layoutControlGroup4.Name = "layoutControlGroup4";
            this.layoutControlGroup4.Size = new System.Drawing.Size(356, 554);
            this.layoutControlGroup4.Text = "공지 사항 등록";
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.CustomizationFormText = "emptySpaceItem4";
            this.emptySpaceItem4.Location = new System.Drawing.Point(318, 30);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(14, 26);
            this.emptySpaceItem4.Text = "emptySpaceItem4";
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.dteIFDATE;
            this.layoutControlItem9.CustomizationFormText = "시작일";
            this.layoutControlItem9.Location = new System.Drawing.Point(0, 30);
            this.layoutControlItem9.MaxSize = new System.Drawing.Size(173, 24);
            this.layoutControlItem9.MinSize = new System.Drawing.Size(173, 24);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(173, 24);
            this.layoutControlItem9.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem9.Spacing = new DevExpress.XtraLayout.Utils.Padding(28, 0, 0, 0);
            this.layoutControlItem9.Text = "시작일";
            this.layoutControlItem9.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem9.TextSize = new System.Drawing.Size(36, 14);
            this.layoutControlItem9.TextToControlDistance = 5;
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.CustomizationFormText = "emptySpaceItem3";
            this.emptySpaceItem3.Location = new System.Drawing.Point(318, 56);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(14, 24);
            this.emptySpaceItem3.Text = "emptySpaceItem3";
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.txtICAPTION;
            this.layoutControlItem11.CustomizationFormText = "팝업 타이틀";
            this.layoutControlItem11.Location = new System.Drawing.Point(0, 56);
            this.layoutControlItem11.MaxSize = new System.Drawing.Size(318, 24);
            this.layoutControlItem11.MinSize = new System.Drawing.Size(318, 24);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(318, 24);
            this.layoutControlItem11.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem11.Text = "팝업 타이틀";
            this.layoutControlItem11.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem11.TextSize = new System.Drawing.Size(64, 14);
            this.layoutControlItem11.TextToControlDistance = 5;
            // 
            // emptySpaceItem5
            // 
            this.emptySpaceItem5.AllowHotTrack = false;
            this.emptySpaceItem5.CustomizationFormText = "emptySpaceItem5";
            this.emptySpaceItem5.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem5.Name = "emptySpaceItem5";
            this.emptySpaceItem5.Size = new System.Drawing.Size(228, 30);
            this.emptySpaceItem5.Text = "emptySpaceItem5";
            this.emptySpaceItem5.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.btnInsert;
            this.layoutControlItem4.CustomizationFormText = "layoutControlItem4";
            this.layoutControlItem4.Location = new System.Drawing.Point(228, 0);
            this.layoutControlItem4.MaxSize = new System.Drawing.Size(104, 30);
            this.layoutControlItem4.MinSize = new System.Drawing.Size(104, 30);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(104, 30);
            this.layoutControlItem4.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem4.Text = "layoutControlItem4";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextToControlDistance = 0;
            this.layoutControlItem4.TextVisible = false;
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.txtIAFILE;
            this.layoutControlItem12.CustomizationFormText = "PDF 파일";
            this.layoutControlItem12.Location = new System.Drawing.Point(0, 82);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(332, 24);
            this.layoutControlItem12.Spacing = new DevExpress.XtraLayout.Utils.Padding(15, 0, 0, 0);
            this.layoutControlItem12.Text = "PDF 파일";
            this.layoutControlItem12.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem12.TextSize = new System.Drawing.Size(49, 14);
            this.layoutControlItem12.TextToControlDistance = 5;
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.Control = this.grdInput;
            this.layoutControlItem15.CustomizationFormText = "layoutControlItem15";
            this.layoutControlItem15.Location = new System.Drawing.Point(0, 162);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.Size = new System.Drawing.Size(332, 343);
            this.layoutControlItem15.Text = "layoutControlItem15";
            this.layoutControlItem15.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem15.TextToControlDistance = 0;
            this.layoutControlItem15.TextVisible = false;
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.dteITDATE;
            this.layoutControlItem10.CustomizationFormText = "종료일";
            this.layoutControlItem10.Location = new System.Drawing.Point(173, 30);
            this.layoutControlItem10.MaxSize = new System.Drawing.Size(145, 24);
            this.layoutControlItem10.MinSize = new System.Drawing.Size(145, 24);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(145, 24);
            this.layoutControlItem10.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem10.Text = "종료일";
            this.layoutControlItem10.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem10.TextSize = new System.Drawing.Size(36, 14);
            this.layoutControlItem10.TextToControlDistance = 5;
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.chkUSEYN;
            this.layoutControlItem14.CustomizationFormText = "layoutControlItem14";
            this.layoutControlItem14.Location = new System.Drawing.Point(0, 108);
            this.layoutControlItem14.MaxSize = new System.Drawing.Size(0, 24);
            this.layoutControlItem14.MinSize = new System.Drawing.Size(92, 24);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Size = new System.Drawing.Size(332, 24);
            this.layoutControlItem14.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem14.Spacing = new DevExpress.XtraLayout.Utils.Padding(12, 0, 0, 0);
            this.layoutControlItem14.Text = "사용 여부";
            this.layoutControlItem14.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem14.TextSize = new System.Drawing.Size(52, 14);
            this.layoutControlItem14.TextToControlDistance = 5;
            // 
            // emptySpaceItem6
            // 
            this.emptySpaceItem6.AllowHotTrack = false;
            this.emptySpaceItem6.AppearanceItemCaption.Font = new System.Drawing.Font("맑은 고딕", 10F);
            this.emptySpaceItem6.AppearanceItemCaption.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.emptySpaceItem6.AppearanceItemCaption.Options.UseFont = true;
            this.emptySpaceItem6.AppearanceItemCaption.Options.UseForeColor = true;
            this.emptySpaceItem6.AppearanceItemCaption.Options.UseTextOptions = true;
            this.emptySpaceItem6.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.emptySpaceItem6.CustomizationFormText = "공지 대상 최상위 메뉴";
            this.emptySpaceItem6.ImageAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.emptySpaceItem6.Location = new System.Drawing.Point(0, 134);
            this.emptySpaceItem6.MaxSize = new System.Drawing.Size(0, 28);
            this.emptySpaceItem6.MinSize = new System.Drawing.Size(104, 28);
            this.emptySpaceItem6.Name = "emptySpaceItem6";
            this.emptySpaceItem6.Size = new System.Drawing.Size(332, 28);
            this.emptySpaceItem6.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem6.Text = "[ 공지 대상 최상위 메뉴 ]";
            this.emptySpaceItem6.TextSize = new System.Drawing.Size(0, 0);
            this.emptySpaceItem6.TextVisible = true;
            // 
            // simpleSeparator2
            // 
            this.simpleSeparator2.AllowHotTrack = false;
            this.simpleSeparator2.CustomizationFormText = "simpleSeparator2";
            this.simpleSeparator2.Location = new System.Drawing.Point(0, 80);
            this.simpleSeparator2.Name = "simpleSeparator2";
            this.simpleSeparator2.Size = new System.Drawing.Size(332, 2);
            this.simpleSeparator2.Text = "simpleSeparator2";
            // 
            // simpleSeparator3
            // 
            this.simpleSeparator3.AllowHotTrack = false;
            this.simpleSeparator3.CustomizationFormText = "simpleSeparator3";
            this.simpleSeparator3.Location = new System.Drawing.Point(0, 106);
            this.simpleSeparator3.Name = "simpleSeparator3";
            this.simpleSeparator3.Size = new System.Drawing.Size(332, 2);
            this.simpleSeparator3.Text = "simpleSeparator3";
            // 
            // simpleSeparator4
            // 
            this.simpleSeparator4.AllowHotTrack = false;
            this.simpleSeparator4.CustomizationFormText = "simpleSeparator4";
            this.simpleSeparator4.Location = new System.Drawing.Point(0, 132);
            this.simpleSeparator4.Name = "simpleSeparator4";
            this.simpleSeparator4.Size = new System.Drawing.Size(332, 2);
            this.simpleSeparator4.Text = "simpleSeparator4";
            // 
            // simpleSeparator1
            // 
            this.simpleSeparator1.AllowHotTrack = false;
            this.simpleSeparator1.CustomizationFormText = "simpleSeparator1";
            this.simpleSeparator1.Location = new System.Drawing.Point(0, 54);
            this.simpleSeparator1.Name = "simpleSeparator1";
            this.simpleSeparator1.Size = new System.Drawing.Size(318, 2);
            this.simpleSeparator1.Text = "simpleSeparator1";
            // 
            // splitterItem2
            // 
            this.splitterItem2.AllowHotTrack = true;
            this.splitterItem2.CustomizationFormText = "splitterItem2";
            this.splitterItem2.Location = new System.Drawing.Point(356, 26);
            this.splitterItem2.Name = "splitterItem2";
            this.splitterItem2.Size = new System.Drawing.Size(5, 554);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "PDF 파일|*.pdf";
            // 
            // SCSYS022
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS022";
            this.Size = new System.Drawing.Size(1135, 600);
            this.Shown += new System.EventHandler(this.SCSYS022_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdInput)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvInput)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit3.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueROOT_MENU.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdSub)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvSub)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkUSEYN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIAFILE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtICAPTION.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteITDATE.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteITDATE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteIFDATE.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteIFDATE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteTDATE.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteTDATE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteFDATE.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteFDATE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpyChkUseYN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private Client.Controls.DXperience.XtraButtonExt btnSearch;
        private Client.Controls.DXperience.XtraButtonExt btnDelete;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private Client.Controls.DXperience.XtraGridControlExt grdMain;
        private DevExpress.XtraGrid.Views.Grid.GridView grvMain;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpyChkUseYN;
        private Controls.StdButtonExecuteManager stdButtonExecuteManager1;
        private DevExpress.XtraGrid.Columns.GridColumn colChk;
        private Windows.Forms.StdSecurityManager stdSecurityManager1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraGrid.Columns.GridColumn colWriter;
        private DevExpress.XtraGrid.Columns.GridColumn colFrom;
        private DevExpress.XtraGrid.Columns.GridColumn colTo;
        private DevExpress.XtraGrid.Columns.GridColumn colHeaderText;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn colAfile;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit1;
        private DevExpress.XtraEditors.DateEdit dteTDATE;
        private DevExpress.XtraEditors.DateEdit dteFDATE;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private Client.Controls.DXperience.XtraButtonEditExt txtIAFILE;
        private Client.Controls.DXperience.XtraTextEditExt txtICAPTION;
        private Client.Controls.DXperience.XtraDateEditExt dteITDATE;
        private Client.Controls.DXperience.XtraDateEditExt dteIFDATE;
        private Client.Controls.DXperience.XtraButtonExt btnInsert;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private Client.Controls.DXperience.XtraButtonExt btnModify;
        private DevExpress.XtraGrid.Columns.GridColumn colUseYN;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private Client.Controls.DXperience.XtraCheckEditExt chkUSEYN;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private DevExpress.XtraGrid.Columns.GridColumn colUpdater;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        private Client.Controls.DXperience.XtraGridControlExt grdSub;
        private DevExpress.XtraGrid.Views.Grid.GridView grvSub;
        private DevExpress.XtraGrid.Columns.GridColumn colSel;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn colSystemCode;
        private DevExpress.XtraGrid.Columns.GridColumn colSystemName;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.SplitterItem splitterItem1;
        private DevExpress.XtraEditors.LookUpEdit lueROOT_MENU;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem5;
        private Client.Controls.DXperience.XtraGridControlExt grdInput;
        private DevExpress.XtraGrid.Views.Grid.GridView grvInput;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit3;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit3;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem6;
        private DevExpress.XtraLayout.SimpleSeparator simpleSeparator2;
        private DevExpress.XtraLayout.SimpleSeparator simpleSeparator3;
        private DevExpress.XtraLayout.SimpleSeparator simpleSeparator4;
        private DevExpress.XtraLayout.SimpleSeparator simpleSeparator1;
        private DevExpress.XtraLayout.SplitterItem splitterItem2;
        private DevExpress.XtraGrid.Columns.GridColumn colROOT_MENUS;
    }
}
