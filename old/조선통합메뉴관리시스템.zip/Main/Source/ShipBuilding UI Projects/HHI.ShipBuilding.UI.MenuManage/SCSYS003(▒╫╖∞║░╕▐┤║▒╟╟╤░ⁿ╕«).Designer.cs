﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS003
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SCSYS003));
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.txtGROUP_ID = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnSearchMenuInfo = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.popupContainerControl1 = new DevExpress.XtraEditors.PopupContainerControl();
            this.xtraLayoutControlExt2 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.btnAuthButtonDelete = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.grdAuthButton = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvAuthButton = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colCHK3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCHK3 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.colDESCR = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colUSE_YN = new DevExpress.XtraGrid.Columns.GridColumn();
            this.btnAuthButtonSave = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup4 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.treeList1 = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumn3 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.grdMaster = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvMaster = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colWORK_GUBUN = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboWORK_GUBUN = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.colSYSTEM_CODE = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboSYSTEM_CODE = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.btnDelete = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.grdMaster1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvMaster1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCHK = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsChk2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsPopupContainerEdit = new DevExpress.XtraEditors.Repository.RepositoryItemPopupContainerEdit();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCheckedCboAUTH = new DevExpress.XtraEditors.Repository.RepositoryItemCheckedComboBoxEdit();
            this.txtGROUP_NAME = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnSave = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnSearch = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.splitterItem1 = new DevExpress.XtraLayout.SplitterItem();
            this.splitterItem2 = new DevExpress.XtraLayout.SplitterItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.stdSecurityManager1 = new HHI.ShipBuilding.Windows.Forms.StdSecurityManager(this.components);
            this.stdButtonExecuteManager1 = new HHI.ShipBuilding.Controls.StdButtonExecuteManager(this.components);
            this.luSYSTEM_CODE = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLookUpEditExt();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtGROUP_ID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupContainerControl1)).BeginInit();
            this.popupContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt2)).BeginInit();
            this.xtraLayoutControlExt2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdAuthButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvAuthButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.treeList1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMaster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMaster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboWORK_GUBUN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboSYSTEM_CODE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMaster1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMaster1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsChk2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsPopupContainerEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCheckedCboAUTH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGROUP_NAME.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.luSYSTEM_CODE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.luSYSTEM_CODE);
            this.xtraLayoutControlExt1.Controls.Add(this.txtGROUP_ID);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearchMenuInfo);
            this.xtraLayoutControlExt1.Controls.Add(this.popupContainerControl1);
            this.xtraLayoutControlExt1.Controls.Add(this.treeList1);
            this.xtraLayoutControlExt1.Controls.Add(this.grdMaster);
            this.xtraLayoutControlExt1.Controls.Add(this.btnDelete);
            this.xtraLayoutControlExt1.Controls.Add(this.grdMaster1);
            this.xtraLayoutControlExt1.Controls.Add(this.txtGROUP_NAME);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSave);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearch);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(742, 395, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(1116, 747);
            this.xtraLayoutControlExt1.TabIndex = 0;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // txtGROUP_ID
            // 
            this.txtGROUP_ID.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtGROUP_ID.EditValue = "";
            this.txtGROUP_ID.EnterExecuteButton = null;
            this.txtGROUP_ID.FocusColor = System.Drawing.Color.Empty;
            this.txtGROUP_ID.IsValueTrim = true;
            this.txtGROUP_ID.Key = "";
            this.txtGROUP_ID.Location = new System.Drawing.Point(394, 68);
            this.txtGROUP_ID.MinLength = 0;
            this.txtGROUP_ID.Name = "txtGROUP_ID";
            this.txtGROUP_ID.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtGROUP_ID.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtGROUP_ID.Properties.Appearance.Options.UseBackColor = true;
            this.txtGROUP_ID.Properties.Appearance.Options.UseForeColor = true;
            this.txtGROUP_ID.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtGROUP_ID.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGROUP_ID.Size = new System.Drawing.Size(103, 20);
            this.txtGROUP_ID.StyleController = this.xtraLayoutControlExt1;
            this.txtGROUP_ID.TabIndex = 15;
            this.txtGROUP_ID.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // btnSearchMenuInfo
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSearchMenuInfo, new string[] {
            "SELECT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSearchMenuInfo, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSearchMenuInfo, false);
            this.btnSearchMenuInfo.Image = ((System.Drawing.Image)(resources.GetObject("btnSearchMenuInfo.Image")));
            this.btnSearchMenuInfo.IsExecuteWdworkerLog = true;
            this.btnSearchMenuInfo.Location = new System.Drawing.Point(256, 366);
            this.btnSearchMenuInfo.Name = "btnSearchMenuInfo";
            this.btnSearchMenuInfo.Size = new System.Drawing.Size(76, 22);
            this.btnSearchMenuInfo.StyleController = this.xtraLayoutControlExt1;
            this.btnSearchMenuInfo.TabIndex = 5;
            this.btnSearchMenuInfo.Text = "조회";
            this.btnSearchMenuInfo.UseSplasher = true;
            this.btnSearchMenuInfo.Click += new System.EventHandler(this.btnSearchMenuInfo_Click);
            // 
            // popupContainerControl1
            // 
            this.popupContainerControl1.Controls.Add(this.xtraLayoutControlExt2);
            this.popupContainerControl1.Location = new System.Drawing.Point(665, 269);
            this.popupContainerControl1.Name = "popupContainerControl1";
            this.popupContainerControl1.Size = new System.Drawing.Size(336, 241);
            this.popupContainerControl1.TabIndex = 13;
            // 
            // xtraLayoutControlExt2
            // 
            this.xtraLayoutControlExt2.Controls.Add(this.btnAuthButtonDelete);
            this.xtraLayoutControlExt2.Controls.Add(this.grdAuthButton);
            this.xtraLayoutControlExt2.Controls.Add(this.btnAuthButtonSave);
            this.xtraLayoutControlExt2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt2.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt2.Name = "xtraLayoutControlExt2";
            this.xtraLayoutControlExt2.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(1176, 279, 250, 350);
            this.xtraLayoutControlExt2.Root = this.layoutControlGroup4;
            this.xtraLayoutControlExt2.Size = new System.Drawing.Size(336, 241);
            this.xtraLayoutControlExt2.TabIndex = 0;
            this.xtraLayoutControlExt2.Text = "xtraLayoutControlExt2";
            // 
            // btnAuthButtonDelete
            // 
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnAuthButtonDelete, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnAuthButtonDelete, false);
            this.btnAuthButtonDelete.IsExecuteWdworkerLog = true;
            this.btnAuthButtonDelete.Location = new System.Drawing.Point(289, 12);
            this.btnAuthButtonDelete.Name = "btnAuthButtonDelete";
            this.btnAuthButtonDelete.Size = new System.Drawing.Size(35, 22);
            this.btnAuthButtonDelete.StyleController = this.xtraLayoutControlExt2;
            this.btnAuthButtonDelete.TabIndex = 6;
            this.btnAuthButtonDelete.Text = "삭제";
            this.btnAuthButtonDelete.UseSplasher = false;
            this.btnAuthButtonDelete.Click += new System.EventHandler(this.btnAuthButtonDelete_Click);
            // 
            // grdAuthButton
            // 
            this.grdAuthButton.CheckBoxFieldName = "CHK";
            this.grdAuthButton.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.None;
            this.grdAuthButton.IsHeaderClickAllCheckedItem = false;
            this.grdAuthButton.Location = new System.Drawing.Point(12, 38);
            this.grdAuthButton.MainView = this.grvAuthButton;
            this.grdAuthButton.MinLength = 0;
            this.grdAuthButton.Name = "grdAuthButton";
            this.grdAuthButton.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpsCHK3});
            this.grdAuthButton.Size = new System.Drawing.Size(312, 191);
            this.grdAuthButton.TabIndex = 11;
            this.grdAuthButton.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvAuthButton});
            // 
            // grvAuthButton
            // 
            this.grvAuthButton.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colCHK3,
            this.colDESCR,
            this.colUSE_YN});
            this.grvAuthButton.GridControl = this.grdAuthButton;
            this.grvAuthButton.Name = "grvAuthButton";
            this.grvAuthButton.OptionsView.ColumnAutoWidth = false;
            this.grvAuthButton.OptionsView.ShowGroupPanel = false;
            // 
            // colCHK3
            // 
            this.colCHK3.AppearanceHeader.Options.UseTextOptions = true;
            this.colCHK3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colCHK3.Caption = "선택";
            this.colCHK3.ColumnEdit = this.rpsCHK3;
            this.colCHK3.FieldName = "CHK";
            this.colCHK3.Name = "colCHK3";
            this.colCHK3.Visible = true;
            this.colCHK3.VisibleIndex = 0;
            // 
            // rpsCHK3
            // 
            this.rpsCHK3.AutoHeight = false;
            this.rpsCHK3.Caption = "Check";
            this.rpsCHK3.Name = "rpsCHK3";
            this.rpsCHK3.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpsCHK3.ValueChecked = "Y";
            this.rpsCHK3.ValueUnchecked = "N";
            // 
            // colDESCR
            // 
            this.colDESCR.AppearanceHeader.Options.UseTextOptions = true;
            this.colDESCR.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDESCR.Caption = "내용";
            this.colDESCR.FieldName = "DESCR";
            this.colDESCR.Name = "colDESCR";
            this.colDESCR.OptionsColumn.AllowEdit = false;
            this.colDESCR.OptionsColumn.ReadOnly = true;
            this.colDESCR.Visible = true;
            this.colDESCR.VisibleIndex = 1;
            this.colDESCR.Width = 133;
            // 
            // colUSE_YN
            // 
            this.colUSE_YN.AppearanceHeader.Options.UseTextOptions = true;
            this.colUSE_YN.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colUSE_YN.Caption = "사용";
            this.colUSE_YN.ColumnEdit = this.rpsCHK3;
            this.colUSE_YN.FieldName = "USE_YN";
            this.colUSE_YN.Name = "colUSE_YN";
            this.colUSE_YN.Visible = true;
            this.colUSE_YN.VisibleIndex = 2;
            // 
            // btnAuthButtonSave
            // 
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnAuthButtonSave, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnAuthButtonSave, false);
            this.btnAuthButtonSave.IsExecuteWdworkerLog = true;
            this.btnAuthButtonSave.Location = new System.Drawing.Point(250, 12);
            this.btnAuthButtonSave.Name = "btnAuthButtonSave";
            this.btnAuthButtonSave.Size = new System.Drawing.Size(35, 22);
            this.btnAuthButtonSave.StyleController = this.xtraLayoutControlExt2;
            this.btnAuthButtonSave.TabIndex = 6;
            this.btnAuthButtonSave.Text = "저장";
            this.btnAuthButtonSave.UseSplasher = false;
            this.btnAuthButtonSave.Click += new System.EventHandler(this.btnAuthButtonSave_Click);
            // 
            // layoutControlGroup4
            // 
            this.layoutControlGroup4.CustomizationFormText = "layoutControlGroup4";
            this.layoutControlGroup4.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup4, false);
            this.layoutControlGroup4.GroupBordersVisible = false;
            this.layoutControlGroup4.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem3,
            this.layoutControlItem4,
            this.layoutControlItem5,
            this.layoutControlItem8});
            this.layoutControlGroup4.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup4.Name = "layoutControlGroup4";
            this.layoutControlGroup4.Size = new System.Drawing.Size(336, 241);
            this.layoutControlGroup4.TextVisible = false;
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.CustomizationFormText = "emptySpaceItem3";
            this.emptySpaceItem3.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(238, 26);
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.btnAuthButtonSave;
            this.layoutControlItem4.CustomizationFormText = "layoutControlItem4";
            this.layoutControlItem4.Location = new System.Drawing.Point(238, 0);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(39, 26);
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextVisible = false;
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.grdAuthButton;
            this.layoutControlItem5.CustomizationFormText = "layoutControlItem5";
            this.layoutControlItem5.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(316, 195);
            this.layoutControlItem5.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem5.TextVisible = false;
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.btnAuthButtonDelete;
            this.layoutControlItem8.CustomizationFormText = "layoutControlItem8";
            this.layoutControlItem8.Location = new System.Drawing.Point(277, 0);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(39, 26);
            this.layoutControlItem8.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem8.TextVisible = false;
            // 
            // treeList1
            // 
            this.treeList1.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn3});
            this.treeList1.ImageIndexFieldName = "";
            this.treeList1.KeyFieldName = "MENU_ID";
            this.treeList1.Location = new System.Drawing.Point(24, 392);
            this.treeList1.Name = "treeList1";
            this.treeList1.OptionsBehavior.Editable = false;
            this.treeList1.OptionsBehavior.ShowEditorOnMouseUp = true;
            this.treeList1.OptionsDragAndDrop.CanCloneNodesOnDrop = true;
            this.treeList1.OptionsDragAndDrop.DragNodesMode = DevExpress.XtraTreeList.DragNodesMode.Multiple;
            this.treeList1.OptionsView.ShowColumns = false;
            this.treeList1.OptionsView.ShowHorzLines = false;
            this.treeList1.OptionsView.ShowIndicator = false;
            this.treeList1.OptionsView.ShowVertLines = false;
            this.treeList1.ParentFieldName = "PARENT_ID";
            this.treeList1.Size = new System.Drawing.Size(308, 331);
            this.treeList1.TabIndex = 11;
            this.treeList1.DragDrop += new System.Windows.Forms.DragEventHandler(this.treeList1_DragDrop);
            // 
            // treeListColumn3
            // 
            this.treeListColumn3.Caption = "MENU_NAME";
            this.treeListColumn3.FieldName = "MENU_NAME";
            this.treeListColumn3.Name = "treeListColumn3";
            this.treeListColumn3.Visible = true;
            this.treeListColumn3.VisibleIndex = 0;
            this.treeListColumn3.Width = 163;
            // 
            // grdMaster
            // 
            this.grdMaster.CheckBoxFieldName = "CHK";
            this.grdMaster.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.None;
            this.grdMaster.IsHeaderClickAllCheckedItem = false;
            this.grdMaster.Location = new System.Drawing.Point(24, 140);
            this.grdMaster.MainView = this.grvMaster;
            this.grdMaster.MinLength = 0;
            this.grdMaster.Name = "grdMaster";
            this.grdMaster.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit1,
            this.rpsCboWORK_GUBUN,
            this.rpsCboSYSTEM_CODE});
            this.grdMaster.Size = new System.Drawing.Size(308, 217);
            this.grdMaster.TabIndex = 10;
            this.grdMaster.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvMaster});
            // 
            // grvMaster
            // 
            this.grvMaster.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn4,
            this.gridColumn7,
            this.gridColumn8,
            this.colWORK_GUBUN,
            this.colSYSTEM_CODE});
            this.grvMaster.GridControl = this.grdMaster;
            this.grvMaster.GroupCount = 2;
            this.grvMaster.Name = "grvMaster";
            this.grvMaster.OptionsBehavior.Editable = false;
            this.grvMaster.OptionsView.ColumnAutoWidth = false;
            this.grvMaster.OptionsView.ShowGroupPanel = false;
            this.grvMaster.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colWORK_GUBUN, DevExpress.Data.ColumnSortOrder.Ascending),
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colSYSTEM_CODE, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.grvMaster.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.grvMaster_FocusedRowChanged);
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.Caption = "그룹ID";
            this.gridColumn4.FieldName = "GROUP_ID";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 0;
            this.gridColumn4.Width = 99;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.Caption = "그룹명";
            this.gridColumn7.FieldName = "GROUP_NAME";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 1;
            this.gridColumn7.Width = 146;
            // 
            // gridColumn8
            // 
            this.gridColumn8.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.Caption = "Note";
            this.gridColumn8.FieldName = "DESCR";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 2;
            this.gridColumn8.Width = 133;
            // 
            // colWORK_GUBUN
            // 
            this.colWORK_GUBUN.Caption = "업무구분";
            this.colWORK_GUBUN.ColumnEdit = this.rpsCboWORK_GUBUN;
            this.colWORK_GUBUN.FieldName = "WORK_GUBUN";
            this.colWORK_GUBUN.Name = "colWORK_GUBUN";
            this.colWORK_GUBUN.Visible = true;
            this.colWORK_GUBUN.VisibleIndex = 3;
            // 
            // rpsCboWORK_GUBUN
            // 
            this.rpsCboWORK_GUBUN.AutoHeight = false;
            this.rpsCboWORK_GUBUN.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboWORK_GUBUN.Name = "rpsCboWORK_GUBUN";
            // 
            // colSYSTEM_CODE
            // 
            this.colSYSTEM_CODE.Caption = "시스템코드";
            this.colSYSTEM_CODE.ColumnEdit = this.rpsCboSYSTEM_CODE;
            this.colSYSTEM_CODE.FieldName = "SYSTEM_CODE";
            this.colSYSTEM_CODE.Name = "colSYSTEM_CODE";
            this.colSYSTEM_CODE.Visible = true;
            this.colSYSTEM_CODE.VisibleIndex = 3;
            // 
            // rpsCboSYSTEM_CODE
            // 
            this.rpsCboSYSTEM_CODE.AutoHeight = false;
            this.rpsCboSYSTEM_CODE.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboSYSTEM_CODE.Name = "rpsCboSYSTEM_CODE";
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Caption = "Check";
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.repositoryItemCheckEdit1.ValueChecked = "Y";
            this.repositoryItemCheckEdit1.ValueUnchecked = "N";
            // 
            // btnDelete
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnDelete, new string[] {
            "DELETE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnDelete, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnDelete, false);
            this.btnDelete.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_삭제;
            this.btnDelete.IsExecuteWdworkerLog = true;
            this.btnDelete.Location = new System.Drawing.Point(1050, 12);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(54, 22);
            this.btnDelete.StyleController = this.xtraLayoutControlExt1;
            this.btnDelete.TabIndex = 5;
            this.btnDelete.Text = "삭제";
            this.btnDelete.UseSplasher = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // grdMaster1
            // 
            this.grdMaster1.AllowDrop = true;
            this.grdMaster1.CheckBoxFieldName = "CHK";
            this.grdMaster1.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdMaster1.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdMaster1.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdMaster1.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdMaster1.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdMaster1.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdMaster1.IsHeaderClickAllCheckedItem = true;
            this.grdMaster1.Location = new System.Drawing.Point(341, 140);
            this.grdMaster1.MainView = this.grvMaster1;
            this.grdMaster1.MinLength = 0;
            this.grdMaster1.Name = "grdMaster1";
            this.grdMaster1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpsCHK,
            this.rpsChk2,
            this.rpsCheckedCboAUTH,
            this.rpsPopupContainerEdit});
            this.grdMaster1.Size = new System.Drawing.Size(751, 583);
            this.grdMaster1.TabIndex = 9;
            this.grdMaster1.UseEmbeddedNavigator = true;
            this.grdMaster1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvMaster1});
            this.grdMaster1.DragDrop += new System.Windows.Forms.DragEventHandler(this.grdMaster1_DragDrop);
            this.grdMaster1.DragEnter += new System.Windows.Forms.DragEventHandler(this.grdMaster1_DragEnter);
            // 
            // grvMaster1
            // 
            this.grvMaster1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn5,
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn19,
            this.gridColumn18,
            this.gridColumn17,
            this.gridColumn16,
            this.gridColumn6,
            this.gridColumn15,
            this.gridColumn14,
            this.gridColumn13,
            this.gridColumn3});
            this.grvMaster1.GridControl = this.grdMaster1;
            this.grvMaster1.Name = "grvMaster1";
            this.grvMaster1.OptionsView.ColumnAutoWidth = false;
            this.grvMaster1.OptionsView.ShowGroupPanel = false;
            this.grvMaster1.ShowingEditor += new System.ComponentModel.CancelEventHandler(this.grvMaster1_ShowingEditor);
            this.grvMaster1.CellValueChanging += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.grvMaster1_CellValueChanging);
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.Caption = "CHK";
            this.gridColumn5.ColumnEdit = this.rpsCHK;
            this.gridColumn5.FieldName = "CHK";
            this.gridColumn5.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 0;
            this.gridColumn5.Width = 35;
            // 
            // rpsCHK
            // 
            this.rpsCHK.AutoHeight = false;
            this.rpsCHK.Caption = "Check";
            this.rpsCHK.Name = "rpsCHK";
            this.rpsCHK.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpsCHK.ValueChecked = "Y";
            this.rpsCHK.ValueUnchecked = "N";
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "Menu ID";
            this.gridColumn1.FieldName = "MENU_ID";
            this.gridColumn1.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 1;
            this.gridColumn1.Width = 120;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "Menu Name";
            this.gridColumn2.FieldName = "MENU_NAME";
            this.gridColumn2.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 2;
            this.gridColumn2.Width = 133;
            // 
            // gridColumn19
            // 
            this.gridColumn19.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn19.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn19.Caption = "Create";
            this.gridColumn19.ColumnEdit = this.rpsChk2;
            this.gridColumn19.FieldName = "BASIC_ACLC";
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 3;
            // 
            // rpsChk2
            // 
            this.rpsChk2.AutoHeight = false;
            this.rpsChk2.Caption = "Check";
            this.rpsChk2.Name = "rpsChk2";
            this.rpsChk2.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpsChk2.ValueChecked = "1";
            this.rpsChk2.ValueUnchecked = "0";
            // 
            // gridColumn18
            // 
            this.gridColumn18.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn18.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn18.Caption = "Read";
            this.gridColumn18.ColumnEdit = this.rpsChk2;
            this.gridColumn18.FieldName = "BASIC_ACLR";
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 4;
            // 
            // gridColumn17
            // 
            this.gridColumn17.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn17.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn17.Caption = "Update";
            this.gridColumn17.ColumnEdit = this.rpsChk2;
            this.gridColumn17.FieldName = "BASIC_ACLU";
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 5;
            // 
            // gridColumn16
            // 
            this.gridColumn16.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn16.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn16.Caption = "Delete";
            this.gridColumn16.ColumnEdit = this.rpsChk2;
            this.gridColumn16.FieldName = "BASIC_ACLD";
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.Visible = true;
            this.gridColumn16.VisibleIndex = 6;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.Caption = "확장권한";
            this.gridColumn6.ColumnEdit = this.rpsPopupContainerEdit;
            this.gridColumn6.FieldName = "AUTH";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 7;
            // 
            // rpsPopupContainerEdit
            // 
            this.rpsPopupContainerEdit.AutoHeight = false;
            this.rpsPopupContainerEdit.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsPopupContainerEdit.Name = "rpsPopupContainerEdit";
            this.rpsPopupContainerEdit.PopupControl = this.popupContainerControl1;
            this.rpsPopupContainerEdit.Popup += new System.EventHandler(this.rpsPopupContainerEdit_Popup);
            // 
            // gridColumn15
            // 
            this.gridColumn15.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.Caption = "Excel";
            this.gridColumn15.ColumnEdit = this.rpsChk2;
            this.gridColumn15.Name = "gridColumn15";
            // 
            // gridColumn14
            // 
            this.gridColumn14.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.Caption = "Print";
            this.gridColumn14.ColumnEdit = this.rpsChk2;
            this.gridColumn14.Name = "gridColumn14";
            // 
            // gridColumn13
            // 
            this.gridColumn13.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn13.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn13.Caption = "Upload";
            this.gridColumn13.ColumnEdit = this.rpsChk2;
            this.gridColumn13.Name = "gridColumn13";
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "GROUP_ID";
            this.gridColumn3.FieldName = "GROUP_ID";
            this.gridColumn3.Name = "gridColumn3";
            // 
            // rpsCheckedCboAUTH
            // 
            this.rpsCheckedCboAUTH.AutoHeight = false;
            this.rpsCheckedCboAUTH.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCheckedCboAUTH.Name = "rpsCheckedCboAUTH";
            // 
            // txtGROUP_NAME
            // 
            this.txtGROUP_NAME.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtGROUP_NAME.EditValue = "";
            this.txtGROUP_NAME.EnterExecuteButton = null;
            this.txtGROUP_NAME.FocusColor = System.Drawing.Color.Empty;
            this.txtGROUP_NAME.IsValueTrim = true;
            this.txtGROUP_NAME.Key = "";
            this.txtGROUP_NAME.Location = new System.Drawing.Point(577, 68);
            this.txtGROUP_NAME.MinLength = 0;
            this.txtGROUP_NAME.Name = "txtGROUP_NAME";
            this.txtGROUP_NAME.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtGROUP_NAME.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtGROUP_NAME.Properties.Appearance.Options.UseBackColor = true;
            this.txtGROUP_NAME.Properties.Appearance.Options.UseForeColor = true;
            this.txtGROUP_NAME.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGROUP_NAME.Size = new System.Drawing.Size(163, 20);
            this.txtGROUP_NAME.StyleController = this.xtraLayoutControlExt1;
            this.txtGROUP_NAME.TabIndex = 6;
            this.txtGROUP_NAME.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // btnSave
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSave, new string[] {
            "UPDATE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSave, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSave, false);
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.IsExecuteWdworkerLog = true;
            this.btnSave.Location = new System.Drawing.Point(992, 12);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(54, 22);
            this.btnSave.StyleController = this.xtraLayoutControlExt1;
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "저장";
            this.btnSave.UseSplasher = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnSearch
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSearch, new string[] {
            "SELECT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSearch, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSearch, true);
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.IsExecuteWdworkerLog = true;
            this.btnSearch.Location = new System.Drawing.Point(934, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(54, 22);
            this.btnSearch.StyleController = this.xtraLayoutControlExt1;
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "조회";
            this.btnSearch.UseSplasher = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "layoutControlGroup1";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup1, false);
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem1,
            this.layoutControlItem1,
            this.layoutControlItem2,
            this.layoutControlItem7,
            this.layoutControlGroup2,
            this.layoutControlGroup3});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1116, 747);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(922, 26);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.btnSearch;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(922, 0);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.btnSave;
            this.layoutControlItem2.CustomizationFormText = "layoutControlItem2";
            this.layoutControlItem2.Location = new System.Drawing.Point(980, 0);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextVisible = false;
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.btnDelete;
            this.layoutControlItem7.CustomizationFormText = "layoutControlItem7";
            this.layoutControlItem7.Location = new System.Drawing.Point(1038, 0);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem7.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem7.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.CaptionImage = ((System.Drawing.Image)(resources.GetObject("layoutControlGroup2.CaptionImage")));
            this.layoutControlGroup2.CustomizationFormText = "List";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup2, false);
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem9,
            this.layoutControlItem6,
            this.splitterItem1,
            this.splitterItem2,
            this.layoutControlItem10,
            this.emptySpaceItem4,
            this.layoutControlItem12});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 92);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(1096, 635);
            this.layoutControlGroup2.Text = "그룹정보";
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.grdMaster;
            this.layoutControlItem9.CustomizationFormText = "layoutControlItem9";
            this.layoutControlItem9.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(312, 221);
            this.layoutControlItem9.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem9.TextVisible = false;
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.grdMaster1;
            this.layoutControlItem6.CustomizationFormText = "layoutControlItem6";
            this.layoutControlItem6.Location = new System.Drawing.Point(317, 0);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(755, 587);
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextVisible = false;
            // 
            // splitterItem1
            // 
            this.splitterItem1.AllowHotTrack = true;
            this.splitterItem1.CustomizationFormText = "splitterItem1";
            this.splitterItem1.Location = new System.Drawing.Point(312, 0);
            this.splitterItem1.Name = "splitterItem1";
            this.splitterItem1.Size = new System.Drawing.Size(5, 587);
            // 
            // splitterItem2
            // 
            this.splitterItem2.AllowHotTrack = true;
            this.splitterItem2.CustomizationFormText = "splitterItem2";
            this.splitterItem2.Location = new System.Drawing.Point(0, 221);
            this.splitterItem2.Name = "splitterItem2";
            this.splitterItem2.Size = new System.Drawing.Size(312, 5);
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.treeList1;
            this.layoutControlItem10.CustomizationFormText = "layoutControlItem10";
            this.layoutControlItem10.Location = new System.Drawing.Point(0, 252);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(312, 335);
            this.layoutControlItem10.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem10.TextVisible = false;
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.CustomizationFormText = "emptySpaceItem4";
            this.emptySpaceItem4.Location = new System.Drawing.Point(0, 226);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(232, 26);
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.btnSearchMenuInfo;
            this.layoutControlItem12.CustomizationFormText = "layoutControlItem12";
            this.layoutControlItem12.Location = new System.Drawing.Point(232, 226);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(80, 26);
            this.layoutControlItem12.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem12.TextVisible = false;
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 1F);
            this.layoutControlGroup3.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup3.CustomizationFormText = " ";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup3, true);
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem3,
            this.emptySpaceItem2,
            this.layoutControlItem13,
            this.layoutControlItem11});
            this.layoutControlGroup3.Location = new System.Drawing.Point(0, 26);
            this.layoutControlGroup3.Name = "layoutControlGroup3";
            this.layoutControlGroup3.Size = new System.Drawing.Size(1096, 66);
            this.layoutControlGroup3.Text = " ";
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.txtGROUP_NAME;
            this.layoutControlItem3.CustomizationFormText = "AuthName";
            this.layoutControlItem3.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem3.Image")));
            this.layoutControlItem3.Location = new System.Drawing.Point(477, 0);
            this.layoutControlItem3.MaxSize = new System.Drawing.Size(243, 24);
            this.layoutControlItem3.MinSize = new System.Drawing.Size(243, 24);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(243, 24);
            this.layoutControlItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem3.Text = "그룹명";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(73, 16);
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(720, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(352, 24);
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.txtGROUP_ID;
            this.layoutControlItem13.CustomizationFormText = "그룹ID";
            this.layoutControlItem13.Image = ((System.Drawing.Image)(resources.GetObject("layoutControlItem13.Image")));
            this.layoutControlItem13.Location = new System.Drawing.Point(294, 0);
            this.layoutControlItem13.MaxSize = new System.Drawing.Size(183, 24);
            this.layoutControlItem13.MinSize = new System.Drawing.Size(183, 24);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(183, 24);
            this.layoutControlItem13.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem13.Text = "그룹ID";
            this.layoutControlItem13.TextSize = new System.Drawing.Size(73, 16);
            // 
            // luSYSTEM_CODE
            // 
            this.luSYSTEM_CODE.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.luSYSTEM_CODE.EnterExecuteButton = null;
            this.luSYSTEM_CODE.FocusColor = System.Drawing.Color.Empty;
            this.luSYSTEM_CODE.Key = "";
            this.luSYSTEM_CODE.Location = new System.Drawing.Point(100, 68);
            this.luSYSTEM_CODE.MinLength = 0;
            this.luSYSTEM_CODE.Name = "luSYSTEM_CODE";
            this.luSYSTEM_CODE.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.luSYSTEM_CODE.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.luSYSTEM_CODE.Properties.Appearance.Options.UseBackColor = true;
            this.luSYSTEM_CODE.Properties.Appearance.Options.UseForeColor = true;
            this.luSYSTEM_CODE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.luSYSTEM_CODE.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("SYSTEM_CODE", 80, "코드"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("SYSTEM_NAME", 150, "명칭")});
            this.luSYSTEM_CODE.Properties.NullText = "";
            this.luSYSTEM_CODE.Size = new System.Drawing.Size(214, 20);
            this.luSYSTEM_CODE.StyleController = this.xtraLayoutControlExt1;
            this.luSYSTEM_CODE.TabIndex = 16;
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.luSYSTEM_CODE;
            this.layoutControlItem11.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_blue;
            this.layoutControlItem11.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem11.MinSize = new System.Drawing.Size(130, 24);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(294, 24);
            this.layoutControlItem11.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem11.Text = "시스템코드";
            this.layoutControlItem11.TextSize = new System.Drawing.Size(73, 16);
            // 
            // SCSYS003
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS003";
            this.Size = new System.Drawing.Size(1116, 747);
            this.Shown += new System.EventHandler(this.SCSYS003_Shown);
            this.Load += new System.EventHandler(this.SCSYS003_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtGROUP_ID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupContainerControl1)).EndInit();
            this.popupContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt2)).EndInit();
            this.xtraLayoutControlExt2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdAuthButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvAuthButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.treeList1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMaster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMaster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboWORK_GUBUN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboSYSTEM_CODE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMaster1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMaster1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsChk2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsPopupContainerEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCheckedCboAUTH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGROUP_NAME.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.luSYSTEM_CODE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private Client.Controls.DXperience.XtraGridControlExt grdMaster1;
        private DevExpress.XtraGrid.Views.Grid.GridView grvMaster1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpsCHK;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private Client.Controls.DXperience.XtraTextEditExt txtGROUP_NAME;
        private Client.Controls.DXperience.XtraButtonExt btnSave;
        private Client.Controls.DXperience.XtraButtonExt btnSearch;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private Client.Controls.DXperience.XtraButtonExt btnDelete;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private Client.Controls.DXperience.XtraGridControlExt grdMaster;
        private DevExpress.XtraGrid.Views.Grid.GridView grvMaster;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpsChk2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.SplitterItem splitterItem1;
        private DevExpress.XtraLayout.SplitterItem splitterItem2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraTreeList.TreeList treeList1;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckedComboBoxEdit rpsCheckedCboAUTH;
        private DevExpress.XtraEditors.Repository.RepositoryItemPopupContainerEdit rpsPopupContainerEdit;
        private DevExpress.XtraEditors.PopupContainerControl popupContainerControl1;
        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt2;
        private Client.Controls.DXperience.XtraGridControlExt grdAuthButton;
        private DevExpress.XtraGrid.Views.Grid.GridView grvAuthButton;
        private DevExpress.XtraGrid.Columns.GridColumn colCHK3;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpsCHK3;
        private DevExpress.XtraGrid.Columns.GridColumn colDESCR;
        private DevExpress.XtraGrid.Columns.GridColumn colUSE_YN;
        private Client.Controls.DXperience.XtraButtonExt btnAuthButtonSave;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup4;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private Client.Controls.DXperience.XtraButtonExt btnAuthButtonDelete;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private Windows.Forms.StdSecurityManager stdSecurityManager1;
        private Client.Controls.DXperience.XtraButtonExt btnSearchMenuInfo;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private Client.Controls.DXperience.XtraTextEditExt txtGROUP_ID;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraGrid.Columns.GridColumn colWORK_GUBUN;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboWORK_GUBUN;
        private DevExpress.XtraGrid.Columns.GridColumn colSYSTEM_CODE;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboSYSTEM_CODE;
        private Controls.StdButtonExecuteManager stdButtonExecuteManager1;
        private Client.Controls.DXperience.XtraLookUpEditExt luSYSTEM_CODE;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
    }
}
