﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using DevExpress.XtraGrid.Views.Grid;
using HHI.Windows.Forms;
using HHI.ShipBuilding.Controls.Utils;
using System.IO;
using System.Globalization;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(false)]
    public partial class SCSYS022 : StdUserControlBase
    {
        HHI.ShipBuilding.Notice.Popup popup = new Notice.Popup();
        CtrlDBKey _cspt = null;

        bool IsFocusedRowChanged = false;

        public SCSYS022()
        {
            InitializeComponent();
            _cspt = CtrlDBKey.Instance;
        }

        private void SCSYS022_Shown(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                DataTable dt = GetInitData();

                if (dt != null)
                {
                    lueROOT_MENU.Properties.DisplayMember = "DISPLAY_TITLE";
                    lueROOT_MENU.Properties.ValueMember = "MENU_ID";
                    lueROOT_MENU.Properties.DataSource = dt;
                    lueROOT_MENU.RefreshEditValue();
                }

                dteFDATE.EditValue = null;
                dteTDATE.EditValue = null;
                InitInputPanel();
                stdSecurityManager1.ApplySecurity(this.SecurityContext);
                stdButtonExecuteManager1.RegisterButtonExecEvent();
            }
        }

        private DataTable GetInitData()
        {
            DataPack par = new DataPack();
            par.DataList.Add("IN_SEL", "ROOT_MENU");
            par.DataList.Add("IN_PARAM1", string.Empty);
            par.DataList.Add("IN_PARAM2", string.Empty);
            par.DataList.Add("IN_PARAM3", string.Empty);

            this.BeforeInvokeServer("초기화 중입니다.");
            DataResultSet resultSet;
            try
            {
                resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS022.INIT_01", par);
                this.AfterInvokeServer();
            }
            catch(Exception)
            {
                this.AfterInvokeServer();
                throw;
            }

            if (resultSet.IsSuccess)
            {
                return resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(this, resultSet.ExceptionMessage, "오류", MessageBoxButtons.OK, ImageKinds.Error);
                return null;
            }
        }

        private DataTable GetData()
        {
            DataPack par = new DataPack();
            par.DataList.Add("IN_N_ID", string.Empty); // 메인 그리드 조회
            par.DataList.Add("IN_TDATE", DateTimeHelper.GetString(dteTDATE.EditValue));
            par.DataList.Add("IN_FDATE", DateTimeHelper.GetString(dteFDATE.EditValue));
            par.DataList.Add("IN_ROOT_MENU", Convert.ToString(lueROOT_MENU.EditValue));

            this.BeforeInvokeServer("조회 중입니다.");
            DataResultSet resultSet;
            try
            {
                resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS022.SEARCH_01", par);
            }
            catch(Exception)
            {
                throw;
            }
            finally
            {
                this.AfterInvokeServer();
            }

            if (resultSet.IsSuccess)
            {
                return resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(this, resultSet.ExceptionMessage, "오류", MessageBoxButtons.OK, ImageKinds.Error);
                return null;
            }
        }
        
        private void InitInputPanel()
        {
            dteIFDATE.EditValue = DateTime.Now;
            dteITDATE.EditValue = DateTime.Now.AddDays(7);
            txtICAPTION.Text = string.Empty;
            txtIAFILE.Text = string.Empty;

            DataTable dt = (lueROOT_MENU.Properties.DataSource as DataTable).Copy();
            dt.Rows.RemoveAt(0);
            dt.AcceptChanges();

            DataTable inputDt = dt.Copy();

            grdInput.DataSource = inputDt;
            grvInput.RefreshData();

            grdSub.DataSource = dt;
            grvSub.RefreshData();
        }

        private string ReturnValue(object val)
        {
            try
            {
                // 참고: NULL 인 경우 값 체크해서 "null" 인지 다른 값인지 확인해야 함.
                if (val == null || val.ToString().Equals("null", StringComparison.OrdinalIgnoreCase))
                {
                    val = string.Empty;
                }

                return val.ToString();
            }
            catch
            {
                return string.Empty;
            }
        }

        private void ShowErrorMsg(string caption, string msg)
        {
            MsgBox.Show(this, msg, caption, MessageBoxButtons.OK, ImageKinds.Error);
        }

        private bool CheckInsert(DataCollection dataList)
        {
            if (Convert.ToString(dataList["IN_FDATE"]).Length != 8)
            {
                ShowErrorMsg("필수 항목", "시작일을 입력하세요.");
                return false;
            }

            if (Convert.ToString(dataList["IN_TDATE"]).Length != 8)
            {
                ShowErrorMsg("필수 항목", "종료일을 입력하세요.");
                return false;
            }

            if (Convert.ToString(dataList["IN_AFILE"]).Length < 6)
            {
                ShowErrorMsg("필수 항목", "PDF 파일을 입력하세요.");
                return false;
            }

            return true;
        }

        private string GetRootMenus(DataTable dt)
        {
            if (dt == null)
                return string.Empty;

            StringBuilder sb = new StringBuilder(128);

            foreach (DataRow dr in dt.Rows)
            {
                if (Convert.ToString(dr["CHK"]).Equals("Y", StringComparison.OrdinalIgnoreCase))
                {
                    sb.Append(Convert.ToString(dr["MENU_ID"]));
                    sb.Append(";");
                }
            }

            return sb.ToString();
        }

        private void WhenFoucsedRowChanged(int rowHandle)
        {
            DataRow dr = grvMain.GetDataRow(rowHandle);

            if (dr == null)
                return;

            string val = Convert.ToString(dr["ROOT_MENUS"]);

            DataTable dtSub = grdSub.DataSource as DataTable;

            foreach (DataRow row in dtSub.Rows)
            {
                if (val.IndexOf(Convert.ToString(row["MENU_ID"]) + ";") > -1)
                {
                    row["CHK"] = "Y";
                }
                else
                {
                    row["CHK"] = "N";
                }
            }

            dtSub.AcceptChanges();
        }

        private void AllNoticeChecked(DataTable dt, DataRow selRow)
        {
            if (Convert.ToString(selRow["MENU_ID"]).Equals("ALL NOTICE", StringComparison.OrdinalIgnoreCase))
            {
                if (Convert.ToString(selRow["CHK"]).Equals("Y", StringComparison.OrdinalIgnoreCase))
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        if (!Convert.ToString(dr["MENU_ID"]).Equals("ALL NOTICE", StringComparison.OrdinalIgnoreCase))
                        {
                            dr["CHK"] = "N";
                        }
                    }
                }
            }
            else
            {
                if (Convert.ToString(selRow["CHK"]).Equals("Y", StringComparison.OrdinalIgnoreCase))
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        if (Convert.ToString(dr["MENU_ID"]).Equals("ALL NOTICE", StringComparison.OrdinalIgnoreCase))
                        {
                            dr["CHK"] = "N";
                        }
                    }
                }
            }
        }

        #region ▶ 버튼 이벤트

        /// <summary>
        /// 조회
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            grdMain.DataSource = GetData();
            grvMain.FocusedRowHandle = -1;
            grvMain.RefreshData();

            if (grdMain.DataSource != null)
            {
                DataTable dt = grdMain.DataSource as DataTable;

                if (dt.Rows.Count == 0)
                {
                    try
                    {
                        DataTable dtSub = grdSub.DataSource as DataTable;
                        foreach (DataRow dr in dtSub.Rows)
                            dr["CHK"] = "N";
                        dtSub.AcceptChanges();
                    }
                    catch
                    {

                    }
                }
            }
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            DataPack par = new DataPack();
            par.DataList.Add("IN_N_ID", string.Empty);
            par.DataList.Add("IN_FDATE", DateTimeHelper.GetString(dteIFDATE.EditValue));
            par.DataList.Add("IN_TDATE", DateTimeHelper.GetString(dteITDATE.EditValue));
            par.DataList.Add("IN_CAPTION", txtICAPTION.Text);
            par.DataList.Add("IN_AFILE", txtIAFILE.Text);
            par.DataList.Add("IN_USEYN", chkUSEYN.Checked ? "Y" : "N");
            par.DataList.Add("IN_USER_ID", this.UserID);
            par.DataList.Add("IN_ROOT_MENUS", GetRootMenus(grdInput.DataSource as DataTable));
            par.DataList.Add("OUT_N_ID", "");

            if (!CheckInsert(par.DataList))
            {
                par.DataList.Clear();
                par = null;
                return;
            }

            this.BeforeInvokeServer("등록 중입니다.");
            DataResultSet resultSet;
            try
            {
                resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS022.SAVE_01", par);
                string n_id = ReturnValue(resultSet.OutParamList["OUT_N_ID"]);
                if (!string.IsNullOrEmpty(n_id))
                {
                    popup.UploadFile(txtIAFILE.Text, n_id + ".pdf");
                }
                InitInputPanel();
            }
            finally
            {
                this.AfterInvokeServer();
            }

            if (resultSet.IsSuccess)
            {
                btnSearch_Click(null, null);
            }
            else
            {
                MsgBox.Show(this, resultSet.ExceptionMessage, "오류", MessageBoxButtons.OK, ImageKinds.Error);
            }
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            DataRow[] rows = _cspt.CheckedRows(this, grdMain, "수정");

            if (rows == null)
                return;


            DataTable cdt = (grdMain.DataSource as DataTable).GetChanges();
            if (cdt == null || cdt.Rows.Count == 0)
            {
                MsgBox.Show(this, "변경된 내역이 없습니다..", "알림", MessageBoxButtons.OK, ImageKinds.Information);
                return;
            }

            this.BeforeInvokeServer(true, "등록 중입니다.", true, rows.Length);
            try
            {
                for (int i = 0; i < rows.Length; i++)
                {
                    DataPack par = new DataPack();

                    if (string.IsNullOrEmpty(Convert.ToString(rows[i]["N_ID"])))
                    {
                        MsgBox.Show(this, (i + 1).ToString() + "번째 항목에 ID 값이 없습니다.", "오류", MessageBoxButtons.OK, ImageKinds.Error);
                        continue;
                    }

                    par.DataList.Add("IN_N_ID", Convert.ToString(rows[i]["N_ID"]));
                    par.DataList.Add("IN_FDATE", Convert.ToDateTime(rows[i]["FDATE"]).ToString("yyyyMMdd"));
                    par.DataList.Add("IN_TDATE", Convert.ToDateTime(rows[i]["TDATE"]).ToString("yyyyMMdd"));
                    par.DataList.Add("IN_CAPTION", Convert.ToString(rows[i]["CAPTION"]));
                    par.DataList.Add("IN_AFILE", Convert.ToString(rows[i]["AFILE"]));
                    par.DataList.Add("IN_USEYN", Convert.ToString(rows[i]["USEYN"]));
                    par.DataList.Add("IN_USER_ID", this.UserID);
                    par.DataList.Add("IN_ROOT_MENUS", Convert.ToString(rows[i]["ROOT_MENUS"]));
                    par.DataList.Add("OUT_N_ID", "");

                    DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS022.SAVE_01", par);
                    string n_id = ReturnValue(resultSet.OutParamList["OUT_N_ID"]);
                    if (!string.IsNullOrEmpty(n_id))
                    {
                        if (!string.IsNullOrWhiteSpace(Convert.ToString(rows[i]["AFILE"])))
                        {
                            if (!Convert.ToString(rows[i]["AFILE"]).Equals(Convert.ToString(rows[i]["AFILE", DataRowVersion.Original])))
                            {
                                popup.UploadFile(Convert.ToString(rows[i]["AFILE"]), n_id + ".pdf");
                            }
                        }
                    }

                    this.ProgressManager.SetWaitFormDescription(i.ToString() + "건 수정하였습니다.");

                    if (!resultSet.IsSuccess)
                    {
                        MsgBox.Show(this, i.ToString() + "번째 수정중 오류 발생\n\n" + resultSet.ExceptionMessage, "오류", MessageBoxButtons.OK, ImageKinds.Error);
                    }
                    par.DataList.Clear();
                }

                this.AfterInvokeServer();
                MsgBox.Show(this, "수정하였습니다.", "알림", MessageBoxButtons.OK, ImageKinds.Information);
                btnSearch_Click(null, null);
            }
            catch (Exception)
            {
                this.AfterInvokeServer();
                throw;
            }

        }

        /// <summary>
        /// 삭제
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            DataRow[] rows = _cspt.CheckedRows(this, grdMain, "삭제");

            if (rows == null)
                return;

            DataPack par = new DataPack();

            List<string> list1 = new List<string>();

            for (int i = 0; i < rows.Length; i++)
            {
                list1.Add(rows[i]["N_ID"].ToString());
            }

            par.DataList.Add("IN_N_ID", list1.ToArray());

            par.ArrayItemCount = rows.Length; //==> ArrayBind 처리시... 항상 지정해야함...

            this.BeforeInvokeServer("삭제 중입니다.");
            DataResultSet resultSet;
            try
            {
                resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS022.DELETE_01", par);
            }
            finally
            {
                this.AfterInvokeServer();
            }

            if (resultSet.IsSuccess)
            {
                btnSearch_Click(null, null);
            }
            else
            {
                MsgBox.Show(this, resultSet.ExceptionMessage, "오류", MessageBoxButtons.OK, ImageKinds.Error);
            }
        }

        #endregion ▶ 버튼 이벤트 끝

        private void txtIAFILE_Properties_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            var res = openFileDialog1.ShowDialog(this);

            if (res == DialogResult.OK)
            {
                if (!string.IsNullOrEmpty(openFileDialog1.FileName))
                {
                    txtIAFILE.Text = openFileDialog1.FileName;
                }
            }
        }

        private void repositoryItemButtonEdit1_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            var res = openFileDialog1.ShowDialog(this);

            if (res == DialogResult.OK)
            {
                if (!string.IsNullOrEmpty(openFileDialog1.FileName))
                {
                    DataRow dr = grvMain.GetFocusedDataRow();
                    dr["AFILE"] = openFileDialog1.FileName;
                    grvMain.RefreshData();
                }
            }
        }

        private void grvMain_RowClick(object sender, RowClickEventArgs e)
        {
            if (e.RowHandle < 0)
                return;

            if (e.Clicks == 2)
            {
                DataRow dr = grvMain.GetDataRow(e.RowHandle);

                if (dr == null)
                    return;

                string n_id = Convert.ToString(dr["N_ID"]);
                string caption = Convert.ToString(dr["CAPTION"]);

                if (string.IsNullOrEmpty(n_id))
                    return;

                string localFile = popup.DownloadFile(n_id + ".pdf", n_id + ".pdf");

                HHI.ShipBuilding.Notice.Popup p = new Notice.Popup(localFile, caption);
                p.Show(this);
            }
        }

        private void grvMain_CellValueChanged(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            if (e.Column == colChk)
                return;
            DataRow dr = grvMain.GetDataRow(e.RowHandle);

            if (dr != null)
            {
                dr["CHK"] = "Y";
            }
        }

        private void grvMain_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            if (e.FocusedRowHandle < 0)
                return;

            WhenFoucsedRowChanged(e.FocusedRowHandle);
            
        }

        private void grv_RowCellStyle(object sender, RowCellStyleEventArgs e)
        {
            if (e.RowHandle < 0)
                return;

            DataRow dr = (sender as GridView).GetDataRow(e.RowHandle);

            if (dr == null)
                return;

            if (Convert.ToString(dr["MENU_ID"]).Equals("ALL NOTICE", StringComparison.OrdinalIgnoreCase))
            {
                e.Appearance.BackColor = Color.LightBlue;
                e.Appearance.Font = new Font(e.Appearance.Font, FontStyle.Bold);
            }
        }

        private void grvSub_RowClick(object sender, RowClickEventArgs e)
        {
            if (e.RowHandle < 0)
                return;

            DataRow drSub = grvSub.GetFocusedDataRow();

            DataTable dtSub = (grdSub.DataSource as DataTable);

            if (dtSub == null)
                return;

            drSub["CHK"] = Convert.ToString(drSub["CHK"]) == "Y" ? "N" : "Y";

            AllNoticeChecked(dtSub, drSub);

            grvSub.RefreshData();

            DataRow drMain = grvMain.GetFocusedDataRow();

            if (drMain == null)
                return;

            drMain["ROOT_MENUS"] = GetRootMenus(dtSub);
            drMain["CHK"] = "Y";
            grvMain.RefreshData();
        }

        private void grvInput_RowClick(object sender, RowClickEventArgs e)
        {
            if (e.RowHandle < 0)
                return;

            DataRow drInput = grvInput.GetFocusedDataRow();

            DataTable dtInput = (grdInput.DataSource as DataTable);

            if (dtInput == null)
                return;

            drInput["CHK"] = Convert.ToString(drInput["CHK"]) == "Y" ? "N" : "Y";

            AllNoticeChecked(dtInput, drInput);

            grvSub.RefreshData();
        }
    }
}
