﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    public partial class SCSYS009P1 : DevExpress.XtraEditors.XtraForm
    {
        /// <summary>
        /// 시스템 정보 DataRow
        /// </summary>
        public DataRow hdnRow { get; set; }

        public string sLOGIN_USERID { get; set; }

        string hdnSYSTEM_CODE = string.Empty;
        string hdnFTP_IP = string.Empty;
        string hdnFTP_SERVER_PATH = string.Empty;
        string hdnFTP_ID = string.Empty;
        string hdnFTP_PASSWORD = string.Empty;

        string isNEW = "N";


        HHI.ShipBuilding.Controls.Utils.FtpHelper ftpHelper = null;

        public SCSYS009P1()
        {
            InitializeComponent();
        }

        #region 화면 Load - SCSYS009P1_Load
        /// <summary>
        /// 화면 Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SCSYS009P1_Load(object sender, EventArgs e)
        {
            initPage();
        }
        #endregion 화면 Load - SCSYS009P1_Load

        #region 화면 초기화 - initPage
        /// <summary>
        /// 화면 초기화
        /// </summary>
        private void initPage()
        {
            // ini 파일 버젼 체크 테스트
            //ftpHelper.VersionCheckedFtp(string.Empty);

            // 콤보 바인딩
            ClientControlHelper.ImageComboBind(cboWORK_GUBUN, "CDNM", "CDCODE", "{value}-{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, ClientControlHelper.GetCodeInfo("SY001"));
            cboWORK_GUBUN.Properties.DropDownRows = cboWORK_GUBUN.Properties.Items.Count;
            chkUseUpdater.EditValue = "";
            chkBizWork.EditValue = "";
            if (hdnRow != null)
            {
                // 컨트롤 바인딩
                ClientControlHelper.CtrlNestedDataBind(hdnRow, layoutControlGroup1);

                txtSystem_Code.Enabled = false;

                lciSYSTEM_CODE_R.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Always;
                lcgSYSTEM_CODE_N.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;

                hdnSYSTEM_CODE = hdnRow["SYSTEM_CODE"].ToString();
                hdnFTP_IP = hdnRow["FTP_IP"].ToString();
                hdnFTP_SERVER_PATH = hdnRow["FTP_SERVER_PATH"].ToString();
                hdnFTP_ID = hdnRow["USER_ID"].ToString();
                hdnFTP_PASSWORD = hdnRow["PASSWORD"].ToString();
                
                // 첨부파일 정보 바인딩
                grdFile_Bind(hdnRow["SYSTEM_CODE"].ToString());

                // set system_code validation
                stdValidationManager1.SetValidation(txtSAUPBU, new ValidationType[] { });
                stdValidationManager1.SetValidation(cboWORK_GUBUN, new ValidationType[] {  });
                stdValidationManager1.SetValidation(txtSYSTEM_GUBUN, new ValidationType[] { });

                isNEW = "Y";
                
            }
            else
            {
                lciSYSTEM_CODE_R.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
                lcgSYSTEM_CODE_N.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Always;
                txtSAUPBU.Text = "C";
                cboWORK_GUBUN.SelectedIndex = 0;
                txtSYSTEM_GUBUN.Text = string.Empty;
                txtSystem_Code.EditValue = string.Empty;
                txtSystem_Name.EditValue = string.Empty;
                txtDownload_Base_Url.EditValue = " ";
                txtInitialize_Module.EditValue = string.Empty;
                txtInitialize_Class.EditValue = string.Empty;
                txtFtp_Ip.EditValue = string.Empty;
                txtFtp_Server_Path.EditValue = string.Empty;
                txtUser_Id.EditValue = string.Empty;
                txtPassword.EditValue = string.Empty;
            }
        }
        #endregion 화면 초기화 - initPage

        #region 저장 - btnSave_Click
        /// <summary>
        /// 저장
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {
            if(hdnSYSTEM_CODE.Equals(""))
                txtSystem_Code.Text = txtSAUPBU.Text + cboWORK_GUBUN.EditValue.ToString() + txtSYSTEM_GUBUN.Text;
            
            // 필수값 체크 - 디자인 모드에서 각 컨트롤별 설정
            if (!stdValidationManager1.Validation())
            {
                return;
            }

            if (!CheckSystemInfo(txtSystem_Code.Text))
            {
                return;
            }

            

            DataPack parameter = new DataPack();
            parameter.DataList.Add("SYSTEM_CODE", txtSystem_Code.Text);
            parameter.DataList.Add("SYSTEM_NAME", txtSystem_Name.Text);
            parameter.DataList.Add("DOWNLOAD_BASE_URL", txtDownload_Base_Url.Text);
            parameter.DataList.Add("INITIALIZE_MODULE", txtInitialize_Module.Text);
            parameter.DataList.Add("INITIALIZE_CLASS", txtInitialize_Class.Text);
            parameter.DataList.Add("FTP_IP", txtFtp_Ip.Text);
            parameter.DataList.Add("FTP_SERVER_PATH", txtFtp_Server_Path.Text);
            parameter.DataList.Add("USER_ID", txtUser_Id.Text);
            parameter.DataList.Add("PASSWORD", txtPassword.Text);
            parameter.DataList.Add("LOGIN_USERID", sLOGIN_USERID);
            parameter.DataList.Add("USE_UPDATER", Convert.ToString(chkUseUpdater.EditValue));
            parameter.DataList.Add("SHARED_SYS", Convert.ToString(chkBizWork.EditValue));

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS009.SAVE_01", parameter);

            if (resultSet.IsSuccess)
            {
                cboWORK_GUBUN.Properties.ReadOnly = true;
                txtSYSTEM_GUBUN.Properties.ReadOnly = true;
                txtSystem_Code.Enabled = false;
                hdnSYSTEM_CODE = parameter.DataList["SYSTEM_CODE"].ToString();
                hdnFTP_IP = parameter.DataList["FTP_IP"].ToString();
                hdnFTP_SERVER_PATH = parameter.DataList["FTP_SERVER_PATH"].ToString();
                hdnFTP_ID = parameter.DataList["USER_ID"].ToString();
                hdnFTP_PASSWORD = parameter.DataList["PASSWORD"].ToString();

                MsgBox.Show("저장되었습니다.", "확인");

                if (hdnRow == null)
                {
                    lciSYSTEM_CODE_R.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Always;
                    lcgSYSTEM_CODE_N.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
                    txtSystem_Code.Text = hdnSYSTEM_CODE;
                    isNEW = "Y";
                }
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 저장 - btnSave_Click

        #region 등록된 시스템 확인 - CheckSystemInfo
        /// <summary>
        /// 등록된 시스템 확인
        /// </summary>
        /// <param name="strSystem_Code"></param>
        /// <returns></returns>
        private bool CheckSystemInfo(string strSystem_Code)
        {
            bool bResult = true;

            // 등록된 시스템 확인 - 수정모드에선 체크 안함
            if (isNEW.Equals("N"))
            {
                DataPack parameter = new DataPack();
                parameter.DataList.Add("SYSTEM_CODE", strSystem_Code);

                DataTable dtCheck = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS009.SEARCH_01", parameter).QuerySet.Tables[0];

                if (dtCheck != null && dtCheck.Rows.Count > 0)
                {
                    MsgBox.Show(string.Format("이미 등록된 시스템 입니다.\r\n시스템 코드 : {0}", strSystem_Code), "경고");
                    bResult = false;
                }
            }

            return bResult;
        }
        #endregion 등록된 시스템 확인 - CheckSystemInfo

        #region 닫기 - btnClose_Click
        /// <summary>
        /// 닫기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }
        #endregion 닫기 - btnClose_Click

        #region 첨부파일 정보 바인딩 - grdFile_Bind
        /// <summary>
        /// 첨부파일 정보 바인딩
        /// </summary>
        /// <param name="strSystem_Code"></param>
        private void grdFile_Bind(string strSystem_Code)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("SYSTEM_CODE", strSystem_Code);

            DataResultSet resultSet = ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS009.SEARCH_02", parameter);

            if (resultSet.IsSuccess)
            {
                grdFile.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 첨부파일 정보 바인딩 - grdFile_Bind

        #region 파일첨부 - btnFileSave_Click
        /// <summary>
        /// 파일첨부
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFileAttach_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = true;
            openFileDialog.InitialDirectory = System.Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            openFileDialog.DefaultExt = "*.*";
            openFileDialog.Filter = "All Files(*.*)|*.*";

            openFileDialog.ShowDialog();

            if (openFileDialog.FileName.Length > 0)
            {
                foreach (string strFileName in openFileDialog.FileNames)
                {
                    FileInfo fileInfo = new FileInfo(strFileName);
                    if (fileInfo.Exists)
                    {
                        grvFile.AddNewRow();
                        grvFile.SetFocusedRowCellValue("CHK", "N");
                        grvFile.SetFocusedRowCellValue("SYSTEM_CODE", string.Empty);
                        grvFile.SetFocusedRowCellValue("ID", string.Empty);
                        grvFile.SetFocusedRowCellValue("PROGRAM_NAME", txtPROGRAM.Text != "" ? txtPROGRAM.Text : string.Empty);
                        grvFile.SetFocusedRowCellValue("FILE_PATH", txtFILE_PATH.Text != "" ? txtFILE_PATH.Text : string.Empty);
                        grvFile.SetFocusedRowCellValue("FILE_NAME", fileInfo.Name);
                        grvFile.SetFocusedRowCellValue("UPDATE_DATE", string.Empty);
                        grvFile.SetFocusedRowCellValue("NEWFILE", "Y");
                        grvFile.SetFocusedRowCellValue("LOCAL_FILE_PATH", fileInfo.FullName);
                        grvFile.UpdateCurrentRow();
                    }
                }
            }
        }
        #endregion 파일첨부 - btnFileSave_Click

        #region 파일저장 - btnFileSave_Click
        /// <summary>
        /// 파일저장
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFileSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(hdnSYSTEM_CODE))
            {
                MsgBox.Show("시스템 정보를 먼저 저장 하세요!", "경고");
                return;
            }

            if (string.IsNullOrWhiteSpace(hdnFTP_SERVER_PATH))
            {
                MsgBox.Show("FTP 서버 경로가 없습니다.\r\nFTP 서버 경로를 먼저 저장 하세요!", "경고");
                txtFtp_Server_Path.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(hdnFTP_ID))
            {
                MsgBox.Show("FTP ID가 없습니다.\r\nFTP ID를 먼저 저장 하세요!", "경고");
                txtUser_Id.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(hdnFTP_PASSWORD))
            {
                MsgBox.Show("FTP Password가 없습니다.\r\nFTP Password를 먼저 저장 하세요!", "경고");
                txtPassword.Focus();
                return;
            }

            if (grvFile.RowCount == 0)
            {
                MsgBox.Show("저장할 정보가 없습니다.", "경고");
                return;
            }

            DataRow[] rowsFtpFile = (grdFile.DataSource as DataTable).Select("NEWFILE = 'Y'");

            if (rowsFtpFile.Length == 0)
            {
                MsgBox.Show("파일을 첨부한 후 저장하세요.", "경고");
                return;
            }

            DataTable dtFile = rowsFtpFile.CopyToDataTable();
            string[] paramnames = new string[] { "SYSTEM_CODE", "ID", "PROGRAM_NAME", "FILE_PATH", "FILE_NAME" };

            DataTable dtParam = new DataTable();
            for (int i = 0; i < paramnames.Length; i++)
            {
                dtParam.Columns.Add(paramnames[i]);
            }

            

            // 파라메터 생성
            DataPack parameter = new DataPack();
            foreach (DataColumn col in dtParam.Columns)
            {
                string[] col1 = new string[dtFile.Rows.Count];
                for (int i = 0; i < dtFile.Rows.Count; i++)
                {
                    if (col.ColumnName.Equals("SYSTEM_CODE"))
                    {
                        col1[i] = hdnSYSTEM_CODE;
                    }
                    else if (col.ColumnName.Equals("PROGRAM_NAME"))
                    {
                        if (string.IsNullOrWhiteSpace(dtFile.Rows[i][col.ColumnName].ToString()))
                        {
                            MsgBox.Show("프로그램명을 입력 하세요!", "경고");
                            FtpFileDelete(rowsFtpFile);
                            return;
                        }

                        col1[i] = dtFile.Rows[i][col.ColumnName].ToString();
                    }
                    else if (col.ColumnName.Equals("FILE_PATH"))
                    {
                        if (string.IsNullOrWhiteSpace(dtFile.Rows[i][col.ColumnName].ToString()))
                        {
                            MsgBox.Show("파일경로를 입력 하세요!", "경고");
                            FtpFileDelete(rowsFtpFile);
                            return;
                        }

                        col1[i] = dtFile.Rows[i][col.ColumnName].ToString();
                    }
                    else
                    {
                        col1[i] = dtFile.Rows[i][col.ColumnName].ToString();
                    }
                }

                parameter.DataList.Add(col.ColumnName, col1);
            }

            string[] col2 = new string[dtFile.Rows.Count];

            for (int i = 0; i < dtFile.Rows.Count; i++)
            {
                col2[i] = sLOGIN_USERID;
            }

            parameter.DataList.Add("LOGIN_USERID", col2); 

            parameter.ArrayItemCount = dtFile.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...


            // FTP 업로드
            ftpHelper = new Controls.Utils.FtpHelper(string.Format(@"ftp://{0}/", hdnFTP_IP), hdnFTP_ID, hdnFTP_PASSWORD);

            // Ftp 연결 확인
            //if (!ftpHelper.isValidFtpConnection(hdnFTP_SERVER_PATH))
            //{
            //    MsgBox.Show("FTP 연결에 실패 했습니다.");
            //    return;
            //}

            // Ftp 파일 업로드
            if (ftpHelper != null)
            {
                FtpFileUpLoad(rowsFtpFile);
            }



            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS009.SAVE_02", parameter);

            if (resultSet.IsSuccess)
            {

                MsgBox.Show("저장 되었습니다.", "확인");
                grdFile_Bind(hdnSYSTEM_CODE);
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 파일저장 - btnFileSave_Click

        #region Ftp 파일 업로드 - FtpFileUpLoad
        /// <summary>
        /// Ftp 파일 업로드
        /// </summary>
        /// <param name="rows"></param>
        private void FtpFileUpLoad(DataRow[] rows)
        {
            foreach (DataRow row in rows)
            {
                string strFtpUploadPathFull = hdnFTP_SERVER_PATH + "/" + row["FILE_NAME"].ToString();
                ftpHelper.Upload(strFtpUploadPathFull, row["LOCAL_FILE_PATH"].ToString());
            }
        }
        #endregion Ftp 파일 업로드 - FtpFileUpLoad

        #region Ftp 파일 삭제 - FtpFileDelete
        /// <summary>
        /// Ftp 파일 삭제
        /// </summary>
        /// <param name="rows"></param>
        private void FtpFileDelete(DataRow[] rows)
        {
            foreach (DataRow row in rows)
            {
                string strFtpUploadPathFull = hdnFTP_SERVER_PATH + "/" + row["FILE_NAME"].ToString();
                ftpHelper.Delete(strFtpUploadPathFull);
            }
        }
        #endregion Ftp 파일 삭제 - FtpFileDelete

        #region 파일삭제 - btnFileDelete_Click
        /// <summary>
        /// 파일삭제
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFileDelete_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("삭제 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }

            if (grvFile.RowCount == 0)
            {
                MsgBox.Show("삭제할 정보가 없습니다.", "경고");
                return;
            }

            DataRow[] rowsFtpFile = (grdFile.DataSource as DataTable).Select("CHK = 'Y'");

            if (rowsFtpFile.Length == 0)
            {
                MsgBox.Show("삭제할 정보를 선택하세요!", "경고");
                return;
            }

            DataTable dtFile = rowsFtpFile.CopyToDataTable();
            string[] paramnames = new string[] { "SYSTEM_CODE", "ID" };

            DataTable dtParam = new DataTable();
            for (int i = 0; i < paramnames.Length; i++)
            {
                dtParam.Columns.Add(paramnames[i]);
            }

            // 파라메터 생성
            DataPack parameter = new DataPack();
            foreach (DataColumn col in dtParam.Columns)
            {
                string[] col1 = new string[dtFile.Rows.Count];
                for (int i = 0; i < dtFile.Rows.Count; i++)
                {
                    col1[i] = dtFile.Rows[i][col.ColumnName].ToString();
                }

                parameter.DataList.Add(col.ColumnName, col1);
            }

            parameter.ArrayItemCount = dtFile.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS009.DELETE_02", parameter);

            if (resultSet.IsSuccess)
            {
                // Ftp 파일 삭제
                //FtpFileDelete(rowsFtpFile);

                MsgBox.Show("삭제 되었습니다.", "확인");
                grdFile_Bind(hdnSYSTEM_CODE);
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 파일삭제 - btnFileDelete_Click

        #region 첨부파일 정보 File DragEnter - grdFile_DragEnter
        /// <summary>
        /// 첨부파일 정보 File DragEnter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void grdFile_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.All;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }
        #endregion 첨부파일 정보 File DragEnter - grdFile_DragEnter

        #region 첨부파일 정보 File DragDrop - grdFile_DragDrop
        /// <summary>
        /// 첨부파일 정보 File DragDrop
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void grdFile_DragDrop(object sender, DragEventArgs e)
        {
            string[] arrFile = (string[])e.Data.GetData(DataFormats.FileDrop, false);

            foreach (string strFile in arrFile)
            {
                FileInfo fileInfo = new FileInfo(strFile);
                if (fileInfo.Exists)
                {
                    grvFile.AddNewRow();
                    grvFile.SetFocusedRowCellValue("CHK", "N");
                    grvFile.SetFocusedRowCellValue("SYSTEM_CODE", string.Empty);
                    grvFile.SetFocusedRowCellValue("ID", string.Empty);
                    grvFile.SetFocusedRowCellValue("PROGRAM_NAME", string.Empty);
                    grvFile.SetFocusedRowCellValue("FILE_PATH", string.Empty);
                    grvFile.SetFocusedRowCellValue("FILE_NAME", fileInfo.Name);
                    grvFile.SetFocusedRowCellValue("UPDATE_DATE", string.Empty);
                    grvFile.SetFocusedRowCellValue("NEWFILE", "Y");
                    grvFile.SetFocusedRowCellValue("LOCAL_FILE_PATH", fileInfo.FullName);
                    grvFile.UpdateCurrentRow();
                }
            }
        }
        #endregion 첨부파일 정보 File DragDrop - grdFile_DragDrop

        #region 첨부파일 정보 더블클릭 - 기존파일 추가 - grvFile_DoubleClick
        /// <summary>
        /// 첨부파일 정보 더블클릭 - 기존 파일 추가
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void grvFile_DoubleClick(object sender, EventArgs e)
        {
            DataRow row = grvFile.GetFocusedDataRow();
            if (row != null)
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Multiselect = true;
                openFileDialog.InitialDirectory = System.Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                openFileDialog.DefaultExt = "*.*";
                openFileDialog.Filter = "All Files(*.*)|*.*";
                openFileDialog.ShowDialog();

                if (openFileDialog.FileName.Length > 0)
                {
                    foreach (string strFileName in openFileDialog.FileNames)
                    {
                        FileInfo fileInfo = new FileInfo(strFileName);
                        if (fileInfo.Exists)
                        {
                            row["CHK"] = "N";
                            row["PROGRAM_NAME"] = txtPROGRAM.Text != "" ? txtPROGRAM.Text : string.Empty;
                            row["FILE_PATH"] = txtFILE_PATH.Text != "" ? txtFILE_PATH.Text : string.Empty;
                            row["FILE_NAME"] = fileInfo.Name;                            
                            row["NEWFILE"] = "Y";
                            row["LOCAL_FILE_PATH"] = fileInfo.FullName;
                            grvFile.UpdateCurrentRow();
                        }
                    }
                }


            }
        }
        #endregion 첨부파일 정보 더블클릭 - 기존파일 추가 - grvFile_DoubleClick
    }
}
