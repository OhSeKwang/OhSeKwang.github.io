﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraTreeList.Nodes;
using DevExpress.XtraEditors;
using HHI.Security;
using System.Threading.Tasks;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS014 : StdUserControlBase// UserControl
    {

        #region 생성자 및 변수 선언
        public SCSYS014()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();



            #endregion
        }

        #endregion

        #region 화면 Load

        public override void InitControl(object args)
        {
            base.InitControl(args);

            string strTCode;
            if (args == null || string.IsNullOrEmpty(Convert.ToString(args)))
            {
                strTCode = this.MenuExtraInfo;
            }
            else
            {
                string displayTitle = string.Empty;

                strTCode = Convert.ToString(args);
                if (strTCode.IndexOf("&") != -1)
                {
                    string[] arrTCode = strTCode.Split('&');
                    strTCode = arrTCode[0];

                    displayTitle = arrTCode.Length > 1 ? arrTCode[1] : string.Empty;
                    if (!string.IsNullOrWhiteSpace(displayTitle))
                    {
                        this.MenuItemInfo.DisplayTitle = displayTitle;
                    }
                }
            }

            string strUrl = HHI.Configuration.AppSectionFactory.AppSection["BIZSAP_GUI"].ToString();

            // 파라메터 GUBUN - 1 : Hi Portal 메인화면, 2 : SAP TCODE 화면, 3 : SAP 메인 화면(사용안함)
            //if (string.IsNullOrWhiteSpace(strTCode))
            //{
            //    strUrl += string.Format(@"?USER_ID={0}&GUBUN={1}&TCODE={2}", UserInfo.UserID, "3", string.Empty);
            //}
            //else
            //{
            //    strUrl += string.Format(@"?USER_ID={0}&GUBUN={1}&TCODE={2}", UserInfo.UserID, "2", strTCode);
            //}

            if (string.IsNullOrWhiteSpace(strTCode))
            {
                strUrl += string.Format(@"?TCODE={0}", "HIPORT");
            }
            else
            {
                strUrl += string.Format(@"?TCODE={0}", strTCode);
            }

            object obj = null;
            axWebBrowser1.Navigate(strUrl, ref obj, ref obj, ref obj, ref obj);

            var ctx = UserInfoContext.Current;
            Action action = () =>
            {
                ctx.SetCallContext();
                try
                {
                    using (var service = HHI.ServiceModel.ClientFactory.CreateChannel<HHI.ShipBuilding.Menu.IStdMenuService>("StdMenuService", "Menu.svc"))
                    {
                        int result = service.SaveMenuStatistics2(this.UserID, strTCode, this.SystemId, UserInfo.LOGIN_IP);
                    }
                }
                catch
                {
                }
                finally
                {
                    UserInfoContext.ClearCallContext();
                }
            };

            Task task = new Task(action);
            task.Start();
        }

        private void SCSYS014_Load(object sender, EventArgs e)
        {
            
        }
        
        #endregion

    }
}
