﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS005P1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.cboSYSTEM_CODE = new HHI.ShipBuilding.Client.Controls.DXperience.XtraImageComboBoxEditExt();
            this.txtProgram_Name = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnSearch = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.txtSystem_Name = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.grdMain = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvMain = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpychkYN = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.btnClose = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.stdValidationManager1 = new HHI.ShipBuilding.Controls.StdValidationManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboSYSTEM_CODE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProgram_Name.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSystem_Name.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkYN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.cboSYSTEM_CODE);
            this.xtraLayoutControlExt1.Controls.Add(this.txtProgram_Name);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearch);
            this.xtraLayoutControlExt1.Controls.Add(this.txtSystem_Name);
            this.xtraLayoutControlExt1.Controls.Add(this.grdMain);
            this.xtraLayoutControlExt1.Controls.Add(this.btnClose);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(514, 167, 374, 570);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(654, 434);
            this.xtraLayoutControlExt1.TabIndex = 0;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // cboSYSTEM_CODE
            // 
            this.cboSYSTEM_CODE.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.cboSYSTEM_CODE.EditValue = "";
            this.cboSYSTEM_CODE.EnterExecuteButton = null;
            this.cboSYSTEM_CODE.FocusColor = System.Drawing.Color.Empty;
            this.cboSYSTEM_CODE.Key = "";
            this.cboSYSTEM_CODE.Location = new System.Drawing.Point(88, 38);
            this.cboSYSTEM_CODE.MinLength = 0;
            this.cboSYSTEM_CODE.Name = "cboSYSTEM_CODE";
            this.cboSYSTEM_CODE.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.cboSYSTEM_CODE.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.cboSYSTEM_CODE.Properties.Appearance.Options.UseBackColor = true;
            this.cboSYSTEM_CODE.Properties.Appearance.Options.UseForeColor = true;
            this.cboSYSTEM_CODE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboSYSTEM_CODE.Size = new System.Drawing.Size(93, 20);
            this.cboSYSTEM_CODE.StyleController = this.xtraLayoutControlExt1;
            this.cboSYSTEM_CODE.TabIndex = 18;
            // 
            // txtProgram_Name
            // 
            this.txtProgram_Name.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtProgram_Name.EditValue = "";
            this.txtProgram_Name.EnterExecuteButton = null;
            this.txtProgram_Name.FocusColor = System.Drawing.Color.Empty;
            this.txtProgram_Name.IsValueTrim = true;
            this.txtProgram_Name.Key = "PROGRAM_NAME";
            this.txtProgram_Name.Location = new System.Drawing.Point(482, 38);
            this.txtProgram_Name.MinLength = 0;
            this.txtProgram_Name.Name = "txtProgram_Name";
            this.txtProgram_Name.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtProgram_Name.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtProgram_Name.Properties.Appearance.Options.UseBackColor = true;
            this.txtProgram_Name.Properties.Appearance.Options.UseForeColor = true;
            this.txtProgram_Name.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProgram_Name.Size = new System.Drawing.Size(145, 20);
            this.txtProgram_Name.StyleController = this.xtraLayoutControlExt1;
            this.txtProgram_Name.TabIndex = 17;
            this.txtProgram_Name.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // btnSearch
            // 
            this.btnSearch.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_조회;
            this.btnSearch.IsExecuteWdworkerLog = true;
            this.btnSearch.Location = new System.Drawing.Point(496, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(71, 22);
            this.btnSearch.StyleController = this.xtraLayoutControlExt1;
            this.btnSearch.TabIndex = 16;
            this.btnSearch.Text = "조회";
            this.btnSearch.UseSplasher = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSystem_Name
            // 
            this.txtSystem_Name.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtSystem_Name.EditValue = "";
            this.txtSystem_Name.EnterExecuteButton = null;
            this.txtSystem_Name.FocusColor = System.Drawing.Color.Empty;
            this.txtSystem_Name.IsValueTrim = true;
            this.txtSystem_Name.Key = "SYSTEM_NMAE";
            this.txtSystem_Name.Location = new System.Drawing.Point(281, 38);
            this.txtSystem_Name.MinLength = 0;
            this.txtSystem_Name.Name = "txtSystem_Name";
            this.txtSystem_Name.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtSystem_Name.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtSystem_Name.Properties.Appearance.Options.UseBackColor = true;
            this.txtSystem_Name.Properties.Appearance.Options.UseForeColor = true;
            this.txtSystem_Name.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSystem_Name.Size = new System.Drawing.Size(106, 20);
            this.txtSystem_Name.StyleController = this.xtraLayoutControlExt1;
            this.txtSystem_Name.TabIndex = 15;
            this.txtSystem_Name.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // grdMain
            // 
            this.grdMain.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdMain.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdMain.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdMain.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdMain.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdMain.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdMain.Location = new System.Drawing.Point(12, 62);
            this.grdMain.MainView = this.grvMain;
            this.grdMain.MinLength = 0;
            this.grdMain.Name = "grdMain";
            this.grdMain.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpychkYN});
            this.grdMain.Size = new System.Drawing.Size(630, 360);
            this.grdMain.TabIndex = 11;
            this.grdMain.UseEmbeddedNavigator = true;
            this.grdMain.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvMain});
            // 
            // grvMain
            // 
            this.grvMain.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn3,
            this.gridColumn1,
            this.gridColumn2});
            this.grvMain.GridControl = this.grdMain;
            this.grvMain.Name = "grvMain";
            this.grvMain.OptionsView.ColumnAutoWidth = false;
            this.grvMain.OptionsView.ShowGroupPanel = false;
            this.grvMain.DoubleClick += new System.EventHandler(this.grvMain_DoubleClick);
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.Caption = "시스템";
            this.gridColumn3.FieldName = "SYSTEM_NAME";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.OptionsColumn.ReadOnly = true;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 0;
            this.gridColumn3.Width = 150;
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "프로그램ID";
            this.gridColumn1.FieldName = "PROGRAM_ID";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.OptionsColumn.ReadOnly = true;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 1;
            this.gridColumn1.Width = 120;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "프로그램명";
            this.gridColumn2.FieldName = "PROGRAM_NAME";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.OptionsColumn.ReadOnly = true;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 2;
            this.gridColumn2.Width = 200;
            // 
            // rpychkYN
            // 
            this.rpychkYN.AutoHeight = false;
            this.rpychkYN.Caption = "Check";
            this.rpychkYN.Name = "rpychkYN";
            this.rpychkYN.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpychkYN.ValueChecked = "Y";
            this.rpychkYN.ValueUnchecked = "N";
            // 
            // btnClose
            // 
            this.btnClose.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_닫기;
            this.btnClose.IsExecuteWdworkerLog = true;
            this.btnClose.Location = new System.Drawing.Point(571, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(71, 22);
            this.btnClose.StyleController = this.xtraLayoutControlExt1;
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "닫기";
            this.btnClose.UseSplasher = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "Root";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.emptySpaceItem2,
            this.layoutControlItem9,
            this.layoutControlItem8,
            this.layoutControlItem7,
            this.layoutControlItem2,
            this.layoutControlItem3});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(654, 434);
            this.layoutControlGroup1.Text = "Root";
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.btnClose;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(559, 0);
            this.layoutControlItem1.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem1.Text = "layoutControlItem1";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextToControlDistance = 0;
            this.layoutControlItem1.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(484, 26);
            this.emptySpaceItem2.Text = "emptySpaceItem2";
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.btnSearch;
            this.layoutControlItem9.CustomizationFormText = "layoutControlItem9";
            this.layoutControlItem9.Location = new System.Drawing.Point(484, 0);
            this.layoutControlItem9.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem9.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem9.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem9.Text = "layoutControlItem9";
            this.layoutControlItem9.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem9.TextToControlDistance = 0;
            this.layoutControlItem9.TextVisible = false;
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.txtSystem_Name;
            this.layoutControlItem8.CustomizationFormText = "그룹명";
            this.layoutControlItem8.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_blue;
            this.layoutControlItem8.Location = new System.Drawing.Point(173, 26);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(221, 24);
            this.layoutControlItem8.Spacing = new DevExpress.XtraLayout.Utils.Padding(20, 15, 0, 0);
            this.layoutControlItem8.Text = "시스템명";
            this.layoutControlItem8.TextSize = new System.Drawing.Size(73, 16);
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.grdMain;
            this.layoutControlItem7.CustomizationFormText = "layoutControlItem7";
            this.layoutControlItem7.Location = new System.Drawing.Point(0, 50);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(634, 364);
            this.layoutControlItem7.Text = "layoutControlItem7";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem7.TextToControlDistance = 0;
            this.layoutControlItem7.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.txtProgram_Name;
            this.layoutControlItem2.CustomizationFormText = "프로그램명";
            this.layoutControlItem2.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_blue;
            this.layoutControlItem2.Location = new System.Drawing.Point(394, 26);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(240, 24);
            this.layoutControlItem2.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 15, 0, 0);
            this.layoutControlItem2.Text = "프로그램명";
            this.layoutControlItem2.TextSize = new System.Drawing.Size(73, 16);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.cboSYSTEM_CODE;
            this.layoutControlItem3.CustomizationFormText = "시스템코드";
            this.layoutControlItem3.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_blue;
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(173, 24);
            this.layoutControlItem3.Text = "시스템코드";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(73, 16);
            // 
            // stdValidationManager1
            // 
            this.stdValidationManager1.IsNullorWhiteSpace = true;
            this.stdValidationManager1.IsShowErrorMessage = true;
            // 
            // SCSYS005P1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 434);
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS005P1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "프로그램정보";
            this.Load += new System.EventHandler(this.SCSYS005P1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cboSYSTEM_CODE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProgram_Name.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSystem_Name.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpychkYN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private Client.Controls.DXperience.XtraButtonExt btnClose;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private Controls.StdValidationManager stdValidationManager1;
        private Client.Controls.DXperience.XtraButtonExt btnSearch;
        private Client.Controls.DXperience.XtraTextEditExt txtSystem_Name;
        private Client.Controls.DXperience.XtraGridControlExt grdMain;
        private DevExpress.XtraGrid.Views.Grid.GridView grvMain;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpychkYN;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private Client.Controls.DXperience.XtraTextEditExt txtProgram_Name;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private Client.Controls.DXperience.XtraImageComboBoxEditExt cboSYSTEM_CODE;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
    }
}