﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using DevExpress.XtraGrid.Views.Grid;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    [ToolboxItem(true)]
    public partial class SCSYS024 : StdUserControlBase
    {
        public SCSYS024()
        {
            InitializeComponent();

            #region 로긴된것처럼...

            //StdUserInfoContext userinfo = new StdUserInfoContext("TEST");
            //userinfo.SetThreadPrincipal();
            //userinfo.SetCallContext();

            #endregion
        }

        #region 화면 Load - SCSYS006_Load
        private void SCSYS024_Load(object sender, EventArgs e)
        {

        }
        #endregion 화면 Load - SCSYS006_Load

        #region SCSYS006_Shown        
        private void SCSYS024_Shown(object sender, EventArgs e)
        {
            initPage();
        }
        #endregion

        #region 화면 초기화 - initPage
        /// <summary>
        /// 화면 초기화
        /// </summary>
        private void initPage()
        {
            //처리상태
            ClientControlHelper.ImageComboBind(rpsCboPROCESS, "CDNM", "CDCODE", "{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, ClientControlHelper.GetCodeInfo("SY013"));
            rpsCboPROCESS.Items.Remove(rpsCboPROCESS.Items.GetItem("R"));  // 반려 item 은 안보이게...

            ClientControlHelper.ImageComboBind(cboPROCESS, "CDNM", "CDCODE", "{text}", ComboDisplayTextOption.top, "전체", string.Empty, ClientControlHelper.GetCodeInfo("SY013"));
            rpsCboPROCESS.Items.Remove(cboPROCESS.Properties.Items.GetItem("R"));  // 반려 item 은 안보이게...

            //내용구분
            ClientControlHelper.ImageComboBind(rpsCboGUBUN, "CDNM", "CDCODE", "{text}", ComboDisplayTextOption.top, string.Empty, string.Empty, ClientControlHelper.GetCodeInfo("SY014"));

            dteReq_From.EditValue = DateTime.Now.AddMonths(-5);
            dteReq_To.EditValue = DateTime.Now;

        }
        #endregion 화면 초기화 - initPage

        #region 신규 - btnNew_Click
        /// <summary>
        /// 신규
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNew_Click(object sender, EventArgs e)
        {
            SCSYS024P1 popup = new SCSYS024P1();
            popup.hdnRow = null;
            popup.sUSERID = UserInfo == null ? "ADMIN" : UserInfo.UserID;
            popup.sUSER_NAME = UserInfo.KOR_NM;            
            popup.sUSER_DEPTDESC = UserInfo.DEPTNAME;
            popup.sUSER_DEPT = UserInfo.DEPT_CD;
            popup.sUSER_CONTACT = UserInfo.OFFI_TEL;

            if (popup.ShowDialog() == DialogResult.OK)
            {
                btnSearch.PerformClick();
            }
        }
        #endregion 신규 - btnNew_Click

        #region 조회 - btnSearch_Click
        /// <summary>
        /// 조회
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            DataResultSet resultSet = GetInfo();

            if (resultSet.IsSuccess)
            {
                grdMain.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 조회 - btnSearch_Click

        private DataResultSet GetInfo()
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("REQ_USERNO", txtReq_Userno.Text);
            parameter.DataList.Add("REQ_USERNAME", txtReq_User_Nm.Text);
            parameter.DataList.Add("REQ_DEPTDESC", txtDeptName.Text);
            parameter.DataList.Add("REQ_DATE_FROM", dteReq_From.DateTime.ToString("yyyyMMdd"));
            parameter.DataList.Add("REQ_DATE_TO", dteReq_To.DateTime.ToString("yyyyMMdd"));
            parameter.DataList.Add("PROCESS", cboPROCESS.EditValue.ToString());

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.C35aDataSource, false, "MENUMANGE.SCSYS024.SEARCH_01", parameter);
        }

        

        #region 삭제 - btnDelete_Click
        /// <summary>
        /// 삭제
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("삭제 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }

            if (grvMain.RowCount == 0)
            {
                MsgBox.Show("삭제할 정보가 없습니다.", "경고");
                return;
            }

            if ((grdMain.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            {
                MsgBox.Show("삭제할 정보를 선택하세요!", "경고");
                return;
            }

            DataTable dtMain = (grdMain.DataSource as DataTable).Select("CHK='Y'").CopyToDataTable();
            string[] paramnames = new string[] { "CODE" };

            DataTable dtParam = new DataTable();
            for (int i = 0; i < paramnames.Length; i++)
            {
                dtParam.Columns.Add(paramnames[i]);
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in dtParam.Columns)
            {
                string[] col1 = new string[dtMain.Rows.Count];
                for (int i = 0; i < dtMain.Rows.Count; i++)
                {
                    col1[i] = dtMain.Rows[i][col.ColumnName].ToString();
                }

                parameter.DataList.Add(col.ColumnName, col1);
            }

            parameter.ArrayItemCount = dtMain.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.C35aDataSource, true, "MENUMANGE.SCSYS024.DELETE_01", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("삭제 되었습니다.", "확인");
                btnSearch.PerformClick();
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        #endregion 삭제 - btnDelete_Click

        #region 그리드 더블 클릭 - grvMain_DoubleClick
        /// <summary>
        /// 그리드 더블 클릭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void grvMain_DoubleClick(object sender, EventArgs e)
        {
            DataRow row = ((GridView)sender).GetFocusedDataRow();
            if (row == null)
                return;

            SCSYS024P1 popup = new SCSYS024P1();
            popup.hdnRow = row;
            popup.sUSERID = UserInfo == null ? "ADMIN" : UserInfo.UserID; // eve
            popup.sUSER_DEPT = UserInfo.DEPT_CD;

            if (popup.ShowDialog() == DialogResult.OK)
            {
                btnSearch.PerformClick();
            }
        }
        #endregion 그리드 더블 클릭 - grvMain_DoubleClick

        #region HHI 조직도 - btnDeptPopUp_Click
        /// <summary>
        /// HHI 조직도
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDeptPopUp_Click(object sender, EventArgs e)
        {
            SCSYS002P2 scsys002p2 = new SCSYS002P2();

            if (scsys002p2.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtDeptName.EditValue = scsys002p2.hdnDEPT_NM;
            }
        }
        #endregion HHI 조직도 - btnDeptPopUp_Click

     

        
    }
}
