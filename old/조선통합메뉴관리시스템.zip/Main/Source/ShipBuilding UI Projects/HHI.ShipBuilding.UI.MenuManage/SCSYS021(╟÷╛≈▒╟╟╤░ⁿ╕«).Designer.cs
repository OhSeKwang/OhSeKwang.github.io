﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS021
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SCSYS021));
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.btnViewUserAuth = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnExcel = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.chkGUBUN = new HHI.ShipBuilding.Client.Controls.DXperience.XtraCheckEditExt();
            this.btnAuthDelete = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.dteTo = new HHI.ShipBuilding.Client.Controls.DXperience.XtraDateEditExt();
            this.dteFrom = new HHI.ShipBuilding.Client.Controls.DXperience.XtraDateEditExt();
            this.btnReject = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnRequest = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.grdAuthRequest = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvAuthRequest = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn26 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn31 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboSYSTEM_CODE1 = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.gridColumn27 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn28 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn29 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoExEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboREQUEST_GUBUN = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboREQUEST_STATUS = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboASSIGN_GROUP_ID = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.gridColumn33 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpstxtUPP10 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.grdAuthUser = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvAuthUser = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCHK = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn20 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn21 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn22 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn24 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn23 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn25 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemImageComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.grdMaster = new HHI.ShipBuilding.Client.Controls.DXperience.XtraGridControlExt();
            this.grvMaster = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colWORK_GUBUN = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboWORK_GUBUN = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.colSYSTEM_CODE = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpsCboSYSTEM_CODE = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.colGROUP_ID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.btnComplete = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnSearch = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.splitterItem3 = new DevExpress.XtraLayout.SplitterItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem18 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem19 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.stdSecurityManager1 = new HHI.ShipBuilding.Windows.Forms.StdSecurityManager(this.components);
            this.stdButtonExecuteManager1 = new HHI.ShipBuilding.Controls.StdButtonExecuteManager(this.components);
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkGUBUN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteTo.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteTo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteFrom.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteFrom.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdAuthRequest)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvAuthRequest)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboSYSTEM_CODE1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboREQUEST_GUBUN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboREQUEST_STATUS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboASSIGN_GROUP_ID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpstxtUPP10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdAuthUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvAuthUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemImageComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMaster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMaster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboWORK_GUBUN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboSYSTEM_CODE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.btnViewUserAuth);
            this.xtraLayoutControlExt1.Controls.Add(this.btnExcel);
            this.xtraLayoutControlExt1.Controls.Add(this.chkGUBUN);
            this.xtraLayoutControlExt1.Controls.Add(this.btnAuthDelete);
            this.xtraLayoutControlExt1.Controls.Add(this.dteTo);
            this.xtraLayoutControlExt1.Controls.Add(this.dteFrom);
            this.xtraLayoutControlExt1.Controls.Add(this.btnReject);
            this.xtraLayoutControlExt1.Controls.Add(this.btnRequest);
            this.xtraLayoutControlExt1.Controls.Add(this.grdAuthRequest);
            this.xtraLayoutControlExt1.Controls.Add(this.grdAuthUser);
            this.xtraLayoutControlExt1.Controls.Add(this.grdMaster);
            this.xtraLayoutControlExt1.Controls.Add(this.btnComplete);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSearch);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(742, 414, 323, 442);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(1116, 747);
            this.xtraLayoutControlExt1.TabIndex = 0;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // btnViewUserAuth
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnViewUserAuth, new string[] {
            "UPDATE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnViewUserAuth, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnViewUserAuth, false);
            this.btnViewUserAuth.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_인쇄미리보기;
            this.btnViewUserAuth.IsExecuteWdworkerLog = true;
            this.btnViewUserAuth.Location = new System.Drawing.Point(888, 432);
            this.btnViewUserAuth.Name = "btnViewUserAuth";
            this.btnViewUserAuth.Size = new System.Drawing.Size(122, 22);
            this.btnViewUserAuth.StyleController = this.xtraLayoutControlExt1;
            this.btnViewUserAuth.TabIndex = 22;
            this.btnViewUserAuth.Tag = "";
            this.btnViewUserAuth.Text = "사용자 권한 조회";
            this.btnViewUserAuth.UseSplasher = true;
            this.btnViewUserAuth.Click += new System.EventHandler(this.btnViewUserAuth_Click);
            // 
            // btnExcel
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnExcel, new string[] {
            "UPDATE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnExcel, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnExcel, false);
            this.btnExcel.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Btn_엑셀;
            this.btnExcel.IsExecuteWdworkerLog = true;
            this.btnExcel.Location = new System.Drawing.Point(802, 432);
            this.btnExcel.Name = "btnExcel";
            this.btnExcel.Size = new System.Drawing.Size(82, 22);
            this.btnExcel.StyleController = this.xtraLayoutControlExt1;
            this.btnExcel.TabIndex = 21;
            this.btnExcel.Tag = "";
            this.btnExcel.Text = "엑셀 저장";
            this.btnExcel.UseSplasher = true;
            this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
            // 
            // chkGUBUN
            // 
            this.chkGUBUN.EnterExecuteButton = null;
            this.chkGUBUN.Key = "";
            this.chkGUBUN.Location = new System.Drawing.Point(367, 68);
            this.chkGUBUN.MinLength = 0;
            this.chkGUBUN.Name = "chkGUBUN";
            this.chkGUBUN.Properties.Caption = "미처리";
            this.chkGUBUN.Properties.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.chkGUBUN.Properties.ValueChecked = "Y";
            this.chkGUBUN.Properties.ValueUnchecked = "N";
            this.chkGUBUN.Size = new System.Drawing.Size(67, 19);
            this.chkGUBUN.StyleController = this.xtraLayoutControlExt1;
            this.chkGUBUN.TabIndex = 20;
            this.chkGUBUN.EditValueChanged += new System.EventHandler(this.chkGUBUN_EditValueChanged);
            // 
            // btnAuthDelete
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnAuthDelete, new string[] {
            "UPDATE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnAuthDelete, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnAuthDelete, false);
            this.btnAuthDelete.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_삭제;
            this.btnAuthDelete.IsExecuteWdworkerLog = true;
            this.btnAuthDelete.Location = new System.Drawing.Point(1014, 432);
            this.btnAuthDelete.Name = "btnAuthDelete";
            this.btnAuthDelete.Size = new System.Drawing.Size(78, 22);
            this.btnAuthDelete.StyleController = this.xtraLayoutControlExt1;
            this.btnAuthDelete.TabIndex = 8;
            this.btnAuthDelete.Tag = "";
            this.btnAuthDelete.Text = "권한삭제";
            this.btnAuthDelete.UseSplasher = true;
            this.btnAuthDelete.Click += new System.EventHandler(this.btnAuthDelete_Click);
            // 
            // dteTo
            // 
            this.dteTo.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.dteTo.EditValue = null;
            this.dteTo.EnterExecuteButton = null;
            this.dteTo.FocusColor = System.Drawing.Color.Empty;
            this.dteTo.Key = "";
            this.dteTo.Location = new System.Drawing.Point(240, 68);
            this.dteTo.MinLength = 0;
            this.dteTo.Name = "dteTo";
            this.dteTo.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.dteTo.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.dteTo.Properties.Appearance.Options.UseBackColor = true;
            this.dteTo.Properties.Appearance.Options.UseForeColor = true;
            this.dteTo.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteTo.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteTo.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Vista;
            this.dteTo.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.dteTo.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dteTo.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.True;
            this.dteTo.Size = new System.Drawing.Size(123, 20);
            this.dteTo.StyleController = this.xtraLayoutControlExt1;
            this.dteTo.TabIndex = 19;
            // 
            // dteFrom
            // 
            this.dteFrom.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.dteFrom.EditValue = null;
            this.dteFrom.EnterExecuteButton = null;
            this.dteFrom.FocusColor = System.Drawing.Color.Empty;
            this.dteFrom.Key = "";
            this.dteFrom.Location = new System.Drawing.Point(88, 68);
            this.dteFrom.MinLength = 0;
            this.dteFrom.Name = "dteFrom";
            this.dteFrom.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.dteFrom.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.dteFrom.Properties.Appearance.Options.UseBackColor = true;
            this.dteFrom.Properties.Appearance.Options.UseForeColor = true;
            this.dteFrom.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteFrom.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteFrom.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Vista;
            this.dteFrom.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.dteFrom.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dteFrom.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.True;
            this.dteFrom.Size = new System.Drawing.Size(134, 20);
            this.dteFrom.StyleController = this.xtraLayoutControlExt1;
            this.dteFrom.TabIndex = 18;
            // 
            // btnReject
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnReject, new string[] {
            "UPDATE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnReject, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnReject, false);
            this.btnReject.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_삭제;
            this.btnReject.IsExecuteWdworkerLog = true;
            this.btnReject.Location = new System.Drawing.Point(991, 12);
            this.btnReject.Name = "btnReject";
            this.btnReject.Size = new System.Drawing.Size(54, 22);
            this.btnReject.StyleController = this.xtraLayoutControlExt1;
            this.btnReject.TabIndex = 7;
            this.btnReject.Tag = "R";
            this.btnReject.Text = "반려";
            this.btnReject.UseSplasher = true;
            this.btnReject.Click += new System.EventHandler(this.btnReject_Click);
            // 
            // btnRequest
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnRequest, new string[] {
            "UPDATE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnRequest, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnRequest, false);
            this.btnRequest.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_편집;
            this.btnRequest.IsExecuteWdworkerLog = true;
            this.btnRequest.Location = new System.Drawing.Point(1049, 12);
            this.btnRequest.Name = "btnRequest";
            this.btnRequest.Size = new System.Drawing.Size(55, 22);
            this.btnRequest.StyleController = this.xtraLayoutControlExt1;
            this.btnRequest.TabIndex = 6;
            this.btnRequest.Tag = "";
            this.btnRequest.Text = "신청";
            this.btnRequest.UseSplasher = true;
            this.btnRequest.Click += new System.EventHandler(this.btnRequest_Click);
            // 
            // grdAuthRequest
            // 
            this.grdAuthRequest.CheckBoxFieldName = "CHK";
            this.grdAuthRequest.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdAuthRequest.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdAuthRequest.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdAuthRequest.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdAuthRequest.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdAuthRequest.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdAuthRequest.IsHeaderClickAllCheckedItem = true;
            this.grdAuthRequest.Location = new System.Drawing.Point(24, 140);
            this.grdAuthRequest.MainView = this.grvAuthRequest;
            this.grdAuthRequest.MinLength = 0;
            this.grdAuthRequest.Name = "grdAuthRequest";
            this.grdAuthRequest.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit3,
            this.rpsCboSYSTEM_CODE1,
            this.repositoryItemMemoExEdit1,
            this.rpsCboREQUEST_GUBUN,
            this.rpsCboREQUEST_STATUS,
            this.rpstxtUPP10,
            this.rpsCboASSIGN_GROUP_ID,
            this.repositoryItemDateEdit1});
            this.grdAuthRequest.Size = new System.Drawing.Size(1068, 283);
            this.grdAuthRequest.TabIndex = 16;
            this.grdAuthRequest.UseEmbeddedNavigator = true;
            this.grdAuthRequest.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvAuthRequest});
            // 
            // grvAuthRequest
            // 
            this.grvAuthRequest.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn26,
            this.gridColumn31,
            this.gridColumn4,
            this.gridColumn27,
            this.gridColumn28,
            this.gridColumn1,
            this.gridColumn29,
            this.gridColumn13,
            this.gridColumn14,
            this.gridColumn16,
            this.gridColumn17,
            this.gridColumn19,
            this.gridColumn3,
            this.gridColumn33,
            this.gridColumn18,
            this.gridColumn15});
            this.grvAuthRequest.GridControl = this.grdAuthRequest;
            this.grvAuthRequest.Name = "grvAuthRequest";
            this.grvAuthRequest.OptionsView.ColumnAutoWidth = false;
            this.grvAuthRequest.OptionsView.ShowGroupPanel = false;
            this.grvAuthRequest.ShowingEditor += new System.ComponentModel.CancelEventHandler(this.grvAuthRequest_ShowingEditor);
            this.grvAuthRequest.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.grvAuthRequest_FocusedRowChanged);
            // 
            // gridColumn26
            // 
            this.gridColumn26.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn26.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn26.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn26.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn26.Caption = "선택";
            this.gridColumn26.ColumnEdit = this.repositoryItemCheckEdit3;
            this.gridColumn26.FieldName = "CHK";
            this.gridColumn26.Name = "gridColumn26";
            this.gridColumn26.OptionsColumn.AllowEdit = false;
            this.gridColumn26.OptionsColumn.ReadOnly = true;
            this.gridColumn26.Width = 35;
            // 
            // repositoryItemCheckEdit3
            // 
            this.repositoryItemCheckEdit3.AutoHeight = false;
            this.repositoryItemCheckEdit3.Caption = "Check";
            this.repositoryItemCheckEdit3.Name = "repositoryItemCheckEdit3";
            this.repositoryItemCheckEdit3.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.repositoryItemCheckEdit3.ValueChecked = "Y";
            this.repositoryItemCheckEdit3.ValueUnchecked = "N";
            // 
            // gridColumn31
            // 
            this.gridColumn31.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn31.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn31.Caption = "시스템명";
            this.gridColumn31.ColumnEdit = this.rpsCboSYSTEM_CODE1;
            this.gridColumn31.FieldName = "SYSTEM_CODE";
            this.gridColumn31.Name = "gridColumn31";
            this.gridColumn31.OptionsColumn.AllowEdit = false;
            this.gridColumn31.OptionsColumn.ReadOnly = true;
            this.gridColumn31.Visible = true;
            this.gridColumn31.VisibleIndex = 0;
            this.gridColumn31.Width = 150;
            // 
            // rpsCboSYSTEM_CODE1
            // 
            this.rpsCboSYSTEM_CODE1.AutoHeight = false;
            this.rpsCboSYSTEM_CODE1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboSYSTEM_CODE1.Items.AddRange(new DevExpress.XtraEditors.Controls.ImageComboBoxItem[] {
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("근무", "Y", -1),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("퇴사", "N", -1)});
            this.rpsCboSYSTEM_CODE1.Name = "rpsCboSYSTEM_CODE1";
            // 
            // gridColumn27
            // 
            this.gridColumn27.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn27.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn27.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn27.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn27.Caption = "신청자ID";
            this.gridColumn27.FieldName = "REQUEST_USER_ID";
            this.gridColumn27.Name = "gridColumn27";
            this.gridColumn27.OptionsColumn.AllowEdit = false;
            this.gridColumn27.OptionsColumn.ReadOnly = true;
            this.gridColumn27.Width = 100;
            // 
            // gridColumn28
            // 
            this.gridColumn28.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn28.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn28.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn28.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn28.Caption = "신청자명";
            this.gridColumn28.FieldName = "REQUEST_USER_NAME";
            this.gridColumn28.Name = "gridColumn28";
            this.gridColumn28.OptionsColumn.AllowEdit = false;
            this.gridColumn28.OptionsColumn.ReadOnly = true;
            this.gridColumn28.Visible = true;
            this.gridColumn28.VisibleIndex = 1;
            this.gridColumn28.Width = 86;
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "부서";
            this.gridColumn1.FieldName = "DEPTNAME";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.OptionsColumn.ReadOnly = true;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 3;
            // 
            // gridColumn29
            // 
            this.gridColumn29.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn29.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn29.Caption = "요구사항";
            this.gridColumn29.ColumnEdit = this.repositoryItemMemoExEdit1;
            this.gridColumn29.FieldName = "REQUEST";
            this.gridColumn29.Name = "gridColumn29";
            this.gridColumn29.OptionsColumn.ReadOnly = true;
            this.gridColumn29.Visible = true;
            this.gridColumn29.VisibleIndex = 4;
            // 
            // repositoryItemMemoExEdit1
            // 
            this.repositoryItemMemoExEdit1.AutoHeight = false;
            this.repositoryItemMemoExEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEdit1.Name = "repositoryItemMemoExEdit1";
            this.repositoryItemMemoExEdit1.ShowIcon = false;
            // 
            // gridColumn13
            // 
            this.gridColumn13.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn13.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn13.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn13.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn13.Caption = "요청구분";
            this.gridColumn13.ColumnEdit = this.rpsCboREQUEST_GUBUN;
            this.gridColumn13.FieldName = "REQUEST_GUBUN";
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.OptionsColumn.AllowEdit = false;
            this.gridColumn13.OptionsColumn.ReadOnly = true;
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 5;
            // 
            // rpsCboREQUEST_GUBUN
            // 
            this.rpsCboREQUEST_GUBUN.AutoHeight = false;
            this.rpsCboREQUEST_GUBUN.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboREQUEST_GUBUN.Name = "rpsCboREQUEST_GUBUN";
            // 
            // gridColumn14
            // 
            this.gridColumn14.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.Caption = "진행상태";
            this.gridColumn14.ColumnEdit = this.rpsCboREQUEST_STATUS;
            this.gridColumn14.FieldName = "REQUEST_STATUS";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.OptionsColumn.AllowEdit = false;
            this.gridColumn14.OptionsColumn.ReadOnly = true;
            this.gridColumn14.Visible = true;
            this.gridColumn14.VisibleIndex = 6;
            // 
            // rpsCboREQUEST_STATUS
            // 
            this.rpsCboREQUEST_STATUS.AutoHeight = false;
            this.rpsCboREQUEST_STATUS.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboREQUEST_STATUS.Name = "rpsCboREQUEST_STATUS";
            // 
            // gridColumn16
            // 
            this.gridColumn16.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn16.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn16.Caption = "관리자추가여부";
            this.gridColumn16.FieldName = "AUTH_USER_INS";
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.OptionsColumn.AllowEdit = false;
            this.gridColumn16.OptionsColumn.ReadOnly = true;
            this.gridColumn16.Width = 98;
            // 
            // gridColumn17
            // 
            this.gridColumn17.AppearanceCell.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.gridColumn17.AppearanceCell.Options.UseBackColor = true;
            this.gridColumn17.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn17.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn17.Caption = "할당메뉴그룹";
            this.gridColumn17.ColumnEdit = this.rpsCboASSIGN_GROUP_ID;
            this.gridColumn17.FieldName = "ASSIGN_GROUP_ID";
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 7;
            this.gridColumn17.Width = 100;
            // 
            // rpsCboASSIGN_GROUP_ID
            // 
            this.rpsCboASSIGN_GROUP_ID.AutoHeight = false;
            this.rpsCboASSIGN_GROUP_ID.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboASSIGN_GROUP_ID.Name = "rpsCboASSIGN_GROUP_ID";
            // 
            // gridColumn19
            // 
            this.gridColumn19.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn19.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn19.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn19.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn19.Caption = "처리자";
            this.gridColumn19.FieldName = "ASSIGN_USER_ID";
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.OptionsColumn.AllowEdit = false;
            this.gridColumn19.OptionsColumn.ReadOnly = true;
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 8;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.Caption = "신청일시";
            this.gridColumn3.ColumnEdit = this.repositoryItemDateEdit1;
            this.gridColumn3.FieldName = "REQUEST_DATE1";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.OptionsColumn.ReadOnly = true;
            this.gridColumn3.UnboundType = DevExpress.Data.UnboundColumnType.DateTime;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 9;
            this.gridColumn3.Width = 120;
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.Mask.EditMask = "yyyy-MM-dd HH:mm:ss";
            this.repositoryItemDateEdit1.Mask.UseMaskAsDisplayFormat = true;
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            // 
            // gridColumn33
            // 
            this.gridColumn33.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn33.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn33.Caption = "처리일시";
            this.gridColumn33.ColumnEdit = this.repositoryItemDateEdit1;
            this.gridColumn33.FieldName = "ASSIGN_DATE";
            this.gridColumn33.Name = "gridColumn33";
            this.gridColumn33.OptionsColumn.AllowEdit = false;
            this.gridColumn33.OptionsColumn.ReadOnly = true;
            this.gridColumn33.UnboundType = DevExpress.Data.UnboundColumnType.DateTime;
            this.gridColumn33.Visible = true;
            this.gridColumn33.VisibleIndex = 10;
            this.gridColumn33.Width = 120;
            // 
            // gridColumn18
            // 
            this.gridColumn18.AppearanceCell.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.gridColumn18.AppearanceCell.Options.UseBackColor = true;
            this.gridColumn18.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn18.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn18.Caption = "처리사항";
            this.gridColumn18.ColumnEdit = this.repositoryItemMemoExEdit1;
            this.gridColumn18.FieldName = "ASSIGN";
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 11;
            this.gridColumn18.Width = 150;
            // 
            // gridColumn15
            // 
            this.gridColumn15.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.Caption = "신청일시";
            this.gridColumn15.FieldName = "REQUEST_DATE";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.OptionsColumn.AllowEdit = false;
            this.gridColumn15.OptionsColumn.ReadOnly = true;
            // 
            // rpstxtUPP10
            // 
            this.rpstxtUPP10.AutoHeight = false;
            this.rpstxtUPP10.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.rpstxtUPP10.MaxLength = 10;
            this.rpstxtUPP10.Name = "rpstxtUPP10";
            // 
            // grdAuthUser
            // 
            this.grdAuthUser.CheckBoxFieldName = "CHK";
            this.grdAuthUser.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.grdAuthUser.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.grdAuthUser.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.grdAuthUser.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.grdAuthUser.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.grdAuthUser.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.Default;
            this.grdAuthUser.IsHeaderClickAllCheckedItem = true;
            this.grdAuthUser.Location = new System.Drawing.Point(306, 458);
            this.grdAuthUser.MainView = this.grvAuthUser;
            this.grdAuthUser.MinLength = 0;
            this.grdAuthUser.Name = "grdAuthUser";
            this.grdAuthUser.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpsCHK,
            this.repositoryItemImageComboBox1});
            this.grdAuthUser.Size = new System.Drawing.Size(786, 265);
            this.grdAuthUser.TabIndex = 15;
            this.grdAuthUser.UseEmbeddedNavigator = true;
            this.grdAuthUser.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvAuthUser});
            // 
            // grvAuthUser
            // 
            this.grvAuthUser.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn12,
            this.gridColumn20,
            this.gridColumn21,
            this.gridColumn22,
            this.gridColumn24,
            this.gridColumn23,
            this.gridColumn25});
            this.grvAuthUser.GridControl = this.grdAuthUser;
            this.grvAuthUser.Name = "grvAuthUser";
            this.grvAuthUser.OptionsView.ColumnAutoWidth = false;
            this.grvAuthUser.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn12
            // 
            this.gridColumn12.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.Caption = "선택";
            this.gridColumn12.ColumnEdit = this.rpsCHK;
            this.gridColumn12.FieldName = "CHK";
            this.gridColumn12.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 0;
            this.gridColumn12.Width = 35;
            // 
            // rpsCHK
            // 
            this.rpsCHK.AutoHeight = false;
            this.rpsCHK.Caption = "Check";
            this.rpsCHK.Name = "rpsCHK";
            this.rpsCHK.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.rpsCHK.ValueChecked = "Y";
            this.rpsCHK.ValueUnchecked = "N";
            // 
            // gridColumn20
            // 
            this.gridColumn20.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn20.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn20.Caption = "사용자ID";
            this.gridColumn20.FieldName = "USER_ID";
            this.gridColumn20.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn20.Name = "gridColumn20";
            this.gridColumn20.OptionsColumn.AllowEdit = false;
            this.gridColumn20.OptionsColumn.ReadOnly = true;
            this.gridColumn20.Visible = true;
            this.gridColumn20.VisibleIndex = 1;
            this.gridColumn20.Width = 90;
            // 
            // gridColumn21
            // 
            this.gridColumn21.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn21.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn21.Caption = "사용자명";
            this.gridColumn21.FieldName = "KOR_NM";
            this.gridColumn21.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn21.Name = "gridColumn21";
            this.gridColumn21.OptionsColumn.AllowEdit = false;
            this.gridColumn21.OptionsColumn.ReadOnly = true;
            this.gridColumn21.Visible = true;
            this.gridColumn21.VisibleIndex = 2;
            this.gridColumn21.Width = 100;
            // 
            // gridColumn22
            // 
            this.gridColumn22.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn22.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn22.Caption = "사용자명(영)";
            this.gridColumn22.FieldName = "ENG_NM";
            this.gridColumn22.Name = "gridColumn22";
            this.gridColumn22.OptionsColumn.AllowEdit = false;
            this.gridColumn22.OptionsColumn.ReadOnly = true;
            this.gridColumn22.Width = 120;
            // 
            // gridColumn24
            // 
            this.gridColumn24.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn24.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn24.Caption = "부서명";
            this.gridColumn24.FieldName = "DEPTNAME";
            this.gridColumn24.Name = "gridColumn24";
            this.gridColumn24.OptionsColumn.AllowEdit = false;
            this.gridColumn24.OptionsColumn.ReadOnly = true;
            this.gridColumn24.Visible = true;
            this.gridColumn24.VisibleIndex = 3;
            this.gridColumn24.Width = 150;
            // 
            // gridColumn23
            // 
            this.gridColumn23.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn23.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn23.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn23.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn23.Caption = "직급";
            this.gridColumn23.FieldName = "JOB_TIT_NM";
            this.gridColumn23.Name = "gridColumn23";
            this.gridColumn23.OptionsColumn.AllowEdit = false;
            this.gridColumn23.OptionsColumn.ReadOnly = true;
            this.gridColumn23.Visible = true;
            this.gridColumn23.VisibleIndex = 4;
            // 
            // gridColumn25
            // 
            this.gridColumn25.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn25.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn25.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn25.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn25.Caption = "근무여부";
            this.gridColumn25.ColumnEdit = this.repositoryItemImageComboBox1;
            this.gridColumn25.FieldName = "USE_YN";
            this.gridColumn25.Name = "gridColumn25";
            this.gridColumn25.OptionsColumn.AllowEdit = false;
            this.gridColumn25.OptionsColumn.ReadOnly = true;
            this.gridColumn25.Visible = true;
            this.gridColumn25.VisibleIndex = 5;
            // 
            // repositoryItemImageComboBox1
            // 
            this.repositoryItemImageComboBox1.AutoHeight = false;
            this.repositoryItemImageComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemImageComboBox1.Items.AddRange(new DevExpress.XtraEditors.Controls.ImageComboBoxItem[] {
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("근무", "Y", -1),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("퇴사", "N", -1)});
            this.repositoryItemImageComboBox1.Name = "repositoryItemImageComboBox1";
            // 
            // grdMaster
            // 
            this.grdMaster.CheckBoxFieldName = "CHK";
            this.grdMaster.GridViewStyle = HHI.ShipBuilding.Controls.XtraGridViewType.None;
            this.grdMaster.IsHeaderClickAllCheckedItem = false;
            this.grdMaster.Location = new System.Drawing.Point(24, 458);
            this.grdMaster.MainView = this.grvMaster;
            this.grdMaster.MinLength = 0;
            this.grdMaster.Name = "grdMaster";
            this.grdMaster.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit1,
            this.rpsCboWORK_GUBUN,
            this.rpsCboSYSTEM_CODE});
            this.grdMaster.Size = new System.Drawing.Size(278, 265);
            this.grdMaster.TabIndex = 10;
            this.grdMaster.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvMaster});
            // 
            // grvMaster
            // 
            this.grvMaster.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colWORK_GUBUN,
            this.colSYSTEM_CODE,
            this.colGROUP_ID,
            this.gridColumn2});
            this.grvMaster.GridControl = this.grdMaster;
            this.grvMaster.GroupCount = 2;
            this.grvMaster.Name = "grvMaster";
            this.grvMaster.OptionsBehavior.Editable = false;
            this.grvMaster.OptionsView.ColumnAutoWidth = false;
            this.grvMaster.OptionsView.ShowGroupPanel = false;
            this.grvMaster.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colWORK_GUBUN, DevExpress.Data.ColumnSortOrder.Ascending),
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colSYSTEM_CODE, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.grvMaster.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.grvMaster_FocusedRowChanged);
            // 
            // colWORK_GUBUN
            // 
            this.colWORK_GUBUN.Caption = "업무구분";
            this.colWORK_GUBUN.ColumnEdit = this.rpsCboWORK_GUBUN;
            this.colWORK_GUBUN.FieldName = "WORK_GUBUN";
            this.colWORK_GUBUN.Name = "colWORK_GUBUN";
            this.colWORK_GUBUN.Visible = true;
            this.colWORK_GUBUN.VisibleIndex = 2;
            // 
            // rpsCboWORK_GUBUN
            // 
            this.rpsCboWORK_GUBUN.AutoHeight = false;
            this.rpsCboWORK_GUBUN.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboWORK_GUBUN.Name = "rpsCboWORK_GUBUN";
            // 
            // colSYSTEM_CODE
            // 
            this.colSYSTEM_CODE.AppearanceHeader.Options.UseTextOptions = true;
            this.colSYSTEM_CODE.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSYSTEM_CODE.Caption = "시스템코드";
            this.colSYSTEM_CODE.ColumnEdit = this.rpsCboSYSTEM_CODE;
            this.colSYSTEM_CODE.FieldName = "SYSTEM_CODE";
            this.colSYSTEM_CODE.Name = "colSYSTEM_CODE";
            this.colSYSTEM_CODE.Visible = true;
            this.colSYSTEM_CODE.VisibleIndex = 0;
            this.colSYSTEM_CODE.Width = 85;
            // 
            // rpsCboSYSTEM_CODE
            // 
            this.rpsCboSYSTEM_CODE.AutoHeight = false;
            this.rpsCboSYSTEM_CODE.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpsCboSYSTEM_CODE.Name = "rpsCboSYSTEM_CODE";
            // 
            // colGROUP_ID
            // 
            this.colGROUP_ID.AppearanceHeader.Options.UseTextOptions = true;
            this.colGROUP_ID.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colGROUP_ID.Caption = "그룹ID";
            this.colGROUP_ID.FieldName = "GROUP_ID";
            this.colGROUP_ID.Name = "colGROUP_ID";
            this.colGROUP_ID.Visible = true;
            this.colGROUP_ID.VisibleIndex = 0;
            this.colGROUP_ID.Width = 93;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "그룹명";
            this.gridColumn2.FieldName = "GROUP_NAME";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            this.gridColumn2.Width = 143;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Caption = "Check";
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.repositoryItemCheckEdit1.ValueChecked = "Y";
            this.repositoryItemCheckEdit1.ValueUnchecked = "N";
            // 
            // btnComplete
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnComplete, new string[] {
            "UPDATE"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnComplete, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnComplete, false);
            this.btnComplete.Image = ((System.Drawing.Image)(resources.GetObject("btnComplete.Image")));
            this.btnComplete.IsExecuteWdworkerLog = true;
            this.btnComplete.Location = new System.Drawing.Point(933, 12);
            this.btnComplete.Name = "btnComplete";
            this.btnComplete.Size = new System.Drawing.Size(54, 22);
            this.btnComplete.StyleController = this.xtraLayoutControlExt1;
            this.btnComplete.TabIndex = 5;
            this.btnComplete.Tag = "C";
            this.btnComplete.Text = "처리";
            this.btnComplete.UseSplasher = true;
            this.btnComplete.Click += new System.EventHandler(this.btnComplete_Click);
            // 
            // btnSearch
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSearch, new string[] {
            "SELECT"});
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.btnSearch, false);
            this.stdButtonExecuteManager1.SetExecuteButton(this.btnSearch, true);
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.IsExecuteWdworkerLog = true;
            this.btnSearch.Location = new System.Drawing.Point(875, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(54, 22);
            this.btnSearch.StyleController = this.xtraLayoutControlExt1;
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "조회";
            this.btnSearch.UseSplasher = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "layoutControlGroup1";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup1, false);
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem1,
            this.layoutControlItem1,
            this.layoutControlGroup2,
            this.layoutControlGroup3,
            this.layoutControlItem2,
            this.layoutControlItem13,
            this.layoutControlItem14});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1116, 747);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(863, 26);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.btnSearch;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(863, 0);
            this.layoutControlItem1.MaxSize = new System.Drawing.Size(58, 26);
            this.layoutControlItem1.MinSize = new System.Drawing.Size(58, 26);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.layoutControlGroup2.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup2.CaptionImage = ((System.Drawing.Image)(resources.GetObject("layoutControlGroup2.CaptionImage")));
            this.layoutControlGroup2.CustomizationFormText = "List";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup2, false);
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem12,
            this.splitterItem3,
            this.layoutControlItem11,
            this.layoutControlItem9,
            this.layoutControlItem3,
            this.emptySpaceItem3,
            this.layoutControlItem5,
            this.layoutControlItem6});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 92);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(1096, 635);
            this.layoutControlGroup2.Text = "시스템정보";
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.grdAuthRequest;
            this.layoutControlItem12.CustomizationFormText = "layoutControlItem12";
            this.layoutControlItem12.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(1072, 287);
            this.layoutControlItem12.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem12.TextVisible = false;
            // 
            // splitterItem3
            // 
            this.splitterItem3.AllowHotTrack = true;
            this.splitterItem3.CustomizationFormText = "splitterItem3";
            this.splitterItem3.Location = new System.Drawing.Point(0, 287);
            this.splitterItem3.Name = "splitterItem3";
            this.splitterItem3.Size = new System.Drawing.Size(1072, 5);
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.grdAuthUser;
            this.layoutControlItem11.CustomizationFormText = "layoutControlItem11";
            this.layoutControlItem11.Location = new System.Drawing.Point(282, 318);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(790, 269);
            this.layoutControlItem11.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem11.TextVisible = false;
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.grdMaster;
            this.layoutControlItem9.CustomizationFormText = "layoutControlItem9";
            this.layoutControlItem9.Location = new System.Drawing.Point(0, 318);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(282, 269);
            this.layoutControlItem9.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem9.TextVisible = false;
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.btnAuthDelete;
            this.layoutControlItem3.CustomizationFormText = "layoutControlItem3";
            this.layoutControlItem3.Location = new System.Drawing.Point(990, 292);
            this.layoutControlItem3.MaxSize = new System.Drawing.Size(82, 26);
            this.layoutControlItem3.MinSize = new System.Drawing.Size(82, 26);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(82, 26);
            this.layoutControlItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem3.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem3.TextVisible = false;
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.CustomizationFormText = "emptySpaceItem3";
            this.emptySpaceItem3.Location = new System.Drawing.Point(0, 292);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(778, 26);
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.btnExcel;
            this.layoutControlItem5.Location = new System.Drawing.Point(778, 292);
            this.layoutControlItem5.MaxSize = new System.Drawing.Size(86, 26);
            this.layoutControlItem5.MinSize = new System.Drawing.Size(86, 26);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(86, 26);
            this.layoutControlItem5.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem5.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem5.TextVisible = false;
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.btnViewUserAuth;
            this.layoutControlItem6.Location = new System.Drawing.Point(864, 292);
            this.layoutControlItem6.MaxSize = new System.Drawing.Size(126, 26);
            this.layoutControlItem6.MinSize = new System.Drawing.Size(126, 26);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(126, 26);
            this.layoutControlItem6.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextVisible = false;
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 1F);
            this.layoutControlGroup3.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup3.CustomizationFormText = " ";
            this.stdButtonExecuteManager1.SetEnterEventConainer(this.layoutControlGroup3, true);
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem2,
            this.layoutControlItem18,
            this.layoutControlItem19,
            this.layoutControlItem4});
            this.layoutControlGroup3.Location = new System.Drawing.Point(0, 26);
            this.layoutControlGroup3.Name = "layoutControlGroup3";
            this.layoutControlGroup3.Size = new System.Drawing.Size(1096, 66);
            this.layoutControlGroup3.Text = " ";
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(414, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(658, 24);
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem18
            // 
            this.layoutControlItem18.Control = this.dteFrom;
            this.layoutControlItem18.CustomizationFormText = "신청기간";
            this.layoutControlItem18.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_blue;
            this.layoutControlItem18.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem18.Name = "layoutControlItem18";
            this.layoutControlItem18.Size = new System.Drawing.Size(202, 24);
            this.layoutControlItem18.Text = "신청기간";
            this.layoutControlItem18.TextSize = new System.Drawing.Size(61, 16);
            // 
            // layoutControlItem19
            // 
            this.layoutControlItem19.Control = this.dteTo;
            this.layoutControlItem19.CustomizationFormText = "~";
            this.layoutControlItem19.Location = new System.Drawing.Point(202, 0);
            this.layoutControlItem19.Name = "layoutControlItem19";
            this.layoutControlItem19.Size = new System.Drawing.Size(141, 24);
            this.layoutControlItem19.Text = "~";
            this.layoutControlItem19.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem19.TextSize = new System.Drawing.Size(9, 14);
            this.layoutControlItem19.TextToControlDistance = 5;
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.chkGUBUN;
            this.layoutControlItem4.CustomizationFormText = "layoutControlItem4";
            this.layoutControlItem4.Location = new System.Drawing.Point(343, 0);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(71, 24);
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.btnComplete;
            this.layoutControlItem2.CustomizationFormText = "layoutControlItem2";
            this.layoutControlItem2.Location = new System.Drawing.Point(921, 0);
            this.layoutControlItem2.MaxSize = new System.Drawing.Size(58, 26);
            this.layoutControlItem2.MinSize = new System.Drawing.Size(58, 26);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextVisible = false;
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.btnRequest;
            this.layoutControlItem13.CustomizationFormText = "layoutControlItem13";
            this.layoutControlItem13.Location = new System.Drawing.Point(1037, 0);
            this.layoutControlItem13.MaxSize = new System.Drawing.Size(59, 26);
            this.layoutControlItem13.MinSize = new System.Drawing.Size(59, 26);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(59, 26);
            this.layoutControlItem13.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem13.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem13.TextVisible = false;
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.btnReject;
            this.layoutControlItem14.CustomizationFormText = "layoutControlItem14";
            this.layoutControlItem14.Location = new System.Drawing.Point(979, 0);
            this.layoutControlItem14.MaxSize = new System.Drawing.Size(58, 26);
            this.layoutControlItem14.MinSize = new System.Drawing.Size(58, 26);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Size = new System.Drawing.Size(58, 26);
            this.layoutControlItem14.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem14.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem14.TextVisible = false;
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.Caption = "요청자";
            this.gridColumn4.FieldName = "INSERT_USER_NAME";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 2;
            this.gridColumn4.Width = 86;
            // 
            // SCSYS021
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS021";
            this.Size = new System.Drawing.Size(1116, 747);
            this.Shown += new System.EventHandler(this.SCSYS021_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chkGUBUN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteTo.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteTo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteFrom.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteFrom.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdAuthRequest)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvAuthRequest)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboSYSTEM_CODE1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboREQUEST_GUBUN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboREQUEST_STATUS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboASSIGN_GROUP_ID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpstxtUPP10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdAuthUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvAuthUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCHK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemImageComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdMaster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvMaster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboWORK_GUBUN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpsCboSYSTEM_CODE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private Client.Controls.DXperience.XtraButtonExt btnComplete;
        private Client.Controls.DXperience.XtraButtonExt btnSearch;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private Client.Controls.DXperience.XtraGridControlExt grdMaster;
        private DevExpress.XtraGrid.Views.Grid.GridView grvMaster;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private Windows.Forms.StdSecurityManager stdSecurityManager1;
        private DevExpress.XtraGrid.Columns.GridColumn colWORK_GUBUN;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboWORK_GUBUN;
        private DevExpress.XtraGrid.Columns.GridColumn colSYSTEM_CODE;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboSYSTEM_CODE;
        private Controls.StdButtonExecuteManager stdButtonExecuteManager1;
        private DevExpress.XtraGrid.Columns.GridColumn colGROUP_ID;
        private Client.Controls.DXperience.XtraGridControlExt grdAuthUser;
        private DevExpress.XtraGrid.Views.Grid.GridView grvAuthUser;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit rpsCHK;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn20;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn21;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn22;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn23;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn24;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn25;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox repositoryItemImageComboBox1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private Client.Controls.DXperience.XtraGridControlExt grdAuthRequest;
        private DevExpress.XtraGrid.Views.Grid.GridView grvAuthRequest;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn26;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn27;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn28;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn31;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboSYSTEM_CODE1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraLayout.SplitterItem splitterItem3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn33;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboREQUEST_GUBUN;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboREQUEST_STATUS;
        private Client.Controls.DXperience.XtraButtonExt btnRequest;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn29;
        private Client.Controls.DXperience.XtraButtonExt btnReject;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private Client.Controls.DXperience.XtraDateEditExt dteTo;
        private Client.Controls.DXperience.XtraDateEditExt dteFrom;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem18;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem19;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private Client.Controls.DXperience.XtraButtonExt btnAuthDelete;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private Client.Controls.DXperience.XtraCheckEditExt chkGUBUN;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit rpstxtUPP10;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox rpsCboASSIGN_GROUP_ID;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        private Client.Controls.DXperience.XtraButtonExt btnViewUserAuth;
        private Client.Controls.DXperience.XtraButtonExt btnExcel;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
    }
}
