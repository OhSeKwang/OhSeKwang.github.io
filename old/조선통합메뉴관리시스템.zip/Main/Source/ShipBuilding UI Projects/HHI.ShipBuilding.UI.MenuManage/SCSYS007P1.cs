﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HHI.ShipBuilding.Windows.Forms;
using HHI.ShipBuilding.Controls;
using HHI.ShipBuilding.Data.Model.WcfParameter;
using HHI.ShipBuilding.WcfService.SystemChannel;
using HHI.ShipBuilding.Security;
using System.Collections;
using System.IO;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraEditors.Repository;
using HHI.Windows.Forms;

namespace HHI.ShipBuilding.UI.MenuManage
{
    public partial class SCSYS007P1 : DevExpress.XtraEditors.XtraForm
    {
        #region 생성자 및 변수 선언
        /// <summary>
        /// 사용자 정보 DataRow
        /// </summary>
        public DataRow hdnRow { get; set; }

        public string sPROGRAM_ID { get; set; }

        public string sPROGRAM_NAME { get; set; }

        public string sFTP_SERVER_PATH { get; set; }
        public string sFTP_IP { get; set; }
        public string sFTP_USER_ID { get; set; }

        public string sFTP_PASSWORD { get; set; }


        public string sLOGIN_USERID { get; set; }

        //HHI.ShipBuilding.Controls.Utils.FtpHelper ftpHelper = new Controls.Utils.FtpHelper(@"ftp://10.100.17.36/", "hyspics", "hyspics");
        //HHI.ShipBuilding.Controls.Utils.FtpHelper ftpHelper = new Controls.Utils.FtpHelper();

        HHI.ShipBuilding.Controls.Utils.FtpHelper ftpHelper = null;

        public SCSYS007P1()
        {
            InitializeComponent();
        }
        #endregion

        #region 화면 Load
        /// <summary>
        /// 화면 Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SCSYS002P1_Load(object sender, EventArgs e)
        {
            if (!ClientControlHelper.DesignMode)
            {
                //initPage();

                

                //ClientControlHelper.LookUpBind(rpsLooKUpFILE_PATH, ClientControlHelper.GetCodeInfo("A004"), "CDNM", "CDNM", true, string.Empty);

                Search();
            }
        }
        #endregion 

        #region 화면 초기화
        /// <summary>
        /// 화면 초기화
        /// </summary>
        private void initPage()
        {
            // 그룹 사용자 그리드 초기화
            DataTable dt = new DataTable();
            dt.Columns.Add("CHK");
            dt.Columns.Add("GROUP_ID");
            dt.Columns.Add("GROUP_NAME");
            dt.Columns.Add("USER_ID");
            dt.Columns.Add("KOR_NM");
            dt.Columns.Add("JOB_TIT_NM");
            dt.Columns.Add("DEPTNAME");

            //grdGroupUser.DataSource = dt;
        }
        #endregion 

        #region 버튼 이벤트

        /// <summary>
        /// 찾아보기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFileAppend_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Multiselect = true;


            AttachUpladFileType ExtentionFilterList = AttachUpladFileType.AllFile;
            // 필터막음
            openFileDialog.Filter = GetDirectorySearchFilterString(ExtentionFilterList).Replace(",", "; ");

            openFileDialog.ShowDialog(this);

            try
            {
                string[] dragFiles = openFileDialog.FileNames;
                if (dragFiles.Length > 0)
                {
                    foreach (string dragFile in dragFiles)
                    {
                        if (File.Exists(dragFile))
                        {
                            FileInfo fileInfo = new FileInfo(dragFile);

                            grvMaster.AddNewRow();
                            DataRow dr = grvMaster.GetFocusedDataRow();

                            dr["CHK"] = "Y";
                            dr["PROGRAM_ID"] = sPROGRAM_ID;
                            dr["PROGRAM_NAME"] = sPROGRAM_NAME;
                            dr["LOCAL_FILE_PATH"] = fileInfo.FullName;
                            dr["FILE_NAME"] = fileInfo.Name;
                            dr["FILE_PATH"] = string.Empty;

                            dr["ID"] = "000";

                            grvMaster.UpdateCurrentRow();

                        }
                        //else
                        //{
                        //    if (Directory.Exists(dragFile))
                        //    {
                        //        IEnumerator<string> dirFileList = Directory.EnumerateFiles(dragFile, "*.*", SearchOption.AllDirectories).GetEnumerator();
                        //        while (dirFileList.MoveNext())
                        //        {
                        //            AddListBoxItemByFileInfo(dirFileList.Current);
                        //        }
                        //    }
                        //}
                    }

                    //lstFileList.CalcBestSize();
                }
            }
            catch (Exception ex)
            {
                MsgBox.Show(ex.Message);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("저장 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            if (grvMaster.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요....", "경고"); return; }

            if ((grdMaster.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            { MsgBox.Show("저장할 데이터를 선택하세요....", "경고"); return; }


            DataRow[] rowsFtpFile = (grdMaster.DataSource as DataTable).Select("CHK = 'Y'");
            DataTable dtMaster = rowsFtpFile.CopyToDataTable();

            string[] paramnames = new string[] { "PROGRAM_ID", "ID", "PROGRAM_NAME", "FILE_NAME", "FILE_PATH"};

            DataTable controlParamInfo = new DataTable("controlParamInfo");
            for (int cnt = 0; cnt < paramnames.Length; cnt++)
            {
                controlParamInfo.Columns.Add(paramnames[cnt], (grvMaster.GridControl.DataSource as DataTable).Columns[paramnames[cnt]].DataType);                
            }

            DataPack parameter = new DataPack();

            foreach (DataColumn col in controlParamInfo.Columns)
            {
                if (!dtMaster.Columns.Contains(col.ColumnName))
                    throw new Exception(string.Format("필드명{0}을 찾을 수 없습니다."));

                if (col.DataType.Equals(typeof(int)))
                {
                    int[] col1 = new int[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = 0;
                        }
                        else
                        {
                            col1[i] = int.Parse(string.IsNullOrWhiteSpace(dtMaster.Rows[i][col.ColumnName].ToString()) ? "0" : dtMaster.Rows[i][col.ColumnName].ToString());
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }
                else
                {
                    string[] col1 = new string[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = string.Empty;
                        }
                        else
                        {
                            col1[i] = dtMaster.Rows[i][col.ColumnName].ToString();
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }

            }

            string[] col2 = new string[dtMaster.Rows.Count];            

            for (int i = 0; i < dtMaster.Rows.Count; i++)
            {
                col2[i] = sLOGIN_USERID;                
            }

            parameter.DataList.Add("LOGIN_USERID", col2);            

            parameter.ArrayItemCount = dtMaster.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            if (ValidationRequired(true, false))
            {                
                // FTP 접속
                ftpHelper = new Controls.Utils.FtpHelper(string.Format(@"ftp://{0}/", sFTP_IP), sFTP_USER_ID, sFTP_PASSWORD);

                // Ftp 연결 확인
                //if (!ftpHelper.isValidFtpConnection(sFTP_SERVER_PATH))
                //{
                //    MsgBox.Show("FTP 연결에 실패 했습니다.");
                //    return;
                //}

                // Ftp 파일 업로드
                if (ftpHelper != null)
                {
                    FtpFileUpLoad(rowsFtpFile);
                }

                DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS007P1.SAVE_01", parameter);

                if (resultSet.IsSuccess)
                {
                    MsgBox.Show("저장되었습니다.", "확인");

                    //재조회
                    Search();
                }
                else
                {
                    MsgBox.Show(resultSet.ExceptionMessage);
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MsgBox.Show("삭제 하시겠습니까?", "확인", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }

            if (grvMaster.RowCount == 0)
            { MsgBox.Show("데이터를 조회하세요....", "경고"); return; }

            if ((grdMaster.DataSource as DataTable).Select("CHK='Y'").Length == 0)
            { MsgBox.Show("삭제할 데이터를 선택하세요....", "경고"); return; }

            if ((grdMaster.DataSource as DataTable).Select("ID='000'").Length > 0)
            { MsgBox.Show("저장후 삭제하세요", "경고"); return; }


            DataRow[] rowsFtpFile = (grdMaster.DataSource as DataTable).Select("CHK='Y'");
            DataTable dtMaster = rowsFtpFile.CopyToDataTable();

            string[] paramnames = new string[] { "PROGRAM_ID", "ID" };

            DataTable controlParamInfo = new DataTable("controlParamInfo");
            for (int cnt = 0; cnt < paramnames.Length; cnt++)
            {
                controlParamInfo.Columns.Add(paramnames[cnt], (grvMaster.GridControl.DataSource as DataTable).Columns[paramnames[cnt]].DataType);
            }



            DataPack parameter = new DataPack();

            foreach (DataColumn col in controlParamInfo.Columns)
            {


                if (!dtMaster.Columns.Contains(col.ColumnName))
                    throw new Exception(string.Format("필드명{0}을 찾을 수 없습니다."));

                if (col.DataType.Equals(typeof(int)))
                {
                    int[] col1 = new int[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = 0;
                        }
                        else
                        {
                            col1[i] = int.Parse(string.IsNullOrWhiteSpace(dtMaster.Rows[i][col.ColumnName].ToString()) ? "0" : dtMaster.Rows[i][col.ColumnName].ToString());
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }
                else
                {
                    string[] col1 = new string[dtMaster.Rows.Count];

                    for (int i = 0; i < dtMaster.Rows.Count; i++)
                    {
                        if (dtMaster.Rows[i][col.ColumnName] == System.DBNull.Value)
                        {
                            col1[i] = string.Empty;
                        }
                        else
                        {
                            col1[i] = dtMaster.Rows[i][col.ColumnName].ToString();
                        }
                    }

                    parameter.DataList.Add(col.ColumnName, col1);
                }

            }

            parameter.ArrayItemCount = dtMaster.Rows.Count; //==> ArrayBind 처리시... 항상 지정해야함...

            DataResultSet resultSet = ShipBuildingSystemChannel.Process(DbDataSourcePrefix.DefaultDataSource, true, "MENUMANGE.SCSYS007P1.DELETE_01", parameter);

            if (resultSet.IsSuccess)
            {
                MsgBox.Show("삭제되었습니다.", "확인");

                //재조회
                Search();
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }
        
        #region 닫기 - btnClose_Click
        /// <summary>
        /// 닫기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }
        #endregion 닫기 - btnClose_Click

        #endregion

        #region 그리드 이벤트
        private void grvMaster_ShowingEditor(object sender, CancelEventArgs e)
        {
            DataRow row = grvMaster.GetFocusedDataRow();
            if (row != null)
            {
                string strFieldName = grvMaster.FocusedColumn.FieldName;
                if (strFieldName.Equals("FILE_NAME"))
                {
                    if (row["DIV"].ToString().Equals("S"))
                        e.Cancel = true;
                    else
                        e.Cancel = false;
                }
            }
        }
        #endregion

        #region 컨트롤 이벤트
        #endregion

        #region 메서드
        private void Search()
        {
            DataResultSet resultSet = GetProgramInfo();

            if (resultSet.IsSuccess)
            {
                grdMaster.DataSource = resultSet.QuerySet.Tables[0];
            }
            else
            {
                MsgBox.Show(resultSet.ExceptionMessage);
            }
        }

        #region 그룹정보 조회 - GetGroupInfo
        /// <summary>
        /// 그룹정보 조회
        /// </summary>
        /// <param name="strGroup_Nm"></param>
        /// <param name="strDescr"></param>
        /// <returns></returns>
        private DataResultSet GetProgramInfo()
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("PROGRAM_ID", sPROGRAM_ID);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCSYS007P1.SEARCH_01", parameter);
        }
        #endregion 그룹정보 조회 - GetGroupInfo

        #region 그리드 관련 메서드
        public bool ValidationRequired(bool IsMessagePrint, bool IsFocusedRowValidationCheck)
        {
            DataTable dt = (grdMaster.DataSource as DataTable);
            if (dt.Rows.Count == 0)
                return false;

            //ArrayList requiredColumns = GetRequiredColumns();
            ArrayList requiredColumns = new ArrayList();
            requiredColumns.Add("PROGRAM_ID");
            requiredColumns.Add("FILE_NAME");
            requiredColumns.Add("FILE_PATH");


            //전체 DataRow에 대하여 Validation체크를 한다
            if (!IsFocusedRowValidationCheck)
            {
                //int RowCount = (grvMaster != null ? grvMaster.DataRowCount : InnerLayoutView.DataRowCount);
                int RowCount = grvMaster.DataRowCount;

                for (int i = 0; i < RowCount; i++)
                {
                    bool validationResult = RequiredValidationByRowHandle(IsMessagePrint, requiredColumns, i);

                    if (!validationResult)
                        return validationResult;
                }

                return true;
            }
            //else
            //{
            //    //int focusedRowHandle = (InnerGridView != null ? InnerGridView.FocusedRowHandle : InnerLayoutView.FocusedRowHandle);

            //    return RequiredValidationByRowHandle(IsMessagePrint, requiredColumns, focusedRowHandle);
            //}
            return false;
        }

        private bool RequiredValidationByRowHandle(bool IsMessagePrint, ArrayList requiredColumns, int rowIndex)
        {
            //DataRow row = (InnerGridView != null ? InnerGridView.GetDataRow(rowIndex) : InnerLayoutView.GetDataRow(rowIndex));
            DataRow row = grvMaster.GetDataRow(rowIndex);
            bool IsValidationCheck = false;

            //신규행에대해
            if (row["CHK"].ToString().Equals("Y"))
                IsValidationCheck = true;

            if (IsValidationCheck)
            {
                foreach (string fieldName in requiredColumns)
                {
                    if (row[fieldName].ToString().Equals(""))
                    {
                        if (IsMessagePrint)
                        {
                            //string colCaption = InnerGridView != null ? InnerGridView.Columns[fieldName].Caption : InnerLayoutView.Columns[fieldName].Caption;
                            string colCaption = grvMaster.Columns[fieldName].Caption;
                            string message = string.Format("{0}은는필수입력입니다", colCaption);

                            //MessageBoxHelper.HiproMessageBoxShow(message);
                            //MsgBox.Show(message);

                            if (grvMaster != null)
                            {
                                grvMaster.ClearColumnErrors();
                                grvMaster.FocusedRowHandle = rowIndex;
                                grvMaster.SetColumnError(grvMaster.Columns[fieldName], message);
                            }
                            else
                            {
                                //InnerLayoutView.ClearColumnErrors();
                                //InnerLayoutView.FocusedRowHandle = rowIndex;
                                //InnerLayoutView.SetColumnError(InnerLayoutView.Columns[fieldName], message);
                            }
                        }
                        return false;
                    }
                }
            }
            return true;
        }
        #endregion

        #region 파일확장자 filterString

        /// <summary>
        /// 지정한 필터리스트에 대한 검색할 문자열을 가져온다
        /// </summary>
        /// <param name="ExtentionFilterList">지정한 필터리스트</param>
        /// <returns>검색할 문자열</returns>
        private string GetDirectorySearchFilterString(AttachUpladFileType ExtentionFilterList)
        {
            string filterString = string.Empty;

            switch (ExtentionFilterList)
            {
                case AttachUpladFileType.AllDocument:
                    filterString = "_모든문서" + "|*.xls,*.doc,*.rtf,*.ppt,*.xlsx,*.docx,*.pptx,*.pdf,*.txt,*.xml,*.htm,*.html,*.mht,*.hwp,*.msg,*.exe";
                    break;
                case AttachUpladFileType.AllImage:
                    filterString = "이미지" + "|*.gif,*.jpg,*.jpeg,*.bmp,*.png,*.tiff,*.tif,*.ico";
                    break;
                case AttachUpladFileType.Excel:
                    filterString = "엑셀" + "|*.xls,*.xlsx";
                    break;
                case AttachUpladFileType.WebPage:
                    filterString = "웹문서" + "|*.htm,*.html,*.mht";
                    break;
                case AttachUpladFileType.Pdf:
                    filterString = "pdf|*.pdf";
                    break;
                case AttachUpladFileType.Office:
                    filterString = "오피스문서" + "|*.xls,*.doc,*.rtf,*.ppt,*.xlsx,*.docx,*.pptx,*.hwp,*.msg";
                    break;
                case AttachUpladFileType.Text:
                    filterString = "텍스트및xml" + "|*.txt,*.xml";
                    break;
                case AttachUpladFileType.Xml:
                    filterString = "xml|*.xml";
                    break;
                case AttachUpladFileType.AllFile:
                    filterString = "모든문서및이미지" + "|*.xls,*.doc,*.rtf,*.ppt,*.xlsx,*.docx,*.pptx,*.pdf,*.txt,*.xml,*.htm,*.html,*.mht,*.hwp,*.msg,,*.exe,*.gif,*.jpg,*.jpeg,*.bmp,*.png,*.tiff,*.tif,*.ico";
                    break;
            }
            return filterString;
        }

        public enum AttachUpladFileType
        {
            /// <summary>
            /// xls,doc,ppt,xlsx,docx,pptx,txt,xml,htm,html,mht
            /// </summary>
            AllDocument = 0,
            /// <summary>
            /// gif,jpg,jpeg,bmp,png,tiff,ico
            /// </summary>
            AllImage = 1,
            /// <summary>
            /// xls,xlsx
            /// </summary>
            Excel = 2,
            /// <summary>
            /// htm,html,mht
            /// </summary>
            WebPage = 3,
            /// <summary>
            /// pdf
            /// </summary>
            Pdf = 4,
            /// <summary>
            /// xls,doc,ppt,xlsx,docx,pptx
            /// </summary>
            Office = 5,
            /// <summary>
            /// txt,xml
            /// </summary>
            Text = 6,
            /// <summary>
            /// xml
            /// </summary>
            Xml = 7,
            /// <summary>
            /// xls,doc,ppt,xlsx,docx,pptx,txt,xml,htm,html,mht,gif,jpg,jpeg,bmp,png,tiff,ico
            /// </summary>
            AllFile = 99
        }

        #endregion 파일확장자 filterString

        #region Ftp 파일 업로드 - FtpFileUpLoad
        /// <summary>
        /// Ftp 파일 업로드
        /// </summary>
        /// <param name="rows"></param>
        private void FtpFileUpLoad(DataRow[] rows)
        {
            foreach (DataRow row in rows)
            {
                if(!string.IsNullOrWhiteSpace(row["LOCAL_FILE_PATH"].ToString()))
                {
                    string strFtpUploadPathFull = sFTP_SERVER_PATH + "/" + row["FILE_NAME"].ToString();
                    ftpHelper.Upload(strFtpUploadPathFull, row["LOCAL_FILE_PATH"].ToString());
                }
            }
        }
        #endregion Ftp 파일 업로드 - FtpFileUpLoad

        #region Ftp 파일 삭제 - FtpFileDelete
        /// <summary>
        /// Ftp 파일 삭제
        /// </summary>
        /// <param name="rows"></param>
        private void FtpFileDelete(DataRow[] rows)
        {
            foreach (DataRow row in rows)
            {
                string strFtpUploadPathFull = row["FILE_PATH"].ToString() + "/" + row["FILE_NAME"].ToString();
                ftpHelper.Delete(strFtpUploadPathFull);
            }
        }
        #endregion Ftp 파일 삭제 - FtpFileDelete

        private void grvMaster_DoubleClick(object sender, EventArgs e)
        {
            DataRow row = grvMaster.GetFocusedDataRow();
            if (row != null)
            {
                if (grvMaster.FocusedColumn.FieldName.Equals("FILE_NAME"))
                {
                    OpenFileDialog openFileDialog = new OpenFileDialog();

                    openFileDialog.Multiselect = true;


                    AttachUpladFileType ExtentionFilterList = AttachUpladFileType.AllFile;
                    // 필터막음
                    openFileDialog.Filter = GetDirectorySearchFilterString(ExtentionFilterList).Replace(",", "; ");

                    openFileDialog.ShowDialog(this);

                    try
                    {
                        string[] dragFiles = openFileDialog.FileNames;
                        if (dragFiles.Length > 0)
                        {
                            foreach (string dragFile in dragFiles)
                            {
                                if (File.Exists(dragFile))
                                {
                                    FileInfo fileInfo = new FileInfo(dragFile);

                                    row["CHK"] = "Y";
                                    row["PROGRAM_ID"] = sPROGRAM_ID;
                                    row["PROGRAM_NAME"] = sPROGRAM_NAME;
                                    row["LOCAL_FILE_PATH"] = fileInfo.FullName;
                                    row["FILE_NAME"] = fileInfo.Name;
                                    
                                    grvMaster.UpdateCurrentRow();
                                }                               
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MsgBox.Show(ex.Message);
                    }

                }

            }
        }
        #endregion

        private void grvMaster_CellValueChanging(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            GridView gridView = (sender as GridView);
            if (gridView != null)
            {

                DataRow row = gridView.GetDataRow(e.RowHandle);
                if (row != null)
                {
                    if (gridView.Columns["CHK"] != null && gridView.Columns["CHK"].ColumnEdit != null && gridView.Columns["CHK"].ColumnEdit is RepositoryItemCheckEdit)
                    {
                        RepositoryItemCheckEdit chkEdit = (gridView.Columns["CHK"].ColumnEdit as RepositoryItemCheckEdit);
                        row["CHK"] = chkEdit.ValueChecked;
                    }
                }
            }
        }

        
    }
}
