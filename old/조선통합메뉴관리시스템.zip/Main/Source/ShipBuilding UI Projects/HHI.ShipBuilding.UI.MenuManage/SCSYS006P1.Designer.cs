﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS006P1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.btnAsgnPopup = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.txtASGNNAME = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnPassword = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.dteSTART_DATE = new HHI.ShipBuilding.Client.Controls.DXperience.XtraDateEditExt();
            this.dteEND_DATE = new HHI.ShipBuilding.Client.Controls.DXperience.XtraDateEditExt();
            this.btnDeptPopUp = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.txtAsgn_Cd = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnHHIUserPopUp = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.chkUse_Yn = new HHI.ShipBuilding.Client.Controls.DXperience.XtraCheckEditExt();
            this.txtPassword = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtDeptName = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtDept_Cd = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtOffi_Tel = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtJob_Tit_Nm = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtEng_Nm = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtKor_Nm = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.txtUser_Id = new HHI.ShipBuilding.Client.Controls.DXperience.XtraTextEditExt();
            this.btnSave = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.btnClose = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem5 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem6 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem7 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem8 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem9 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem16 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem10 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem17 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem18 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem19 = new DevExpress.XtraLayout.LayoutControlItem();
            this.stdValidationManager1 = new HHI.ShipBuilding.Controls.StdValidationManager();
            this.stdSecurityManager1 = new HHI.ShipBuilding.Windows.Forms.StdSecurityManager();
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtASGNNAME.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteSTART_DATE.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteSTART_DATE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteEND_DATE.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteEND_DATE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAsgn_Cd.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkUse_Yn.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPassword.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDeptName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDept_Cd.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOffi_Tel.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJob_Tit_Nm.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEng_Nm.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKor_Nm.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUser_Id.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.btnAsgnPopup);
            this.xtraLayoutControlExt1.Controls.Add(this.txtASGNNAME);
            this.xtraLayoutControlExt1.Controls.Add(this.btnPassword);
            this.xtraLayoutControlExt1.Controls.Add(this.dteSTART_DATE);
            this.xtraLayoutControlExt1.Controls.Add(this.dteEND_DATE);
            this.xtraLayoutControlExt1.Controls.Add(this.btnDeptPopUp);
            this.xtraLayoutControlExt1.Controls.Add(this.txtAsgn_Cd);
            this.xtraLayoutControlExt1.Controls.Add(this.btnHHIUserPopUp);
            this.xtraLayoutControlExt1.Controls.Add(this.chkUse_Yn);
            this.xtraLayoutControlExt1.Controls.Add(this.txtPassword);
            this.xtraLayoutControlExt1.Controls.Add(this.txtDeptName);
            this.xtraLayoutControlExt1.Controls.Add(this.txtDept_Cd);
            this.xtraLayoutControlExt1.Controls.Add(this.txtOffi_Tel);
            this.xtraLayoutControlExt1.Controls.Add(this.txtJob_Tit_Nm);
            this.xtraLayoutControlExt1.Controls.Add(this.txtEng_Nm);
            this.xtraLayoutControlExt1.Controls.Add(this.txtKor_Nm);
            this.xtraLayoutControlExt1.Controls.Add(this.txtUser_Id);
            this.xtraLayoutControlExt1.Controls.Add(this.btnSave);
            this.xtraLayoutControlExt1.Controls.Add(this.btnClose);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(720, 273, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(391, 266);
            this.xtraLayoutControlExt1.TabIndex = 0;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // btnAsgnPopup
            // 
            this.btnAsgnPopup.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_조회;
            this.btnAsgnPopup.IsExecuteWdworkerLog = true;
            this.btnAsgnPopup.Location = new System.Drawing.Point(318, 160);
            this.btnAsgnPopup.Name = "btnAsgnPopup";
            this.btnAsgnPopup.Size = new System.Drawing.Size(34, 22);
            this.btnAsgnPopup.StyleController = this.xtraLayoutControlExt1;
            this.btnAsgnPopup.TabIndex = 23;
            this.btnAsgnPopup.Text = " ";
            this.btnAsgnPopup.UseSplasher = false;
            this.btnAsgnPopup.Click += new System.EventHandler(this.btnAsgnPopup_Click);
            // 
            // txtASGNNAME
            // 
            this.txtASGNNAME.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtASGNNAME.EditValue = "";
            this.txtASGNNAME.EnterExecuteButton = null;
            this.txtASGNNAME.FocusColor = System.Drawing.Color.Empty;
            this.txtASGNNAME.IsValueTrim = true;
            this.txtASGNNAME.Key = "ASGNNAME";
            this.txtASGNNAME.Location = new System.Drawing.Point(178, 160);
            this.txtASGNNAME.MinLength = 0;
            this.txtASGNNAME.Name = "txtASGNNAME";
            this.txtASGNNAME.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtASGNNAME.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtASGNNAME.Properties.Appearance.Options.UseBackColor = true;
            this.txtASGNNAME.Properties.Appearance.Options.UseForeColor = true;
            this.txtASGNNAME.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtASGNNAME.Size = new System.Drawing.Size(136, 20);
            this.txtASGNNAME.StyleController = this.xtraLayoutControlExt1;
            this.txtASGNNAME.TabIndex = 17;
            this.txtASGNNAME.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // btnPassword
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnPassword, new string[] {
            "SAVE"});
            this.btnPassword.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_저장;
            this.btnPassword.IsExecuteWdworkerLog = true;
            this.btnPassword.Location = new System.Drawing.Point(225, 62);
            this.btnPassword.Name = "btnPassword";
            this.btnPassword.Size = new System.Drawing.Size(102, 22);
            this.btnPassword.StyleController = this.xtraLayoutControlExt1;
            this.btnPassword.TabIndex = 6;
            this.btnPassword.Text = "비밀번호변경";
            this.btnPassword.UseSplasher = true;
            this.btnPassword.Click += new System.EventHandler(this.btnPassword_Click);
            // 
            // dteSTART_DATE
            // 
            this.dteSTART_DATE.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.dteSTART_DATE.EditValue = null;
            this.dteSTART_DATE.EnterExecuteButton = null;
            this.dteSTART_DATE.FocusColor = System.Drawing.Color.Empty;
            this.dteSTART_DATE.Key = "START_DATE";
            this.dteSTART_DATE.Location = new System.Drawing.Point(98, 234);
            this.dteSTART_DATE.MinLength = 0;
            this.dteSTART_DATE.Name = "dteSTART_DATE";
            this.dteSTART_DATE.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.dteSTART_DATE.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.dteSTART_DATE.Properties.Appearance.Options.UseBackColor = true;
            this.dteSTART_DATE.Properties.Appearance.Options.UseForeColor = true;
            this.dteSTART_DATE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteSTART_DATE.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteSTART_DATE.Properties.CalendarTimeProperties.CloseUpKey = new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.F4);
            this.dteSTART_DATE.Properties.CalendarTimeProperties.PopupBorderStyle = DevExpress.XtraEditors.Controls.PopupBorderStyles.Default;
            this.dteSTART_DATE.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Vista;
            this.dteSTART_DATE.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.dteSTART_DATE.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dteSTART_DATE.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.True;
            this.dteSTART_DATE.Size = new System.Drawing.Size(94, 20);
            this.dteSTART_DATE.StyleController = this.xtraLayoutControlExt1;
            this.dteSTART_DATE.TabIndex = 24;
            this.stdValidationManager1.SetValidation(this.dteSTART_DATE, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // dteEND_DATE
            // 
            this.dteEND_DATE.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.dteEND_DATE.EditValue = null;
            this.dteEND_DATE.EnterExecuteButton = null;
            this.dteEND_DATE.FocusColor = System.Drawing.Color.Empty;
            this.dteEND_DATE.Key = "END_DATE";
            this.dteEND_DATE.Location = new System.Drawing.Point(210, 234);
            this.dteEND_DATE.MinLength = 0;
            this.dteEND_DATE.Name = "dteEND_DATE";
            this.dteEND_DATE.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.dteEND_DATE.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.dteEND_DATE.Properties.Appearance.Options.UseBackColor = true;
            this.dteEND_DATE.Properties.Appearance.Options.UseForeColor = true;
            this.dteEND_DATE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteEND_DATE.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dteEND_DATE.Properties.CalendarTimeProperties.CloseUpKey = new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.F4);
            this.dteEND_DATE.Properties.CalendarTimeProperties.PopupBorderStyle = DevExpress.XtraEditors.Controls.PopupBorderStyles.Default;
            this.dteEND_DATE.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Vista;
            this.dteEND_DATE.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.dteEND_DATE.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dteEND_DATE.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.True;
            this.dteEND_DATE.Size = new System.Drawing.Size(104, 20);
            this.dteEND_DATE.StyleController = this.xtraLayoutControlExt1;
            this.dteEND_DATE.TabIndex = 23;
            this.stdValidationManager1.SetValidation(this.dteEND_DATE, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // btnDeptPopUp
            // 
            this.btnDeptPopUp.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_조회;
            this.btnDeptPopUp.IsExecuteWdworkerLog = true;
            this.btnDeptPopUp.Location = new System.Drawing.Point(326, 136);
            this.btnDeptPopUp.Name = "btnDeptPopUp";
            this.btnDeptPopUp.Size = new System.Drawing.Size(26, 20);
            this.btnDeptPopUp.StyleController = this.xtraLayoutControlExt1;
            this.btnDeptPopUp.TabIndex = 22;
            this.btnDeptPopUp.Text = " ";
            this.btnDeptPopUp.UseSplasher = false;
            this.btnDeptPopUp.Click += new System.EventHandler(this.btnDeptPopUp_Click);
            // 
            // txtAsgn_Cd
            // 
            this.txtAsgn_Cd.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtAsgn_Cd.EditValue = "";
            this.txtAsgn_Cd.EnterExecuteButton = null;
            this.txtAsgn_Cd.FocusColor = System.Drawing.Color.Empty;
            this.txtAsgn_Cd.IsValueTrim = true;
            this.txtAsgn_Cd.Key = "ASGN_CD";
            this.txtAsgn_Cd.Location = new System.Drawing.Point(98, 160);
            this.txtAsgn_Cd.MinLength = 0;
            this.txtAsgn_Cd.Name = "txtAsgn_Cd";
            this.txtAsgn_Cd.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtAsgn_Cd.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtAsgn_Cd.Properties.Appearance.Options.UseBackColor = true;
            this.txtAsgn_Cd.Properties.Appearance.Options.UseForeColor = true;
            this.txtAsgn_Cd.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtAsgn_Cd.Size = new System.Drawing.Size(76, 20);
            this.txtAsgn_Cd.StyleController = this.xtraLayoutControlExt1;
            this.txtAsgn_Cd.TabIndex = 16;
            this.txtAsgn_Cd.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // btnHHIUserPopUp
            // 
            this.btnHHIUserPopUp.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_조회;
            this.btnHHIUserPopUp.IsExecuteWdworkerLog = true;
            this.btnHHIUserPopUp.Location = new System.Drawing.Point(225, 38);
            this.btnHHIUserPopUp.Name = "btnHHIUserPopUp";
            this.btnHHIUserPopUp.Size = new System.Drawing.Size(26, 20);
            this.btnHHIUserPopUp.StyleController = this.xtraLayoutControlExt1;
            this.btnHHIUserPopUp.TabIndex = 15;
            this.btnHHIUserPopUp.Text = " ";
            this.btnHHIUserPopUp.UseSplasher = false;
            this.btnHHIUserPopUp.Click += new System.EventHandler(this.btnHHIUserPopUp_Click);
            // 
            // chkUse_Yn
            // 
            this.chkUse_Yn.EditValue = "Y";
            this.chkUse_Yn.EnterExecuteButton = null;
            this.chkUse_Yn.Key = "USE_YN";
            this.chkUse_Yn.Location = new System.Drawing.Point(255, 38);
            this.chkUse_Yn.MinLength = 0;
            this.chkUse_Yn.Name = "chkUse_Yn";
            this.chkUse_Yn.Properties.Caption = "사용여부";
            this.chkUse_Yn.Properties.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.chkUse_Yn.Properties.ValueChecked = "Y";
            this.chkUse_Yn.Properties.ValueUnchecked = "N";
            this.chkUse_Yn.Size = new System.Drawing.Size(107, 19);
            this.chkUse_Yn.StyleController = this.xtraLayoutControlExt1;
            this.chkUse_Yn.TabIndex = 14;
            this.stdValidationManager1.SetValidation(this.chkUse_Yn, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // txtPassword
            // 
            this.txtPassword.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.txtPassword.EditValue = "";
            this.txtPassword.EnterExecuteButton = null;
            this.txtPassword.FocusColor = System.Drawing.Color.Empty;
            this.txtPassword.IsValueTrim = true;
            this.txtPassword.Key = "PASSWORD";
            this.txtPassword.Location = new System.Drawing.Point(98, 62);
            this.txtPassword.MinLength = 0;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.txtPassword.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtPassword.Properties.Appearance.Options.UseBackColor = true;
            this.txtPassword.Properties.Appearance.Options.UseForeColor = true;
            this.txtPassword.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtPassword.Size = new System.Drawing.Size(123, 20);
            this.txtPassword.StyleController = this.xtraLayoutControlExt1;
            this.txtPassword.TabIndex = 13;
            this.txtPassword.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtPassword, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // txtDeptName
            // 
            this.txtDeptName.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtDeptName.EditValue = "";
            this.txtDeptName.EnterExecuteButton = null;
            this.txtDeptName.FocusColor = System.Drawing.Color.Empty;
            this.txtDeptName.IsValueTrim = true;
            this.txtDeptName.Key = "DEPTNAME";
            this.txtDeptName.Location = new System.Drawing.Point(170, 136);
            this.txtDeptName.MinLength = 0;
            this.txtDeptName.Name = "txtDeptName";
            this.txtDeptName.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtDeptName.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtDeptName.Properties.Appearance.Options.UseBackColor = true;
            this.txtDeptName.Properties.Appearance.Options.UseForeColor = true;
            this.txtDeptName.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtDeptName.Size = new System.Drawing.Size(152, 20);
            this.txtDeptName.StyleController = this.xtraLayoutControlExt1;
            this.txtDeptName.TabIndex = 12;
            this.txtDeptName.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtDept_Cd
            // 
            this.txtDept_Cd.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtDept_Cd.EditValue = "";
            this.txtDept_Cd.EnterExecuteButton = null;
            this.txtDept_Cd.FocusColor = System.Drawing.Color.Empty;
            this.txtDept_Cd.IsValueTrim = true;
            this.txtDept_Cd.Key = "DEPT_CD";
            this.txtDept_Cd.Location = new System.Drawing.Point(98, 136);
            this.txtDept_Cd.MinLength = 0;
            this.txtDept_Cd.Name = "txtDept_Cd";
            this.txtDept_Cd.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtDept_Cd.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtDept_Cd.Properties.Appearance.Options.UseBackColor = true;
            this.txtDept_Cd.Properties.Appearance.Options.UseForeColor = true;
            this.txtDept_Cd.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtDept_Cd.Size = new System.Drawing.Size(68, 20);
            this.txtDept_Cd.StyleController = this.xtraLayoutControlExt1;
            this.txtDept_Cd.TabIndex = 11;
            this.txtDept_Cd.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtOffi_Tel
            // 
            this.txtOffi_Tel.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtOffi_Tel.EditValue = "";
            this.txtOffi_Tel.EnterExecuteButton = null;
            this.txtOffi_Tel.FocusColor = System.Drawing.Color.Empty;
            this.txtOffi_Tel.IsValueTrim = true;
            this.txtOffi_Tel.Key = "OFFI_TEL";
            this.txtOffi_Tel.Location = new System.Drawing.Point(98, 210);
            this.txtOffi_Tel.MinLength = 0;
            this.txtOffi_Tel.Name = "txtOffi_Tel";
            this.txtOffi_Tel.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtOffi_Tel.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtOffi_Tel.Properties.Appearance.Options.UseBackColor = true;
            this.txtOffi_Tel.Properties.Appearance.Options.UseForeColor = true;
            this.txtOffi_Tel.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtOffi_Tel.Size = new System.Drawing.Size(122, 20);
            this.txtOffi_Tel.StyleController = this.xtraLayoutControlExt1;
            this.txtOffi_Tel.TabIndex = 10;
            this.txtOffi_Tel.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtJob_Tit_Nm
            // 
            this.txtJob_Tit_Nm.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtJob_Tit_Nm.EditValue = "";
            this.txtJob_Tit_Nm.EnterExecuteButton = null;
            this.txtJob_Tit_Nm.FocusColor = System.Drawing.Color.Empty;
            this.txtJob_Tit_Nm.IsValueTrim = true;
            this.txtJob_Tit_Nm.Key = "JOB_TIT_NM";
            this.txtJob_Tit_Nm.Location = new System.Drawing.Point(98, 186);
            this.txtJob_Tit_Nm.MinLength = 0;
            this.txtJob_Tit_Nm.Name = "txtJob_Tit_Nm";
            this.txtJob_Tit_Nm.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtJob_Tit_Nm.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtJob_Tit_Nm.Properties.Appearance.Options.UseBackColor = true;
            this.txtJob_Tit_Nm.Properties.Appearance.Options.UseForeColor = true;
            this.txtJob_Tit_Nm.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtJob_Tit_Nm.Size = new System.Drawing.Size(122, 20);
            this.txtJob_Tit_Nm.StyleController = this.xtraLayoutControlExt1;
            this.txtJob_Tit_Nm.TabIndex = 9;
            this.txtJob_Tit_Nm.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtEng_Nm
            // 
            this.txtEng_Nm.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Normal;
            this.txtEng_Nm.EditValue = "";
            this.txtEng_Nm.EnterExecuteButton = null;
            this.txtEng_Nm.FocusColor = System.Drawing.Color.Empty;
            this.txtEng_Nm.IsValueTrim = true;
            this.txtEng_Nm.Key = "ENG_NM";
            this.txtEng_Nm.Location = new System.Drawing.Point(98, 112);
            this.txtEng_Nm.MinLength = 0;
            this.txtEng_Nm.Name = "txtEng_Nm";
            this.txtEng_Nm.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtEng_Nm.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtEng_Nm.Properties.Appearance.Options.UseBackColor = true;
            this.txtEng_Nm.Properties.Appearance.Options.UseForeColor = true;
            this.txtEng_Nm.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtEng_Nm.Size = new System.Drawing.Size(190, 20);
            this.txtEng_Nm.StyleController = this.xtraLayoutControlExt1;
            this.txtEng_Nm.TabIndex = 8;
            this.txtEng_Nm.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            // 
            // txtKor_Nm
            // 
            this.txtKor_Nm.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.txtKor_Nm.EditValue = "";
            this.txtKor_Nm.EnterExecuteButton = null;
            this.txtKor_Nm.FocusColor = System.Drawing.Color.Empty;
            this.txtKor_Nm.IsValueTrim = true;
            this.txtKor_Nm.Key = "KOR_NM";
            this.txtKor_Nm.Location = new System.Drawing.Point(98, 88);
            this.txtKor_Nm.MinLength = 0;
            this.txtKor_Nm.Name = "txtKor_Nm";
            this.txtKor_Nm.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.txtKor_Nm.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtKor_Nm.Properties.Appearance.Options.UseBackColor = true;
            this.txtKor_Nm.Properties.Appearance.Options.UseForeColor = true;
            this.txtKor_Nm.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtKor_Nm.Size = new System.Drawing.Size(190, 20);
            this.txtKor_Nm.StyleController = this.xtraLayoutControlExt1;
            this.txtKor_Nm.TabIndex = 7;
            this.txtKor_Nm.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtKor_Nm, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // txtUser_Id
            // 
            this.txtUser_Id.ColorSkin = HHI.ShipBuilding.Controls.EditColorSkinType.Required;
            this.txtUser_Id.EditValue = "";
            this.txtUser_Id.EnterExecuteButton = null;
            this.txtUser_Id.FocusColor = System.Drawing.Color.Empty;
            this.txtUser_Id.IsValueTrim = true;
            this.txtUser_Id.Key = "USER_ID";
            this.txtUser_Id.Location = new System.Drawing.Point(98, 38);
            this.txtUser_Id.MinLength = 0;
            this.txtUser_Id.Name = "txtUser_Id";
            this.txtUser_Id.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(217)))));
            this.txtUser_Id.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtUser_Id.Properties.Appearance.Options.UseBackColor = true;
            this.txtUser_Id.Properties.Appearance.Options.UseForeColor = true;
            this.txtUser_Id.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtUser_Id.Size = new System.Drawing.Size(123, 20);
            this.txtUser_Id.StyleController = this.xtraLayoutControlExt1;
            this.txtUser_Id.TabIndex = 6;
            this.txtUser_Id.TextFormat = HHI.ShipBuilding.Controls.TextEditTextFormatType.CustomType;
            this.stdValidationManager1.SetValidation(this.txtUser_Id, new HHI.ShipBuilding.Controls.ValidationType[] {
            HHI.ShipBuilding.Controls.ValidationType.Required});
            // 
            // btnSave
            // 
            this.stdSecurityManager1.SetAllowedAccess(this.btnSave, new string[] {
            "SAVE"});
            this.btnSave.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_저장;
            this.btnSave.IsExecuteWdworkerLog = true;
            this.btnSave.Location = new System.Drawing.Point(216, 12);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(71, 22);
            this.btnSave.StyleController = this.xtraLayoutControlExt1;
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "저장";
            this.btnSave.UseSplasher = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_닫기;
            this.btnClose.IsExecuteWdworkerLog = true;
            this.btnClose.Location = new System.Drawing.Point(291, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(71, 22);
            this.btnClose.StyleController = this.xtraLayoutControlExt1;
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "닫기";
            this.btnClose.UseSplasher = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "Root";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.layoutControlItem2,
            this.emptySpaceItem2,
            this.layoutControlItem3,
            this.layoutControlItem6,
            this.layoutControlItem4,
            this.layoutControlItem11,
            this.layoutControlItem8,
            this.layoutControlItem9,
            this.layoutControlItem10,
            this.layoutControlItem5,
            this.layoutControlItem7,
            this.emptySpaceItem4,
            this.emptySpaceItem5,
            this.emptySpaceItem6,
            this.emptySpaceItem7,
            this.emptySpaceItem8,
            this.layoutControlItem13,
            this.emptySpaceItem1,
            this.layoutControlItem12,
            this.emptySpaceItem3,
            this.layoutControlItem14,
            this.emptySpaceItem9,
            this.layoutControlItem15,
            this.layoutControlItem16,
            this.emptySpaceItem10,
            this.layoutControlItem17,
            this.layoutControlItem18,
            this.layoutControlItem19});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(374, 270);
            this.layoutControlGroup1.Text = "Root";
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.btnClose;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(279, 0);
            this.layoutControlItem1.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem1.Text = "layoutControlItem1";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextToControlDistance = 0;
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.btnSave;
            this.layoutControlItem2.CustomizationFormText = "layoutControlItem2";
            this.layoutControlItem2.Location = new System.Drawing.Point(204, 0);
            this.layoutControlItem2.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem2.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem2.Text = "layoutControlItem2";
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextToControlDistance = 0;
            this.layoutControlItem2.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(204, 26);
            this.emptySpaceItem2.Text = "emptySpaceItem2";
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem3.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem3.Control = this.txtUser_Id;
            this.layoutControlItem3.CustomizationFormText = "시스템코드";
            this.layoutControlItem3.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(213, 24);
            this.layoutControlItem3.Text = "사용자Id";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(83, 16);
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem6.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem6.Control = this.txtJob_Tit_Nm;
            this.layoutControlItem6.CustomizationFormText = "모듈정보";
            this.layoutControlItem6.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 174);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(212, 24);
            this.layoutControlItem6.Text = "직급";
            this.layoutControlItem6.TextSize = new System.Drawing.Size(83, 16);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem4.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem4.Control = this.txtKor_Nm;
            this.layoutControlItem4.CustomizationFormText = "시스템명";
            this.layoutControlItem4.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 76);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(280, 24);
            this.layoutControlItem4.Text = "사용자명(한)";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(83, 16);
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.chkUse_Yn;
            this.layoutControlItem11.CustomizationFormText = "layoutControlItem11";
            this.layoutControlItem11.Location = new System.Drawing.Point(243, 26);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(111, 24);
            this.layoutControlItem11.Text = "layoutControlItem11";
            this.layoutControlItem11.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem11.TextToControlDistance = 0;
            this.layoutControlItem11.TextVisible = false;
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem8.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem8.Control = this.txtDept_Cd;
            this.layoutControlItem8.CustomizationFormText = "FTP 서버 경로";
            this.layoutControlItem8.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem8.Location = new System.Drawing.Point(0, 124);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(158, 24);
            this.layoutControlItem8.Text = "부서";
            this.layoutControlItem8.TextSize = new System.Drawing.Size(83, 16);
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem9.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem9.Control = this.txtDeptName;
            this.layoutControlItem9.CustomizationFormText = "사용자ID";
            this.layoutControlItem9.Location = new System.Drawing.Point(158, 124);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(156, 24);
            this.layoutControlItem9.Text = "부서명";
            this.layoutControlItem9.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem9.TextToControlDistance = 0;
            this.layoutControlItem9.TextVisible = false;
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem10.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem10.Control = this.txtPassword;
            this.layoutControlItem10.CustomizationFormText = "Password";
            this.layoutControlItem10.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem10.Location = new System.Drawing.Point(0, 50);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(213, 26);
            this.layoutControlItem10.Text = "Password";
            this.layoutControlItem10.TextSize = new System.Drawing.Size(83, 16);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem5.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem5.Control = this.txtEng_Nm;
            this.layoutControlItem5.CustomizationFormText = "다운로드 경로";
            this.layoutControlItem5.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem5.Location = new System.Drawing.Point(0, 100);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(280, 24);
            this.layoutControlItem5.Text = "사용자명(영)";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(83, 16);
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem7.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem7.Control = this.txtOffi_Tel;
            this.layoutControlItem7.CustomizationFormText = "Class 정보";
            this.layoutControlItem7.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem7.Location = new System.Drawing.Point(0, 198);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(212, 24);
            this.layoutControlItem7.Text = "전화";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(83, 16);
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.CustomizationFormText = "emptySpaceItem4";
            this.emptySpaceItem4.Location = new System.Drawing.Point(319, 50);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(35, 26);
            this.emptySpaceItem4.Text = "emptySpaceItem4";
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem5
            // 
            this.emptySpaceItem5.AllowHotTrack = false;
            this.emptySpaceItem5.CustomizationFormText = "emptySpaceItem5";
            this.emptySpaceItem5.Location = new System.Drawing.Point(280, 76);
            this.emptySpaceItem5.Name = "emptySpaceItem5";
            this.emptySpaceItem5.Size = new System.Drawing.Size(74, 24);
            this.emptySpaceItem5.Text = "emptySpaceItem5";
            this.emptySpaceItem5.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem6
            // 
            this.emptySpaceItem6.AllowHotTrack = false;
            this.emptySpaceItem6.CustomizationFormText = "emptySpaceItem6";
            this.emptySpaceItem6.Location = new System.Drawing.Point(280, 100);
            this.emptySpaceItem6.Name = "emptySpaceItem6";
            this.emptySpaceItem6.Size = new System.Drawing.Size(74, 24);
            this.emptySpaceItem6.Text = "emptySpaceItem6";
            this.emptySpaceItem6.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem7
            // 
            this.emptySpaceItem7.AllowHotTrack = false;
            this.emptySpaceItem7.CustomizationFormText = "emptySpaceItem7";
            this.emptySpaceItem7.Location = new System.Drawing.Point(212, 174);
            this.emptySpaceItem7.Name = "emptySpaceItem7";
            this.emptySpaceItem7.Size = new System.Drawing.Size(142, 24);
            this.emptySpaceItem7.Text = "emptySpaceItem7";
            this.emptySpaceItem7.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem8
            // 
            this.emptySpaceItem8.AllowHotTrack = false;
            this.emptySpaceItem8.CustomizationFormText = "emptySpaceItem8";
            this.emptySpaceItem8.Location = new System.Drawing.Point(212, 198);
            this.emptySpaceItem8.Name = "emptySpaceItem8";
            this.emptySpaceItem8.Size = new System.Drawing.Size(142, 24);
            this.emptySpaceItem8.Text = "emptySpaceItem8";
            this.emptySpaceItem8.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem13.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem13.Control = this.txtAsgn_Cd;
            this.layoutControlItem13.CustomizationFormText = "과코드";
            this.layoutControlItem13.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem13.Location = new System.Drawing.Point(0, 148);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(166, 26);
            this.layoutControlItem13.Text = "과코드";
            this.layoutControlItem13.TextSize = new System.Drawing.Size(83, 16);
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(344, 148);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(10, 26);
            this.emptySpaceItem1.Text = "emptySpaceItem1";
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.btnHHIUserPopUp;
            this.layoutControlItem12.CustomizationFormText = "layoutControlItem12";
            this.layoutControlItem12.Location = new System.Drawing.Point(213, 26);
            this.layoutControlItem12.MaxSize = new System.Drawing.Size(30, 24);
            this.layoutControlItem12.MinSize = new System.Drawing.Size(30, 24);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(30, 24);
            this.layoutControlItem12.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem12.Text = "layoutControlItem12";
            this.layoutControlItem12.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem12.TextToControlDistance = 0;
            this.layoutControlItem12.TextVisible = false;
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.CustomizationFormText = "emptySpaceItem3";
            this.emptySpaceItem3.Location = new System.Drawing.Point(344, 124);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(10, 24);
            this.emptySpaceItem3.Text = "emptySpaceItem3";
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.btnDeptPopUp;
            this.layoutControlItem14.CustomizationFormText = "layoutControlItem14";
            this.layoutControlItem14.Location = new System.Drawing.Point(314, 124);
            this.layoutControlItem14.MaxSize = new System.Drawing.Size(30, 24);
            this.layoutControlItem14.MinSize = new System.Drawing.Size(30, 24);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Size = new System.Drawing.Size(30, 24);
            this.layoutControlItem14.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem14.Text = "layoutControlItem14";
            this.layoutControlItem14.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem14.TextToControlDistance = 0;
            this.layoutControlItem14.TextVisible = false;
            // 
            // emptySpaceItem9
            // 
            this.emptySpaceItem9.AllowHotTrack = false;
            this.emptySpaceItem9.CustomizationFormText = "emptySpaceItem9";
            this.emptySpaceItem9.Location = new System.Drawing.Point(306, 222);
            this.emptySpaceItem9.Name = "emptySpaceItem9";
            this.emptySpaceItem9.Size = new System.Drawing.Size(48, 28);
            this.emptySpaceItem9.Text = "emptySpaceItem9";
            this.emptySpaceItem9.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem15.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem15.Control = this.dteEND_DATE;
            this.layoutControlItem15.CustomizationFormText = "유효일자";
            this.layoutControlItem15.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem15.Location = new System.Drawing.Point(198, 222);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.Size = new System.Drawing.Size(108, 28);
            this.layoutControlItem15.Text = "유효일자";
            this.layoutControlItem15.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem15.TextToControlDistance = 0;
            this.layoutControlItem15.TextVisible = false;
            // 
            // layoutControlItem16
            // 
            this.layoutControlItem16.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem16.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem16.Control = this.dteSTART_DATE;
            this.layoutControlItem16.CustomizationFormText = "유효일자";
            this.layoutControlItem16.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.circle_green;
            this.layoutControlItem16.Location = new System.Drawing.Point(0, 222);
            this.layoutControlItem16.Name = "layoutControlItem16";
            this.layoutControlItem16.Size = new System.Drawing.Size(184, 28);
            this.layoutControlItem16.Text = "유효일자";
            this.layoutControlItem16.TextSize = new System.Drawing.Size(83, 16);
            // 
            // emptySpaceItem10
            // 
            this.emptySpaceItem10.AllowHotTrack = false;
            this.emptySpaceItem10.CustomizationFormText = "~";
            this.emptySpaceItem10.Location = new System.Drawing.Point(184, 222);
            this.emptySpaceItem10.MaxSize = new System.Drawing.Size(14, 28);
            this.emptySpaceItem10.MinSize = new System.Drawing.Size(14, 28);
            this.emptySpaceItem10.Name = "emptySpaceItem10";
            this.emptySpaceItem10.Size = new System.Drawing.Size(14, 28);
            this.emptySpaceItem10.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem10.Text = "~";
            this.emptySpaceItem10.TextSize = new System.Drawing.Size(83, 0);
            this.emptySpaceItem10.TextVisible = true;
            // 
            // layoutControlItem17
            // 
            this.layoutControlItem17.Control = this.btnPassword;
            this.layoutControlItem17.CustomizationFormText = "layoutControlItem17";
            this.layoutControlItem17.Location = new System.Drawing.Point(213, 50);
            this.layoutControlItem17.Name = "layoutControlItem17";
            this.layoutControlItem17.Size = new System.Drawing.Size(106, 26);
            this.layoutControlItem17.Text = "layoutControlItem17";
            this.layoutControlItem17.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem17.TextToControlDistance = 0;
            this.layoutControlItem17.TextVisible = false;
            // 
            // layoutControlItem18
            // 
            this.layoutControlItem18.Control = this.txtASGNNAME;
            this.layoutControlItem18.CustomizationFormText = "layoutControlItem18";
            this.layoutControlItem18.Location = new System.Drawing.Point(166, 148);
            this.layoutControlItem18.Name = "layoutControlItem18";
            this.layoutControlItem18.Size = new System.Drawing.Size(140, 26);
            this.layoutControlItem18.Text = "layoutControlItem18";
            this.layoutControlItem18.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem18.TextToControlDistance = 0;
            this.layoutControlItem18.TextVisible = false;
            // 
            // layoutControlItem19
            // 
            this.layoutControlItem19.Control = this.btnAsgnPopup;
            this.layoutControlItem19.CustomizationFormText = "layoutControlItem19";
            this.layoutControlItem19.Location = new System.Drawing.Point(306, 148);
            this.layoutControlItem19.Name = "layoutControlItem19";
            this.layoutControlItem19.Size = new System.Drawing.Size(38, 26);
            this.layoutControlItem19.Text = "layoutControlItem19";
            this.layoutControlItem19.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem19.TextToControlDistance = 0;
            this.layoutControlItem19.TextVisible = false;
            // 
            // stdValidationManager1
            // 
            this.stdValidationManager1.IsNullorWhiteSpace = true;
            this.stdValidationManager1.IsShowErrorMessage = true;
            // 
            // SCSYS006P1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(391, 266);
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS006P1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "사용자 정보 저장";
            this.Load += new System.EventHandler(this.SCSYS006P1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtASGNNAME.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteSTART_DATE.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteSTART_DATE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteEND_DATE.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteEND_DATE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAsgn_Cd.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkUse_Yn.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPassword.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDeptName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDept_Cd.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOffi_Tel.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJob_Tit_Nm.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEng_Nm.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKor_Nm.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUser_Id.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private Client.Controls.DXperience.XtraTextEditExt txtPassword;
        private Client.Controls.DXperience.XtraTextEditExt txtDeptName;
        private Client.Controls.DXperience.XtraTextEditExt txtDept_Cd;
        private Client.Controls.DXperience.XtraTextEditExt txtOffi_Tel;
        private Client.Controls.DXperience.XtraTextEditExt txtJob_Tit_Nm;
        private Client.Controls.DXperience.XtraTextEditExt txtEng_Nm;
        private Client.Controls.DXperience.XtraTextEditExt txtKor_Nm;
        private Client.Controls.DXperience.XtraTextEditExt txtUser_Id;
        private Client.Controls.DXperience.XtraButtonExt btnSave;
        private Client.Controls.DXperience.XtraButtonExt btnClose;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private Controls.StdValidationManager stdValidationManager1;
        private Client.Controls.DXperience.XtraCheckEditExt chkUse_Yn;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private Client.Controls.DXperience.XtraButtonExt btnHHIUserPopUp;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem5;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem6;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem7;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem8;
        private Client.Controls.DXperience.XtraTextEditExt txtAsgn_Cd;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private Client.Controls.DXperience.XtraButtonExt btnDeptPopUp;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private Client.Controls.DXperience.XtraDateEditExt dteEND_DATE;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private Windows.Forms.StdSecurityManager stdSecurityManager1;
        private Client.Controls.DXperience.XtraDateEditExt dteSTART_DATE;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem16;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem10;
        private Client.Controls.DXperience.XtraButtonExt btnPassword;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem17;
        private Client.Controls.DXperience.XtraTextEditExt txtASGNNAME;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem18;
        private Client.Controls.DXperience.XtraButtonExt btnAsgnPopup;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem19;
    }
}