﻿namespace HHI.ShipBuilding.UI.MenuManage
{
    partial class SCSYS002P2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.xtraLayoutControlExt1 = new HHI.ShipBuilding.Client.Controls.DXperience.XtraLayoutControlExt();
            this.treeDept = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumn2 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.btnClose = new HHI.ShipBuilding.Client.Controls.DXperience.XtraButtonExt();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.stdValidationManager1 = new HHI.ShipBuilding.Controls.StdValidationManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).BeginInit();
            this.xtraLayoutControlExt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.treeDept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraLayoutControlExt1
            // 
            this.xtraLayoutControlExt1.Controls.Add(this.treeDept);
            this.xtraLayoutControlExt1.Controls.Add(this.btnClose);
            this.xtraLayoutControlExt1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraLayoutControlExt1.Location = new System.Drawing.Point(0, 0);
            this.xtraLayoutControlExt1.Name = "xtraLayoutControlExt1";
            this.xtraLayoutControlExt1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(720, 273, 250, 350);
            this.xtraLayoutControlExt1.Root = this.layoutControlGroup1;
            this.xtraLayoutControlExt1.Size = new System.Drawing.Size(432, 605);
            this.xtraLayoutControlExt1.TabIndex = 0;
            this.xtraLayoutControlExt1.Text = "xtraLayoutControlExt1";
            // 
            // treeDept
            // 
            this.treeDept.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn2});
            this.treeDept.KeyFieldName = "ASGN_CD";
            this.treeDept.Location = new System.Drawing.Point(12, 38);
            this.treeDept.Name = "treeDept";
            this.treeDept.OptionsNavigation.AutoFocusNewNode = true;
            this.treeDept.OptionsDragAndDrop.DragNodesMode = DevExpress.XtraTreeList.DragNodesMode.Multiple;
            this.treeDept.OptionsSelection.InvertSelection = true;
            this.treeDept.OptionsSelection.UseIndicatorForSelection = true;
            this.treeDept.OptionsView.ShowColumns = false;
            this.treeDept.OptionsView.ShowHorzLines = false;
            this.treeDept.OptionsView.ShowIndicator = false;
            this.treeDept.OptionsView.ShowVertLines = false;
            this.treeDept.ParentFieldName = "WK_PRTN_CD";
            this.treeDept.Size = new System.Drawing.Size(408, 555);
            this.treeDept.TabIndex = 15;
            this.treeDept.DoubleClick += new System.EventHandler(this.treeDept_DoubleClick);
            // 
            // treeListColumn2
            // 
            this.treeListColumn2.Caption = "부서명";
            this.treeListColumn2.FieldName = "ASGN_SHRT_NM";
            this.treeListColumn2.Name = "treeListColumn2";
            this.treeListColumn2.OptionsColumn.AllowEdit = false;
            this.treeListColumn2.OptionsColumn.ReadOnly = true;
            this.treeListColumn2.Visible = true;
            this.treeListColumn2.VisibleIndex = 0;
            // 
            // btnClose
            // 
            this.btnClose.Image = global::HHI.ShipBuilding.UI.MenuManage.Properties.Resources.Icon_닫기;
            this.btnClose.IsExecuteWdworkerLog = true;
            this.btnClose.Location = new System.Drawing.Point(349, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(71, 22);
            this.btnClose.StyleController = this.xtraLayoutControlExt1;
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "닫기";
            this.btnClose.UseSplasher = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "Root";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem1,
            this.layoutControlItem1,
            this.layoutControlItem2});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(432, 605);
            this.layoutControlGroup1.Text = "Root";
            this.layoutControlGroup1.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(337, 26);
            this.emptySpaceItem1.Text = "emptySpaceItem1";
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.btnClose;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(337, 0);
            this.layoutControlItem1.MaxSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.MinSize = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(75, 26);
            this.layoutControlItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem1.Text = "layoutControlItem1";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextToControlDistance = 0;
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.treeDept;
            this.layoutControlItem2.CustomizationFormText = "layoutControlItem2";
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(412, 559);
            this.layoutControlItem2.Text = "layoutControlItem2";
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextToControlDistance = 0;
            this.layoutControlItem2.TextVisible = false;
            // 
            // stdValidationManager1
            // 
            this.stdValidationManager1.IsNullorWhiteSpace = true;
            this.stdValidationManager1.IsShowErrorMessage = true;
            // 
            // SCSYS002P2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(432, 605);
            this.Controls.Add(this.xtraLayoutControlExt1);
            this.Name = "SCSYS002P2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "HHI 조직도";
            this.Load += new System.EventHandler(this.SCSYS002P2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xtraLayoutControlExt1)).EndInit();
            this.xtraLayoutControlExt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.treeDept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Client.Controls.DXperience.XtraLayoutControlExt xtraLayoutControlExt1;
        private Client.Controls.DXperience.XtraButtonExt btnClose;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private Controls.StdValidationManager stdValidationManager1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraTreeList.TreeList treeDept;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
    }
}