﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Text;
using System.IO;

namespace HHI.ShipBuilding.WebSite
{
    public partial class SAPGUI : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Session.Add("IsSAPLogon", "N");
            }

            InitPage();
        }

        private void InitPage()
        {
            return;

            try
            {
                HttpCookie cook = null;

                string strUrl = string.Empty;
                string strOTP = string.Empty;

                string strUserId = Request.QueryString["USER_ID"];
                string strTCode = Request.QueryString["TCODE"];
                string strGubun = Request.QueryString["GUBUN"];

                // 세션에 SAP 로그인 여부 정보가 있는지 확인 하여, 최초에만 처리
                if (Session.Count == 0 || (Session["IsSAPLogon"] != null && !Session["IsSAPLogon"].ToString().Equals("Y")))
                {
                    Nets.IM.Common.CryptoProvider.TripleDES tdes = new Nets.IM.Common.CryptoProvider.TripleDES();
                    strOTP = tdes.Encrypt("sso.hhi.co.kr", strUserId);

                    //// 조선
                    //strUrl = "http://hiport.hhi.co.kr/irj/portal?command=ssologin&param1=" + strOTP;

                    // 엔진
                    strUrl = "http://emdportal.hhi.co.kr/irj/portal?command=ssologin&param1=" + strOTP;

                    cook = issueLogonTicket(strUserId, strUrl);
                    Response.AppendCookie(cook);
                    Session.Add("IsSAPLogon", "Y");
                }

                // Hi Portal 메인 화면 - 조선
                //string strExcuteUrl = "http://hiport.hhi.co.kr/irj/portal?command=ssologin&param1=" + strOTP;

                // emd Portal 메인 화면 - 엔진
                string strExcuteUrl = "http://emdportal.hhi.co.kr/irj/portal?command=ssologin&param1=" + strOTP;

                if (strGubun.Equals("2"))
                {
                    strExcuteUrl = string.Format(@"http://hiport.hhi.co.kr/irj/servlet/prt/portal/prtroot/pcd!3aportal_content!2fhhi!2ferp!2fiviews!2fcom.hhi.portal.erp.tcode_launcher_iv?System=sapr3_sa&TCode=ZSPCO001&GuiType=WinGui&WinGui_Type=SSD&OkCode=ONLI&AutoStart=true&SupportsUnicodeCodePages=true&ApplicationParameter=ZTCODE={0};P_PERNR={1}", strTCode, strUserId);
                }
                else if (strGubun.Equals("3"))
                {
                    strExcuteUrl = @"http://hiport.hhi.co.kr/irj/servlet/prt/portal/prtroot/pcd!3aportal_content!2fhhi!2frole!2fcom.hhi.portal.role.cp_w25_r!2fworkplace!2fcom.hhi.portal.erp.SMEN_iv?NavPathUpdate=false";
                }

                Response.Redirect(strExcuteUrl, false);
            }
            catch (Exception ex)
            {
                //Response.Redirect("" + ex.Message + "", false);
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }


        private HttpCookie issueLogonTicket(string strUserId, string strTicketIssuerURL)
        {
            CookieContainer cookCont = null;
            HttpCookie logonTicket = null;
            HttpWebRequest request;
            HttpWebResponse response;

            //First Request
            request = (HttpWebRequest)WebRequest.Create(strTicketIssuerURL);
            request.UserAgent = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; MS-RTC LM 8)";
            request.Method = "GET";
            request.CookieContainer = new CookieContainer();
            response = (HttpWebResponse)request.GetResponse();

            if (!response.StatusCode.ToString().Equals("OK"))
            {
                throw new Exception("hi port 접속에 실패하였습니다. 관리자에게 문의하십시오");
            }

            cookCont = request.CookieContainer;

            //Second Request
            request = (HttpWebRequest)WebRequest.Create(strTicketIssuerURL);
            request.UserAgent = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; MS-RTC LM 8)";
            request.Method = "POST";
            request.CookieContainer = cookCont;

            string postData = "command=ssologin&j_authscheme=default&j_password=&j_user=" + strUserId;
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] byte1 = encoding.GetBytes(postData);

            // Set the content type of the data being posted.
            request.ContentType = "application/x-www-form-urlencoded";

            // Set the content length of the string being posted.
            request.ContentLength = byte1.Length;

            Stream newStream = request.GetRequestStream();
            newStream.Write(byte1, 0, byte1.Length);
            response = (HttpWebResponse)request.GetResponse();

            if (!response.StatusCode.ToString().Equals("OK"))
            {
                throw new Exception("hi port 접속에 실패하였습니다. 관리자에게 문의하십시오");
            }

            foreach (Cookie cook in response.Cookies)
            {
                if (cook.Name == "MYSAPSSO2")
                {
                    logonTicket = new System.Web.HttpCookie(cook.Name);
                    logonTicket.Value = cook.Value;
                    logonTicket.Domain = cook.Domain;
                    logonTicket.Expires = cook.Expires;
                    logonTicket.Path = cook.Path;
                }
            }

            if (logonTicket == null)
            {
                throw new Exception("SAP 인증 토큰 발급에 실패하였습니다. 관리자에게 문의하십시오");
            }

            return logonTicket;
        }
    }
}