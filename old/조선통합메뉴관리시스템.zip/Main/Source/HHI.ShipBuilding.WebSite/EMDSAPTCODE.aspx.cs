﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Text;
using System.IO;

using NETSCredentialManagerLib;

namespace HHI.ShipBuilding.WebSite
{
    public partial class EMDSAPTCODE : System.Web.UI.Page
    {
        public string strParam = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Session.Add("IsSAPLogon", "N");
            }
        }

        protected void btnExecute_Click(object sender, EventArgs e)
        {
            InitPage();
        }

        private void InitPage()
        {
            try
            {
                string strTCode = Request.QueryString["TCODE"];
                string strAddParam = Request.QueryString["ADDPARAM"];

                strTCode = "ZSDKAR0079";

                if (string.IsNullOrWhiteSpace(strTCode))
                {
                    lblMessage.Text = "SAP TCODE 가 없습니다.";
                    return;
                }

                string strUserId = Request.QueryString["USERID"];    // txtUserId.Text;
                strUserId = "A376701";
                if (string.IsNullOrWhiteSpace(strUserId))
                {
                    lblMessage.Text = "SAP 사용자 ID 가 없습니다.";
                    return;
                }

                HttpCookie cook = null;

                string strUrl = string.Empty;
                string strUrl2 = string.Empty;
                string strOTP = string.Empty;

                // 세션에 SAP 로그인 여부 정보가 있는지 확인 하여, 최초에만 처리
                if (Session.Count == 0 || (Session["IsSAPLogon"] != null && !Session["IsSAPLogon"].ToString().Equals("Y")))
                {
                    Nets.IM.Common.CryptoProvider.TripleDES tdes = new Nets.IM.Common.CryptoProvider.TripleDES();
                    strOTP = tdes.Encrypt("sso.hhi.co.kr", strUserId);

                    //strUrl = "http://emdportal.hhi.co.kr/irj/portal?command=ssologin&param1=" + strOTP;
                    //strUrl = "http://emdportal.hhi.co.kr/irj/servlet/prt/portal/prtroot/hhiemd.sso.logon.hhiemdSsoLogin?command=ssologin&param1=" + strOTP;

                    strUrl = "http://emdportal.hhi.co.kr/irj/servlet/prt/portal/prtroot/hhiemd.sso.logon.hhiemdSsoLogin?param3=A376701";

                    //issueLogonTicket2(strUserId, strUrl);
                    //issueLogonTicket3(strUserId, "http://emdportal.hhi.co.kr/irj/portal");
                    //issueLogonTicket3(strUserId, "http://emdportal.hhi.co.kr/irj/servlet/prt/portal/prtroot/hhiemd.article.PCNotice");

                    cook = issueLogonTicket2(strUserId, strUrl);
                    Response.AppendCookie(cook);
                    Session.Add("IsSAPLogon", "Y");
                }

                //string strParam = "ZTCODE=" + strTCode + ";P_PERNR=" + strUserId;
                //if (!string.IsNullOrWhiteSpace(strAddParam))
                //{
                //    strParam += ";" + strAddParam;
                //}

                //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", "SetZTCODE(" + "\"" + strParam + "\"" + ");", true);

                strUrl = "http://emdportal.hhi.co.kr/irj/servlet/prt/portal/prtroot/hhiemd.sso.logon.hhiemdSsoLogin?param3=A376701";

                Response.Redirect(strUrl, false);

                cook = issueLogonTicket2(strUserId, strUrl);

                //strUrl = "http://emdportal.hhi.co.kr/irj/portal";
                //Response.Redirect(strUrl, false);

                //Response.Redirect(strUrl, false);

                //Response.Redirect("http://emdportal.hhi.co.kr/irj/servlet/prt/portal/prtroot/pcd!3aportal_content!2fhhiemd!2fqm!2fiviews!2fhhiemd.iv.EMDEXE?ApplicationParameter=ZTCODE=ZSDKAR0079;P_PERNR=A376701", false);
            }
            catch (Exception ex)
            {
                lblMessage.Text += ex.Message + "SAP 인증 토큰 발급에 실패하였습니다. 관리자에게 문의하십시오";
                //throw new Exception(ex.Message);
            }
        }

        private HttpCookie issueLogonTicket2(string strUserId, string strTicketIssuerURL)
        {
            CookieContainer cookCont = null;
            HttpCookie logonTicket = null;
            HttpWebRequest request;
            HttpWebResponse response;

            //First Request
            request = (HttpWebRequest)WebRequest.Create(strTicketIssuerURL);
            request.UserAgent = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; MS-RTC LM 8)";
            request.Method = "GET";
            request.CookieContainer = new CookieContainer();
            response = (HttpWebResponse)request.GetResponse();

            if (!response.StatusCode.ToString().Equals("OK"))
            {
                lblMessage.Text += "엔진기계 ERP 포탈 접속에 실패하였습니다. 관리자에게 문의하십시오.(1)";
            }

            cookCont = request.CookieContainer;

            //First Request
            request = (HttpWebRequest)WebRequest.Create("http://emdportal.hhi.co.kr/irj/portal");
            request.UserAgent = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; MS-RTC LM 8)";
            request.Method = "GET";
            request.CookieContainer = new CookieContainer();
            response = (HttpWebResponse)request.GetResponse();

            if (!response.StatusCode.ToString().Equals("OK"))
            {
                lblMessage.Text += "엔진기계 ERP 포탈 접속에 실패하였습니다. 관리자에게 문의하십시오.(1)";
            }

            cookCont = request.CookieContainer;

            //Second Request
            request = (HttpWebRequest)WebRequest.Create(strTicketIssuerURL);
            request.UserAgent = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; MS-RTC LM 8)";
            request.Method = "POST";
            request.CookieContainer = cookCont;

            //string postData = "command=ssologin&j_authscheme=default&j_password=&j_user=" + strUserId;
            string postData = "command=ssologin&j_authscheme=default&j_password=&j_username=" + strUserId;
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] byte1 = encoding.GetBytes(postData);

            // Set the content type of the data being posted.
            request.ContentType = "application/x-www-form-urlencoded";

            // Set the content length of the string being posted.
            request.ContentLength = byte1.Length;

            Stream newStream = request.GetRequestStream();
            newStream.Write(byte1, 0, byte1.Length);
            response = (HttpWebResponse)request.GetResponse();

            if (!response.StatusCode.ToString().Equals("OK"))
            {
                lblMessage.Text += "엔진기계 ERP 포탈 접속에 실패하였습니다. 관리자에게 문의하십시오.(2)";
            }

            foreach (Cookie cook in response.Cookies)
            {
                if (cook.Name == "MYSAPSSO2")
                {
                    logonTicket = new System.Web.HttpCookie(cook.Name);
                    logonTicket.Value = cook.Value;
                    logonTicket.Domain = cook.Domain;
                    logonTicket.Expires = cook.Expires;
                    logonTicket.Path = cook.Path;
                }
            }

            if (logonTicket == null)
            {
                lblMessage.Text += "SAP 인증 토큰 발급에 실패하였습니다. 관리자에게 문의하십시오.";
            }

            return logonTicket;
        }

        private HttpCookie issueLogonTicket(string strUserId, string strTicketIssuerURL)
        {
            CookieContainer cookCont = null;
            HttpCookie logonTicket = null;
            HttpWebRequest request;
            HttpWebResponse response;

            //First Request
            request = (HttpWebRequest)WebRequest.Create(strTicketIssuerURL);
            request.UserAgent = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; MS-RTC LM 8)";
            request.Method = "GET";
            request.CookieContainer = new CookieContainer();
            response = (HttpWebResponse)request.GetResponse();

            if (!response.StatusCode.ToString().Equals("OK"))
            {
                lblMessage.Text += "엔진기계 ERP 포탈 접속에 실패하였습니다. 관리자에게 문의하십시오.(1)";
            }

            cookCont = request.CookieContainer;

            //Second Request
            request = (HttpWebRequest)WebRequest.Create(strTicketIssuerURL);
            //request = (HttpWebRequest)WebRequest.Create("http://emdportal.hhi.co.kr/irj/portal");
            request.UserAgent = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; MS-RTC LM 8)";
            request.Method = "POST";
            request.CookieContainer = cookCont;

            //string postData = "command=ssologin&j_authscheme=default&j_password=&j_user=" + strUserId;
            string postData = "command=ssologin&j_authscheme=default&j_password=&j_username=" + strUserId;

            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] byte1 = encoding.GetBytes(postData);

            // Set the content type of the data being posted.
            request.ContentType = "application/x-www-form-urlencoded";

            // Set the content length of the string being posted.
            request.ContentLength = byte1.Length;

            Stream newStream = request.GetRequestStream();
            newStream.Write(byte1, 0, byte1.Length);
            response = (HttpWebResponse)request.GetResponse();

            if (!response.StatusCode.ToString().Equals("OK"))
            {
                lblMessage.Text += "엔진기계 ERP 포탈 접속에 실패하였습니다. 관리자에게 문의하십시오.(2)";
            }
           
            foreach (Cookie cook in response.Cookies)
            {
                if (cook.Name == "PortalAlias")
                {
                    logonTicket = new System.Web.HttpCookie(cook.Name);
                    logonTicket.Value = cook.Value;
                    logonTicket.Domain = cook.Domain;
                    logonTicket.Expires = cook.Expires;
                    logonTicket.Path = cook.Path;
                }
            }

            if (logonTicket == null)
            {
                lblMessage.Text += "SAP 인증 티켓 발급에 실패하였습니다. 관리자에게 문의하십시오.";
            }

            return logonTicket;
        }
    }
}