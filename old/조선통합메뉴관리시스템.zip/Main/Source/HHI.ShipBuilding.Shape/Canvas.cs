﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraTreeList.Nodes;
using HHI.ShipBuilding.Shape.CLS;
using DevExpress.XtraBars;
using System.Net;

namespace HHI.ShipBuilding.Shape
{
    public partial class Canvas : UserControl, IShapeEntity
    {
        readonly string ITEM_CONTROL_NAME = "Item";
        readonly string GROUPAREA_CONTROL_NAME = "GroupArea";

        public event EventHandler<ChangedCanvasEventArg> ChangedCanvas;
        /// <summary>
        /// Canvas 컨트롤에서 경고 메시지가 있음을 알린다.
        /// </summary>
        public event EventHandler<AlertMessageEventArg> AlertMessage;

        public event EventHandler<EventArgs> ChangedStaus = (obj, args) => { };

        #region -> Viewr 메뉴 클릭 이벤트
        public event EventHandler<ShapeMenuClickEventArg> ShapeMenuClick;

        public void DoShapeMenuClick(string menuId, string tcode)
        {
            OnShapeMenuClick(new ShapeMenuClickEventArg(menuId, tcode));
        }

        public virtual void OnShapeMenuClick(ShapeMenuClickEventArg e)
        {
            EventHandler<ShapeMenuClickEventArg> handler = ShapeMenuClick;

            if (handler != null)
            {
                handler(this, e);
            }
        }

        #endregion

        /// <summary>
        /// 캔버스에 존재하는 Shape UID
        /// </summary>
        public List<string> ExistShapesID = new List<string>();
        // SHAPE_ID 채번
        int shapeSequence = 0;
        // LINE_ID 채번
        int lineSequence = 0;

        public bool IsViewer = false;

        /// <summary>
        /// 영역에 그랴야 하는 선
        /// </summary>
        private List<Line> Lines = new List<Line>();

        /// <summary>
        /// 
        /// </summary>
        public List<ShapeBase> SelectedShapes = new List<ShapeBase>();

        /// <summary>
        /// Mouse Click 시점의 Screen 좌표값
        /// </summary>
        public Point WhenClickPoint = Point.Empty;

        /// <summary>
        /// 현재 Target Control
        /// </summary>
        public Control TargetControl = null;

        /// <summary>
        /// 현재 Canvas 상태
        /// </summary>
        public ENUM_STATUS_CANVAS Status = ENUM_STATUS_CANVAS.Released;

        /// <summary>
        /// 생성자
        /// </summary>
        public Canvas()
        {
            InitializeComponent();
            ShapeEvironments.Instance.SetResNames();
        }

        /// <summary>
        /// 화살표를 그린다.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            //e.Graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;

            // 선을 그린다.
            foreach (var l in Lines)
            {
                Pen myPen = new Pen(l.Color, l.Width);
                myPen.StartCap = System.Drawing.Drawing2D.LineCap.RoundAnchor;
                myPen.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
                e.Graphics.DrawLine(myPen, l.SPoint, l.EPoint);
            }
        }

        #region ▶ 사용자 정의 이벤트

        /// <summary>
        /// CANVAS 의 상태 변화를 알린다.
        /// </summary>
        protected void DoChangedCanvas()
        {
            Size s = Size.Empty;
            s.Height = s.Height + this.VerticalScroll.Maximum;
            s.Width = s.Width + this.HorizontalScroll.Maximum;
            canvas_Size = s.ToString();
            OnChangedShape(new ChangedCanvasEventArg(canvas_Id, canvas_Size, this.BackColor));
        }

        public virtual void OnChangedShape(ChangedCanvasEventArg e)
        {
            EventHandler<ChangedCanvasEventArg> handler = ChangedCanvas;

            if (handler != null)
            {
                handler(this, e);
            }
        }

        public void DoAlertMessage(string msg)
        {
            OnAlertMessage(new AlertMessageEventArg(msg)); // 
        }

        public virtual void OnAlertMessage(AlertMessageEventArg e)
        {
            EventHandler<AlertMessageEventArg> handler = AlertMessage;

            if (handler != null)
            {
                handler(this, e);
            }
            else
            {
                MessageBox.Show(e.AlertMessage);
            }
        }

        #endregion

        #region ▶ Canvas 데이터 생성 / 적재 / 삭제 / 저장

        /// <summary>
        /// 새로운 Canvas 을 만들기 위핸 CANVAS_ID 을 채번한다..
        /// </summary>
        /// <returns></returns>
        public bool NewCanvas()
        {
            if (string.IsNullOrEmpty(canvas_Id))
            {
                CANVAS_ID = Guid.NewGuid().ToString("N").ToUpper();
                return true;
            }
            else
                return false;
        }

        /// <summary>
        /// Cavas 을 Clear 한다.
        /// </summary>
        public void ClearCanvas()
        {
            this.Controls.Clear();
            this.Lines.Clear();
            ExistShapesID.Clear();
            SelectedShapes.Clear();
            CANVAS_ID = string.Empty;
            lblEmptyCanvas.Visible = true;
            Controls.Add(lblEmptyCanvas);

            shapeSequence = 0;
            lineSequence = 0;
        }

        /// <summary>
        /// 현재 Canvas 의 데이터를 가져온다.
        /// </summary>
        /// <param name="shapes"></param>
        /// <param name="lines"></param>
        public void GetCanvasData(ref List<IShapeEntity> shapes, ref List<ILineEntity> lines)
        {
            var items = from c in this.Controls.Find(ITEM_CONTROL_NAME, true)
                        where c is HHI.ShipBuilding.Shape.ShapeBase
                        select c;

            foreach (var shape in items)
                shapes.Add(shape as IShapeEntity);

            lines.AddRange(this.Lines);

            var groups = from c in this.Controls.Find(GROUPAREA_CONTROL_NAME, true)
                         where c is HHI.ShipBuilding.Shape.ShapeBase
                         select c;

            foreach (var shape in groups)
            {
                shapes.Add(shape as IShapeEntity);

                lines.AddRange((shape as GroupArea).Lines);
            }
        }

        /// <summary>
        /// 현재 Canvas 에 Shape와 Line 을 그린다. 이메서드는 요구되는 사전 작업이 있다.
        /// </summary>
        /// <param name="shapeDt"></param>
        /// <param name="lineDt"></param>
        /// <returns></returns>
        public bool LoadCanvasData(DataTable shapeDt, DataTable lineDt)
        {
            string preCheck = string.Empty;

            if (shapeSequence != 0)
            {
                preCheck = "shapeSequence 초기화";
            }
            else if (lineSequence != 0)
            {
                preCheck = "lineSequence 초기화";
            }
            else if (lblEmptyCanvas.Visible == true)
            {
                preCheck = "준비된 Canvas 상태";
            }
            else if (ExistShapesID.Count > 0)
            {
                preCheck = "Shape 유일값 체크 초기화";
            }

            // Debugging
            if (!string.IsNullOrEmpty(preCheck))
            {
                DoAlertMessage(preCheck + "가 선행되지 않았습니다.");
                return false;
            }

            // 부모 컨트롤을 찾기 위한 Dictionary
            Dictionary<string, ShapeBase> shapesDic = new Dictionary<string, ShapeBase>();

            foreach (DataRow dr in shapeDt.Rows) // 이미 데이터가 SHAPE_ID로 정렬되었다고 가정한다.
            {
                Control owner = null;
                dynamic shape = null;

                if (dr["P_SHAPE_ID"].ToString().Equals(canvas_Id, StringComparison.OrdinalIgnoreCase))
                {
                    owner = this;
                }
                else
                {
                    owner = shapesDic[dr["P_SHAPE_ID"].ToString()];
                }

                // shapeSequence 값을 넣어 로드 후 추가 되는 shape_id 의 채번을 계속 할 수 있게 한다.
                shapeSequence = Convert.ToInt32(dr["SHAPE_ID"].ToString());

                // 기존 메서드를 재사용한 후 추가 데이터 입력한다.
                if (dr["TYPE_ENTITY"].ToString().Equals(((int)ENUM_TYPE_ENTITY.ITEM).ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    shape = CreateItem(owner, Utils.StringToPoint(dr["SHAPE_LOC"].ToString()),
                                new DragAndDropItem(Convert.ToString(dr["SOURCE_ID"]), string.Empty),
                                shapeSequence);
                }

                if (dr["TYPE_ENTITY"].ToString().Equals(((int)ENUM_TYPE_ENTITY.GROUP_AREA).ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    shape = CreateGroupArea(owner, Utils.StringToPoint(dr["SHAPE_LOC"].ToString()),
                        shapeSequence);
                }

                if (shape != null)
                {
                    var s = (shape as ShapeBase);
                    shapesDic.Add(s.SHAPE_ID, s);
                    s.DESCRIPTION = Convert.ToString(dr["DESCRIPTION"]);
                    s.FONT_DESC = Convert.ToString(dr["FONT_DESC"]);
                    s.TYPE_ENTITY = Convert.ToInt32(dr["TYPE_ENTITY"]);
                    s.TYPE_SHAPE = Convert.ToInt32(dr["TYPE_SHAPE"]);
                    //s.SHAPE_LOC = "" 위에서 이미 입력됨.
                    s.SHAPE_SIZE = Convert.ToString(dr["SHAPE_SIZE"]);
                    s.RES_NAME = Convert.ToString(dr["RES_NAME"]); // 입력될때 백그라운드 이미지가 변경된다.
                    s.SOURCE_ID = Convert.ToString(dr["SOURCE_ID"]); // 아이템인 경우 이미 입력되어 있다.
                    s.EXTRA1 = Convert.ToString(dr["EXTRA1"]); // TCODE 값이 있는 경우

                    if (IsViewer)
                    {
                        if (s is Item)
                        {
                            if (string.IsNullOrEmpty(s.EXTRA1)) // TCODE 가 없다면 권한 체크
                            {
                                if (!ViewerVariables.Values.AuthMenuId.Contains(s.SOURCE_ID))
                                {
                                    s.EnableShape = false;
                                }
                            }
                        }
                    }

                    s.InitializedShapeDisplay();
                }
                
            }

            foreach (DataRow dr in lineDt.Rows)
            {
                // lineSequence 값을 넣어 로드 후 추가 되는 LINE_ID 의 채번을 계속 할 수 있게 한다.
                lineSequence = Convert.ToInt32(dr["LINE_ID"].ToString());

                var line = MakeLine(shapesDic[dr["START_ID"].ToString()], shapesDic[dr["END_ID"].ToString()], lineSequence);

                if (IsViewer)
                {
                    line.SPoint = Utils.StringToPoint(dr["SPOINT"].ToString());
                    line.EPoint = Utils.StringToPoint(dr["EPOINT"].ToString());
                }
                else
                {
                    line.GenPoints();
                }
            }

            shapesDic.Clear();
            return true;
        }

        #endregion ▶ Canvas 데이터 생성 / 적재 / 삭제 / 저장

        #region ▶ Shape 컨트롤 생성 / 소멸 관리

        // Shape 컨트롤을 생성하고 이벤트를 구독한다.
        private void CreateShape(Control owner, ref ShapeBase shape, Point p, int id = -1)
        {
            owner.Controls.Add(shape);
            shape.Location = p;
            shape.MyCanvas = this;

            string shapeId;
            if (id == -1)
                shapeId = (++shapeSequence).ToString();
            else
                shapeId = id.ToString();

            shape.SHAPE_ID = shapeId;
            shape.P_SHAPE_ID = (owner as IShapeEntity).SHAPE_ID;
            ExistShapesID.Add(shapeId);

            // 이벤트 구독
            shape.ChangedStatus += ctr_ChangedStatus;
            shape.ChangedShape += ctrl_ChangedShape;
            shape.AlertMessage += ctrl_AlertMessage;
            shape.Removing += ctrl_Removing;

            if (IsViewer)
            {
                if (shape is Item)
                {
                    (shape as Item).ShapeMenuClick += Canvas_ShapeMenuClick;
                }
            }
        }

        // 메뉴가 클릭 되었을을 알린다.
        void Canvas_ShapeMenuClick(object sender, ShapeMenuClickEventArg e)
        {
            if (sender is Item)
            {
                if ((sender as Item).EnableShape == false)
                {
                    return;
                }

            }
            DoShapeMenuClick(e.MenuId, e.TCODE);
        }

        // Item Shape 을 생성한 후 여러가지 초기화를 처리한다.
        private ShapeBase CreateItem(Control owner, Point p, DragAndDropItem menu, int id = -1)
        {
            ShapeBase ctr = new Item();
            CreateShape(owner, ref ctr, p, id);
            ctr.Size = Utils.StringToSize(DEF_TYPE_ENTITY_SIZE.ITEM);

            // 맨 앞으로
            ctr.BringToFront();
            
            var data = (ctr as Item);
            data.SourceId = menu.MenuId;
            data.SoucrceDesc = menu.DisplayText; // 빈값이 들어 오면 IShapeEntity 의 DESCRIPTION 값을 별도로 넣어 줘야 한다.

            if (id == -1) // Edit 작업중
            {
                ctr.TYPE_ENTITY = (int)CLS.ENUM_TYPE_ENTITY.ITEM;
                data.RES_NAME = ShapeEvironments.Instance.ListCircle[1];
            }
                
            return ctr;
        }

        // GroupArea Shape 을 생성한 후 여러가지 초기화를 처리한다.
        private ShapeBase CreateGroupArea(Control owner, Point p, int id = -1)
        {
            ShapeBase ctr = new GroupArea();
            CreateShape(owner, ref ctr, p, id);
            ctr.Size = Utils.StringToSize(DEF_TYPE_ENTITY_SIZE.GROUP_AREA);

            if (id == -1) // Edit 작업중
            {
                ctr.TYPE_ENTITY = (int)CLS.ENUM_TYPE_ENTITY.GROUP_AREA;
                var data = (ctr as ShapeBase);
                data.DESCRIPTION = "Group Area";

                if (owner.GetType().Equals(typeof(Canvas)))
                {
                    data.RES_NAME = ShapeEvironments.Instance.ListGroupArea[0];
                }
                else if (owner is GroupArea)
                {
                    
                    var ev = ShapeEvironments.Instance;
                    int ci = ev.ListGroupArea.FindIndex(x => (x == (owner as ShapeBase).RES_NAME));

                    if (ci == ev.ListGroupArea.Count - 1)
                    {
                        data.RES_NAME = ev.ListGroupArea[0];
                    }
                    else
                    {
                        data.RES_NAME = ev.ListGroupArea[ci + 1];
                    }
                }
            }
            
            return ctr;
        }

        // Shape 을 Canvas 에서 제거 한다.
        private void RemoveShape(ShapeBase ctrl)
        {
            var pCtrl = ctrl.Parent;
            
            try
            {
                ctrl.DoRemoving();
                pCtrl.Controls.Remove(ctrl);
            }
            catch
            {
                throw;
            }
            finally
            {
                List<Line> delLines = new List<Line>();
                foreach (var line in Lines)
                {
                    if (!line.IsValid(ExistShapesID))
                    {
                        delLines.Add(line);
                    }
                }

                if (delLines.Count > 0)
                {
                    delLines.ForEach(s => Lines.Remove(s));
                    Invalidate();
                }
            }
        }

        #region -> 사용자 정의 핸들러

        // SHAPE STATUS 상태 변경시 CANVAS 에 상태 전송
        private void ctr_ChangedStatus(object sender, EventArgs e)
        {
            var shape = (sender as ShapeBase);
            if ((int)shape.MyCanvas.Status < (int)shape.Status)
                shape.MyCanvas.Status = (ENUM_STATUS_CANVAS)shape.Status;

            switch (shape.Status)
            {
                case ENUM_STATUS_SHAPE.Released :
                    SelectedShapes.Remove(shape);
                    break;
                case ENUM_STATUS_SHAPE.Selected :
                    SelectedShapes.Add(shape);
                    break;
            }

            ChangedStaus(sender, e);
        }

        // SHAPE 위치 / 크기 변경시 CANVAS 에 상태 전송
        private void ctrl_ChangedShape(object sender, ChangedShapeEventArg e)
        {
            var pCtrl = e.Parent;

            if (pCtrl is Canvas)
            {
                foreach (var line in Lines)
                    line.GenPoints();
            }
            else if (pCtrl is GroupArea)
            {
                foreach (var line in (pCtrl as GroupArea).Lines)
                    line.GenPoints();
            }

            pCtrl.Invalidate();
            pCtrl.Update();
        }

        // 각 Shape 에서 발생한 경고 메시지 처리
        private void ctrl_AlertMessage(object sender, AlertMessageEventArg e)
        {
            string addMsg = string.Empty;
            if (sender is GroupArea)
            {
                addMsg = (sender as ShapeBase).DESCRIPTION + " 그룹";
            }
            else if (sender is Item)
            {
                addMsg = (sender as Item).MenuId + " 메뉴";
            }

            DoAlertMessage(e.AlertMessage + " 대상:" + addMsg);
        }

        void ctrl_Removing(object sender, RemovingEventArg e)
        {
            ExistShapesID.Remove(e.ID);
        }

        #endregion

        #endregion

        #region ▶ Drag & Drop 시 처리
        private void Canvas_DragDrop(object sender, DragEventArgs e)
        {
            if (IsViewer)
                return;

            if (e.Data == null)
                return;

            TreeListNode node = (TreeListNode)e.Data.GetData(typeof(TreeListNode));

            if (node == null)
                return;

            Point p = MousePosition;

            var pCtrl = GetGroupAreaWithCursor(p);

            var dropData = DragAndDropItem.Instance;

            ShapeBase shape;
             
            if (pCtrl == null)
            {
                shape = CreateItem(this, this.PointToClient(p), dropData);
            }
            else
            {
                shape = CreateItem(pCtrl, pCtrl.PointToClient(p), dropData);
            }

            shape.InitializedShapeDisplay();
        }

        private void Canvas_DragEnter(object sender, DragEventArgs e)
        {
            if (IsViewer)
                return;

            if (e.Data == null)
                return;

            TreeListNode node = (TreeListNode)e.Data.GetData(typeof(TreeListNode));

            if (node == null)
                return;

            Cursor.Current = Utils.CreateCursor(HHI.ShipBuilding.Resources.ShapeImage.Circle_01, 0, 0);
        }

        private void Canvas_DragOver(object sender, DragEventArgs e)
        {
            if (IsViewer)
                return;

            e.Effect = DragDropEffects.Move;
        }

        #endregion

        #region ▶ Mouse Event 처리


        private void Canvas_MouseClick(object sender, MouseEventArgs e)
        {
            if (IsViewer)
                return;

            if (e.Clicks == 1 && e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                WhenClickPoint = MousePosition;
                popupMenu1.ShowPopup(WhenClickPoint);
            }
            else
            {
                ReleaseSelectedStatus(this);
            }
        }

        #endregion

        #region ▶ Popup 메뉴에서 각 메뉴 클릭시 처리와 BeforePopup

        // Popup 메뉴가 열리기 전 상태 지정
        private void popupMenu1_BeforePopup(object sender, CancelEventArgs e)
        {
            if (IsViewer)
                return;

            foreach (var btn in popupMenu1.ItemLinks)
            {
                (btn as BarButtonItemLink).Item.Enabled = false;
            }

            TargetControl = GetShapeWithCursor(WhenClickPoint);

            if (Status == ENUM_STATUS_CANVAS.Bridge)
            {
                btnStartLine.Visibility = BarItemVisibility.Never;
                btnEndLine.Visibility = BarItemVisibility.Always;
                btnMoveLine.Visibility = BarItemVisibility.Always;
                btnDeleteLine.Visibility = BarItemVisibility.Always;
            }
            else
            {
                btnStartLine.Visibility = BarItemVisibility.Always;
                btnEndLine.Visibility = BarItemVisibility.Never;
                btnMoveLine.Visibility = BarItemVisibility.Never;
                btnDeleteLine.Visibility = BarItemVisibility.Never;
            }

            if (TargetControl == null)
            {
                btnCreateGroup.Enabled = true;
                btnCreateTCODE.Enabled = true;
            }
            else
            {
                if (TargetControl.GetType().Equals(typeof(GroupArea)))
                {
                    btnCreateGroup.Enabled = true;
                    btnCreateTCODE.Enabled = true;
                    btnDeleteShape.Enabled = true;
                    btnEditText.Enabled = true;
                    btnStartLine.Enabled = true;
                    btnEndLine.Enabled = true;
                    btnMoveLine.Enabled = true;
                    btnDeleteLine.Enabled = true;
                }
                else if (TargetControl.GetType().Equals(typeof(Item)))
                {
                    btnCreateGroup.Enabled = true;
                    btnCreateTCODE.Enabled = true;
                    btnDeleteShape.Enabled = true;
                    btnEditText.Enabled = true;
                    btnStartLine.Enabled = true;
                    btnEndLine.Enabled = true;
                    btnMoveLine.Enabled = true;
                    btnDeleteLine.Enabled = true;
                    btnTransform.Enabled = true;
                }

                if (Status == ENUM_STATUS_CANVAS.Selected)
                {
                    if ((TargetControl as ShapeBase).Status == ENUM_STATUS_SHAPE.Selected)
                    {
                        btnAlignTop.Enabled = true;
                        btnAlignLeft.Enabled = true;
                        btnAlignVCenter.Enabled = true;
                        btnAlignHCenter.Enabled = true;
                    }
                }
                
            }
        }

        // Create Group
        private void btnCreateGroup_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            var pCtrl = GetGroupAreaWithCursor(WhenClickPoint);
            ShapeBase shape;
            if (pCtrl == null)
            {
                shape = CreateGroupArea(this, this.PointToClient(WhenClickPoint));
                shape.MyCanvas = this;
            }
            else
            {
                shape = CreateGroupArea(pCtrl, pCtrl.PointToClient(WhenClickPoint));
                shape.MyCanvas = this;
            }
            shape.InitializedShapeDisplay();
            
        }

        // Delete Shape
        private void btnDeleteShape_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            RemoveShape(TargetControl as ShapeBase);
        }

        // Start Line
        private void btnStartLine_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            ReleaseSelectedStatus(this); // Canvas에 있는 모든 컨트롤 상태 해제
            (TargetControl as ShapeBase).Status = ENUM_STATUS_SHAPE.Selected; // 라인이 시작될 곳은 Selected 상태 표시
            btnStartLine.Tag = TargetControl; // 시작 라인이된 컨트롤 임시 저장
            SetLineStatus(); // 화살표로 연결할 대상이 되는 컨트롤을 사용자에게 표시
        }

        // End Line -> 이곳에서 라인 데이터를 만든다.
        private void btnEndLine_ItemClick(object sender, ItemClickEventArgs e)
        {
            if ((TargetControl as ShapeBase).Status == ENUM_STATUS_SHAPE.Bridge)
            {
                var line = MakeLine(btnStartLine.Tag as Control, TargetControl, ++lineSequence);

                if (line != null)
                    line.GenPoints();
            }
            
            ReleaseSelectedStatus(this);
        }

        private void btnMoveLine_ItemClick(object sender, ItemClickEventArgs e)
        {
            if ((TargetControl as ShapeBase).Status == ENUM_STATUS_SHAPE.Bridge)
            {
                var pCtrl = (TargetControl as ShapeBase).Parent;
                Line line;
                if (pCtrl is GroupArea)
                {
                    var ga = (pCtrl as GroupArea);

                    line = ga.Lines.FirstOrDefault(s => s.START_ID == (btnStartLine.Tag as ShapeBase).SHAPE_ID && s.END_ID == (TargetControl as ShapeBase).SHAPE_ID);
                }
                else
                {
                    line = this.Lines.FirstOrDefault(s => s.START_ID == (btnStartLine.Tag as ShapeBase).SHAPE_ID && s.END_ID == (TargetControl as ShapeBase).SHAPE_ID);
                }

                if (line == null)
                    return;

                line.ChangeAnchor();
                this.Invalidate();
            }

            //ReleaseSelectedStatus(this);
        }

        // Delete Line
        private void btnDeleteLine_ItemClick(object sender, ItemClickEventArgs e)
        {
            if ((TargetControl as ShapeBase).Status == ENUM_STATUS_SHAPE.Bridge)
            {
                DeleteLine((TargetControl as ShapeBase).Parent, (btnStartLine.Tag as ShapeBase).SHAPE_ID, (TargetControl as ShapeBase).SHAPE_ID);
            }

            ReleaseSelectedStatus(this);
        }

        private Line MakeLine(Control start, Control end, int lineId)
        {
            var pCtrl = start.Parent;
            Line line;
            if (pCtrl is GroupArea)
            {
                line = new Line(start as ShapeBase, end as ShapeBase);
                var entity = (line as ILineEntity);
                entity.CANVAS_ID = canvas_Id;
                entity.SHAPE_ID = (pCtrl as ShapeBase).SHAPE_ID;

                entity.LINE_ID = lineId.ToString();    

                entity.Color = DEF_LINE_ENTITY.Color;
                entity.Width = DEF_LINE_ENTITY.Width;

                (pCtrl as GroupArea).Lines.Add(line);
            }
            else
            {
                line = new Line(start as ShapeBase, end as ShapeBase);
                var entity = (line as ILineEntity);
                entity.CANVAS_ID = canvas_Id;
                entity.SHAPE_ID = canvas_Id;

                if (lineId == -1)
                    entity.LINE_ID = (++lineSequence).ToString();
                else
                    entity.LINE_ID = lineId.ToString();
                entity.Color = DEF_LINE_ENTITY.Color;
                entity.Width = DEF_LINE_ENTITY.Width;

                Lines.Add(line);
            }

            return line;
        }

        private void DeleteLine(Control owner, string startId, string endId)
        {
            var pCtrl = owner.Parent;

            if (pCtrl is GroupArea)
            {
                var ga = (pCtrl as GroupArea);

                var line = ga.Lines.FirstOrDefault(s => s.START_ID == startId && s.END_ID == endId);

                if (line == null)
                    return;

                ga.Lines.Remove(line);
            }
            else
            {
                var line = this.Lines.FirstOrDefault(s => s.START_ID == startId && s.END_ID == endId);

                if (line == null)
                    return;

                this.Lines.Remove(line);
            }
        }

        // Edit Text
        private void btnEditText_ItemClick(object sender, ItemClickEventArgs e)
        {
            (TargetControl as ShapeBase).DoShowTextBox();
        }

        // Transform
        private void btnTransform_ItemClick(object sender, ItemClickEventArgs e)
        {
            string resName = string.Empty;

            dynamic ctrl;
            if (TargetControl is Item)
            {
                ctrl = (TargetControl as Item);
                
            }
            else if (TargetControl is GroupArea)
            {
                ctrl = (TargetControl as GroupArea);
            }
            else
            {
                return;
            }

            var st = ctrl.CurrentShapeTypes.GetEnumerator();
            string cName = st.Current;
            st.MoveNext();

            // RES_NAME 에 입력되면 컨트롤의 백그라운드 이미지가 변경된다.
            ctrl.RES_NAME = ctrl.RES_NAME.Replace(cName, st.Current);
            ctrl.TYPE_SHAPE = st.Position;
        }

        // Align Top
        private void btnAlignTop_ItemClick(object sender, ItemClickEventArgs e)
        {
            int y = TargetControl.Location.Y;
            for (int i = 0; i < SelectedShapes.Count; i++)
            {
                SelectedShapes[i].Location = new Point(SelectedShapes[i].Location.X, y);
            }
        }

        // Align Left
        private void btnAlignLeft_ItemClick(object sender, ItemClickEventArgs e)
        {
            int x = TargetControl.Location.X;

            for (int i = 0; i < SelectedShapes.Count; i++)
            {
                SelectedShapes[i].Location = new Point(x, SelectedShapes[i].Location.Y);
            }
        }

        private void btnAlignVCenter_ItemClick(object sender, ItemClickEventArgs e)
        {
            int y = Utils.GetAnchorPoint(ENUM_ANCHOR_POINT.LEFT, (TargetControl as ShapeBase).MyPointRect).Y;
            int sy = 0;
            for (int i = 0; i < SelectedShapes.Count; i++)
            {
                sy = y - Utils.GetAnchorPoint(ENUM_ANCHOR_POINT.LEFT, SelectedShapes[i].MyPointRect).Y;
                SelectedShapes[i].Location = new Point(SelectedShapes[i].Location.X, SelectedShapes[i].Location.Y + sy);
            }
        }

        private void btnAlignHCenter_ItemClick(object sender, ItemClickEventArgs e)
        {
            int x = Utils.GetAnchorPoint(ENUM_ANCHOR_POINT.UP, (TargetControl as ShapeBase).MyPointRect).X;
            int sx = 0; 
            for (int i = 0; i < SelectedShapes.Count; i++)
            {
                sx = x - Utils.GetAnchorPoint(ENUM_ANCHOR_POINT.UP, SelectedShapes[i].MyPointRect).X;
                SelectedShapes[i].Location = new Point(SelectedShapes[i].Location.X + sx, SelectedShapes[i].Location.Y);
            }
        }

        // Create TCODE
        private void btnCreateTCODE_ItemClick(object sender, ItemClickEventArgs e)
        {
            var pCtrl = GetGroupAreaWithCursor(WhenClickPoint);
            ShapeBase shape;
            if (pCtrl == null)
            {
                shape = CreateItem(this, this.PointToClient(WhenClickPoint), new DragAndDropItem("SCSYS014", "TCODE MENU"));
                shape.MyCanvas = this;
            }
            else
            {
                shape = CreateItem(pCtrl, pCtrl.PointToClient(WhenClickPoint), new DragAndDropItem("SCSYS014", "TCODE MENU"));
                shape.MyCanvas = this;
            }
            
            shape.InitializedShapeDisplay();
        }

        #endregion

        #region ▶ Shape 들도 사용하는 노출되는 메서드

        /// <summary>
        /// 마우스 커서가 있는 그룹영역 컨트롤이 있으면 가져온다.
        /// </summary>
        /// <param name="screenPoint"></param>
        /// <returns></returns>
        public Control GetGroupAreaWithCursor(Point screenPoint)
        {
            var groups = from c in Controls.Find(GROUPAREA_CONTROL_NAME, true)
                         where c is HHI.ShipBuilding.Shape.ShapeBase
                         select c;

            //int t = groups.Where(c => c.Bounds.Contains(c.Parent.PointToClient(screenPoint))).Count();
            //System.Diagnostics.Debug.WriteLine(t.ToString());

            var pCtrl = groups.Where(c => c.Bounds.Contains(c.Parent.PointToClient(screenPoint))).LastOrDefault();
            
            return pCtrl;
        }

        /// <summary>
        /// 마우스 커서가 있는 Shape 컨트롤이 있으면 가져온다.
        /// </summary>
        /// <param name="screenPoint"></param>
        /// <returns></returns>
        public Control GetShapeWithCursor(Point screenPoint)
        {
            var pCtrl = GetGroupAreaWithCursor(screenPoint);

            IEnumerable<Control> Items;
            if (pCtrl == null)
            {
                Items = from c in Controls.Find(ITEM_CONTROL_NAME, false)
                         where c is HHI.ShipBuilding.Shape.ShapeBase
                         select c;
            }
            else
            {
                Items = from c in pCtrl.Controls.Find(ITEM_CONTROL_NAME, false)
                         where c is HHI.ShipBuilding.Shape.ShapeBase
                         select c;
            }

            if (Items.Count() == 0)
            {
                return pCtrl;
            }
            else
            {
                var ctrl = Items.Where(c => c.Bounds.Contains(c.Parent.PointToClient(screenPoint))).LastOrDefault();

                if (ctrl == null)
                {
                    return pCtrl;
                }

                return ctrl;
            }
            
        }

        /// <summary>
        /// 대상 컨트롤의 자식들의 상태를 모두 해제한다.
        /// </summary>
        public void ReleaseSelectedStatus(Control owner)
        {
            if (owner == null)
                return;

            var items = from c in owner.Controls.Find(ITEM_CONTROL_NAME, true)
                        where c is HHI.ShipBuilding.Shape.ShapeBase
                        select c;

            var groups = from c in owner.Controls.Find(GROUPAREA_CONTROL_NAME, true)
                         where c is HHI.ShipBuilding.Shape.ShapeBase
                         select c;

            foreach (var m in items)
            {
                (m as ShapeBase).Status = ENUM_STATUS_SHAPE.Released;
            }

            foreach (var m in groups)
            {
                (m as ShapeBase).Status = ENUM_STATUS_SHAPE.Released;
            }

            // Canvas 일 경우
            if (owner.GetType().Equals(typeof(Canvas)))
            {
                btnStartLine.Tag = null;
                this.Status = ENUM_STATUS_CANVAS.Released;
            }
            owner.Invalidate();
            owner.Update();
        }

        #endregion

        #region ▶ 전역 상태 변화

        // LINE 연결 가능한 컨트롤 활성화
        private void SetLineStatus()
        {
            var pCtrl = TargetControl.Parent;

            foreach (var shape in pCtrl.Controls)
            {
                if (!(shape is ShapeBase))
                    continue;

                if ((shape as ShapeBase).Status == ENUM_STATUS_SHAPE.Selected)
                    continue;

                (shape as ShapeBase).Status = ENUM_STATUS_SHAPE.Bridge;
            }
        }

        /// <summary>
        /// Viewer 용도로 사용함을 알린다.
        /// </summary>
        public void SetViewer()
        {
            IsViewer = true;
        }

        #region -> DoChangedCanvas();

        //public override Color BackColor
        //{
        //    get
        //    {
        //        return base.BackColor;
        //    }
        //    set
        //    {
        //        base.BackColor = value;
        //        DoChangedCanvas();
        //    }
        //}

        private void Canvas_Scroll(object sender, ScrollEventArgs e)
        {
            DoChangedCanvas();
        }

        private void Canvas_SizeChanged(object sender, EventArgs e)
        {
            DoChangedCanvas();
        }

        #endregion
        #endregion

        #region ▶ IDataEntity 구현

        private string canvas_Id = string.Empty;
        /// <summary>
        /// Canvas ID
        /// </summary>
        public string CANVAS_ID 
        { 
            get
            {
                return canvas_Id;
            }
            set
            {
                bool IdCahnged = false;

                if (canvas_Id != value)
                {
                    IdCahnged = true;
                }

                canvas_Id = value;

                if (IdCahnged)
                {
                    if (canvas_Id == string.Empty)
                    {
                        canvas_Size = string.Empty;
                    }
                    else
                    {
                        canvas_Size = this.Size.ToString();
                    }
                    DoChangedCanvas();
                }
            }
        }
        /// <summary>
        /// Shape ID (Canvas ID 와 같다.)
        /// </summary>
        public string SHAPE_ID 
        { 
            get
            {
                return canvas_Id;
            }
            set
            {
                canvas_Id = value;
            }
        }

        /// <summary>
        /// 부모의 Shape ID
        /// </summary>
        public string P_SHAPE_ID { get; set; }

        /// <summary>
        /// Text
        /// </summary>
        public string DESCRIPTION { get; set; }

        public string FONT_DESC { get; set; }

        /// <summary>
        /// TYPE_ENTITY 열거형 값 (CANVAS = 0, GROUP_AREA = 1, ITEM = 2)
        /// </summary>
        public int TYPE_ENTITY { get; set; }

        /// <summary>
        /// TYPE_SHAPE 열거형 값 (Circle = 0, Rectangle = 1)
        /// </summary>
        public int TYPE_SHAPE { get; set; }

        private string canvas_Loc = string.Empty;
        /// <summary>
        /// Location 값 (Canvas 인 경우 "0,0")
        /// </summary>
        public string SHAPE_LOC 
        { 
            get
            {
               return string.Empty;
            }
            set
            {
                // Empty
            }
        }

        private string canvas_Size = string.Empty;

        /// <summary>
        /// Size 값 (Canvas 영역)
        /// </summary>
        public string SHAPE_SIZE 
        { 
            get
            {
                return canvas_Size;
            }
            set
            {
                canvas_Size = value;
            }
        }

        public string RES_NAME { get; set; }

        public string SOURCE_ID { get; set; }

        public string EXTRA1 { get; set; }
        #endregion

        #region ▶ 윈도우 기본 컨트롤 이벤트 처리
        private void Canvas_BackColorChanged(object sender, EventArgs e)
        {
            DoChangedCanvas();
        }
        #endregion

    }
}
