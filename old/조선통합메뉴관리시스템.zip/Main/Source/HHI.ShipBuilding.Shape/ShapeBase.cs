﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HHI.ShipBuilding.Shape.CLS;
using HHI.ShipBuilding.Resources;

namespace HHI.ShipBuilding.Shape
{
    /// <summary>
    /// Shape 컨트롤 기본 개체
    /// </summary>
    public partial class ShapeBase : UserControl, IShapeEntity
    {
        #region -> 사용자 정의 이벤트
        /// <summary>
        /// Shape 컨트롤의 TextBox 를 보이기 전에 발생한다.
        /// </summary>
        public event EventHandler<EventArgs> ShowTextBox;

        /// <summary>
        /// SHAPE STATUS 상태 변경시 발생한다.
        /// </summary>
        public event EventHandler<EventArgs> ChangedStatus;

        /// <summary>
        /// Shape 컨트롤의 위치또는 크기가 변했을때 발생한다.
        /// </summary>
        public event EventHandler<ChangedShapeEventArg> ChangedShape;

        /// <summary>
        /// Shape 컨트롤에서 경고 메시지가 있음을 알린다.
        /// </summary>
        public event EventHandler<AlertMessageEventArg> AlertMessage;

        /// <summary>
        /// Shape 컨트롤 자신이 부모 컨트롤에서 제거됨을 알린다.
        /// </summary>
        public event EventHandler<RemovingEventArg> Removing;

        /// <summary>
        /// Shape 컨트롤 자신이 부모 컨트롤에서 제거되었음을 알린다.
        /// </summary>
        protected event EventHandler<EventArgs> Removed;

        #endregion

        /// <summary>
        /// 부모에서 제거 되어도 이전 부모가 누구 인지 마지막 이벤트 발생시에 반환하기 위하여
        /// </summary>
        private Control parentControl = null;

        // 영역 값
        private PointRect myPointRect = PointRect.Empty;

        /// <summary>
        /// Shape 에서 처리되는 마우스 커서의 변경전값
        /// </summary>
        protected Cursor preCursor = Cursors.Default;

        /// <summary>
        /// Shape 컨트롤이 이동하거나 크기가 변경되기 전의 좌표값
        /// </summary>
        protected PointRect movingSRect = PointRect.Empty;

        /// <summary>
        /// Shape 컨트롤이 이동하기 위한 변위 기준값 (실제 컨트롤 Location 가 아니라 마우스 커서 위치다.)
        /// </summary>
        protected Point movingSPoint = Point.Empty;

        /// <summary>
        /// Shape 컨트롤의 현재 상태값 (기본 Released 상태)
        /// </summary>
        protected ENUM_STATUS_SHAPE status = ENUM_STATUS_SHAPE.Released;

        /// <summary>
        /// Shape 의 최소 사이즈 제한 (기본 50 pixel 로 되어 있다.)
        /// </summary>
        protected int SmallSizeLimit = 50;

        // 부모 Canvas
        private Canvas myCanvas = null;

        /// <summary>
        /// Shape 가 있는 Canvas (입력시 CANVAS_ID 값이 입력 된다.)
        /// </summary>
        public Canvas MyCanvas
        {
            get
            {
                return myCanvas;
            }
            set
            {
                myCanvas = value;
                CANVAS_ID = myCanvas.CANVAS_ID;
            }
        }

        /// <summary>
        /// Shape 컨트롤의 상태를 가져오거나 지정한다.
        /// </summary>
        public ENUM_STATUS_SHAPE Status
        {
            get
            {
                return status;
            }
            set
            {
                SetResizebarVisible(value);
                DoChangedStatus();
                Refresh();
            }
        }

        /// <summary>
        /// 현재 컨트롤의 왼쪽 위와 아래 오른쪽 좌표값
        /// </summary>
        public PointRect MyPointRect
        {
            get
            {
                return myPointRect;
            }
        }

        /// <summary>
        /// Shape 컨트롤의 형태
        /// </summary>
        public CircularItems<string> CurrentShapeTypes
        {
            get;
            set;
        }

        /// <summary>
        /// 권한이 있는지 여부
        /// </summary>
        private bool enableShape = true;

        /// <summary>
        /// 권한이 있는지 여부를 지정하거나 가져온다.
        /// 화면이 보여질때 결정되고 이후 변경하지 않는다.
        /// </summary>
        public bool EnableShape
        {
            get
            {
                return enableShape;
            }
            set
            {
                enableShape = value;

                var ct1 = CurrentShapeTypes.GetEnumerator();
                if (enableShape == false)
                {
                    RES_NAME = ct1.Current + "_" + ShapeEvironments.Instance.DisableResName;
                }
            }
        }

        public ShapeFont MyDescFont = null;

        /// <summary>
        /// 생상자 : BorderStyle.None, SHAPE_STATUS.Released 상태로 초기화한다.
        /// </summary>
        public ShapeBase()
        {
            InitializeComponent();

            /** 생성 초기화 시작**/
            this.BorderStyle = System.Windows.Forms.BorderStyle.None;
            SetResizebarVisible(ENUM_STATUS_SHAPE.Released);
            /** 생성 초기화 끝**/
        }

        // 일단 한번만 호출 하는거로 처리
        int InitializedShapeDisplayCount = 0;

        /// <summary>
        /// 화면 초기화가 된 후 처리
        /// </summary>
        public virtual void InitializedShapeDisplay()
        {
            System.Diagnostics.Debug.Assert(TYPE_ENTITY == 0 ? false : true, "TypeEntity 을 지정해야 합니다.");
            System.Diagnostics.Debug.Assert(MyDescFont == null ? false : true, "MyDescFont 을 지정해야 합니다.");
            System.Diagnostics.Debug.Assert(InitializedShapeDisplayCount < 1, "Shape 화면 초기화는 최초 한번만 가능합니다.");
            MyDescFont.SetShapeFontToControl();
            InitializedShapeDisplayCount++;
        }

        // Paint
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (status == ENUM_STATUS_SHAPE.Selected)
            {
                ControlPaint.DrawBorder(e.Graphics, this.ClientRectangle, Color.OrangeRed, ButtonBorderStyle.Dashed);
            }
            else if (status == ENUM_STATUS_SHAPE.Bridge)
            {
                ControlPaint.DrawBorder(e.Graphics, this.ClientRectangle, Color.DodgerBlue, ButtonBorderStyle.Dashed);
            }
            else
            {

            }
        }

        #region ▶ 사용자 정의 이벤트 처리 -----------*

        /// <summary>
        /// Shape 컨트롤의 입력 텍스트 박스가 나타나야 함을 알린다.
        /// </summary>
        public void DoShowTextBox()
        {
            OnShowTextBox(new EventArgs());
        }

        /// <summary>
        /// Shape 컨트롤의 상태값이 변경되었음을 알린다.
        /// </summary>
        public void DoChangedStatus()
        {
            OnChangedStatus(new EventArgs()); // 상태 변경을 
        }

        protected void DoChangedShape(Control parent)
        {
            OnChangedShape(new ChangedShapeEventArg(parent)); // 위치, 크기 변경
        }

        public void DoAlertMessage(string msg)
        {
            OnAlertMessage(new AlertMessageEventArg(msg)); // 
        }

        /// <summary>
        /// 컨트롤이 제거할려고 함을 알린다.
        /// </summary>
        public void DoRemoving()
        {
            OnRemoving(new RemovingEventArg(this.SHAPE_ID));
        }
        

        protected virtual void OnShowTextBox(EventArgs e)
        {
            EventHandler<EventArgs> handler = ShowTextBox;

            if (handler != null)
            {
                handler(this, e);
            }
        }

        public virtual void OnChangedStatus(EventArgs e)
        {
            EventHandler<EventArgs> handler = ChangedStatus;

            if (handler != null)
            {
                handler(this, e);
            }
        }

        public virtual void OnChangedShape(ChangedShapeEventArg e)
        {
            EventHandler<ChangedShapeEventArg> handler = ChangedShape;

            if (handler != null)
            {
                handler(this, e);
            }
        }

        public virtual void OnAlertMessage(AlertMessageEventArg e)
        {
            EventHandler<AlertMessageEventArg> handler = AlertMessage;

            if (handler != null)
            {
                handler(this, e);
            }
        }

        /// <summary>
        /// 컨트롤이 제거되기 전에 처리할 핸들러
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnRemoving(RemovingEventArg e)
        {
            EventHandler<RemovingEventArg> handler = Removing;

            if (handler != null)
            {
                handler(this, e);
            }

            if (this.HasChildren)
            {
                foreach (var c in Controls)
                {
                    if (c is ShapeBase)
                        (c as ShapeBase).DoRemoving();
                }
            }

            if (this.Parent != null && this.Parent is GroupArea)
            {
                var g = this.Parent as GroupArea;

                List<Line> delLines = new List<Line>();
                foreach (var line in g.Lines)
                {
                    if (!line.IsValid(myCanvas.ExistShapesID))
                    {
                        delLines.Add(line);
                    }
                }

                if (delLines.Count > 0)
                {
                    delLines.ForEach(s => g.Lines.Remove(s));
                }
            }
        }

        protected virtual void OnRemoved(EventArgs e)
        {
            EventHandler<EventArgs> handler = Removed;

            if (handler != null)
            {
                handler(this, e);
            }
        }

        #endregion

        #region ▶ 사이즈 조절
        private void pnlAll_MouseHover(object sender, EventArgs e)
        {
            if (status != ENUM_STATUS_SHAPE.Selected)
                return;
            var pnl = sender as Panel;
            preCursor = Cursor.Current;
            switch(pnl.Name.Substring(3).ToLower())
            {
                // Bar
                case "right" :
                    Cursor = Cursors.SizeWE;
                    break;
                case "left":
                    Cursor = Cursors.SizeWE;
                    break;
                case "up":
                    Cursor = Cursors.SizeNS;
                    break;
                case "down":
                    Cursor = Cursors.SizeNS;
                    break;

                // Edge
                case "rightup":
                    Cursor = Cursors.SizeNESW;
                    break;
                case "rightdown":
                    Cursor = Cursors.SizeNWSE;
                    break;
                case "leftup":
                    Cursor = Cursors.SizeNWSE;
                    break;
                case "leftdown":
                    Cursor = Cursors.SizeNESW;
                    break;
            }
        }

        private void pnlAll_MouseDown(object sender, MouseEventArgs e)
        {
            if (status != ENUM_STATUS_SHAPE.Selected)
                return;

            var pnl = sender as Panel;

            /* 이전 정보들 저장 */
            preCursor = Cursor.Current;
            movingSPoint = new Point(e.X, e.Y);
            movingSRect = new PointRect(this.Location, this.Width, this.Height);
            /********************/

            switch (pnl.Name.Substring(3).ToLower())
            {
                // Bar
                case "right":
                case "left":
                    Cursor = Cursors.SizeWE;
                    break;
                case "up":
                case "down":
                    Cursor = Cursors.SizeNS;
                    break;

                // Edge
                case "rightup":
                case "leftdown":
                    Cursor = Cursors.SizeNESW;
                    break;
                case "leftup":
                case "rightdown":
                    Cursor = Cursors.SizeNWSE;
                    break;
                
            }
        }

        private void pnlAll_MouseMove(object sender, MouseEventArgs e)
        {
            if (status != ENUM_STATUS_SHAPE.Selected)
                return;

            if (movingSPoint == Point.Empty)
                return;

            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                var pnl = sender as Panel;
                int movedValue = 0;
                switch (pnl.Name.Substring(3).ToLower())
                {
                    // Bar
                    case "right":
                        Cursor = Cursors.SizeWE;
                        {
                            movedValue = (e.X - movingSPoint.X);

                            if (SmallSizeLimit > (this.Width + movedValue))
                                return;

                            this.Width = this.Width + movedValue;
                        }
                        break;
                    case "left":
                        Cursor = Cursors.SizeWE;
                        {
                            movedValue = this.Left + e.X - movingSPoint.X;
                            if (movingSRect.X2 < (movedValue + SmallSizeLimit))
                                return;

                            this.Width = this.Width + (movingSPoint.X - e.X);
                            Point location = new Point(movedValue, this.Top);
                            this.Location = location;
                        }
                        break;
                    case "up":
                        Cursor = Cursors.SizeNS;
                        {
                            movedValue = this.Top + e.Y - movingSPoint.Y;
                            if (movingSRect.Y2 < (movedValue + SmallSizeLimit))
                                return;

                            this.Height = this.Height + (movingSPoint.Y - e.Y);
                            Point location = new Point(this.Left, movedValue);
                            this.Location = location;
                        }
                        break;
                    case "down":
                        Cursor = Cursors.SizeNS;
                        {
                            movedValue = (e.Y - movingSPoint.Y);

                            if (SmallSizeLimit > (this.Height + movedValue))
                                return;

                            this.Height = this.Height + movedValue;
                        }
                        break;

                    // Edge
                    case "rightup":
                        Cursor = Cursors.SizeNESW;
                        {
                            {
                                movedValue = (e.X - movingSPoint.X);

                                if (SmallSizeLimit > (this.Width + movedValue))
                                    return;

                                this.Width = this.Width + movedValue;
                            }

                            {
                                movedValue = this.Top + e.Y - movingSPoint.Y;
                                if (movingSRect.Y2 < (movedValue + SmallSizeLimit))
                                    return;

                                this.Height = this.Height + (movingSPoint.Y - e.Y);
                                Point location = new Point(this.Left, movedValue);
                                this.Location = location;
                            }
                        }
                        break;
                    case "rightdown":
                        Cursor = Cursors.SizeNWSE;
                        {
                            {
                                movedValue = (e.X - movingSPoint.X);

                                if (SmallSizeLimit > (this.Width + movedValue))
                                    return;

                                this.Width = this.Width + movedValue;
                            }

                            {
                                movedValue = (e.Y - movingSPoint.Y);

                                if (SmallSizeLimit > (this.Height + movedValue))
                                    return;

                                this.Height = this.Height + movedValue;
                            }
                        }
                        break;
                    case "leftup":
                        Cursor = Cursors.SizeNWSE;
                        {
                            {
                                movedValue = this.Left + e.X - movingSPoint.X;
                                if (movingSRect.X2 < (movedValue + SmallSizeLimit))
                                    return;

                                this.Width = this.Width + (movingSPoint.X - e.X);
                                Point location = new Point(movedValue, this.Top);
                                this.Location = location;
                            }

                            {
                                movedValue = this.Top + e.Y - movingSPoint.Y;
                                if (movingSRect.Y2 < (movedValue + SmallSizeLimit))
                                    return;

                                this.Height = this.Height + (movingSPoint.Y - e.Y);
                                Point location = new Point(this.Left, movedValue);
                                this.Location = location;
                            }
                        }
                        break;
                    case "leftdown":
                        Cursor = Cursors.SizeNESW;
                        {
                            {
                                movedValue = this.Left + e.X - movingSPoint.X;
                                if (movingSRect.X2 < (movedValue + SmallSizeLimit))
                                    return;

                                this.Width = this.Width + (movingSPoint.X - e.X);
                                Point location = new Point(movedValue, this.Top);
                                this.Location = location;
                            }

                            {
                                movedValue = (e.Y - movingSPoint.Y);

                                if (SmallSizeLimit > (this.Height + movedValue))
                                    return;

                                this.Height = this.Height + movedValue;
                            }
                        }
                        break;
                }
                Application.DoEvents();
            }
        }

        private void pnlAll_MouseUp(object sender, MouseEventArgs e)
        {
            Cursor = preCursor;
        }

        #endregion ▶ 사이즈 조절 및 부모 컨트롤 저장

        #region ▶ Shape 마우스 처리 사용자 정의 메서드

        // 크기 조절 포인트들 보여줄지 아닐지 설정.
        private void SetResizebarVisible(ENUM_STATUS_SHAPE s)
        {
            bool visible = false;
            if (s == ENUM_STATUS_SHAPE.Selected)
            {
                visible = true;
            }
            pnlDown.Visible = visible;
            pnlDown.BringToFront();

            pnlLeft.Visible = visible;
            pnlLeft.BringToFront();

            pnlLeftDown.Visible = visible;
            pnlLeftDown.BringToFront();

            pnlLeftUp.Visible = visible;
            pnlLeftUp.BringToFront();

            pnlRight.Visible = visible;
            pnlRight.BringToFront();

            pnlRightDown.Visible = visible;
            pnlRightDown.BringToFront();

            pnlRightUp.Visible = visible;
            pnlRightUp.BringToFront();

            pnlUp.Visible = visible;
            pnlUp.BringToFront();

            status = s;
        }

        protected void ShapeMouseDown(MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left)
                return;

            if (Control.ModifierKeys == Keys.Control)
            {
                if (Status == ENUM_STATUS_SHAPE.Selected)
                {
                    Status = ENUM_STATUS_SHAPE.Released;
                }
                else
                {
                    for (int i = 0; i < myCanvas.SelectedShapes.Count; i++)
                    {
                        if (myCanvas.SelectedShapes[i].Parent != this.Parent)
                        {
                            myCanvas.ReleaseSelectedStatus(myCanvas.SelectedShapes[i].Parent);
                        }
                    }

                    Status = ENUM_STATUS_SHAPE.Selected;
                }

                return;
            }
            preCursor = Cursor.Current;
            Cursor.Current = Cursors.SizeAll;
            movingSPoint = new Point(e.X, e.Y);
        }

        protected void ShapeMouseMoving(MouseEventArgs e)
        {
            if (movingSPoint == Point.Empty)
                return;

            if (Cursor.Current == Cursors.SizeAll)
            {
                Point location = new Point(this.Left + e.X - movingSPoint.X, this.Top + e.Y - movingSPoint.Y);
                this.Location = location;
            }
        }

        protected void ShapeMouseUp(MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left)
                return;

            movingSPoint = Point.Empty;

            Cursor.Current = preCursor;
        }

        protected void ShapeMouseClick(MouseEventArgs e)
        {
            if (e.Clicks == 1 && e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                if (MyCanvas == null)
                    return;

                MyCanvas.WhenClickPoint = MousePosition;
                MyCanvas.popupMenu1.ShowPopup(MyCanvas.WhenClickPoint);
            }
            else
            {
                if (MyCanvas == null)
                    return;

                MyCanvas.ReleaseSelectedStatus(this);
            }
        }

        #endregion ▶ Shape 마우스 처리 사용자 정의 메서드

        private void ShapeBase_Resize(object sender, EventArgs e)
        {
            SetMyPointRect();
            DoChangedShape(parentControl);
        }

        private void ShapeBase_Move(object sender, EventArgs e)
        {
            SetMyPointRect();
            DoChangedShape(parentControl);
        }

        /// <summary>
        /// 마지막 이벤트 발생시 부모를 지정하기 위하여
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ShapeBase_ParentChanged(object sender, EventArgs e)
        {
            if (this.Parent == null)
                return;

            parentControl = this.Parent;
        }

        private void SetMyPointRect()
        {
            myPointRect.X1 = Location.X;
            myPointRect.Y1 = Location.Y;

            myPointRect.X2 = Location.X + Width;
            myPointRect.Y2 = Location.Y + Height;
        }

        #region ▶ IDataEntity 구현
        /// <summary>
        /// Canvas ID
        /// </summary>
        public string CANVAS_ID { get; set; }
        /// <summary>
        /// Shape ID
        /// </summary>
        public string SHAPE_ID { get; set; }

        /// <summary>
        /// 부모의 Shape ID
        /// </summary>
        public string P_SHAPE_ID { get; set; }

        
        /// <summary>
        /// Text
        /// </summary>
        public string DESCRIPTION { get; set; }

        public string FONT_DESC 
        { 
            get
            {
                return MyDescFont.ToString();
            }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    MyDescFont.SetShapeFont(value);
                }
            }
        }

        /// <summary>
        /// TYPE_ENTITY 열거형 값 (CANVAS = 0, GROUP_AREA = 1, ITEM = 2)
        /// 컨트롤 생성시 값 입력이 필요한다.
        /// </summary>
        public int TYPE_ENTITY { get; set; }

        /// <summary>
        /// TYPE_SHAPE 열거형 값 (Circle = 0, Rectangle = 1)
        /// 컨트롤 생성시 값 입력이 필요한다.
        /// </summary>
        public int TYPE_SHAPE {get; set;}

        /// <summary>
        /// Location 값 (Canvas 인 경우 "0,0")
        /// </summary>
        public string SHAPE_LOC 
        { 
            get
            {
                return Location.ToString();
            } 
            set
            {
                Location = Utils.StringToPoint(value);
            } 
        }

        /// <summary>
        /// Size 값 ( Width, Height => "0,0")
        /// </summary>
        public string SHAPE_SIZE 
        { 
            get
            {
                return this.Size.ToString(); 
            }
            set
            {
                this.Size = Utils.StringToSize(value);
            }
        }

        private string res_name = string.Empty;

        /// <summary>
        /// RESOURCE NAME : 그림을 지정한다.
        /// </summary>
        public string RES_NAME
        {
            get
            {
                return res_name;
            }
            set
            {
                var obj = ShapeImage.ResourceManager.GetObject(value);

                if (obj == null)
                {
                    DoAlertMessage("리소스 ShapeImage 에 " + value + " 이 없습니다.");
                    this.BackgroundImage = HHI.ShipBuilding.Resources.ShapeImage.StatusAnnotationRed_No_32xLG;
                    res_name = string.Empty;
                }
                else
                {
                    this.BackgroundImage = ((System.Drawing.Bitmap)(obj));
                    res_name = value;
                }
            }
        }

        public string SOURCE_ID { get; set; }

        public string EXTRA1 { get; set; }

        #endregion
    }
}
