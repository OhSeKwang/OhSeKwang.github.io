﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HHI.ShipBuilding.Shape
{
    public class DragAndDropItem : IDataCom
    {
        private static readonly Lazy<DragAndDropItem> instance = new Lazy<DragAndDropItem>(() => new DragAndDropItem());

        public static DragAndDropItem Instance
        {
            get
            {
                return instance.Value;
            }
        }

        private string menuId = string.Empty;
        private string displayText = string.Empty;

        public DragAndDropItem()
        {

        }

        public DragAndDropItem(string menuId, string displayText)
        {
            this.menuId = menuId;
            this.displayText = displayText;
        }

        public string MenuId 
        { 
            get
            {
                return menuId;
            }
        }
        public string DisplayText 
        {
            get
            {
                return displayText;
            }
        }

        public string SourceId
        {
            set
            {
                menuId = value;
            }
        }

        public string SoucrceDesc
        {
            set
            {
                displayText = value;
            }
        }
    }
}
