﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HHI.ShipBuilding.Shape.CLS
{

    #region -> 영역 구조체
    /// <summary>
    /// Shape 영역 좌표 구조체
    /// </summary>
    public struct PointRect
    {
        /// <summary>
        /// Empty
        /// </summary>
        public static readonly PointRect Empty = new PointRect(Point.Empty, Point.Empty);

        /// <summary>
        /// 사각 영역의 시작 X 값 (보통 왼쪽 위 X 좌표값)
        /// </summary>
        int x1;
        /// <summary>
        /// 사각 영역의 시작 Y 값 (보통 왼쪽 위 Y 좌표값)
        /// </summary>
        int y1;
        /// <summary>
        /// 사각 영역의 다음 X 값 (보통 오른쪽 아래 X 좌표값)
        /// </summary>
        int x2;
        /// <summary>
        /// 사각 영역의 다음 Y 값 (보통 오른쪽 아래 Y 좌표값)
        /// </summary>
        int y2;

        /// <summary>
        /// 왼쪽 위 모서리와 오른쪽 아래 모서리값으로 Shape 영역 구조체 생성
        /// </summary>
        /// <param name="edgeTopLeft"></param>
        /// <param name="edgeDownRight"></param>
        public PointRect(Point edgeTopLeft, Point edgeDownRight)
        {
            this.x1 = edgeTopLeft.X;
            this.y1 = edgeTopLeft.Y;
            this.x2 = edgeDownRight.X;
            this.y2 = edgeDownRight.Y;
        }

        /// <summary>
        /// Location 과 Width, Height 로 Shape 영역 구조체 생성
        /// </summary>
        /// <param name="location"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        public PointRect(Point location, int width, int height)
        {
            this.x1 = location.X;
            this.y1 = location.Y;
            this.x2 = location.X + width;
            this.y2 = location.Y + height;
        }

        /// <summary>
        /// 좌표값으로 Shape 영역 구조체 생성
        /// </summary>
        /// <param name="x1"></param>
        /// <param name="y1"></param>
        /// <param name="x2"></param>
        /// <param name="y2"></param>
        public PointRect(int x1, int y1, int x2, int y2)
        {
            this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2;
        }

        /// <summary>
        /// 사각 영역의 시작 X 값 (보통 왼쪽 위 X 좌표값)을 설정하거나 가져온다.
        /// </summary>
        public int X1
        {
            get
            {
                return x1;
            }
            set
            {
                x1 = value;
            }
        }

        /// <summary>
        /// 사각 영역의 시작 Y 값 (보통 왼쪽 위 Y 좌표값)을 설정하거나 가져온다.
        /// </summary>
        public int Y1
        {
            get
            {
                return y1;
            }
            set
            {
                y1 = value;
            }
        }

        /// <summary>
        /// 사각 영역의 다음 X 값 (보통 오른쪽 아래 X 좌표값)을 설정하거나 가져온다.
        /// </summary>
        public int X2
        {
            get
            {
                return x2;
            }
            set
            {
                x2 = value;
            }
        }

        /// <summary>
        /// 사각 영역의 다음 Y 값 (보통 오른쪽 아래 Y 좌표값)을 설정하거나 가져온다.
        /// </summary>
        public int Y2
        {
            get
            {
                return y2;
            }
            set
            {
                y2 = value;
            }
        }

        /// <summary>
        /// 기준 모서리 좌표
        /// </summary>
        public Point StartEdgePoint
        {
            get
            {
                return new Point(x1, y1);
            }
            set
            {
                x1 = value.X;
                y1 = value.Y;
            }
        }

        /// <summary>
        /// 대칭되는 다음 모서리 좌표
        /// </summary>
        public Point EndEdgePoint
        {
            get
            {
                return new Point(x2, y2);
            }
            set
            {
                x2 = value.X;
                y2 = value.Y;
            }
        }

        public static bool operator ==(PointRect left, PointRect right)
        {
            return left.StartEdgePoint == right.StartEdgePoint && left.EndEdgePoint == right.EndEdgePoint;
        }

        public static bool operator !=(PointRect left, PointRect right)
        {
            return !(left == right);
        }

        public override bool Equals(object obj)
        {
            if (!(obj is PointRect)) 
                return false;

            PointRect rect = (PointRect)obj;
            return rect.X1 == this.X1 && rect.Y1 == this.Y1 && rect.X2 == this.X2 && rect.Y2 == this.Y2; 

        }

        public override int GetHashCode()
        {
            return Utils.RSHash(x1, y1, x2, y2);
        }

        public override string ToString()
        {
            return "{X1=" + X1.ToString(CultureInfo.CurrentCulture) + ",Y1=" + Y1.ToString(CultureInfo.CurrentCulture) + "},"
                + "{X2=" + X2.ToString(CultureInfo.CurrentCulture) + ",Y2=" + Y2.ToString(CultureInfo.CurrentCulture) + "}";
        } 
    }
    #endregion

    #region -> 사용자 정의 이벤트 데이터

    public class ChangedShapeEventArg : EventArgs
    {
        private Control parent;
        public ChangedShapeEventArg(Control parent)
        {
            this.parent = parent;
        }

        public Control Parent
        {
            get
            {
                return parent;
            }
        }
    }

    /// <summary>
    /// ShapeAlertMessage 이벤트 데이터
    /// </summary>
    public class AlertMessageEventArg : EventArgs
    {
        private string msg = string.Empty;

        public string AlertMessage
        {
            get
            {
                return msg;
            }
        }

        public AlertMessageEventArg(string msg)
        {
            this.msg = msg;
        }
    }

    /// <summary>
    /// Removing 이벤트 데이터
    /// </summary>
    public class RemovingEventArg : EventArgs
    {
        private string id = string.Empty;

        public string ID
        {
            get
            {
                return id;
            }
        }

        public RemovingEventArg(string id)
        {
            this.id = id;
        }
    }

    /// <summary>
    /// Canvas 변경 데이터
    /// </summary>
    public class ChangedCanvasEventArg : EventArgs
    {
        private string id = string.Empty;

        public string ID
        {
            get
            {
                return id;
            }
        }

        private string size = string.Empty;

        public string Size
        {
            get
            {
                return size;
            }
        }

        private Color color;

        public Color Color
        {
            get
            {
                return color;
            }
        }

        public ChangedCanvasEventArg(string id, string size, Color color)
        {
            this.id = id;
            this.size = size;
            this.color = color;
        }
    }

    public class ShapeMenuClickEventArg : EventArgs
    {
        private string menuId = string.Empty;
        private string tcode = string.Empty;

        public string MenuId
        {
            get
            {
                return menuId;
            }
        }

        public string TCODE
        {
            get
            {
                return tcode;
            }
        }

        public ShapeMenuClickEventArg(string menuId, string tcode)
        {
            this.menuId = menuId;
            this.tcode = tcode;
        }
    }

    #endregion

    #region -> 순환 데이터 클래스

    /// <summary>
    /// 순환 데이터
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class CircularItems<T> : IEnumerable 
    {
        private CircularItemsEnum<T> items = null;
        private T[] _items;

        public CircularItems(T[] pArray)
        {
            System.Diagnostics.Debug.Assert(
                !(pArray == null || pArray.Length == 0), "CircularItems 에 입력된 데이터가 없습니다.");

            _items = new T[pArray.Length];

            for (int i = 0; i < pArray.Length; i++)
            {
                _items[i] = pArray[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return (IEnumerator)GetEnumerator();
        }

        public CircularItemsEnum<T> GetEnumerator()
        {
            if (items == null)
            {
                items = new CircularItemsEnum<T>(_items); 
            }

            return items;
        }

    }

    /// <summary>
    /// CircularItems(순환 데이터)의 반복자 구현
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class CircularItemsEnum<T> : IEnumerator
    {
        public T[] Items;
        int position = 0;

        public CircularItemsEnum(T[] list)
        {
            System.Diagnostics.Debug.Assert(!(list == null), "CircularItems 에 입력된 데이터가 없습니다.");
            Items = list;
        }

        public bool MoveNext()
        {
            if (position == (Items.Length - 1))
            {
                Reset();
            }
            else
            {
                position++;
            }

            return true;
        }

        public void Reset()
        {
            position = 0;
        }

        object IEnumerator.Current
        {
            get
            {
                return Current;
            }
        }

        public T Current
        {
            get
            {
                return Items[position];
            }
        }

        /// <summary>
        /// 현재 위치값
        /// </summary>
        public int Position
        {
            get
            {
                return position;
            }
            set
            {
                position = value;
            }
        }
    }

    #endregion

    #region -> 열거형

    /// <summary>
    /// CANVAS = 0, GROUP_AREA = 1, ITEM = 2
    /// </summary>
    public enum ENUM_TYPE_ENTITY
    {
        CANVAS = 0,
        GROUP_AREA = 1,
        ITEM = 2,
    }

    /// <summary>
    /// Shape 컨트롤의 상태( 미선택, 선택, 선연결 끝점 준비 )
    /// </summary>
    public enum ENUM_STATUS_SHAPE
    {
        /// <summary>
        /// 미선택
        /// </summary>
        Released = 1,
        /// <summary>
        /// 선택
        /// </summary>
        Selected = 2,
        /// <summary>
        /// 선연결 끝점이 될수 있는 상태
        /// </summary>
        Bridge = 3,
    }

    /// <summary>
    /// Canvas 의 상태
    /// </summary>
    public enum ENUM_STATUS_CANVAS
    {
        /// <summary>
        /// 
        /// </summary>
        Released = 1,
        /// <summary>
        /// 
        /// </summary>
        Selected = 2,
        /// <summary>
        /// 
        /// </summary>
        Bridge = 3,
    }

    /// <summary>
    /// Shape 접점
    /// </summary>
    public enum ENUM_ANCHOR_POINT
    {
        ALL = 0,
        UP = 1,
        RIGHT = 2,
        LEFT = 3,
        DOWN = 4,
    }

    #endregion

    #region -> 전역 변수

    public class DEF_TYPE_ENTITY_SIZE
    {
        public static string CANVAS = "{Width=800, Height=600}";
        public static string GROUP_AREA = "{Width=130, Height=130}";
        public static string ITEM = "{Width=130, Height=130}";
    }

    public class DEF_LINE_ENTITY
    {
        public static Color Color = Color.Chocolate;
        public static float Width = 7;
    }

    /// <summary>
    /// View 모드일때 환경 변수
    /// </summary>
    public class ViewerVariables
    {
        
        private static readonly Lazy<ViewerVariables> values = new Lazy<ViewerVariables>(() => new ViewerVariables());

        public static ViewerVariables Values
        {
            get
            {
                return values.Value;
            }
        }

        public static bool DbCalled = false;

        public List<string> AuthMenuId = new List<string>();
    }

    /// <summary>
    /// Shape 환경 변수
    /// </summary>
    public class ShapeEvironments
    {
        private static readonly Lazy<ShapeEvironments> instance = new Lazy<ShapeEvironments>(() => new ShapeEvironments());

        public static ShapeEvironments Instance
        {
            get
            {
                return instance.Value;
            }
        }

        public List<string> ListCircle = new List<string>();
        public List<string> ListRectangle = new List<string>();
        public List<string> ListCustom = new List<string>();

        public List<string> ListGroupArea = new List<string>();

        public List<string> SortItemImageNames = new List<string>();
        public List<string> SortGroupImageNames = new List<string>();
        public ImageList ItemImages = new ImageList();
        public ImageList GroupImages = new ImageList();

        /// <summary>
        /// Item 의 Disable 상태 색상
        /// </summary>
        public readonly string DisableResName = "00";

        public readonly string TCODE_MENU = "SCSYS014";
 
        public void SetResNames()
        {
            ItemImages.ColorDepth = ColorDepth.Depth32Bit;
            GroupImages.ColorDepth = ColorDepth.Depth32Bit;

            ListCircle.Clear();
            ListRectangle.Clear();
            ListGroupArea.Clear();
            SortItemImageNames.Clear();
            ItemImages.Images.Clear();
            SortGroupImageNames.Clear();
            GroupImages.Images.Clear();

            var rSet = HHI.ShipBuilding.Resources.ShapeImage.ResourceManager.GetResourceSet(CultureInfo.CurrentUICulture, true, true);
            foreach (var r in rSet)
            {
                var entry = (DictionaryEntry)r;
                if (entry.Key.ToString().StartsWith("circle_", StringComparison.OrdinalIgnoreCase))
                {
                    ListCircle.Add(entry.Key.ToString());
                }
                else if (entry.Key.ToString().StartsWith("rectanlge_", StringComparison.OrdinalIgnoreCase))
                {
                    ListRectangle.Add(entry.Key.ToString());
                }
                else if (entry.Key.ToString().StartsWith("grouparea_", StringComparison.OrdinalIgnoreCase))
                {
                    ListGroupArea.Add(entry.Key.ToString());
                }
                else if (entry.Key.ToString().StartsWith("Item_", StringComparison.OrdinalIgnoreCase))
                {
                    SortItemImageNames.Add(entry.Key.ToString());
                    //ItemImages.Images.Add(entry.Key.ToString(), (Image)entry.Value);
                }
                else if (entry.Key.ToString().StartsWith("Group_", StringComparison.OrdinalIgnoreCase))
                {
                    SortGroupImageNames.Add(entry.Key.ToString());
                }
            }

            ListCircle.Sort();
            ListRectangle.Sort();
            ListGroupArea.Sort();
            SortItemImageNames.Sort();
            SortGroupImageNames.Sort();

            foreach (var key in SortItemImageNames)
            {
                ItemImages.Images.Add(key, (Image)rSet.GetObject(key));
            }

            foreach (var key in SortGroupImageNames)
            {
                GroupImages.Images.Add(key, (Image)rSet.GetObject(key));
            }
        }
    }

    #endregion

    public class HLine
    {
        public HLine(Point sp, Point ep)
        {
            StartAP = sp;
            EndAP = ep;
        }

        public Point StartAP = Point.Empty;
        public Point EndAP = Point.Empty;
    }
}
