﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HHI.ShipBuilding.Shape.CLS
{
    public interface IShapeEntity
    {
        /// <summary>
        /// Canvas ID
        /// </summary>
        string CANVAS_ID { get; set; }
        /// <summary>
        /// Shape ID
        /// </summary>
        string SHAPE_ID { get; set; }

        /// <summary>
        /// 부모의 Shape ID
        /// </summary>
        string P_SHAPE_ID { get; set; }

        /// <summary>
        /// Text
        /// </summary>
        string DESCRIPTION { get; set; }

        /// <summary>
        /// DESCRIPTION 글꼴 정보
        /// </summary>
        string FONT_DESC { get; set; }

        /// <summary>
        /// TYPE_ENTITY 열거형 값 (CANVAS = 0, GROUP_AREA = 1, ITEM = 2)
        /// </summary>
        int TYPE_ENTITY { get; set; }

        /// <summary>
        /// TYPE_SHAPE 열거형 값 (Circle = 0, Rectangle = 1)
        /// </summary>
        int TYPE_SHAPE { get; set; }

        /// <summary>
        /// Location 값 (Canvas 인 경우 "0,0")
        /// </summary>
        string SHAPE_LOC { get; set; }

        /// <summary>
        /// Size 값 ( Width, Height => "0,0")
        /// </summary>
        string SHAPE_SIZE { get; set; }

        string RES_NAME { get; set; }

        string SOURCE_ID { get; set; }

        string EXTRA1 { get; set; }
    }
}
