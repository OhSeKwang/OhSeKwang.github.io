﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HHI.ShipBuilding.Shape.CLS
{
    abstract class EditCommand
    {

    }
}
