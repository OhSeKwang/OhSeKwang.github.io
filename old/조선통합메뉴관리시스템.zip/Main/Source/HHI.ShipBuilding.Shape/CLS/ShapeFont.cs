﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HHI.ShipBuilding.Shape.CLS
{
    public class ShapeFont
    {
        private Control myCtrl = null;

        public ShapeFont(Control ctrl)
        {
            myCtrl = ctrl;

            Font f = MyCtrl.Font;
            this.Bold = f.Bold;
            this.Italic = f.Italic;
            this.Name = f.Name;
            this.FontSize = f.Size;
            this.Color = MyCtrl.ForeColor;
        }

        public Control MyCtrl
        {
            get
            {
                return myCtrl;
            }
        }

        /// <summary>
        /// Name;Bold;Italic;Size;Color 필드 구분으로 값이 들어가있는 문자열을 반환한다.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            //Name, Bold, Italic, Size, Color
            return this.Name + ";" + Convert.ToInt32(this.Bold).ToString() + ";" +
                Convert.ToInt32(this.Italic).ToString() + ";" + Convert.ToString(this.FontSize) + ";" +
                this.Color.ToArgb().ToString();
        }

        public void SetShapeFont(string s)
        {
            //Name, Bold, Italic, Size, Color
            string[] arr = s.Split(';');
            this.Name = string.IsNullOrEmpty(arr[0]) ? this.Name : arr[0];
            this.Bold = string.IsNullOrEmpty(arr[1]) ? this.Bold : Convert.ToBoolean(Convert.ToInt32(arr[1]));
            this.Italic = string.IsNullOrEmpty(arr[2]) ? this.Italic : Convert.ToBoolean(Convert.ToInt32(arr[2]));
            this.FontSize = string.IsNullOrEmpty(arr[3]) ? this.FontSize : float.Parse(arr[3]);
            this.Color = string.IsNullOrEmpty(arr[4]) ? this.Color : Color.FromArgb(Convert.ToInt32(arr[4]));

        }

        public void SetShapeFontToControl()
        {
            int nBold = 0;
            int nItalic = 0;

            if (this.Bold == true)
                nBold = 1;

            if (this.Italic == true)
                nItalic = 2;

            myCtrl.Font = new System.Drawing.Font(this.Name, this.FontSize,
                ((System.Drawing.FontStyle)((nBold | nItalic))), System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            myCtrl.ForeColor = this.Color;
        }

        public string Name { get; set; }

        public bool Bold { get; set; }

        public bool Italic { get; set; }

        public float FontSize { get; set; }

        public Color Color { get; set; }
    }
}
