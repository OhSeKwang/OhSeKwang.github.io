﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace HHI.ShipBuilding.Shape.CLS
{
    public interface ILineEntity
    {
        /// <summary>
        /// CANVAS_ID
        /// </summary>
        string CANVAS_ID { get; set; }
        /// <summary>
        /// 부모 ID
        /// </summary>
        string SHAPE_ID { get; set; }
        /// <summary>
        /// 라인 ID
        /// </summary>
        string LINE_ID { get; set; }
        Color Color { get; set; }
        float Width {get; set;}
        Point SPoint { get;}
        Point EPoint { get; }

        string START_ID { get; set; }
        string END_ID { get; set; }

    }
}
