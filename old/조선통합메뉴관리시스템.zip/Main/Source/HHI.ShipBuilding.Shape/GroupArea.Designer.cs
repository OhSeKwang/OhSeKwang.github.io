﻿namespace HHI.ShipBuilding.Shape
{
    partial class GroupArea
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblText = new System.Windows.Forms.Label();
            this.txtText = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblText
            // 
            this.lblText.AutoSize = true;
            this.lblText.Font = new System.Drawing.Font("맑은 고딕", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblText.ForeColor = System.Drawing.Color.Gray;
            this.lblText.Location = new System.Drawing.Point(-6, -5);
            this.lblText.Name = "lblText";
            this.lblText.Size = new System.Drawing.Size(128, 30);
            this.lblText.TabIndex = 9;
            this.lblText.Text = "Group Area";
            // 
            // txtText
            // 
            this.txtText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtText.Font = new System.Drawing.Font("굴림", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtText.Location = new System.Drawing.Point(2, 5);
            this.txtText.Name = "txtText";
            this.txtText.Size = new System.Drawing.Size(115, 30);
            this.txtText.TabIndex = 10;
            this.txtText.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtText_KeyDown);
            // 
            // GroupArea
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.txtText);
            this.Controls.Add(this.lblText);
            this.DoubleBuffered = true;
            this.Name = "GroupArea";
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.GroupArea_MouseClick);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.GroupArea_MouseDown);
            this.MouseLeave += new System.EventHandler(this.GroupArea_MouseLeave);
            this.MouseHover += new System.EventHandler(this.GroupArea_MouseHover);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.GroupArea_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.GroupArea_MouseUp);
            this.Controls.SetChildIndex(this.lblText, 0);
            this.Controls.SetChildIndex(this.txtText, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblText;
        private System.Windows.Forms.TextBox txtText;

    }
}
