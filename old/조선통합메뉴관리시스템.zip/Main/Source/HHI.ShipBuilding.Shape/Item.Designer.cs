﻿namespace HHI.ShipBuilding.Shape
{
    partial class Item
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblText = new System.Windows.Forms.Label();
            this.txtText = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblText
            // 
            this.lblText.AutoEllipsis = true;
            this.lblText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblText.Font = new System.Drawing.Font("맑은 고딕", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblText.ForeColor = System.Drawing.Color.White;
            this.lblText.Location = new System.Drawing.Point(15, 15);
            this.lblText.Margin = new System.Windows.Forms.Padding(0);
            this.lblText.Name = "lblText";
            this.lblText.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this.lblText.Size = new System.Drawing.Size(100, 100);
            this.lblText.TabIndex = 0;
            this.lblText.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblText.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Item_MouseClick);
            this.lblText.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Item_MouseDown);
            this.lblText.MouseLeave += new System.EventHandler(this.Item_MouseLeave);
            this.lblText.MouseHover += new System.EventHandler(this.Item_MouseHover);
            this.lblText.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Item_MouseMove);
            this.lblText.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Item_MouseUp);
            // 
            // txtText
            // 
            this.txtText.BackColor = System.Drawing.Color.White;
            this.txtText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtText.Font = new System.Drawing.Font("맑은 고딕", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtText.Location = new System.Drawing.Point(15, 15);
            this.txtText.Multiline = true;
            this.txtText.Name = "txtText";
            this.txtText.Size = new System.Drawing.Size(100, 100);
            this.txtText.TabIndex = 9;
            this.txtText.TabStop = false;
            this.txtText.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtText_KeyDown);
            // 
            // Item
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.txtText);
            this.Controls.Add(this.lblText);
            this.DoubleBuffered = true;
            this.Name = "Item";
            this.Padding = new System.Windows.Forms.Padding(15);
            this.SHAPE_LOC = "{X=15,Y=15}";
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Item_MouseClick);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Item_MouseDown);
            this.MouseLeave += new System.EventHandler(this.Item_MouseLeave);
            this.MouseHover += new System.EventHandler(this.Item_MouseHover);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Item_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Item_MouseUp);
            this.Controls.SetChildIndex(this.lblText, 0);
            this.Controls.SetChildIndex(this.txtText, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblText;
        private System.Windows.Forms.TextBox txtText;

    }
}
