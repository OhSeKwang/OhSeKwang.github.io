﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HHI.ShipBuilding.Shape.CLS;

namespace HHI.ShipBuilding.Shape
{
    public partial class GroupArea : ShapeBase
    {
        /// <summary>
        /// 영역에 그려야 하는 선
        /// </summary>
        public List<Line> Lines = new List<Line>();

        public GroupArea()
        {
            InitializeComponent();
            CurrentShapeTypes = new CircularItems<string>(new string[] { "GroupArea" });
            MyDescFont = new ShapeFont(this.lblText);

            this.txtText.Visible = false;
            this.ShowTextBox += Item_ShowTextBox;
        }

        /// <summary>
        /// 화살표를 그린다.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            //e.Graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;

            // 선을 그린다.
            foreach (var l in Lines)
            {
                Pen myPen = new Pen(l.Color, l.Width);
                myPen.StartCap = System.Drawing.Drawing2D.LineCap.RoundAnchor;
                myPen.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
                e.Graphics.DrawLine(myPen, l.SPoint, l.EPoint);
            }
        }

        void Item_ShowTextBox(object sender, EventArgs e)
        {
            txtText.Text = lblText.Text;
            txtText.Visible = true;
        }

        private void GroupArea_MouseDown(object sender, MouseEventArgs e)
        {
            if (MyCanvas.IsViewer)
                return;

            ShapeMouseDown(e);
        }

        private void GroupArea_MouseHover(object sender, EventArgs e)
        {
            if (MyCanvas.IsViewer)
                return;

            if (Status == CLS.ENUM_STATUS_SHAPE.Selected)
            {

            }
            else
            {
                if (Cursor.Current == Cursors.SizeAll)
                    return;

                Cursor = Cursors.Hand;
            }
        }

        private void GroupArea_MouseLeave(object sender, EventArgs e)
        {
            if (MyCanvas.IsViewer)
                return;

            if (MyCanvas.Status == ENUM_STATUS_CANVAS.Bridge)
            {

            }
            else
            {
                Cursor = Cursors.Default;
            }
        }

        private void GroupArea_MouseMove(object sender, MouseEventArgs e)
        {
            if (MyCanvas.IsViewer)
                return;

            ShapeMouseMoving(e);
        }

        private void GroupArea_MouseUp(object sender, MouseEventArgs e)
        {
            if (MyCanvas.IsViewer)
                return;

            ShapeMouseUp(e);
        }

        private void GroupArea_MouseClick(object sender, MouseEventArgs e)
        {
            if (MyCanvas.IsViewer)
                return;

            ShapeMouseClick(e);
        }

        private void txtText_KeyDown(object sender, KeyEventArgs e)
        {
            if (MyCanvas.IsViewer)
                return;

            if (e.Modifiers == Keys.Control)
            {
                DESCRIPTION = txtText.Text;
                lblText.Text = txtText.Text;
                txtText.Visible = false;
            }
        }
    }
}
