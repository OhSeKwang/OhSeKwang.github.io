﻿namespace HHI.ShipBuilding.Shape
{
    partial class ShapeBase
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlRight = new System.Windows.Forms.Panel();
            this.pnlLeft = new System.Windows.Forms.Panel();
            this.pnlUp = new System.Windows.Forms.Panel();
            this.pnlDown = new System.Windows.Forms.Panel();
            this.pnlRightDown = new System.Windows.Forms.Panel();
            this.pnlLeftUp = new System.Windows.Forms.Panel();
            this.pnlLeftDown = new System.Windows.Forms.Panel();
            this.pnlRightUp = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // pnlRight
            // 
            this.pnlRight.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.pnlRight.BackColor = System.Drawing.Color.SteelBlue;
            this.pnlRight.Location = new System.Drawing.Point(125, 59);
            this.pnlRight.Margin = new System.Windows.Forms.Padding(0);
            this.pnlRight.Name = "pnlRight";
            this.pnlRight.Size = new System.Drawing.Size(5, 12);
            this.pnlRight.TabIndex = 2;
            this.pnlRight.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseDown);
            this.pnlRight.MouseHover += new System.EventHandler(this.pnlAll_MouseHover);
            this.pnlRight.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseMove);
            this.pnlRight.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseUp);
            // 
            // pnlLeft
            // 
            this.pnlLeft.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pnlLeft.BackColor = System.Drawing.Color.SteelBlue;
            this.pnlLeft.Location = new System.Drawing.Point(0, 59);
            this.pnlLeft.Margin = new System.Windows.Forms.Padding(0);
            this.pnlLeft.Name = "pnlLeft";
            this.pnlLeft.Size = new System.Drawing.Size(5, 12);
            this.pnlLeft.TabIndex = 3;
            this.pnlLeft.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseDown);
            this.pnlLeft.MouseHover += new System.EventHandler(this.pnlAll_MouseHover);
            this.pnlLeft.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseMove);
            this.pnlLeft.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseUp);
            // 
            // pnlUp
            // 
            this.pnlUp.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlUp.BackColor = System.Drawing.Color.SteelBlue;
            this.pnlUp.Location = new System.Drawing.Point(59, 0);
            this.pnlUp.Margin = new System.Windows.Forms.Padding(0);
            this.pnlUp.Name = "pnlUp";
            this.pnlUp.Size = new System.Drawing.Size(12, 5);
            this.pnlUp.TabIndex = 4;
            this.pnlUp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseDown);
            this.pnlUp.MouseHover += new System.EventHandler(this.pnlAll_MouseHover);
            this.pnlUp.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseMove);
            this.pnlUp.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseUp);
            // 
            // pnlDown
            // 
            this.pnlDown.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.pnlDown.BackColor = System.Drawing.Color.SteelBlue;
            this.pnlDown.Location = new System.Drawing.Point(59, 125);
            this.pnlDown.Margin = new System.Windows.Forms.Padding(0);
            this.pnlDown.Name = "pnlDown";
            this.pnlDown.Size = new System.Drawing.Size(12, 5);
            this.pnlDown.TabIndex = 5;
            this.pnlDown.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseDown);
            this.pnlDown.MouseHover += new System.EventHandler(this.pnlAll_MouseHover);
            this.pnlDown.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseMove);
            this.pnlDown.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseUp);
            // 
            // pnlRightDown
            // 
            this.pnlRightDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlRightDown.BackColor = System.Drawing.Color.SteelBlue;
            this.pnlRightDown.Location = new System.Drawing.Point(124, 124);
            this.pnlRightDown.Margin = new System.Windows.Forms.Padding(0);
            this.pnlRightDown.Name = "pnlRightDown";
            this.pnlRightDown.Size = new System.Drawing.Size(6, 6);
            this.pnlRightDown.TabIndex = 7;
            this.pnlRightDown.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseDown);
            this.pnlRightDown.MouseHover += new System.EventHandler(this.pnlAll_MouseHover);
            this.pnlRightDown.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseMove);
            this.pnlRightDown.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseUp);
            // 
            // pnlLeftUp
            // 
            this.pnlLeftUp.BackColor = System.Drawing.Color.SteelBlue;
            this.pnlLeftUp.Location = new System.Drawing.Point(0, 0);
            this.pnlLeftUp.Margin = new System.Windows.Forms.Padding(0);
            this.pnlLeftUp.Name = "pnlLeftUp";
            this.pnlLeftUp.Size = new System.Drawing.Size(6, 6);
            this.pnlLeftUp.TabIndex = 8;
            this.pnlLeftUp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseDown);
            this.pnlLeftUp.MouseHover += new System.EventHandler(this.pnlAll_MouseHover);
            this.pnlLeftUp.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseMove);
            this.pnlLeftUp.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseUp);
            // 
            // pnlLeftDown
            // 
            this.pnlLeftDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlLeftDown.BackColor = System.Drawing.Color.SteelBlue;
            this.pnlLeftDown.Location = new System.Drawing.Point(0, 124);
            this.pnlLeftDown.Margin = new System.Windows.Forms.Padding(0);
            this.pnlLeftDown.Name = "pnlLeftDown";
            this.pnlLeftDown.Size = new System.Drawing.Size(6, 6);
            this.pnlLeftDown.TabIndex = 8;
            this.pnlLeftDown.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseDown);
            this.pnlLeftDown.MouseHover += new System.EventHandler(this.pnlAll_MouseHover);
            this.pnlLeftDown.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseMove);
            this.pnlLeftDown.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseUp);
            // 
            // pnlRightUp
            // 
            this.pnlRightUp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlRightUp.BackColor = System.Drawing.Color.SteelBlue;
            this.pnlRightUp.Location = new System.Drawing.Point(124, 0);
            this.pnlRightUp.Name = "pnlRightUp";
            this.pnlRightUp.Size = new System.Drawing.Size(6, 6);
            this.pnlRightUp.TabIndex = 8;
            this.pnlRightUp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseDown);
            this.pnlRightUp.MouseHover += new System.EventHandler(this.pnlAll_MouseHover);
            this.pnlRightUp.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseMove);
            this.pnlRightUp.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlAll_MouseUp);
            // 
            // ShapeBase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.pnlLeftDown);
            this.Controls.Add(this.pnlRightUp);
            this.Controls.Add(this.pnlLeftUp);
            this.Controls.Add(this.pnlRightDown);
            this.Controls.Add(this.pnlDown);
            this.Controls.Add(this.pnlUp);
            this.Controls.Add(this.pnlLeft);
            this.Controls.Add(this.pnlRight);
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "ShapeBase";
            this.Size = new System.Drawing.Size(130, 130);
            this.Move += new System.EventHandler(this.ShapeBase_Move);
            this.Resize += new System.EventHandler(this.ShapeBase_Resize);
            this.ParentChanged += new System.EventHandler(this.ShapeBase_ParentChanged);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlRight;
        private System.Windows.Forms.Panel pnlLeft;
        private System.Windows.Forms.Panel pnlUp;
        private System.Windows.Forms.Panel pnlDown;
        private System.Windows.Forms.Panel pnlRightDown;
        private System.Windows.Forms.Panel pnlLeftUp;
        private System.Windows.Forms.Panel pnlLeftDown;
        private System.Windows.Forms.Panel pnlRightUp;
    }
}
