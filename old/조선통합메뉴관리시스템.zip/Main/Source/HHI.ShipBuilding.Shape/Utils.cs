﻿using HHI.ShipBuilding.Shape.CLS;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace HHI.ShipBuilding.Shape
{
    public class Utils
    {
        public struct IconInfo
        {
            public bool fIcon;
            public int xHotspot;
            public int yHotspot;
            public IntPtr hbmMask;
            public IntPtr hbmColor;
        }

        [DllImport("user32.dll")]
        public static extern IntPtr CreateIconIndirect(ref IconInfo icon);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetIconInfo(IntPtr hIcon, ref IconInfo pIconInfo);

        public static Cursor CreateCursor(Bitmap bmp, int xHotSpot, int yHotSpot)
        {
            IconInfo tmp = new IconInfo();
            GetIconInfo(bmp.GetHicon(), ref tmp);
            tmp.xHotspot = xHotSpot;
            tmp.yHotspot = yHotSpot;
            tmp.fIcon = false;
            return new Cursor(CreateIconIndirect(ref tmp));
        }

        /// <summary> 
        /// This is a simple hashing function from Robert Sedgwicks Hashing in C book.
        /// Also, some simple optimizations to the algorithm in order to speed up
        /// its hashing process have been added. from: www.partow.net
        /// </summary>
        /// <param name="input">array of objects, parameters combination that you need
        /// to get a unique hash code for them</param>
        /// <returns>Hash code</returns>
        public static int RSHash(params object[] input)
        {
            const int b = 378551;
            int a = 63689;
            int hash = 0;

            // I have added the unchecked keyword to make sure 
            // not get an overflow exception.
            // It can be enhanced later by catching the OverflowException.

            unchecked
            {
                for (int i = 0; i < input.Length; i++)
                {
                    if (input[i] != null)
                    {
                        hash = hash * a + input[i].GetHashCode();
                        a = a * b;
                    }
                }
            }

            return hash;
        }

        public static int GetControlDepth(Control ctrl)
        {
            int i = 2;

            Control tempCtrl = ctrl.Parent;


            while (!tempCtrl.Parent.GetType().Equals(typeof(Canvas)))
            {
                tempCtrl = tempCtrl.Parent;
                i++;

                if ( i == 10)
                {
                    throw new IndexOutOfRangeException("컨트롤의 부모 개수는 10 미만까지만 허용합니다.");
                }
            }

            return i;
        }

        /// <summary>
        /// 선 연결점 좌표를 가져온다. (- 좌표는 없다고 가정한다.)
        /// </summary>
        /// <param name="ap"></param>
        /// <param name="pr"></param>
        /// <returns></returns>
        public static Point GetAnchorPoint(ENUM_ANCHOR_POINT ap, PointRect pr)
        {
            Point p = Point.Empty;

            switch(ap)
            {
                case ENUM_ANCHOR_POINT.UP:
                    p.X = pr.X1 + (pr.X2 - pr.X1) / 2;
                    p.Y = pr.Y1;
                    break;
                case ENUM_ANCHOR_POINT.RIGHT:
                    p.X = pr.X2;
                    p.Y = pr.Y1 + (pr.Y2 - pr.Y1) / 2;
                    break;
                case ENUM_ANCHOR_POINT.LEFT:
                    p.X = pr.X1;
                    p.Y = pr.Y1 + (pr.Y2 - pr.Y1) / 2;
                    break;
                case ENUM_ANCHOR_POINT.DOWN:
                    p.X = pr.X1 + (pr.X2 - pr.X1) / 2;
                    p.Y = pr.Y2;
                    break;
            }

            return p;
        }

        public static void SetAnchorPointsAll(PointRect pr, ref Dictionary<ENUM_ANCHOR_POINT, Point> AnchorPointsAll)
        {
            if (AnchorPointsAll.Count == 0)
            {
                AnchorPointsAll.Add(ENUM_ANCHOR_POINT.UP, Point.Empty);
                AnchorPointsAll.Add(ENUM_ANCHOR_POINT.RIGHT, Point.Empty);
                AnchorPointsAll.Add(ENUM_ANCHOR_POINT.LEFT, Point.Empty);
                AnchorPointsAll.Add(ENUM_ANCHOR_POINT.DOWN, Point.Empty);
            }

            for (int i = 1; i < 5; i++)
            {
                AnchorPointsAll[(ENUM_ANCHOR_POINT)i] = GetAnchorPoint((ENUM_ANCHOR_POINT)i, pr);
            }
        }

        public static List<Line> GetLinesFromData(Control parent, List<ILineEntity> linesData)
        {
            Dictionary<ENUM_ANCHOR_POINT, Point> aPoints = new Dictionary<ENUM_ANCHOR_POINT, Point>();

            foreach (Control ctrl in parent.Controls)
            {
                Utils.SetAnchorPointsAll((ctrl as ShapeBase).MyPointRect, ref aPoints);
            }

            return null;
        }

        public static Size StringToSize(string pSize)
        {
            //{Width=664, Height=464}
            string regex = @"\{Width=(?<Width>[-]?\d+),(|\s)(Height=(?<Height>[-]?\d+))}";
            var result = new Regex(regex).Match(pSize);
            var Width = result.Groups["Width"].Value;
            var Height = result.Groups["Height"].Value;

            return new Size(Convert.ToInt32(Width), Convert.ToInt32(Height));
        }

        public static Point StringToPoint(string pStr)
        {
            //{X=198,Y=42}
            string regex = @"\{X=(?<X>[-]?\d+),(|\s)(Y=(?<Y>[-]?\d+))}";
            var result = new Regex(regex).Match(pStr);
            var X = result.Groups["X"].Value;
            var Y = result.Groups["Y"].Value;

            return new Point(Convert.ToInt32(X), Convert.ToInt32(Y));
        }
    }
    
}
