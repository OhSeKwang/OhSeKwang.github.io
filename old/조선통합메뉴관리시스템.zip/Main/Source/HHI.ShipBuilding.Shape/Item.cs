﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HHI.ShipBuilding.Shape.CLS;

namespace HHI.ShipBuilding.Shape
{
    public partial class Item : ShapeBase, IDataCom
    {
        #region -> Viewr 메뉴 클릭 이벤트
        public event EventHandler<ShapeMenuClickEventArg> ShapeMenuClick;

        public void DoShapeMenuClick(string menuId, string tcode)
        {
            OnShapeMenuClick(new ShapeMenuClickEventArg(menuId, tcode));
        }

        public virtual void OnShapeMenuClick(ShapeMenuClickEventArg e)
        {
            EventHandler<ShapeMenuClickEventArg> handler = ShapeMenuClick;

            if (handler != null)
            {
                handler(this, e);
            }
        }
        #endregion

        #region -> 외부에서 받은 IDataCom 의 데이터 : 상황에 따라 변할 수 있다.

        private string menuId = string.Empty;
        private string menuTitle = string.Empty;

        /// <summary>
        /// 메뉴 아이디
        /// </summary>
        public string MenuId
        {
            get
            {
                return menuId;
            }
        }

        /// <summary>
        /// 메뉴 타이틀
        /// </summary>
        public string MenuTitle
        {
            get
            {
                return menuTitle;
            }
        }

        #endregion -> 외부에서 받은 IDataCom 의 데이터

        public Item()
        {
            InitializeComponent();

            CurrentShapeTypes = new CircularItems<string>(new string[] { "Circle", "Rectangle" });
            MyDescFont = new ShapeFont(this.lblText);

            this.txtText.Visible = false;
            this.ShowTextBox += Item_ShowTextBox;
        }

        public override void InitializedShapeDisplay()
        {
            base.InitializedShapeDisplay();

            if (string.IsNullOrEmpty(DESCRIPTION))
                DESCRIPTION = menuTitle + "\r\n" + menuId;

            lblText.Text = DESCRIPTION;
        }

        void Item_ShowTextBox(object sender, EventArgs e)
        {
            txtText.Text = lblText.Text;
            txtText.Visible = true;
        }

        #region ▶ 마우스 관련 처리
        
        private void Item_MouseDown(object sender, MouseEventArgs e)
        {
            if (MyCanvas.IsViewer)
                return;

            ShapeMouseDown(e);
        }

        private void Item_MouseMove(object sender, MouseEventArgs e)
        {
            if (MyCanvas.IsViewer)
                return;

            ShapeMouseMoving(e);
        }

        private void Item_MouseUp(object sender, MouseEventArgs e)
        {
            if (MyCanvas.IsViewer)
                return;

            ShapeMouseUp(e);
        }

        private void Item_MouseHover(object sender, EventArgs e)
        {
            if (MyCanvas.IsViewer)
            {
                if (EnableShape)
                {
                    Cursor = Cursor = Cursors.Hand;
                }
                return;
            }

            if (Status == CLS.ENUM_STATUS_SHAPE.Selected)
            {
                
            }
            else
            {
                if (Cursor.Current == Cursors.SizeAll)
                    return;

                Cursor = Cursors.Hand;
            }
        }

        private void Item_MouseLeave(object sender, EventArgs e)
        {
            Cursor = Cursors.Default;
        }

        private void Item_MouseClick(object sender, MouseEventArgs e)
        {
            if (MyCanvas.IsViewer)
            {
                DoShapeMenuClick(menuId, Convert.ToString(EXTRA1));
                return;
            }
                
            ShapeMouseClick(e);
        }

        #endregion ▶ 마우스 관련 처리

        #region ▶ IDataCom 구현
        public string SourceId
        {
            set 
            { 
                menuId = value;
                SOURCE_ID = menuId;
            }
        }

        public string SoucrceDesc
        {
            set 
            { 
                menuTitle = value; 
            }
        }
        #endregion

        private void txtText_KeyDown(object sender, KeyEventArgs e)
        {
            if (MyCanvas.IsViewer)
                return;

            if (e.Modifiers == Keys.Control)
            {
                DESCRIPTION = txtText.Text;
                lblText.Text = txtText.Text;
                txtText.Visible = false;
            }
        }
        
    }
}
