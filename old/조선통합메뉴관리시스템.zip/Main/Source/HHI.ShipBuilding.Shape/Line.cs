﻿using HHI.ShipBuilding.Shape.CLS;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace HHI.ShipBuilding.Shape
{
    /// <summary>
    /// 
    /// </summary>
    public class Line : ILineEntity
    {
        private ShapeBase startShape = null;
        private ShapeBase endShape = null;

        private Color color = Color.SkyBlue;
        private float width = 7;
        private Point start = Point.Empty;
        private Point end = Point.Empty;

        private string start_Id = string.Empty;
        private string end_Id = string.Empty;

        Dictionary<ENUM_ANCHOR_POINT, Point> startAnchorPointsAll = new Dictionary<ENUM_ANCHOR_POINT, Point>();
        Dictionary<ENUM_ANCHOR_POINT, Point> endAnchorPointsAll = new Dictionary<ENUM_ANCHOR_POINT, Point>();

        List<HLine> listLine = new List<HLine>();
        Dictionary<int, double> hline = new Dictionary<int, double>();
        CircularItems<HLine> anchorLines;

        public Line(ShapeBase start, ShapeBase end)
        {
            startShape = start;
            endShape = end;

            start_Id = startShape.SHAPE_ID;
            end_Id = endShape.SHAPE_ID;
        }

        /// <summary>
        /// CANVAS_ID
        /// </summary>
        public string CANVAS_ID { get; set; }
        /// <summary>
        /// 부모 ID
        /// </summary>
        public string SHAPE_ID { get; set; }
        /// <summary>
        /// 라인 ID
        /// </summary>
        public string LINE_ID { get; set; }

        /// <summary>
        /// 색
        /// </summary>
        public Color Color
        {
            get
            {
                return color;
            }
            set
            {
                color = value;
            }
        }

        /// <summary>
        /// 두께
        /// </summary>
        public float Width
        {
            get
            {
                return width;
            }
            set
            {
                width = value;
            }
        }

        /// <summary>
        /// 시작 좌표
        /// </summary>
        public Point SPoint
        {
            get
            {
                return start;
            }
            set
            {
                start = value;
            }
        }
        /// <summary>
        /// 끝 좌표
        /// </summary>
        public Point EPoint
        {
            get
            {
                return end;
            }
            set
            {
                end = value;
            }
        }

        public string START_ID
        {
            get
            {
                return start_Id;
            }
            set
            {
                start_Id = value;
            }
        }

        public string END_ID
        {
            get
            {
                return end_Id;
            }
            set
            {
                end_Id = value;
            }
        }

        /// <summary>
        /// 좌표값을 다시 계산 한다.
        /// </summary>
        public void GenPoints()
        {
            Utils.SetAnchorPointsAll(startShape.MyPointRect, ref startAnchorPointsAll);
            Utils.SetAnchorPointsAll(endShape.MyPointRect, ref endAnchorPointsAll);

            double absX = 0, absY = 0;
            double sum = 0;
            listLine.Clear();
            hline.Clear();
            int idx = 0;
            for (int i = 1; i < 5; i++)
            {
                for (int j = 1; j < 5; j++)
                {
                    absX = Math.Abs(startAnchorPointsAll[(ENUM_ANCHOR_POINT)i].X - endAnchorPointsAll[(ENUM_ANCHOR_POINT)j].X);
                    absY = Math.Abs(startAnchorPointsAll[(ENUM_ANCHOR_POINT)i].Y - endAnchorPointsAll[(ENUM_ANCHOR_POINT)j].Y);

                    absX = absX * absX;
                    absY = absY * absY;
                    sum = Math.Sqrt((absX * absX) + (absY * absY));
                    
                    listLine.Add(new HLine(startAnchorPointsAll[(ENUM_ANCHOR_POINT)i], endAnchorPointsAll[(ENUM_ANCHOR_POINT)j]));
                    hline.Add(idx, sum);
                    idx++;
                }
            }

            if (anchorLines == null)
            {
                anchorLines = new CircularItems<HLine>(new HLine[] { null, null, null, null });
            }

            int n = 0;
            foreach(var h in hline.OrderBy(k => k.Value))
            {
                anchorLines.GetEnumerator().Items[n] = listLine[h.Key];
                n++;
                if (n == 6)
                {
                    break;
                }
            }
            start = anchorLines.GetEnumerator().Current.StartAP;
            end = anchorLines.GetEnumerator().Current.EndAP;
            //System.Diagnostics.Debug.WriteLine("Shape 좌표: " + startShape.MyPointRect.ToString(), endShape.MyPointRect.ToString());
            //System.Diagnostics.Debug.WriteLine("Anchor 좌표: " + start.ToString(), end.ToString());
        }

        /// <summary>
        /// 연결점 변경
        /// </summary>
        public void ChangeAnchor()
        {
            if (anchorLines == null)
                return;

            anchorLines.GetEnumerator().MoveNext();

            start = anchorLines.GetEnumerator().Current.StartAP;
            end = anchorLines.GetEnumerator().Current.EndAP;
        }

        /// <summary>
        /// 선이 유효한지 검사한다.
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        public bool IsValid(List<string> list)
        {
            if (list.Contains(startShape.SHAPE_ID) && list.Contains(endShape.SHAPE_ID))
            {
                return true;
            }
            return false;
        }
    }
}
