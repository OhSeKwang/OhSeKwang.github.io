﻿namespace HHI.ShipBuilding.Shape
{
    partial class Canvas
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Canvas));
            this.popupMenu1 = new DevExpress.XtraBars.PopupMenu(this.components);
            this.btnCreateGroup = new DevExpress.XtraBars.BarButtonItem();
            this.btnCreateTCODE = new DevExpress.XtraBars.BarButtonItem();
            this.btnDeleteShape = new DevExpress.XtraBars.BarButtonItem();
            this.btnStartLine = new DevExpress.XtraBars.BarButtonItem();
            this.btnEndLine = new DevExpress.XtraBars.BarButtonItem();
            this.btnDeleteLine = new DevExpress.XtraBars.BarButtonItem();
            this.btnEditText = new DevExpress.XtraBars.BarButtonItem();
            this.btnTransform = new DevExpress.XtraBars.BarButtonItem();
            this.btnAlignTop = new DevExpress.XtraBars.BarButtonItem();
            this.btnAlignLeft = new DevExpress.XtraBars.BarButtonItem();
            this.btnAlignVCenter = new DevExpress.XtraBars.BarButtonItem();
            this.btnAlignHCenter = new DevExpress.XtraBars.BarButtonItem();
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.barSubItem1 = new DevExpress.XtraBars.BarSubItem();
            this.btnAttributes = new DevExpress.XtraBars.BarButtonItem();
            this.lblEmptyCanvas = new System.Windows.Forms.Label();
            this.btnMoveLine = new DevExpress.XtraBars.BarButtonItem();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // popupMenu1
            // 
            this.popupMenu1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btnCreateGroup),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnCreateTCODE),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnDeleteShape),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnStartLine, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnEndLine),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnMoveLine),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnDeleteLine),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnEditText, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnTransform),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnAlignTop, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnAlignLeft),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnAlignVCenter),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnAlignHCenter)});
            this.popupMenu1.Manager = this.barManager1;
            this.popupMenu1.Name = "popupMenu1";
            this.popupMenu1.BeforePopup += new System.ComponentModel.CancelEventHandler(this.popupMenu1_BeforePopup);
            // 
            // btnCreateGroup
            // 
            this.btnCreateGroup.Caption = "Create Group";
            this.btnCreateGroup.Glyph = ((System.Drawing.Image)(resources.GetObject("btnCreateGroup.Glyph")));
            this.btnCreateGroup.Id = 3;
            this.btnCreateGroup.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnCreateGroup.LargeGlyph")));
            this.btnCreateGroup.Name = "btnCreateGroup";
            this.btnCreateGroup.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnCreateGroup_ItemClick);
            // 
            // btnCreateTCODE
            // 
            this.btnCreateTCODE.Caption = "Create TCODE";
            this.btnCreateTCODE.Id = 13;
            this.btnCreateTCODE.Name = "btnCreateTCODE";
            this.btnCreateTCODE.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnCreateTCODE_ItemClick);
            // 
            // btnDeleteShape
            // 
            this.btnDeleteShape.Caption = "Delete Shape";
            this.btnDeleteShape.Glyph = ((System.Drawing.Image)(resources.GetObject("btnDeleteShape.Glyph")));
            this.btnDeleteShape.Id = 4;
            this.btnDeleteShape.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnDeleteShape.LargeGlyph")));
            this.btnDeleteShape.Name = "btnDeleteShape";
            this.btnDeleteShape.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnDeleteShape_ItemClick);
            // 
            // btnStartLine
            // 
            this.btnStartLine.Caption = "Start Line";
            this.btnStartLine.Glyph = ((System.Drawing.Image)(resources.GetObject("btnStartLine.Glyph")));
            this.btnStartLine.Id = 5;
            this.btnStartLine.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnStartLine.LargeGlyph")));
            this.btnStartLine.Name = "btnStartLine";
            this.btnStartLine.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnStartLine_ItemClick);
            // 
            // btnEndLine
            // 
            this.btnEndLine.Caption = "End Line";
            this.btnEndLine.Glyph = ((System.Drawing.Image)(resources.GetObject("btnEndLine.Glyph")));
            this.btnEndLine.Id = 9;
            this.btnEndLine.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnEndLine.LargeGlyph")));
            this.btnEndLine.Name = "btnEndLine";
            this.btnEndLine.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnEndLine_ItemClick);
            // 
            // btnDeleteLine
            // 
            this.btnDeleteLine.Caption = "Delete Line";
            this.btnDeleteLine.Id = 14;
            this.btnDeleteLine.Name = "btnDeleteLine";
            this.btnDeleteLine.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnDeleteLine_ItemClick);
            // 
            // btnEditText
            // 
            this.btnEditText.Caption = "Edit Text";
            this.btnEditText.Glyph = ((System.Drawing.Image)(resources.GetObject("btnEditText.Glyph")));
            this.btnEditText.Id = 7;
            this.btnEditText.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnEditText.LargeGlyph")));
            this.btnEditText.Name = "btnEditText";
            this.btnEditText.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnEditText_ItemClick);
            // 
            // btnTransform
            // 
            this.btnTransform.Caption = "Transform";
            this.btnTransform.Glyph = ((System.Drawing.Image)(resources.GetObject("btnTransform.Glyph")));
            this.btnTransform.Id = 8;
            this.btnTransform.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnTransform.LargeGlyph")));
            this.btnTransform.Name = "btnTransform";
            this.btnTransform.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnTransform_ItemClick);
            // 
            // btnAlignTop
            // 
            this.btnAlignTop.Caption = "Align Top";
            this.btnAlignTop.Id = 11;
            this.btnAlignTop.Name = "btnAlignTop";
            this.btnAlignTop.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnAlignTop_ItemClick);
            // 
            // btnAlignLeft
            // 
            this.btnAlignLeft.Caption = "Align Left";
            this.btnAlignLeft.Id = 12;
            this.btnAlignLeft.Name = "btnAlignLeft";
            this.btnAlignLeft.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnAlignLeft_ItemClick);
            // 
            // btnAlignVCenter
            // 
            this.btnAlignVCenter.Caption = "Align VCenter";
            this.btnAlignVCenter.Id = 15;
            this.btnAlignVCenter.Name = "btnAlignVCenter";
            this.btnAlignVCenter.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnAlignVCenter_ItemClick);
            // 
            // btnAlignHCenter
            // 
            this.btnAlignHCenter.Caption = "Align HCenter";
            this.btnAlignHCenter.Id = 16;
            this.btnAlignHCenter.Name = "btnAlignHCenter";
            this.btnAlignHCenter.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnAlignHCenter_ItemClick);
            // 
            // barManager1
            // 
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.btnCreateGroup,
            this.btnDeleteShape,
            this.btnStartLine,
            this.barSubItem1,
            this.btnEditText,
            this.btnTransform,
            this.btnEndLine,
            this.btnAttributes,
            this.btnAlignTop,
            this.btnAlignLeft,
            this.btnCreateTCODE,
            this.btnDeleteLine,
            this.btnAlignVCenter,
            this.btnAlignHCenter,
            this.btnMoveLine});
            this.barManager1.MaxItemId = 18;
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Size = new System.Drawing.Size(662, 0);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 462);
            this.barDockControlBottom.Size = new System.Drawing.Size(662, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 0);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 462);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(662, 0);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 462);
            // 
            // barSubItem1
            // 
            this.barSubItem1.Caption = "barSubItem1";
            this.barSubItem1.Id = 6;
            this.barSubItem1.Name = "barSubItem1";
            // 
            // btnAttributes
            // 
            this.btnAttributes.Caption = "Attributes";
            this.btnAttributes.Id = 10;
            this.btnAttributes.Name = "btnAttributes";
            // 
            // lblEmptyCanvas
            // 
            this.lblEmptyCanvas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmptyCanvas.Font = new System.Drawing.Font("Tahoma", 45F);
            this.lblEmptyCanvas.ForeColor = System.Drawing.Color.Silver;
            this.lblEmptyCanvas.Location = new System.Drawing.Point(0, 0);
            this.lblEmptyCanvas.Name = "lblEmptyCanvas";
            this.lblEmptyCanvas.Size = new System.Drawing.Size(662, 462);
            this.lblEmptyCanvas.TabIndex = 4;
            this.lblEmptyCanvas.Text = "Empty Canvas";
            this.lblEmptyCanvas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnMoveLine
            // 
            this.btnMoveLine.Caption = "Move Line";
            this.btnMoveLine.Id = 17;
            this.btnMoveLine.Name = "btnMoveLine";
            this.btnMoveLine.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnMoveLine_ItemClick);
            // 
            // Canvas
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.lblEmptyCanvas);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.Highlight;
            this.Name = "Canvas";
            this.Size = new System.Drawing.Size(662, 462);
            this.Scroll += new System.Windows.Forms.ScrollEventHandler(this.Canvas_Scroll);
            this.BackColorChanged += new System.EventHandler(this.Canvas_BackColorChanged);
            this.SizeChanged += new System.EventHandler(this.Canvas_SizeChanged);
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.Canvas_DragDrop);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.Canvas_DragEnter);
            this.DragOver += new System.Windows.Forms.DragEventHandler(this.Canvas_DragOver);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Canvas_MouseClick);
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.BarButtonItem btnCreateGroup;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.BarButtonItem btnDeleteShape;
        private DevExpress.XtraBars.BarButtonItem btnStartLine;
        public DevExpress.XtraBars.PopupMenu popupMenu1;
        private DevExpress.XtraBars.BarButtonItem btnEditText;
        private DevExpress.XtraBars.BarSubItem barSubItem1;
        private DevExpress.XtraBars.BarButtonItem btnTransform;
        private DevExpress.XtraBars.BarButtonItem btnEndLine;
        private DevExpress.XtraBars.BarButtonItem btnAttributes;
        public System.Windows.Forms.Label lblEmptyCanvas;
        private DevExpress.XtraBars.BarButtonItem btnAlignTop;
        private DevExpress.XtraBars.BarButtonItem btnAlignLeft;
        private DevExpress.XtraBars.BarButtonItem btnCreateTCODE;
        private DevExpress.XtraBars.BarButtonItem btnDeleteLine;
        private DevExpress.XtraBars.BarButtonItem btnAlignVCenter;
        private DevExpress.XtraBars.BarButtonItem btnAlignHCenter;
        private DevExpress.XtraBars.BarButtonItem btnMoveLine;
    }
}
