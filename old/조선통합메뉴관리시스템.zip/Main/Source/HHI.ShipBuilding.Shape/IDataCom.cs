﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HHI.ShipBuilding.Shape
{
    interface IDataCom
    {
        string SourceId { set; }
        string SoucrceDesc { set; }
    }
}
