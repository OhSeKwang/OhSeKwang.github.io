﻿namespace WindowsFormsApplication2
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.gtRadioButtonGroup1 = new WindowsFormsApplication2.GTRadioButtonGroup();
            this.gtRadioButtonGroup2 = new WindowsFormsApplication2.GTRadioButtonGroup();
            this.gtRadioButtonGroup3 = new WindowsFormsApplication2.GTRadioButtonGroup();
            this.gtRadioButtonGroup4 = new WindowsFormsApplication2.GTRadioButtonGroup();
            this.gtRadioButtonGroup5 = new WindowsFormsApplication2.GTRadioButtonGroup();
            this.gtRadioButtonGroup6 = new WindowsFormsApplication2.GTRadioButtonGroup();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Controls.Add(this.gtRadioButtonGroup1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.gtRadioButtonGroup2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.gtRadioButtonGroup3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.gtRadioButtonGroup4, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.gtRadioButtonGroup5, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.gtRadioButtonGroup6, 1, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(54, 29);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(418, 97);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // gtRadioButtonGroup1
            // 
            this.gtRadioButtonGroup1.AutoSize = true;
            this.gtRadioButtonGroup1.GroupName = "GROUP1";
            this.gtRadioButtonGroup1.Location = new System.Drawing.Point(3, 3);
            this.gtRadioButtonGroup1.Name = "gtRadioButtonGroup1";
            this.gtRadioButtonGroup1.Size = new System.Drawing.Size(24, 16);
            this.gtRadioButtonGroup1.TabIndex = 0;
            this.gtRadioButtonGroup1.TabStop = true;
            this.gtRadioButtonGroup1.Text = "gtRadioButtonGroup1";
            this.gtRadioButtonGroup1.UseVisualStyleBackColor = true;
            // 
            // gtRadioButtonGroup2
            // 
            this.gtRadioButtonGroup2.AutoSize = true;
            this.gtRadioButtonGroup2.GroupName = "GROUP1";
            this.gtRadioButtonGroup2.Location = new System.Drawing.Point(33, 3);
            this.gtRadioButtonGroup2.Name = "gtRadioButtonGroup2";
            this.gtRadioButtonGroup2.Size = new System.Drawing.Size(24, 16);
            this.gtRadioButtonGroup2.TabIndex = 0;
            this.gtRadioButtonGroup2.TabStop = true;
            this.gtRadioButtonGroup2.Text = "gtRadioButtonGroup1";
            this.gtRadioButtonGroup2.UseVisualStyleBackColor = true;
            // 
            // gtRadioButtonGroup3
            // 
            this.gtRadioButtonGroup3.AutoSize = true;
            this.gtRadioButtonGroup3.GroupName = "GROUP2";
            this.gtRadioButtonGroup3.Location = new System.Drawing.Point(3, 33);
            this.gtRadioButtonGroup3.Name = "gtRadioButtonGroup3";
            this.gtRadioButtonGroup3.Size = new System.Drawing.Size(24, 16);
            this.gtRadioButtonGroup3.TabIndex = 0;
            this.gtRadioButtonGroup3.TabStop = true;
            this.gtRadioButtonGroup3.Text = "gtRadioButtonGroup1";
            this.gtRadioButtonGroup3.UseVisualStyleBackColor = true;
            // 
            // gtRadioButtonGroup4
            // 
            this.gtRadioButtonGroup4.AutoSize = true;
            this.gtRadioButtonGroup4.GroupName = "GROUP2";
            this.gtRadioButtonGroup4.Location = new System.Drawing.Point(33, 33);
            this.gtRadioButtonGroup4.Name = "gtRadioButtonGroup4";
            this.gtRadioButtonGroup4.Size = new System.Drawing.Size(24, 16);
            this.gtRadioButtonGroup4.TabIndex = 0;
            this.gtRadioButtonGroup4.TabStop = true;
            this.gtRadioButtonGroup4.Text = "gtRadioButtonGroup1";
            this.gtRadioButtonGroup4.UseVisualStyleBackColor = true;
            // 
            // gtRadioButtonGroup5
            // 
            this.gtRadioButtonGroup5.AutoSize = true;
            this.gtRadioButtonGroup5.GroupName = "GROUP3";
            this.gtRadioButtonGroup5.Location = new System.Drawing.Point(3, 63);
            this.gtRadioButtonGroup5.Name = "gtRadioButtonGroup5";
            this.gtRadioButtonGroup5.Size = new System.Drawing.Size(24, 16);
            this.gtRadioButtonGroup5.TabIndex = 0;
            this.gtRadioButtonGroup5.TabStop = true;
            this.gtRadioButtonGroup5.Text = "gtRadioButtonGroup1";
            this.gtRadioButtonGroup5.UseVisualStyleBackColor = true;
            // 
            // gtRadioButtonGroup6
            // 
            this.gtRadioButtonGroup6.AutoSize = true;
            this.gtRadioButtonGroup6.GroupName = "GROUP3";
            this.gtRadioButtonGroup6.Location = new System.Drawing.Point(33, 63);
            this.gtRadioButtonGroup6.Name = "gtRadioButtonGroup6";
            this.gtRadioButtonGroup6.Size = new System.Drawing.Size(24, 16);
            this.gtRadioButtonGroup6.TabIndex = 0;
            this.gtRadioButtonGroup6.TabStop = true;
            this.gtRadioButtonGroup6.Text = "gtRadioButtonGroup1";
            this.gtRadioButtonGroup6.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(661, 416);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private GTRadioButtonGroup gtRadioButtonGroup1;
        private GTRadioButtonGroup gtRadioButtonGroup2;
        private GTRadioButtonGroup gtRadioButtonGroup3;
        private GTRadioButtonGroup gtRadioButtonGroup4;
        private GTRadioButtonGroup gtRadioButtonGroup5;
        private GTRadioButtonGroup gtRadioButtonGroup6;

    }
}

