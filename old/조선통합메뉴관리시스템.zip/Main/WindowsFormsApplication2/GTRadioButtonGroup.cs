﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{   
    
    public class GTRadioButtonGroup : RadioButton
    {
        public string GroupName { get; set; }

        public GTRadioButtonGroup()
        {
            this.CheckedChanged += GTRadioButtonGroup_CheckedChanged;
          

        }

        void GTRadioButtonGroup_CheckedChanged(object sender, EventArgs e)
        {
            GTRadioButtonGroup rb = (sender as GTRadioButtonGroup);

            if (!rb.Checked)
            {
                foreach (var c in Controls)
                {
                    if (c is GTRadioButtonGroup && (c as GTRadioButtonGroup).GroupName == rb.GroupName)
                    {
                        (c as GTRadioButtonGroup).Checked = false;
                    }
                }
                rb.Checked = true;
            }
            
        }


     
    }
}
