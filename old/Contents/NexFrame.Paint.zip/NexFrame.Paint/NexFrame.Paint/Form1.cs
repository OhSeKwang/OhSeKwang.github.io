﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NexFrame.Paint
{
    public partial class Form1 : Form
    {
        private ScreenCapture objScreenCapture;

        public Form1()
        {
            InitializeComponent();
            this.Load += Form1_Load;
            btnPaint.Click += btnPaint_Click;
        }

        void Form1_Load(object sender, EventArgs e)
        {

        }

        void btnPaint_Click(object sender, EventArgs e)
        {
            //화면 호출
            if (ScreenCapture.SetCanvas())
            {
                //NexFrame에서 구현할 영역 아니면 저장까지 해줄지 확인하기
                //기본 MessageBox로 코딩 한다.
                DialogResult dr = MessageBox.Show("YES : 이미지 저장\r\nNO : Clipboard 저장 \r\nCancel : 취소", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);

                //이미지 저장
                //내부적으로 DialogResult 구현 커스텀 구현 해서 사용할수 있음
                if (dr == System.Windows.Forms.DialogResult.Yes)
                {
                    Bitmap image = ScreenCapture.GetSnapShot();
                    ScreenCapture.SaveFileDialogImages(image);    //Save 다이얼로그
                    //ScreenCapture.SaveFolderDialogImages(image); //폴더 다이얼로드

                    //Sample 코딩
                    //ScreenCapture.SaveAsImages(ScreenCapture.GetSnapShot());

                }
                //클립보드 저장
                else if (dr == System.Windows.Forms.DialogResult.No)
                {
                    Clipboard.Clear(); //클립보드 초기화
                    Image image = ScreenCapture.GetSnapShot();
                    Clipboard.SetImage(image);


                    //Sample 코딩
                    //Clipboard.SetImage(ScreenCapture.GetSnapShot());
                }
            }
        }
    }
}
