﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NexFrame.Paint
{
    public partial class Form2 : Form
    {
        private Image _image;
        public Form2()
        {
            InitializeComponent();
        }

        public Form2(Image image)
        {
            InitializeComponent();
            _image = image;
            this.Load += Form2_Load;
        }

        void Form2_Load(object sender, EventArgs e)
        {
            picCaption.Image = _image;
        }

    }
}
