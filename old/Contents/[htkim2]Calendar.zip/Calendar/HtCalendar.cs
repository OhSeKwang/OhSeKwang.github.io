﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication30
{
    public class HtCalendar : TableLayoutPanel
    {
        private readonly int MAX_LAYOUT_CALL_COUNT = 100;

        public HtCalendar()
            : base()
        {
            this.DoubleBuffered = true;
            this.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
            this.CellPaint += (s, e) =>
            {
                Graphics g = e.Graphics;
                Rectangle r = e.CellBounds;

                using (Pen pen = new Pen(Color.PowderBlue, 0))
                {
                    pen.Alignment = System.Drawing.Drawing2D.PenAlignment.Center;
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;

                    if (e.Row == (this.RowCount - 1))
                        r.Height -= 1;

                    if (e.Column == (this.ColumnCount - 1))
                        r.Width -= 1;

                    e.Graphics.DrawRectangle(pen, r);
                    pen.Dispose();
                }
            };
        }

        public DateTime _sourceDate = DateTime.Now;
        /// <summary>
        /// 달력이 표현된 날짜 입니다.
        /// </summary>
        public DateTime SourceDate 
        {
            get
            {
                return _sourceDate;
            }
        }

        public ListDaysType _listDaysType = ListDaysType.ListDaysByMonth;
        /// <summary>
        /// 달력을 표현하는 유형을 지정 합니다.
        /// </summary>
        public ListDaysType CalendarType 
        {
            get { return _listDaysType; }
            set { _listDaysType = value; }
        }

        public int iCallCount = 0;
        private bool _isInit = false;
        protected override void OnLayout(LayoutEventArgs levent)
        {
            if (iCallCount <= MAX_LAYOUT_CALL_COUNT) iCallCount++;

            if (_isInit == false && iCallCount == 6)
            {
                this.ColumnCount = 7;
                this.RowCount = 7;

                //if (this.ColumnCount == 7)
                //{
                //    MessageBox.Show("7임 : " + iCallCount.ToString() + " ? " + this.RowCount.ToString());

                //}
                //else
                //    MessageBox.Show(iCallCount.ToString() + " ? " + this.RowCount.ToString());

                AddToHeaderControls();
                SetCalander(this.SourceDate, null);

                _isInit = true;
            }
            SetColumnRowLayoutStyle();
            base.OnLayout(levent);
        }

        private void SetColumnRowLayoutStyle()
        {
            // 계속 설정 하지 말라고 임의로 100 을 잡아서 리턴함
            if (iCallCount > MAX_LAYOUT_CALL_COUNT) return;
            
            System.Diagnostics.Trace.WriteLine("iCallCount_" + iCallCount.ToString());
            
            foreach (ColumnStyle column in this.ColumnStyles)
            {
                column.SizeType = SizeType.Percent;
                column.Width = 100F / 2;
            }

            for (int i = 0; i < this.RowStyles.Count; i++)
            {
                RowStyle row = this.RowStyles[i];
                if (i == 0)
                {
                    row.SizeType = SizeType.Absolute;
                    row.Height = 25;
                }
                else
                {
                    row.SizeType = SizeType.Percent;
                    row.Height = 100F / 2;
                }
            }
        }

        /// <summary>
        /// 달력 헤더 넣기
        /// </summary>
        private void AddToHeaderControls()
        {
            int HEADER_ROW_INDEX = 0;
            string[] arrWeek = { "일", "월", "화", "수", "목", "금", "토" };

            for (int i = 0; i < arrWeek.Length; i++)
            {
                HtHeaderLabel lblHeader = new HtHeaderLabel(i == arrWeek.Length - 1);
                lblHeader.Name = "lblWeek" + i.ToString();
                lblHeader.Text = arrWeek[i];
                lblHeader.BackColor = Color.Beige;

                this.Controls.Add(lblHeader, i, HEADER_ROW_INDEX);
            }

            SetColumnRowLayoutStyle();
        }

        /// <summary>
        /// 달력 날짜 넣기
        /// </summary>
        /// <param name="date"></param>
        /// <param name="eventList"></param>
        public void SetCalander(DateTime date, List<EventItem> eventList)
        {
            // 달력을 만든 날짜 설정
            _sourceDate = date;

            int iPrevMonthLastDay = date.AddMonths(-1).Lastday();
            int iPrevMonthFirstDay = date.AddMonths(1).Firstday();

            int iMonthLastDay = date.Lastday();
            int iMonthFirstDay = date.Firstday();
            int iWeeksInMonth = (iMonthFirstDay + iMonthLastDay) / 7 + 1;

            List<string> dayList = null;
            if(this.CalendarType == ListDaysType.ListDaysByMonth)
                dayList = date.ListDaysByMonth();
            else
                dayList = date.ListDaysByTodayFirst();

            // 이전달 날짜 추가
            int iEmptyCount = dayList.Where(a => a.Trim() == "").Count();
            int iPrevEmptyStartDay = iPrevMonthLastDay - iEmptyCount + 1;
            for (int i = 0; i < iEmptyCount; i++)
            {
                dayList[i] = "-" + (iPrevEmptyStartDay + i).ToString();
            }

            // 다음달 날짜 추가
            Enumerable.Range(1, 42 - dayList.Count).ToList().ForEach(a => dayList.Add("+" + a.ToString()));

            // 달력 만들기
            int iTableRowIndex = 1;
            int iTableColumnIndex = 0;
            foreach (string day in dayList)
            {
                HtPanel dayPanel = null;

                dayPanel = (HtPanel)this.GetControlFromPosition(iTableColumnIndex, iTableRowIndex);
                if (dayPanel == null)
                {
                    dayPanel = new HtPanel();
                    this.Controls.Add(dayPanel, iTableColumnIndex, iTableRowIndex);
                }

                dayPanel.Name = "pnl" + day + "Day";
                dayPanel.ColumnIndex = iTableColumnIndex;
                dayPanel.Day = System.Math.Abs(Convert.ToInt16(day));

                if (day.StartsWith("-"))
                {
                    dayPanel.Month = date.Month - 1;
                    dayPanel.DayColor = Color.Gray;
                }
                else if(day.StartsWith("+"))
                {
                    dayPanel.Month = date.Month + 1;
                    dayPanel.DayColor = Color.Gray;
                }
                else
                {
                    dayPanel.Month = date.Month;
                    dayPanel.DayColor = Color.Black;
                }

                // 다음 컬럼으로..
                iTableColumnIndex += 1;

                // Row 증가
                if (iTableColumnIndex == 7)
                {
                    iTableRowIndex += 1;
                    iTableColumnIndex = 0;
                }
            }
        }
    }
}
