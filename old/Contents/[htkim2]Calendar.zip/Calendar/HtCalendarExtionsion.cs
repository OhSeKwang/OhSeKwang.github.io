﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication30
{
    public static class HtCalendarExtionsion
    {
        public static int Firstday(this DateTime date)
        {
            return (int)date.AddDays(-date.Day + 1).DayOfWeek;
        }

        public static int Lastday(this DateTime date)
        {
            return DateTime.DaysInMonth(date.Year, date.Month);
        }

        public static List<string> ListDaysByMonth(this DateTime date)
        {
            return Enumerable.Repeat(" ", Firstday(date))
                .Concat(Enumerable.Range(1, Lastday(date))
                .Select(i => i.ToString())).ToList();
        }

        public static List<string> ListDaysByTodayFirst(this DateTime date)
        {
            List<string> dayList = new List<string>();

            for (int i = 0; i < 42; i++)
            {
                DateTime dt = date.AddDays(-(int)date.DayOfWeek).AddDays(i);

                if(dt.Month == date.Month)
                    dayList.Add(dt.Day.ToString());
                else if (dt.Month > date.Month)
                    dayList.Add("+" + dt.Day.ToString());
                else
                    dayList.Add("-" + dt.Day.ToString());
            }
            return dayList;
        }
    }
}
