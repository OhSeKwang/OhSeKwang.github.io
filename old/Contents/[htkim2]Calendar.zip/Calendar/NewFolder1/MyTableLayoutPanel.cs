﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace WindowsFormsApplication30
{
    public class MyTableLayoutPanel : TableLayoutPanel
    {
        #region 프로퍼티 관련 변수 year, month, eventSource

        private DateTime date = DateTime.Now;
        private List<EventList> eventSource = null;
        private Color focusEnter = Color.Gray;
        private Color focusLeave = Color.Yellow;
        private Color cellLayout = Color.Black;
        
        #endregion

        #region 프로퍼티 Year, EventSource

        /// <summary>
        /// 달력에 표시할 년도에 해당하는 프로퍼티
        /// </summary>
        public DateTime Date
        {
            get
            {
                return date;
            }
            set
            {
                date = value;
                DateEventSource(date, eventSource);
            }
        }

        /// <summary>
        /// 달력에 표시될 DateTime과 해당 날짜의 Event를 가진 List<EventList>를 List로 하는 프로퍼티
        /// </summary>
        public List<EventList> EventSource
        {
            get
            {
                return eventSource;
            }
            set
            {
                eventSource = value;
            }
        }
        /// <summary>
        /// 달력의 MouseEnter, MouseLeave, CellLayout의 컬러 프로퍼티
        /// </summary>
        public Color FocusEnter
        {
            get { return focusEnter; }
            set { focusEnter = value; }
        }
        public Color FocusLeave
        {
            get { return focusLeave; }
            set { focusLeave = value; }
        }
        public Color CellLayout
        {
            get { return cellLayout; }
            set { cellLayout = value; }
        }
        

        #endregion

        #region 메소드 MyTableLayoutPanel, GetCalendar

        public MyTableLayoutPanel() : base()
        {
            this.DoubleBuffered = true;
            this.RowStyles.Clear();
            
            GetCalendar();
        }

        protected override void OnLayout(LayoutEventArgs levent)
        {
            // improve rendering
            this.RowCount = 7;
            this.ColumnCount = 7;
            base.OnLayout(levent);
        }

        
        public void DateEventSource (DateTime toDay, List<EventList> List)
        {
            this.Controls.Clear();
            //iFirstday는 1일이 무슨요일인지 확인
            //iLastday는 해당 월이 몇일까지 있는지 확인
            //iWeeksInMonth 해당 월이 몇주까지 있는지 확인
            //TextList 해당 월의 날짜를 List<string>으로 초기화
            int bfLastday = HtCalendarExtionsion.Lastday(toDay.AddMonths(-1));
            int afFirstday = HtCalendarExtionsion.Firstday(toDay.AddMonths(1));
            int iFirstday = HtCalendarExtionsion.Firstday(toDay);
            int iLastday = HtCalendarExtionsion.Lastday(toDay);
            int iWeeksInMonth = (iFirstday + iLastday) / 7 + 1;
            List<string> TextList = HtCalendarExtionsion.ListDaysByMonth(toDay);

            //MyTableLayoutPanel에 날짜 순서대로 출력해줄때 카운트
            var index = 0;

            //MyTableLayoutPanel 내의 요일 표시
            string[] week = { "일", "월", "화", "수", "목", "금", "토" };
            for (int j = 0; j < 7; j++)
            {
                Label lbl = new Label();
                lbl.Dock = DockStyle.Fill;
                lbl.Margin = new Padding(1);
                lbl.TextAlign = ContentAlignment.MiddleCenter;
                lbl.Text = week[j];
                this.Controls.Add(lbl);
            }

            //MyTableLayoutPanel에서 활성화된 달력 이전 달 날짜를 표시
            int q = bfLastday;
            int w = (iFirstday == 0) ? 7 : iFirstday;
            for (int r = q - w + 1; r <= q; r++)
            {
                String drawString = r.ToString();
                Font drawFont = new Font("맑은 고딕", 9);
                SolidBrush drawBrush = new SolidBrush(Color.DarkGray);
                PointF drawPoint = new PointF(5, 5);

                MyPanel pnl = new MyPanel();
                pnl.Paint += (object sender, PaintEventArgs e) =>
                {
                    e.Graphics.DrawString(drawString, drawFont, drawBrush, drawPoint);
                };
                pnl.Click += (object sender, EventArgs e) =>
                {
                    this.Date = toDay.AddMonths(-1);
                };
                this.Controls.Add(pnl);
            }

            //List로 받아온 날짜를 순서대로 MyTableLayoutPanel에 출력
            foreach (string dateText in TextList)
            {
                //받아온 List중 날짜가 없으면 MyPanel만 넣고 다음으로 진행
                if (dateText.Equals(" "))
                {
                }
                //받아온 List중 날짜가 있으면 진행
                else
                {
                    String drawString = dateText;
                    Font drawFont = new Font("맑은 고딕", 9);
                    SolidBrush drawBrush = new SolidBrush(index % 7 == 0 ? Color.Red : (index % 7 == 6 ? Color.Blue : Color.Black));
                    PointF drawPoint = new PointF(5, 5);

                    //MyPanel을 넣고 속성값 정의
                    MyPanel pnl = new MyPanel();
                    pnl.Name = drawString;
                    pnl.BackColor = focusLeave;
                    pnl.MouseEnter += (s1, e1) => pnl.BackColor = focusEnter;
                    pnl.MouseLeave += (s1, e1) => pnl.BackColor = focusLeave;
                    //Panel 위쪽에 날짜가 표시되도록 Paint
                    pnl.Paint += (object sender, PaintEventArgs e) =>
                    {
                        e.Graphics.DrawString(drawString, drawFont, drawBrush, drawPoint);
                    };

                    if (List != null)
                    {
                        //eventSource 프로퍼티로 가져온 List을 확인
                        foreach (EventList i in List)
                        {
                            //List중 달력에 표시한 년, 월이 있으면 실행 없으면 무시
                            if (i.eventDay.Year == toDay.Year && i.eventDay.Month == toDay.Month)
                            {
                                //List중 현재 MyPanel의 날짜와 일치하는 데이터가 있다면 실행 없으면 무시
                                if (i.eventDay.Day.ToString().Equals(pnl.Name))
                                {
                                    int lblName = 0;
                                    //달력의 MyPanel과 일치하므로 List 내부 String[] eventList를 MyLabel형식으로 출력
                                    foreach (string k in i.eventList)
                                    {
                                        MyLabel lbl = new MyLabel();
                                        lbl.Click += MyLabel.Label_Click;
                                        lbl.Name = lblName.ToString();
                                        lbl.Text = k;
                                        lbl.BackColor = Color.LightBlue;
                                        MyPanel space = new MyPanel();
                                        space.Height = 2;
                                        space.Dock = DockStyle.Top;
                                        pnl.Controls.Add(lbl);
                                        pnl.Controls.Add(space);
                                        lblName++;
                                    }
                                }
                            }
                        }
                    }
                    //해당 MyPanel을 MyTableLayoutPanel에 추가
                    this.Controls.Add(pnl);
                }
                index++;
            }
            //MyTableLayoutPanel에서 활성화된 달력 다음 달 날짜를 표시
            for (int t = 1; t <= 42 - iLastday - w; t++)
            {
                String drawString = t.ToString();
                Font drawFont = new Font("맑은 고딕", 9);
                SolidBrush drawBrush = new SolidBrush(Color.DarkGray);
                PointF drawPoint = new PointF(5, 5);

                MyPanel pnl = new MyPanel();
                pnl.Paint += (object sender, PaintEventArgs e) =>
                {
                    e.Graphics.DrawString(drawString, drawFont, drawBrush, drawPoint);
                };
                pnl.Click += (object sender, EventArgs e) =>
                {
                    this.Date = toDay.AddMonths(1);
                };
                this.Controls.Add(pnl);
            }
        }

        void OnTableLayoutPanelCellPaint(object sender, TableLayoutCellPaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Rectangle r = e.CellBounds;

            using (Pen pen = new Pen(this.CellLayout, 0))
            {
                pen.Alignment = System.Drawing.Drawing2D.PenAlignment.Center;
                pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;

                if (e.Row == (this.RowCount - 1))
                    r.Height -= 1;

                if (e.Column == (this.ColumnCount - 1))
                    r.Width -= 1;

                e.Graphics.DrawRectangle(pen, r);
                pen.Dispose();
            }
        }

        /// <summary>
        /// MyTableLayoutPanel에 날짜와 해당 Event를 Label형식으로 출력하는 메소드
        /// </summary>
        /// <param name="toDay">달력에 보여질 DateTime</param>
        /// <returns></returns>
        public void GetCalendar()
        {
            //MyTableLayoutPanel 속성 정의
            this.ColumnCount = 7;
            this.RowCount = 7;
            this.Dock = DockStyle.Fill;
            this.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
            this.CellPaint += new TableLayoutCellPaintEventHandler(OnTableLayoutPanelCellPaint);

            //MyTableLayoutPanel 내의 사이즈 조절
            this.ColumnStyles.Clear();
            this.RowStyles.Clear();
            Enumerable.Range(1, 7).ToList().ForEach(x =>
                this.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F / 2)));
            Enumerable.Range(1, 1).ToList().ForEach(x =>
                this.RowStyles.Add(new RowStyle(SizeType.Absolute, 25)));
            Enumerable.Range(2, 7).ToList().ForEach(x =>
                this.RowStyles.Add(new RowStyle(SizeType.Percent, 100F / 2)));
        }

        #endregion
    }
}
