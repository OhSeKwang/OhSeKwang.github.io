﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication30
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(htCalendar1.iCallCount.ToString());
            //MessageBox.Show(htCalendar1.CallString.ToString());
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            DateTime dt = new DateTime(Convert.ToInt16(txtYear.Text), Convert.ToInt16(txtMonth.Text), Convert.ToInt16(txtDay.Text));

            if (rdoMonth.Checked)
                htCalendar1.CalendarType = ListDaysType.ListDaysByMonth;
            else
                htCalendar1.CalendarType = ListDaysType.ListDaysByTodayFirst;

            htCalendar1.SetCalander(dt, null);
        }

        private void rdoMonth_CheckedChanged(object sender, EventArgs e)
        {
            button1.PerformClick();
        }
    }
}
