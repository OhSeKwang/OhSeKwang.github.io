﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication30
{
    public enum ListDaysType
    {
        /// <summary>
        /// 월 기준으로 달력을 표현 합니다.
        /// </summary>
        ListDaysByMonth,
        /// <summary>
        /// 일 기준으로 달력을 표현 합니다.
        /// </summary>
        ListDaysByTodayFirst
        
    }
}
