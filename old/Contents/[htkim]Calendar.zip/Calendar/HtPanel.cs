﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication30
{
    public class HtPanel : Panel
    {
        public HtPanel()
        {
            this.Margin = new Padding(0);
            this.Padding = new Padding(5, 35, 5, 0);

            this.Dock = DockStyle.None;
            this.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;

            this.Location = new Point(0, 0);

            this.Font = new Font("맑은 고딕", 9);
        }

        private int _day = 1;
        public int Day
        {
            get { return _day; }
            set { _day = value; }
        }

        private Color _dayColor = Color.Black;
        public Color DayColor
        {
            get { return _dayColor; }
            set { _dayColor = value; }
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            using (SolidBrush drawBrush = new SolidBrush(_dayColor))
            {
                PointF drawPoint = new PointF(5, 5);
                e.Graphics.DrawString(this.Day.ToString(), this.Font, drawBrush, drawPoint);
            }

            base.OnPaint(e);
        }
    }
}
