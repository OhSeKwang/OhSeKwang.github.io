﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication30
{
    public class HtCalendar : TableLayoutPanel
    {
        public HtCalendar()
            : base()
        {
            this.DoubleBuffered = true;
            this.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
            this.CellPaint += (s, e) =>
            {
                Graphics g = e.Graphics;
                Rectangle r = e.CellBounds;

                using (Pen pen = new Pen(Color.PowderBlue, 0))
                {
                    pen.Alignment = System.Drawing.Drawing2D.PenAlignment.Center;
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;

                    if (e.Row == (this.RowCount - 1))
                        r.Height -= 1;

                    if (e.Column == (this.ColumnCount - 1))
                        r.Width -= 1;

                    e.Graphics.DrawRectangle(pen, r);
                    pen.Dispose();
                }
            };
        }

        public int iCallCount = 0;
        public StringBuilder CallString = new StringBuilder();

        protected override void OnLayout(LayoutEventArgs levent)
        {
            iCallCount++;
            if (iCallCount == 6)
            {
                this.ColumnCount = 7;
                this.RowCount = 7;

                //if (this.ColumnCount == 7)
                //{
                //    MessageBox.Show("7임 : " + iCallCount.ToString() + " ? " + this.RowCount.ToString());

                //}
                //else
                //    MessageBox.Show(iCallCount.ToString() + " ? " + this.RowCount.ToString());

                AddToHeaderControls();
                SetCalander(DateTime.Now, null);
            }
            SetColumnRowLayoutStyle();
            base.OnLayout(levent);
        }

        private void SetColumnRowLayoutStyle()
        {
            foreach (ColumnStyle column in this.ColumnStyles)
            {
                column.SizeType = SizeType.Percent;
                column.Width = 100F / 2;
            }

            for (int i = 0; i < this.RowStyles.Count; i++)
            {
                RowStyle row = this.RowStyles[i];
                if (i == 0)
                {
                    row.SizeType = SizeType.Absolute;
                    row.Height = 25;
                }
                else
                {
                    row.SizeType = SizeType.Percent;
                    row.Height = 100F / 2;
                }
            }
            
        }

        /// <summary>
        /// 달력 헤더 넣기
        /// </summary>
        private void AddToHeaderControls()
        {
            int HEADER_ROW_INDEX = 0;
            string[] arrWeek = { "일", "월", "화", "수", "목", "금", "토" };

            for (int i = 0; i < arrWeek.Length; i++)
            {
                HtHeaderLabel lblHeader = new HtHeaderLabel(i == arrWeek.Length - 1);
                lblHeader.Name = "lblWeek" + i.ToString();
                lblHeader.Text = arrWeek[i];
                lblHeader.BackColor = Color.Beige;

                this.Controls.Add(lblHeader, i, HEADER_ROW_INDEX);
            }

            SetColumnRowLayoutStyle();
        }

        /// <summary>
        /// 달력 날짜 넣기
        /// </summary>
        /// <param name="date"></param>
        /// <param name="eventList"></param>
        private void SetCalander(DateTime date, List<EventItem> eventList)
        {
            int iPrevMonthLastDay = GetDate.Lastday(date.AddMonths(-1));
            int iPrevMonthFirstDay = GetDate.Firstday(date.AddMonths(1));

            int iMonthLastDay = GetDate.Lastday(date);
            int iMonthFirstDay = GetDate.Firstday(date);
            int iWeeksInMonth = (iMonthFirstDay + iMonthLastDay) / 7 + 1;

            List<string> dayList = GetDate.Listday(date);

            int iBlankDay = 0;
            
            foreach (string day in dayList)
            {
                HtPanel dayPanel = new HtPanel();

                if (!string.IsNullOrEmpty(day.Trim()))
                    dayPanel.Name = "pnl" + day + "Day";
                else
                    dayPanel.Name = "pnl" + iBlankDay + "NonDay";

                this.Controls.Add(dayPanel);
            }
        }
    }
}
