﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HHI.NexFrame.Client.UI.Interface
{
    /// <summary>
    /// 해당 Editor내에서 엔터발생시 자동으로 버튼으로 실행할 Edit를 정의한다.
    /// </summary>
    public interface IStdAutoFireEnterEvtControl
    {
        /// <summary>
        /// 엔터시 실행할 버튼객체를 담는다
        /// </summary>
        IButtonControl[] EnterExecuteButton
        {
            get;
            set;
        }
    }
}
