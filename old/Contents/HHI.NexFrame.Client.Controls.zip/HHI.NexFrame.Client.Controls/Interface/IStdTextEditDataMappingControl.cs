﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HHI.NexFrame.Client.UI.Interface
{
    /// <summary>
    /// IStdBaseDataMappingControl 기본 인터페이스 및 텍스트입력 컨트롤에 대한 인터페이스를 정의
    /// </summary>
    public interface IStdTextEditDataMappingControl : IStdBaseDataMappingControl
    {
        /// <summary>
        /// 해당 컨트롤내의 값을 가져오거나, 설정시 Trim처리할지 여부를 설정한다.
        /// </summary>
        bool IsValueTrim
        {
            get;
            set;
        }
    }
}
