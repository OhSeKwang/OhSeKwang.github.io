﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HHI.NexFrame.Client.UI.Interface
{
    /// <summary>
    /// 지정한 컨트롤 Key값에 대하여 데이터에 바인딩 및 지정한 형식으로 값을 반환한다.
    /// </summary>
    public interface IStdBaseDataMappingControl
    {
        /// <summary>
        /// 해당 컨트롤에 대한 DB Mapping Name을 설정하거나,가져온다
        /// </summary>
        string Key
        {
            get;
            set;
        }

        /// <summary>
        /// 컨트롤에 데이터를 바인딩한다
        /// </summary>
        /// <param name="data"></param>
        void DataBindControl(object data);

        /// <summary>
        /// 컨트롤내의 값을 가져온다
        /// </summary>
        /// <returns></returns>
        object GetControlValue();
    }
}
