﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HHI.Security;

namespace HHI.NexFrame.Client.UI.Interface
{
    /// <summary>
    /// 표준 UI 컨트롤을 위한 인터페이스.
    /// </summary>
    public interface IStdControl
    {
        // 주) 이 인터페이스에는 권한 검사 뿐만 아니라 다국어 설정 기능 등 컨트롤에 공통 기능들이 추가로 포함되어야 한다.
        //     다국어 설정 기능은 현재 미 구현 상태임.

        /// <summary>
        /// 컨트롤이 요구하는 권한과 SecurityContext를 비교하여 권한에 따른 작업을 수행한다.
        /// </summary>
        /// <param name="accessList">컨트롤이 요구하는 권한 목록</param>
        /// <param name="ctx">SecurityContext 객체</param>
        void ApplySecurity(string[] accessList, SecurityContext ctx);
    }
}
