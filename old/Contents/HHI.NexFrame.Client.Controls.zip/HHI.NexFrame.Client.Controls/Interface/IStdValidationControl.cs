﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace HHI.NexFrame.Client.UI.Interface
{
    /// <summary>
    /// Validation 체크 가능한 컨트롤을 나타내는 인터페이스
    /// </summary>
    public interface IStdValidationControl
    {
        /// <summary>
        /// 해당 컨트롤의 값에 대한 필수입력여부를 체크한다.
        /// </summary>
        /// <returns></returns>
        bool RequiredValidation(bool isTrim);

        /// <summary>
        /// 해당 컨트롤내의 MinLength 프로퍼티의 값의 자릿수보다 작은지 여부를 체크한다.
        /// MinLength 프로퍼티 값은 0보다 커야 함.
        /// </summary>
        /// <returns></returns>
        bool MinLengthValidation();

        /// <summary>
        /// Control의 최소 자리수를 가져오거나/설정한다.
        /// </summary>
        int MinLength
        {
            get;
            set;
        }

        /// <summary>
        /// 유효성 체크검사에 실패한 컨트롤에 에러 메시지를 설정하고, 포커스 지정
        /// </summary>
        /// <param name="message">에러 메시지</param>
        void CtrlShowErrorMessage(string message);
    }
}
