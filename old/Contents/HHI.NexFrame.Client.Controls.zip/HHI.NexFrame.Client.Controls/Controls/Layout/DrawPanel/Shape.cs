﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls
{
    [Serializable]
    public class Shape
    {
        public Point Location;          //포인트
        public float Width;             //두께
        public Color Colour;            //Color
        public int ShapeNumber;         //ShapeNumber

        public Shape(Point L, float W, Color C, int S)
        {
            Location = L;               //좌표 정보
            Width = W;                  //Pen 두께
            Colour = C;                 //Color
            ShapeNumber = S;            //Shape Number
        }
    }
}


