﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HHI.NexFrame.Client.Controls
{
    public class DrawingPanel : PictureBox
    {
        #region ▶ 전역변수

        public bool Brush = true;
        private Shapes DrawingShapes = new Shapes();     // Shapes 전체 Data
        private bool IsPainting = false;                 // PAINTING
        private bool IsEraseing = false;                 // ERASEING

        private Point LastPos = new Point(0, 0);         // Down Data
        private Color _currentColour = Color.Red;
        private float _currentWidth = 5;
        private Color _highlighterColor = Color.FromArgb(100, Color.Yellow); //고정 변하지 않음.
        private DrawingMode _drawingMode = DrawingMode.Pen;

        private Color _mouseMoveColor = Color.Green;  //추가 요구사항반영 코드
        private float _mouseMoveWidth = 10;            //추가 요구사항반영 코드
        private bool _isShiftCheck = false;




        private int ShapeNum = 0;
        private Point MouseLoc = new Point(0, 0);
        private bool IsMouseing = false;

        #endregion ▶ 전역변수

        #region ▶ 생성자


        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.ResumeLayout(false);

        }
        public DrawingPanel()
        {
            this.BackgroundImageLayout = ImageLayout.Center;
            this.GetType().GetMethod("SetStyle", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic).Invoke(this, new object[] { System.Windows.Forms.ControlStyles.UserPaint | System.Windows.Forms.ControlStyles.AllPaintingInWmPaint | System.Windows.Forms.ControlStyles.DoubleBuffer, true });

            this.MouseDown += new MouseEventHandler(GtDrawingPanel_MouseDown);
            this.MouseMove += new MouseEventHandler(GtDrawingPanel_MouseMove);
            this.MouseUp += new MouseEventHandler(GtDrawingPanel_MouseUp);
            this.Paint += new PaintEventHandler(GtDrawingPanel_Paint);
            this.MouseEnter += new EventHandler(GtDrawingPanel_MouseEnter);
            this.MouseLeave += new EventHandler(GtDrawingPanel_MouseLeave);

        }


        #endregion

        #region ▶ Event

        /// <summary>
        /// MouseLeave
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GtDrawingPanel_MouseLeave(object sender, EventArgs e)
        {
            Cursor.Show();
            IsMouseing = false;
            this.Refresh();
        }

        /// <summary>
        /// MouseEnter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GtDrawingPanel_MouseEnter(object sender, EventArgs e)
        {
            Cursor.Hide();
            IsMouseing = true;
        }

        /// <summary>
        /// MouseUp
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GtDrawingPanel_MouseUp(object sender, MouseEventArgs e)
        {
            if (IsPainting)
            {
                IsPainting = false;
            }
            if (IsEraseing)
            {

                IsEraseing = false;
            }
        }

        /// <summary>
        /// MouseMove
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GtDrawingPanel_MouseMove(object sender, MouseEventArgs e)
        {
            //위치 정보
            MouseLoc = e.Location;
            //Painting
            if (IsPainting)
            {
                if (LastPos != e.Location)
                {
                    LastPos = e.Location;

                    // Color 변경 및 펜두께
                    if (DrawingMode.Equals(DrawingMode.Highlighter))
                    {
                        _currentColour = _highlighterColor;
                        _currentWidth = 20; //HighlighterColor 일경우 강제로 20;
                    }
                    else
                    {
                        _currentWidth = 5;
                    }
                    DrawingShapes.NewShape(LastPos, _currentWidth, _currentColour, ShapeNum);
                }
            }
            //Eraseing
            if (IsEraseing)
            {
                DrawingShapes.RemoveShape(e.Location, 10);
            }
            //Re Draw
            this.Refresh();
        }

        /// <summary>
        /// MouseDown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GtDrawingPanel_MouseDown(object sender, MouseEventArgs e)
        {
            //Draw
            if (Brush)
            {
                IsPainting = true;
                ShapeNum++;
                LastPos = new Point(0, 0);
            }
            //Eraseing
            else
            {
                IsEraseing = true;
            }
        }

        /// <summary>
        /// OnPaint
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GtDrawingPanel_Paint(object sender, PaintEventArgs e)
        {
            //라인정보 설정
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;

            //Draw Line
            for (int i = 0; i < DrawingShapes.NumberOfShapes() - 1; i++)
            {
                Shape T = DrawingShapes.GetShape(i);
                Shape T1 = DrawingShapes.GetShape(i + 1);

                if (T.ShapeNumber == T1.ShapeNumber)
                {

                    Pen p = new Pen(T.Colour, T.Width);

                    p.StartCap = System.Drawing.Drawing2D.LineCap.Custom;
                    p.EndCap = System.Drawing.Drawing2D.LineCap.Custom;

                    e.Graphics.DrawLine(p, T.Location, T1.Location);
                    p.Dispose();
                }
            }
            //Mouse
            if (IsMouseing)
            {
                e.Graphics.DrawEllipse(new Pen(_mouseMoveColor, 0.5f), MouseLoc.X - (_mouseMoveWidth / 2), MouseLoc.Y - (_mouseMoveWidth / 2), _mouseMoveWidth, _mouseMoveWidth);
            }
        }

        #endregion

        #region ▶ API

        /// <summary>
        /// ColorChange
        /// </summary>
        public void ColorChange()
        {

            ColorDialog colorDialog = new ColorDialog();
            DialogResult dlg = colorDialog.ShowDialog();
            if (dlg == DialogResult.OK)
            {
                //Apply the new colour
                _currentColour = colorDialog.Color;
            }
        }

        /// <summary>
        /// Clear
        /// </summary>
        public void Clear()
        {
            //Reset the list, removeing all shapes.
            DrawingShapes = new Shapes();
            this.Refresh();
            Brush = true;
        }

        /// <summary>
        /// 화면을 저장 합니다.
        /// </summary>
        public void SavePicture()
        {
            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Filter = "JPeg Image|*.jpg|Bitmap Image|*.bmp|Gif Image|*.gif|Png Image|*.png";
                dialog.Title = "Save an Image File";
                ImageFormat format = ImageFormat.Png;
                dialog.ShowDialog();
                if (dialog.FileName != "")
                {
                    string ext = System.IO.Path.GetExtension(dialog.FileName);
                    int width = Convert.ToInt32(this.Width); //Panel Width
                    int height = Convert.ToInt32(this.Height); //Panel Height
                    Bitmap bmp = new Bitmap(width, height); //Bitmap 생성
                    this.DrawToBitmap(bmp, new Rectangle(0, 0, width, height)); //Panel Image 저장 시작점(0,0) 너비(width) 높이 Height
                    switch (ext)
                    {
                        case ".jpg":
                            format = ImageFormat.Jpeg;
                            break;
                        case ".bmp":
                            format = ImageFormat.Bmp;
                            break;
                        case ".gif":
                            format = ImageFormat.Gif;
                            break;
                        case ".png":
                            format = ImageFormat.Png;
                            break;
                    }
                    bmp.Save(dialog.FileName, format);
                }
            }

        }


        /// <summary>
        /// Image 를 반환
        /// </summary>
        /// <returns></returns>
        public Bitmap GetSnapShot()
        {
            int width = Convert.ToInt32(this.Width); //Panel Width
            int height = Convert.ToInt32(this.Height); //Panel Height
            Bitmap bmp = new Bitmap(width, height); //Bitmap 생성
            this.DrawToBitmap(bmp, new Rectangle(0, 0, width, height));
            return bmp;
        }

        public void RemoveTest()
        {
            DrawingShapes.RemoveShape();
            Invalidate();
        }

        #endregion

        #region▶ 속성

        #region 사용하지 않음.

        ///// <summary>
        ///// 형광펜 색을 지정합니다. 고정입니다.
        ///// 노출 하지 않는다.
        ///// </summary>
        //[Description("형광펜 색을 지정합니다.")]
        //[DefaultValue("")]
        //public Color HighlighterColor
        //{
        //    get { return _highlighterColor; }
        //    set
        //    {
        //        _highlighterColor = Color.FromArgb(value.ToArgb());
        //        Invalidate();
        //    }
        //}

        #endregion

        /// <summary>
        /// 펜 색을 지정 합니다.
        /// </summary>
        [Description("펜 색을 지정 합니다.")]
        [DefaultValue("")]
        public Color PenColor
        {
            get { return _currentColour; }
            set
            {
                _currentColour = Color.FromArgb(value.ToArgb());
                Invalidate();
            }
        }

        /// <summary>
        /// 펜 색을 지정 합니다.
        /// </summary>
        [Description("펜 두께를 지정 합니다.")]
        [DefaultValue("")]
        public float PenWidth
        {
            get { return _currentWidth; }
            set
            {
                _currentWidth = value >= 0 ? value : 0;
                Invalidate();
            }
        }

        /// <summary>
        /// Drawing Mode
        /// </summary>
        public DrawingMode DrawingMode
        {
            get { return _drawingMode; }
            set
            {
                _drawingMode = value;
                Invalidate();
            }
        }

        #endregion

    }
}
