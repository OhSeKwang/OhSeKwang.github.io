﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls
{
    public enum DrawingMode
    {
        Pen,
        Highlighter
    };
}
