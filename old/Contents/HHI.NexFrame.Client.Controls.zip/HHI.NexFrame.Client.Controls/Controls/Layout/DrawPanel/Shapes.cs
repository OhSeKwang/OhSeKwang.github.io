﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls
{
    [Serializable]
    public class Shapes
    {
        private List<Shape> _Shapes;    //List<Shape>

        public Shapes()
        {
            _Shapes = new List<Shape>();
        }

        //Shape Count
        public int NumberOfShapes()
        {
            return _Shapes.Count;
        }

        /// <summary>
        /// Shape를 정보를 Add 합니다.
        /// </summary>
        /// <param name="L"></param>
        /// <param name="W"></param>
        /// <param name="C"></param>
        /// <param name="S"></param>
        public void NewShape(Point L, float W, Color C, int S)
        {
            _Shapes.Add(new Shape(L, W, C, S));
        }

        public Shape GetShape(int Index)
        {
            return _Shapes[Index];
        }

        /// <summary>
        /// Shape 정보를 삭제 합니다.
        /// </summary>
        /// <param name="L"></param>
        /// <param name="threshold"></param>
        public void RemoveShape(Point L, float threshold)
        {
            for (int i = 0; i < _Shapes.Count; i++)
            {
                if ((Math.Abs(L.X - _Shapes[i].Location.X) < threshold) && (Math.Abs(L.Y - _Shapes[i].Location.Y) < threshold))
                {
                    _Shapes.RemoveAt(i);
                    for (int n = i; n < _Shapes.Count; n++)
                    {
                        _Shapes[n].ShapeNumber += 1;
                    }

                    i -= 1;
                }
            }
        }

        public void RemoveShape()
        {
            if (_Shapes.Count > 0)
            {
                _Shapes.Clear();
            }
        }
    }
}


