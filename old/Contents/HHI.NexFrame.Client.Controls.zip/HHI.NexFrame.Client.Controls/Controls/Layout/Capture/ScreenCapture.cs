﻿using HHI.NexFrame.Client.Controls;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HHI.NexFrame.Client.Controls
{
    public class ScreenCapture
    {
        #region ▶ 전역변수

        private static Rectangle canvasBounds = Screen.GetBounds(Point.Empty);

        #endregion

        #region ▶ 생성자

        public ScreenCapture()
        {

        }

        #endregion

        #region ▶ Method


        /// <summary>
        /// 클립보드로 Image를 붙입니다.
        /// </summary>
        /// <returns></returns>
        public static void CaptureToCliboard()
        {
            try
            {
                using (ScreenCaptureForm canvas = new ScreenCaptureForm())
                {
                    if (canvas.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        canvasBounds = canvas.GetRectangle();
                        SetAreaSetting();
                        //클립보드 초기화
                        Clipboard.Clear();
                        Clipboard.SetImage(GetSnapShot());
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// 이미지를 반환 합니다.
        /// </summary>
        /// <returns></returns>
        public static Image CaptureToImageFile()
        {
            try
            {
                using (ScreenCaptureForm canvas = new ScreenCaptureForm())
                {
                    if (canvas.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        canvasBounds = canvas.GetRectangle();
                        SetAreaSetting();
                        return GetSnapShot();
                    }
                }

            }
            catch (Exception)
            {
                return null;
            }
            return null;
        }


        /// <summary>
        /// 폴더 다이얼로그를 호출 합니다.
        /// </summary>
        /// <returns></returns>
        public static void CaptureToFromptDialog()
        {
            try
            {
                using (ScreenCaptureForm canvas = new ScreenCaptureForm())
                {
                    if (canvas.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        canvasBounds = canvas.GetRectangle();
                        SetAreaSetting();
                        SaveFileDialogImages(GetSnapShot());
                    }
                }

            }
            catch (Exception)
            {

            }
        }

        /// <summary>
        /// Edit 화면을 호출 합니다.
        /// </summary>
        /// <returns></returns>
        public static Image CaptureToEditor()
        {
            bool _iResult = false;
            Image image;
            try
            {   
                while (true)
                {
                    using (ScreenCaptureForm canvas = new ScreenCaptureForm())
                    {
                        if (canvas.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                        {
                            canvasBounds = canvas.GetRectangle();
                            SetAreaSetting();
                            image = GetSnapShot();
                            HHI.NexFrame.Client.Controls.NexImageEditForm form = new Client.Controls.NexImageEditForm(image);
                            if (form.ShowDialog() == DialogResult.OK)
                            {
                                _iResult = false;
                                return form.ReturnImage;
                            }
                            else 
                            {
                                _iResult = true;
                            }
                        }
                        else
                            return null;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }

        /// <summary>
        /// 모니터 영역을 선택후에 전체 화면을 캡처 합니다.
        /// </summary>
        /// <returns></returns>
        public static Image CaptureToScreen(int moniterNumber)
        {
            try
            {
                //Canvas 정보를 설정 합니다.
                if (Screen.AllScreens.Count() > 1)
                {
                    //모니터가 2개일 경우만 처리
                    Screen screen = Screen.AllScreens[moniterNumber];
                    if (screen.Bounds.X < 0)
                    {
                        canvasBounds.X += (screen.Bounds.X);
                    }
                    Image image = GetSnapShot();
                    return image;
                }
            }
            catch (Exception)
            {
                return null;
            }
            return null;
        }

        /// <summary>
        /// 모니터 갯수를 리턴 합니다. 사용않함
        /// DataTable : Display Member : NAME 
        /// VALUE Member : CODE
        /// </summary>
        /// <returns>DataTable(CODE, NAME)</returns>
        private static DataTable GetMoniterCount()
        {
            //TODO :추가기능! 수정이 필요합니다.
            DataTable dt = new DataTable();
            dt.Columns.Add("CODE");
            dt.Columns.Add("NAME");
            int count = 0;

            string pattern = @"(\\\.?)"; //문자 변경처리
            string replacement = "";
            Regex rgx = new Regex(pattern);
            foreach (var item in Screen.AllScreens)
            {
                DataRow row = dt.NewRow();
                row["CODE"] = count;
                row["NAME"] = rgx.Replace(item.DeviceName, replacement);
                dt.Rows.Add(row);
                count++;
            }
            return dt;
        }

        /// <summary>
        /// 화면을 캡쳐 합니다. 사용않함
        /// </summary>
        private static bool SetCanvas()
        {
            try
            {
                using (ScreenCaptureForm canvas = new ScreenCaptureForm())
                {
                    if (canvas.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        canvasBounds = canvas.GetRectangle();
                        SetAreaSetting();
                        return true;
                    }
                    else
                        return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }


        /// <summary>
        /// 전체 영역을 캡쳐 합니다.
        /// </summary>
        /// <returns></returns>
        private static bool SetAllCanvas(int moniterNumber)
        {
            try
            {
                //Canvas 정보를 설정 합니다.
                if (Screen.AllScreens.Count() > 1)
                {
                    //모니터가 2개일 경우만 처리
                    Screen screen = Screen.AllScreens[moniterNumber];
                    if (screen.Bounds.X < 0)
                    {
                        canvasBounds.X += (screen.Bounds.X);
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }


        /// <summary>
        /// 모니터 영역을 계산해서 해당하는 부분을 캡쳐 한다.
        /// </summary>
        private static void SetAreaSetting()
        {
            Rectangle fullScrenn_bounds = Rectangle.Empty; //전체 영역 확인
            if (Screen.AllScreens.Count() > 1)
            {
                foreach (var screen in Screen.AllScreens)
                {
                    fullScrenn_bounds = Rectangle.Union(fullScrenn_bounds, screen.Bounds);
                }
                if (fullScrenn_bounds.X < 0)
                {
                    canvasBounds.X += (fullScrenn_bounds.X);
                }
            }
        }

        /// <summary>
        /// 화면을 가져 옵니다.
        /// </summary>
        /// <returns></returns>
        private static Bitmap GetSnapShot()
        {
            using (Image image = new Bitmap(canvasBounds.Width, canvasBounds.Height))
            {
                using (Graphics graphics = Graphics.FromImage(image))
                {
                    graphics.CopyFromScreen(new Point(canvasBounds.Left, canvasBounds.Top), Point.Empty, canvasBounds.Size);
                    graphics.Dispose();
                }
                return new Bitmap(image);
            }
        }

        /// <summary>
        /// Image Board 영역 처리
        /// 사용하지 않음. 필요시 사용하세요.
        /// </summary>
        /// <param name="srcImg"></param>
        /// <param name="color"></param>
        /// <param name="width"></param>
        /// <returns></returns>
        private static Image SetBorder(Image srcImg, Color color, int width)
        {
            Image dstImg = srcImg.Clone() as Image;
            Graphics g = Graphics.FromImage(dstImg);
            //g.InterpolationMode = InterpolationMode.HighQualityBicubic; //확인코드
            Pen pBorder = new Pen(color, width)
            {
                Alignment = PenAlignment.Center
            };

            // 캡쳐영역에 1px 영역에 보더를 그립니다.
            g.DrawRectangle(pBorder, 0, 0, dstImg.Width - 1, dstImg.Height - 1);

            // Clean up
            pBorder.Dispose();
            g.Save();
            g.Dispose();

            // Return
            return dstImg;
        }

        /// <summary>
        /// SaveFileDialogImages SaveFileDialog 를 호출 합니다.
        /// </summary>
        /// <param name="images"></param>
        public static void SaveFileDialogImages(Bitmap images)
        {
            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Filter = "JPeg Image|*.jpg|Bitmap Image|*.bmp|Gif Image|*.gif|Png Image|*.png";
                dialog.Title = "Save an Image File";
                ImageFormat format = ImageFormat.Png;
                dialog.ShowDialog();
                if (dialog.FileName != "")
                {
                    string ext = System.IO.Path.GetExtension(dialog.FileName);
                    switch (ext)
                    {
                        case ".jpg":
                            format = ImageFormat.Jpeg;
                            break;
                        case ".bmp":
                            format = ImageFormat.Bmp;
                            break;
                        case ".gif":
                            format = ImageFormat.Gif;
                            break;
                        case ".png":
                            format = ImageFormat.Png;
                            break;
                    }
                    images.Save(dialog.FileName, format);
                }
            }
        }

        /// <summary>
        /// 폴더 다이얼로그를 호출 해줍니다.
        /// </summary>
        /// <param name="images"></param>
        private static void SaveFolderDialogImages(Bitmap images)
        {
            using (FolderBrowserDialog dialog = new FolderBrowserDialog())
            {
                if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    images.Save(dialog.SelectedPath + "\\Snap_" + Guid.NewGuid() + ".bmp");
                }
            }
        }

        #endregion
    }
}

