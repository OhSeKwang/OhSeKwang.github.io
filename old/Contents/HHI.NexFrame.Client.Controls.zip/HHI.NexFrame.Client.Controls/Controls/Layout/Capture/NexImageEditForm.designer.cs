﻿namespace HHI.NexFrame.Client.Controls
{
    partial class NexImageEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnuTop = new System.Windows.Forms.MenuStrip();
            this.tolFile = new System.Windows.Forms.ToolStripMenuItem();
            this.tolSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.tolSend = new System.Windows.Forms.ToolStripMenuItem();
            this.tolSenEmail = new System.Windows.Forms.ToolStripMenuItem();
            this.tolSendEmailFile = new System.Windows.Forms.ToolStripMenuItem();
            this.tolEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tolCopy = new System.Windows.Forms.ToolStripMenuItem();
            this.도구ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tolPen = new System.Windows.Forms.ToolStripMenuItem();
            this.tolRedPen = new System.Windows.Forms.ToolStripMenuItem();
            this.tolBluePen = new System.Windows.Forms.ToolStripMenuItem();
            this.tolBlackPen = new System.Windows.Forms.ToolStripMenuItem();
            this.tolCustomPen = new System.Windows.Forms.ToolStripMenuItem();
            this.tolHighlighter = new System.Windows.Forms.ToolStripMenuItem();
            this.tolEraser = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnEraser = new DevExpress.XtraEditors.SimpleButton();
            this.btnHighlighter = new DevExpress.XtraEditors.SimpleButton();
            this.btnEmail = new DevExpress.XtraEditors.SimpleButton();
            this.btnCopy = new DevExpress.XtraEditors.SimpleButton();
            this.btnSave = new DevExpress.XtraEditors.SimpleButton();
            this.drpPenColor = new DevExpress.XtraEditors.DropDownButton();
            this.popupMenu1 = new DevExpress.XtraBars.PopupMenu();
            this.btnRedPen = new DevExpress.XtraBars.BarButtonItem();
            this.btnBluePen = new DevExpress.XtraBars.BarButtonItem();
            this.btnBlackPen = new DevExpress.XtraBars.BarButtonItem();
            this.barManager1 = new DevExpress.XtraBars.BarManager();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.btnCapture = new DevExpress.XtraEditors.SimpleButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pnlDrawing = new HHI.NexFrame.Client.Controls.DrawingPanel();
            this.mnuTop.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pnlDrawing)).BeginInit();
            this.SuspendLayout();
            // 
            // mnuTop
            // 
            this.mnuTop.BackColor = System.Drawing.Color.Transparent;
            this.mnuTop.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tolFile,
            this.toolStripMenuItem1,
            this.도구ToolStripMenuItem});
            this.mnuTop.Location = new System.Drawing.Point(1, 1);
            this.mnuTop.Name = "mnuTop";
            this.mnuTop.Size = new System.Drawing.Size(922, 24);
            this.mnuTop.TabIndex = 1;
            this.mnuTop.Text = "menuStrip1";
            // 
            // tolFile
            // 
            this.tolFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tolSaveAs,
            this.tolSend,
            this.tolEnd});
            this.tolFile.Name = "tolFile";
            this.tolFile.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.S)));
            this.tolFile.Size = new System.Drawing.Size(57, 20);
            this.tolFile.Text = "파일(&F)";
            // 
            // tolSaveAs
            // 
            this.tolSaveAs.Name = "tolSaveAs";
            this.tolSaveAs.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.tolSaveAs.Size = new System.Drawing.Size(154, 22);
            this.tolSaveAs.Text = "저장(S)";
            // 
            // tolSend
            // 
            this.tolSend.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tolSenEmail,
            this.tolSendEmailFile});
            this.tolSend.Name = "tolSend";
            this.tolSend.Size = new System.Drawing.Size(154, 22);
            this.tolSend.Text = "보내기(T)";
            // 
            // tolSenEmail
            // 
            this.tolSenEmail.Name = "tolSenEmail";
            this.tolSenEmail.Size = new System.Drawing.Size(234, 22);
            this.tolSenEmail.Text = "전자 메일 수신자 (E)";
            // 
            // tolSendEmailFile
            // 
            this.tolSendEmailFile.Name = "tolSendEmailFile";
            this.tolSendEmailFile.Size = new System.Drawing.Size(234, 22);
            this.tolSendEmailFile.Text = "전자 메일 수진자 첨부파일(A)";
            this.tolSendEmailFile.Visible = false;
            // 
            // tolEnd
            // 
            this.tolEnd.Name = "tolEnd";
            this.tolEnd.Size = new System.Drawing.Size(154, 22);
            this.tolEnd.Text = "끝내기 (X)";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tolCopy});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.E)));
            this.toolStripMenuItem1.Size = new System.Drawing.Size(57, 20);
            this.toolStripMenuItem1.Text = "편집(&E)";
            // 
            // tolCopy
            // 
            this.tolCopy.Name = "tolCopy";
            this.tolCopy.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.tolCopy.Size = new System.Drawing.Size(140, 22);
            this.tolCopy.Text = "복사";
            // 
            // 도구ToolStripMenuItem
            // 
            this.도구ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tolPen,
            this.tolHighlighter,
            this.tolEraser});
            this.도구ToolStripMenuItem.Name = "도구ToolStripMenuItem";
            this.도구ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.T)));
            this.도구ToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.도구ToolStripMenuItem.Text = "도구(&T)";
            // 
            // tolPen
            // 
            this.tolPen.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tolRedPen,
            this.tolBluePen,
            this.tolBlackPen,
            this.tolCustomPen});
            this.tolPen.Name = "tolPen";
            this.tolPen.Size = new System.Drawing.Size(127, 22);
            this.tolPen.Text = "펜(P)";
            // 
            // tolRedPen
            // 
            this.tolRedPen.Name = "tolRedPen";
            this.tolRedPen.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.tolRedPen.Size = new System.Drawing.Size(221, 22);
            this.tolRedPen.Text = "빨간 펜(R)";
            // 
            // tolBluePen
            // 
            this.tolBluePen.Name = "tolBluePen";
            this.tolBluePen.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B)));
            this.tolBluePen.Size = new System.Drawing.Size(221, 22);
            this.tolBluePen.Text = "파란 펜(B)";
            // 
            // tolBlackPen
            // 
            this.tolBlackPen.Name = "tolBlackPen";
            this.tolBlackPen.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.tolBlackPen.Size = new System.Drawing.Size(221, 22);
            this.tolBlackPen.Text = "검은 펜(L)";
            // 
            // tolCustomPen
            // 
            this.tolCustomPen.Name = "tolCustomPen";
            this.tolCustomPen.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.tolCustomPen.Size = new System.Drawing.Size(221, 22);
            this.tolCustomPen.Text = "사용자 지정 펜(C...)";
            // 
            // tolHighlighter
            // 
            this.tolHighlighter.Name = "tolHighlighter";
            this.tolHighlighter.Size = new System.Drawing.Size(127, 22);
            this.tolHighlighter.Text = "형광펜(&H)";
            // 
            // tolEraser
            // 
            this.tolEraser.Name = "tolEraser";
            this.tolEraser.Size = new System.Drawing.Size(127, 22);
            this.tolEraser.Text = "지우개";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnEraser);
            this.panel1.Controls.Add(this.btnHighlighter);
            this.panel1.Controls.Add(this.btnEmail);
            this.panel1.Controls.Add(this.btnCopy);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Controls.Add(this.drpPenColor);
            this.panel1.Controls.Add(this.btnCapture);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(1, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(922, 65);
            this.panel1.TabIndex = 2;
            // 
            // btnEraser
            // 
            this.btnEraser.Appearance.BackColor = System.Drawing.Color.White;
            this.btnEraser.Appearance.ForeColor = System.Drawing.Color.Transparent;
            this.btnEraser.Appearance.Options.UseBackColor = true;
            this.btnEraser.Appearance.Options.UseForeColor = true;
            this.btnEraser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnEraser.Image = global::HHI.NexFrame.Client.Controls.Properties.Resources.Eraser;
            this.btnEraser.Location = new System.Drawing.Point(396, 8);
            this.btnEraser.LookAndFeel.SkinName = "VS2010";
            this.btnEraser.LookAndFeel.Style = DevExpress.LookAndFeel.LookAndFeelStyle.Flat;
            this.btnEraser.LookAndFeel.UseDefaultLookAndFeel = false;
            this.btnEraser.Name = "btnEraser";
            this.btnEraser.Size = new System.Drawing.Size(54, 50);
            this.btnEraser.TabIndex = 6;
            // 
            // btnHighlighter
            // 
            this.btnHighlighter.Appearance.BackColor = System.Drawing.Color.White;
            this.btnHighlighter.Appearance.ForeColor = System.Drawing.Color.Transparent;
            this.btnHighlighter.Appearance.Options.UseBackColor = true;
            this.btnHighlighter.Appearance.Options.UseForeColor = true;
            this.btnHighlighter.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnHighlighter.Image = global::HHI.NexFrame.Client.Controls.Properties.Resources.HighlighterPen;
            this.btnHighlighter.Location = new System.Drawing.Point(321, 8);
            this.btnHighlighter.LookAndFeel.SkinName = "VS2010";
            this.btnHighlighter.LookAndFeel.Style = DevExpress.LookAndFeel.LookAndFeelStyle.Flat;
            this.btnHighlighter.LookAndFeel.UseDefaultLookAndFeel = false;
            this.btnHighlighter.Name = "btnHighlighter";
            this.btnHighlighter.Size = new System.Drawing.Size(54, 50);
            this.btnHighlighter.TabIndex = 5;
            // 
            // btnEmail
            // 
            this.btnEmail.Appearance.BackColor = System.Drawing.Color.White;
            this.btnEmail.Appearance.ForeColor = System.Drawing.Color.Transparent;
            this.btnEmail.Appearance.Options.UseBackColor = true;
            this.btnEmail.Appearance.Options.UseForeColor = true;
            this.btnEmail.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnEmail.Image = global::HHI.NexFrame.Client.Controls.Properties.Resources.Email;
            this.btnEmail.Location = new System.Drawing.Point(160, 8);
            this.btnEmail.LookAndFeel.SkinName = "VS2010";
            this.btnEmail.LookAndFeel.Style = DevExpress.LookAndFeel.LookAndFeelStyle.Flat;
            this.btnEmail.LookAndFeel.UseDefaultLookAndFeel = false;
            this.btnEmail.Name = "btnEmail";
            this.btnEmail.Size = new System.Drawing.Size(54, 50);
            this.btnEmail.TabIndex = 3;
            // 
            // btnCopy
            // 
            this.btnCopy.Appearance.BackColor = System.Drawing.Color.White;
            this.btnCopy.Appearance.ForeColor = System.Drawing.Color.Transparent;
            this.btnCopy.Appearance.Options.UseBackColor = true;
            this.btnCopy.Appearance.Options.UseForeColor = true;
            this.btnCopy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnCopy.Image = global::HHI.NexFrame.Client.Controls.Properties.Resources.Copy;
            this.btnCopy.Location = new System.Drawing.Point(85, 8);
            this.btnCopy.LookAndFeel.SkinName = "VS2010";
            this.btnCopy.LookAndFeel.Style = DevExpress.LookAndFeel.LookAndFeelStyle.Flat;
            this.btnCopy.LookAndFeel.UseDefaultLookAndFeel = false;
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(54, 50);
            this.btnCopy.TabIndex = 2;
            // 
            // btnSave
            // 
            this.btnSave.Appearance.BackColor = System.Drawing.Color.White;
            this.btnSave.Appearance.ForeColor = System.Drawing.Color.Transparent;
            this.btnSave.Appearance.Options.UseBackColor = true;
            this.btnSave.Appearance.Options.UseForeColor = true;
            this.btnSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSave.Image = global::HHI.NexFrame.Client.Controls.Properties.Resources.save;
            this.btnSave.Location = new System.Drawing.Point(10, 8);
            this.btnSave.LookAndFeel.SkinName = "VS2010";
            this.btnSave.LookAndFeel.Style = DevExpress.LookAndFeel.LookAndFeelStyle.Flat;
            this.btnSave.LookAndFeel.UseDefaultLookAndFeel = false;
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(54, 50);
            this.btnSave.TabIndex = 1;
            // 
            // drpPenColor
            // 
            this.drpPenColor.Appearance.BackColor = System.Drawing.Color.White;
            this.drpPenColor.Appearance.Options.UseBackColor = true;
            this.drpPenColor.DropDownControl = this.popupMenu1;
            this.drpPenColor.Image = global::HHI.NexFrame.Client.Controls.Properties.Resources.RedPen;
            this.drpPenColor.Location = new System.Drawing.Point(235, 8);
            this.drpPenColor.Name = "drpPenColor";
            this.barManager1.SetPopupContextMenu(this.drpPenColor, this.popupMenu1);
            this.drpPenColor.Size = new System.Drawing.Size(65, 50);
            this.drpPenColor.TabIndex = 4;
            this.drpPenColor.Click += new System.EventHandler(this.drpPenColor_Click);
            // 
            // popupMenu1
            // 
            this.popupMenu1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btnRedPen),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnBluePen),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnBlackPen)});
            this.popupMenu1.Manager = this.barManager1;
            this.popupMenu1.Name = "popupMenu1";
            // 
            // btnRedPen
            // 
            this.btnRedPen.Caption = "빨간 펜";
            this.btnRedPen.Id = 0;
            this.btnRedPen.Name = "btnRedPen";
            this.btnRedPen.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.PenColor_SelectedValueChanged);
            // 
            // btnBluePen
            // 
            this.btnBluePen.Caption = "파란 펜";
            this.btnBluePen.Id = 1;
            this.btnBluePen.Name = "btnBluePen";
            this.btnBluePen.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.PenColor_SelectedValueChanged);
            // 
            // btnBlackPen
            // 
            this.btnBlackPen.Caption = "검정 펜";
            this.btnBlackPen.Id = 2;
            this.btnBlackPen.Name = "btnBlackPen";
            this.btnBlackPen.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.PenColor_SelectedValueChanged);
            // 
            // barManager1
            // 
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.btnRedPen,
            this.btnBluePen,
            this.btnBlackPen});
            this.barManager1.MaxItemId = 3;
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(1, 1);
            this.barDockControlTop.Size = new System.Drawing.Size(922, 0);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(1, 766);
            this.barDockControlBottom.Size = new System.Drawing.Size(922, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(1, 1);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 765);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(923, 1);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 765);
            // 
            // btnCapture
            // 
            this.btnCapture.Appearance.BackColor = System.Drawing.Color.White;
            this.btnCapture.Appearance.ForeColor = System.Drawing.Color.Transparent;
            this.btnCapture.Appearance.Options.UseBackColor = true;
            this.btnCapture.Appearance.Options.UseForeColor = true;
            this.btnCapture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnCapture.Image = global::HHI.NexFrame.Client.Controls.Properties.Resources.Capture;
            this.btnCapture.Location = new System.Drawing.Point(471, 8);
            this.btnCapture.LookAndFeel.SkinName = "VS2010";
            this.btnCapture.LookAndFeel.Style = DevExpress.LookAndFeel.LookAndFeelStyle.Flat;
            this.btnCapture.LookAndFeel.UseDefaultLookAndFeel = false;
            this.btnCapture.Name = "btnCapture";
            this.btnCapture.Size = new System.Drawing.Size(54, 50);
            this.btnCapture.TabIndex = 0;
            this.btnCapture.Visible = false;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(1, 90);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(922, 5);
            this.panel2.TabIndex = 14;
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.AutoScrollMinSize = new System.Drawing.Size(10, 10);
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.pnlDrawing);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(1, 95);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(922, 671);
            this.panel3.TabIndex = 15;
            // 
            // pnlDrawing
            // 
            this.pnlDrawing.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pnlDrawing.DrawingMode = HHI.NexFrame.Client.Controls.DrawingMode.Pen;
            this.pnlDrawing.Location = new System.Drawing.Point(0, 0);
            this.pnlDrawing.Name = "pnlDrawing";
            this.pnlDrawing.PenColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pnlDrawing.PenWidth = 5F;
            this.pnlDrawing.Size = new System.Drawing.Size(924, 682);
            this.pnlDrawing.TabIndex = 0;
            this.pnlDrawing.TabStop = false;
            // 
            // NexImageEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(924, 767);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.mnuTop);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Name = "NexImageEditForm";
            this.Padding = new System.Windows.Forms.Padding(1);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "캡처 도구";
            this.mnuTop.ResumeLayout(false);
            this.mnuTop.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pnlDrawing)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuTop;
        private System.Windows.Forms.ToolStripMenuItem tolFile;
        private System.Windows.Forms.ToolStripMenuItem tolSaveAs;
        private System.Windows.Forms.ToolStripMenuItem tolSend;
        private System.Windows.Forms.ToolStripMenuItem tolSenEmail;
        private System.Windows.Forms.ToolStripMenuItem tolSendEmailFile;
        private System.Windows.Forms.ToolStripMenuItem tolEnd;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tolCopy;
        private System.Windows.Forms.ToolStripMenuItem 도구ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tolPen;
        private System.Windows.Forms.ToolStripMenuItem tolRedPen;
        private System.Windows.Forms.ToolStripMenuItem tolBluePen;
        private System.Windows.Forms.ToolStripMenuItem tolBlackPen;
        private System.Windows.Forms.ToolStripMenuItem tolCustomPen;
        private System.Windows.Forms.ToolStripMenuItem tolHighlighter;
        private System.Windows.Forms.ToolStripMenuItem tolEraser;
        private System.Windows.Forms.Panel panel1;
        private DevExpress.XtraEditors.SimpleButton btnCapture;
        private DevExpress.XtraEditors.DropDownButton drpPenColor;
        private DevExpress.XtraBars.PopupMenu popupMenu1;
        private DevExpress.XtraBars.BarButtonItem btnRedPen;
        private DevExpress.XtraBars.BarButtonItem btnBluePen;
        private DevExpress.XtraBars.BarButtonItem btnBlackPen;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraEditors.SimpleButton btnEraser;
        private DevExpress.XtraEditors.SimpleButton btnHighlighter;
        private DevExpress.XtraEditors.SimpleButton btnEmail;
        private DevExpress.XtraEditors.SimpleButton btnCopy;
        private DevExpress.XtraEditors.SimpleButton btnSave;
        private System.Windows.Forms.Panel panel3;
        private DrawingPanel pnlDrawing;
        private System.Windows.Forms.Panel panel2;
    }
}