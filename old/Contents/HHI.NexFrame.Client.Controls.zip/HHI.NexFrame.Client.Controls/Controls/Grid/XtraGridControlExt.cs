﻿using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Views.BandedGrid;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using DevExpress.XtraGrid.Views.Layout;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using HHI.NexFrame.Client.Controls;
using HHI.NexFrame.Client.Controls.Enums;
using HHI.NexFrame.Client.UI.Interface;
using System;
using System.ComponentModel;
using System.Data;

namespace HHI.NexFrame.Client.Controls
{
    public class XtraGridControlExt : GridControl, IStdValidationControl
    {
        public XtraGridControlExt()
        {
        }

        bool IsSetProperty = false;

        protected override void OnLoaded()
        {
            base.OnLoaded();
            if (!DesignMode && !IsSetProperty)
            {
                IsSetProperty = true;

                if (IsHeaderClickAllCheckedItem)
                {
                    this.Click += new EventHandler(HeaderCheckedItem_Click);
                }
                else
                {
                    this.Click -= new EventHandler(HeaderCheckedItem_Click);
                }
            }
        }
        private string _CheckBoxFieldName = "CHK";
        /// <summary>
        /// 체크박스를 포함하는 컬럼 필드명을 지정한다
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [Description("체크박스를 포함하는 컬럼 필드명을 지정한다")]
        public string CheckBoxFieldName
        {
            get { return _CheckBoxFieldName; }
            set { _CheckBoxFieldName = value; }
        }

        /// <summary>
        /// 그리드뷰 객체를 반환한다
        /// </summary>
        [Browsable(false)]
        public GridView InnerGridView
        {
            get
            {
                GridView gridView = null;

                if (this.MainView is AdvBandedGridView)
                    gridView = this.MainView as AdvBandedGridView;
                else if (this.MainView is BandedGridView)
                    gridView = this.MainView as BandedGridView;
                else if (this.MainView is GridView)
                    gridView = this.MainView as GridView;
                return gridView;
            }
        }

        /// <summary>
        /// 레이아웃뷰 객체를 반환한다
        /// </summary>
        [Browsable(false)]
        public LayoutView InnerLayoutView
        {
            get
            {
                LayoutView layoutView = null;
                foreach (BaseView gv in this.Views)
                {
                    if (gv is LayoutView)
                        layoutView = gv as LayoutView;
                }
                return layoutView;
            }
        }

        private XtraGridViewType _GridViewStyle = XtraGridViewType.None;

        /// <summary>
        /// 그리드 기본스타일
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [Description("그리드 기본스타일")]
        public XtraGridViewType GridViewStyle
        {
            get { return _GridViewStyle; }
            set
            {
                GridView gridView = null;
                foreach (BaseView view in this.Views)
                {
                    gridView = view as GridView;
                    if (gridView != null)
                    {
                        gridView.OptionsView.ShowGroupPanel = false;
                    }
                }
                switch (value)
                {
                    case XtraGridViewType.Default:
                        this.UseEmbeddedNavigator = true;
                        this.EmbeddedNavigator.Buttons.Edit.Visible = false;
                        this.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
                        this.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
                        this.EmbeddedNavigator.Buttons.Append.Visible = false;
                        this.EmbeddedNavigator.Buttons.Remove.Visible = false;
                        if (gridView != null)
                        {
                            gridView.OptionsView.ShowGroupPanel = false;
                            gridView.OptionsView.ColumnAutoWidth = false;
                        }
                        break;
                    case XtraGridViewType.Default_ButtonAppend:
                        this.UseEmbeddedNavigator = true;
                        this.EmbeddedNavigator.Buttons.Edit.Visible = false;
                        this.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
                        this.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
                        this.EmbeddedNavigator.Buttons.Append.Visible = true;//
                        this.EmbeddedNavigator.Buttons.Remove.Visible = false;
                        if (gridView != null)
                        {
                            gridView.OptionsView.ColumnAutoWidth = false;
                        }
                        break;
                    case XtraGridViewType.Default_ButtonAppendRemove:
                        this.UseEmbeddedNavigator = true;
                        this.EmbeddedNavigator.Buttons.Edit.Visible = false;
                        this.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
                        this.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
                        this.EmbeddedNavigator.Buttons.Append.Visible = true;//
                        this.EmbeddedNavigator.Buttons.Remove.Visible = true;//
                        if (gridView != null)
                        {
                            gridView.OptionsView.ColumnAutoWidth = false;
                        }
                        break;
                    case XtraGridViewType.Default_ButtonRemove:
                        this.UseEmbeddedNavigator = true;
                        this.EmbeddedNavigator.Buttons.Edit.Visible = false;
                        this.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
                        this.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
                        this.EmbeddedNavigator.Buttons.Append.Visible = false;
                        this.EmbeddedNavigator.Buttons.Remove.Visible = true;
                        if (gridView != null)
                        {
                            gridView.OptionsView.ColumnAutoWidth = false;
                        }
                        break;
                    case XtraGridViewType.Default_ShowGroupPanel:
                        this.UseEmbeddedNavigator = true;
                        this.EmbeddedNavigator.Buttons.Edit.Visible = false;
                        this.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
                        this.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
                        this.EmbeddedNavigator.Buttons.Append.Visible = false;
                        this.EmbeddedNavigator.Buttons.Remove.Visible = false;
                        if (gridView != null)
                        {
                            gridView.OptionsView.ShowGroupPanel = true;
                            gridView.OptionsView.ColumnAutoWidth = false;
                        }
                        break;
                    case XtraGridViewType.None:
                        this.UseEmbeddedNavigator = false;
                        this.EmbeddedNavigator.Buttons.Edit.Visible = true;
                        this.EmbeddedNavigator.Buttons.EndEdit.Visible = true;
                        this.EmbeddedNavigator.Buttons.CancelEdit.Visible = true;
                        this.EmbeddedNavigator.Buttons.Append.Visible = true;
                        this.EmbeddedNavigator.Buttons.Remove.Visible = true;
                        if (gridView != null)
                        {
                            gridView.OptionsView.ShowGroupPanel = true;
                            gridView.OptionsView.ColumnAutoWidth = true;
                        }
                        break;
                }

                _GridViewStyle = value;
            }
        }

        #region IStdValidationControl 인터페이스 구현

        /// <summary>
        /// 컨트롤에 에러 메시지를 설정하고, 포커스 지정
        /// </summary>
        /// <param name="message"></param>
        public void CtrlShowErrorMessage(string message)
        {
            this.Focus();
        }

        private int _MinLength = 0;

        /// <summary>
        /// 사용안함
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("사용안함")]
        public int MinLength
        {
            get { return _MinLength; }
            set { _MinLength = value; }
        }


        public bool RequiredValidation(bool isTrim)
        {
            return this.DataSource != null && this.DataSource is DataTable && (this.DataSource as DataTable).Rows.Count > 0;
        }

        public bool MinLengthValidation()
        {
            return true;
        }

        #endregion


        #region 전체 체크, 해제

        /// <summary>
        /// 헤더를 클릭시 지정된 체크박스를 전체선택,해제한다
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [Description("헤더를 클릭시 지정된 체크박스를 전체선택,해제한다")]
        public bool IsHeaderClickAllCheckedItem
        {
            get;
            set;
        }

        void HeaderCheckedItem_Click(object sender, EventArgs e)
        {
            //GridHeaderClickAllCheckedItem(this, this.CheckBoxFieldName);
            GridHeaderClickAllCheckedItem(this, "CHK");
        }

        /// <summary>
        /// fieldName에 지정된 CheckEdit컨트롤 찾아서 checked,unChecked처리를 한다
        /// 해당 fieldName의 헤더는 sort옵션을 사용할 수 없다
        /// </summary>
        /// <param name="gridControl"></param>
        /// <param name="fieldName">checked를 실행할 Grid의 fieldName을 지정한다</param>
        public static void GridHeaderClickAllCheckedItem(XtraGridControlExt gridControl, string fieldName)
        {
            
            if (gridControl.InnerGridView != null)
            {
                GridHitInfo hi = gridControl.InnerGridView.CalcHitInfo(gridControl.PointToClient(System.Windows.Forms.Control.MousePosition));

                GridHitInfo hiMain = gridControl.InnerGridView.CalcHitInfo(gridControl.PointToClient(System.Windows.Forms.Control.MousePosition));

                if (gridControl.InnerGridView is GridView)
                {
                    //hi = gridControl.InnerGridView.CalcHitInfo(gridControl.PointToClient(System.Windows.Forms.Control.MousePosition));
                }
                else if (gridControl.InnerGridView is BandedGridView)
                {
                    hi = (gridControl.InnerGridView as BandedGridView).CalcHitInfo(gridControl.PointToClient(System.Windows.Forms.Control.MousePosition));
                }
                else if (gridControl.InnerGridView is AdvBandedGridView)
                {
                }
                // hi.GetType()
                //if (hiMain.GetType().Equals("GridHitInfo"))
                //{
                //}
                //else
                //{
                //    hi = ((Control)gridControl as AdvBandedGridView).CalcHitInfo(gridControl.PointToClient(System.Windows.Forms.Control.MousePosition));
                //    //hi = gridControl.InnerGridView.GridContr.InnerLayoutView.CalcHitInfo(System.Windows.Forms.Control.MousePosition);
                //    //   hi.InRowCell
                //}
                if (hi.InColumn && hi.Column.FieldName.Equals(fieldName))
                {
                    //gridControl.InnerGridView.OptionsCustomization.AllowSort = false;
                    
                    object checkedValue = null;
                    if (gridControl.InnerGridView.Columns[fieldName].ColumnEdit is RepositoryItemCheckEdit)
                    {
                        RepositoryItemCheckEdit chkEdit = (gridControl.InnerGridView.Columns[fieldName].ColumnEdit as RepositoryItemCheckEdit);
                        if (chkEdit.Tag == null || chkEdit.Tag.ToString().Equals("0"))
                        {
                            checkedValue = GetCheckEditAsignValue(chkEdit, true);
                            chkEdit.Tag = "1";
                        }
                        else
                        {
                            checkedValue = GetCheckEditAsignValue(chkEdit, false);
                            chkEdit.Tag = "0";
                        }
                    }
                    SetDataTableAllRowsApplyValue(gridControl, fieldName, checkedValue);
                }
            }
            

        }

        public static object GetCheckEditAsignValue(RepositoryItemCheckEdit chkEdit, bool getCheckedValue)
        {
            if (getCheckedValue)
                return chkEdit.ValueChecked;
            else
                return chkEdit.ValueUnchecked;
        }

        public static void SetDataTableAllRowsApplyValue(XtraGridControlExt gridControl, string ColumnName, object value)
        {
            if (gridControl.InnerGridView != null)
            {
                int RowCount = gridControl.InnerGridView.DataRowCount;
                for (int i = 0; i < RowCount; i++)
                {
                    gridControl.InnerGridView.SetRowCellValue(i, ColumnName, value);
                }
            }
        }


        #endregion

        /// <summary>
        /// 체크박스의 지정된 체크필드값을 가져온다
        /// </summary>
        [Browsable(false)]
        public string CheckBoxFieldValue
        {
            get
            {
                if (DesignMode && LicenseManager.UsageMode == LicenseUsageMode.Designtime)
                {
                    return string.Empty;
                }

                if (!string.IsNullOrWhiteSpace(CheckBoxFieldName))
                {
                    foreach (GridView gridView in this.Views)
                    {
                        if (gridView.Columns[this.CheckBoxFieldName] != null && gridView.Columns[this.CheckBoxFieldName].ColumnEdit != null && gridView.Columns[this.CheckBoxFieldName].ColumnEdit is RepositoryItemCheckEdit)
                        {
                            RepositoryItemCheckEdit chkEdit = (gridView.Columns[this.CheckBoxFieldName].ColumnEdit as RepositoryItemCheckEdit);
                            return chkEdit.ValueChecked.ToString();
                        }
                    }
                    return string.Empty;
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        /// <summary>
        /// 체크박스에 선택되었는지 여부를 가져온다
        /// </summary>
        [Browsable(false)]
        public bool IsChecked
        {
            get
            {
                if (DesignMode && LicenseManager.UsageMode == LicenseUsageMode.Designtime)
                {
                    return false;
                }

                if (!string.IsNullOrWhiteSpace(CheckBoxFieldName))
                {
                    return (this.DataSource as DataTable).Select(this.CheckBoxFieldName + " = '" + this.CheckBoxFieldValue + "'").Length > 0;
                }
                else
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// DataSource에 데이터가 존재하지 여부 및 DataTable에 DataRow가 존재하는 여부를 가져온다
        /// </summary>
        [Browsable(false)]
        public bool IsDataExists
        {
            get
            {
                //return this.DataSource != null && (this.DataSource as DataTable).Rows.Count > 0;
                if (InnerGridView != null)
                {
                    return this.DataSource != null && InnerGridView.DataRowCount > 0;
                }
                else if (InnerLayoutView != null)
                {
                    return this.DataSource != null && InnerLayoutView.DataRowCount > 0;
                }
                else
                {
                    return this.DataSource != null && (this.DataSource as DataTable).Rows.Count > 0;
                }
            }
        }

        /// <summary>
        /// 그리드내의 DataSource(DataTable)를 Rows를 초기화한다
        /// </summary>
        public void InitDataRows()
        {
            //GetFocusRowHandleAndInitRowHandle();

            if (this.DataSource is DataTable)
                (this.DataSource as DataTable).Rows.Clear();
        }

        
    }
}