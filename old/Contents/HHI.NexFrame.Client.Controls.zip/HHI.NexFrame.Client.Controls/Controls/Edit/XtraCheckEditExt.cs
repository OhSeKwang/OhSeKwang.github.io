﻿using DevExpress.XtraEditors;
using HHI.NexFrame.Client.Controls;
using HHI.NexFrame.Client.Controls.Enums;
using HHI.NexFrame.Client.UI.Interface;
using System.ComponentModel;
using System.Windows.Forms;

namespace HHI.NexFrame.Client.Controls
{
    public class XtraCheckEditExt : CheckEdit, IStdValidationControl, IStdBaseDataMappingControl, IStdAutoFireEnterEvtControl
    {
        public XtraCheckEditExt()
        {
            this.SetStyle(ControlStyles.Opaque, true);
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer, !true);
        }

        protected override void OnLoaded()
        {
            base.OnLoaded();
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams parms = base.CreateParams;
                parms.ExStyle |= 0x20;
                // Turn on WS_EX_TRANSPARENT
                return parms;
            }
        }

        /// <summary>
        /// 컨트롤에 에러 메시지를 설정하고, 포커스 지정
        /// </summary>
        /// <param name="message"></param>
        public void CtrlShowErrorMessage(string message)
        {
            this.ErrorText = message;
            this.Focus();
        }

        #region IStdValidationControl 인터페이스 구현

        private int _MinLength = 0;

        /// <summary>
        /// Control의 최소 자리수를 가져오거나/설정한다.
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("Control의 최소 자리수를 가져오거나/설정한다.")]
        public int MinLength
        {
            get { return _MinLength; }
            set { _MinLength = value; }
        }


        public bool RequiredValidation(bool isTrim)
        {
            return this.SetExRequiredValidation(isTrim);
        }

        public bool MinLengthValidation()
        {
            return this.SetExMinLengthValidation(this.MinLength);
        }

        #endregion

        #region IStdDataMappingControl 인터페이스 구현

        string _Key = string.Empty;

        /// <summary>
        /// 해당 컨트롤에 대한 DB Mapping Name을 설정하거나,가져온다
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("해당 컨트롤에 대한 DB Mapping Name을 설정하거나,가져온다")]
        public string Key
        {
            get { return _Key; }
            set { _Key = value; }
        }

        /// <summary>
        /// 지정한 값을 해당 컨트롤에 바인딩한다
        /// </summary>
        /// <param name="data"></param>
        public void DataBindControl(object data)
        {
            this.EditValue = (data != null ? data.ToString() : string.Empty);
        }

        /// <summary>
        /// 컨트롤내의 값을 가져온다
        /// </summary>
        /// <returns></returns>
        public object GetControlValue()
        {
            return (this.Checked ? this.Properties.ValueChecked : this.Properties.ValueUnchecked);
        }

        #endregion

        /// <summary>
        /// 엔터시 실행할 버튼 리스트를 가져오거나,설정한다
        /// </summary>
        
        public IButtonControl[] EnterExecuteButton
        {
            get;
            set;
        }
    }
}