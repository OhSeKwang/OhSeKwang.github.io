﻿using DevExpress.Office.Services;
using DevExpress.XtraPrinting;
using DevExpress.XtraRichEdit;
using DevExpress.XtraRichEdit.API.Native;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using HHI.NexFrame.Client.Controls;
using HHI.NexFrame.Client.Controls.Enums;
using HHI.NexFrame.Client.UI.Interface;
using System;
using System.ComponentModel;
using System.Drawing.Printing;
using System.IO;
using System.Windows.Forms;

namespace HHI.NexFrame.Client.Controls
{
    [ToolboxItem(true)]
    public partial class XtraToolBarRichEditControl : UserControl, IStdValidationControl, IStdTextEditDataMappingControl
    {
        public XtraToolBarRichEditControl()
        {
            InitializeComponent();

            OutputFormat = RichEditOutputFormat.Html;

            this.InnerRichEditControl.DocumentLoaded += new EventHandler(InnerRichEditControl_DocumentLoaded);
        }

        void InnerRichEditControl_DocumentLoaded(object sender, EventArgs e)
        {
            IUriProviderService service = this.InnerRichEditControl.GetService<IUriProviderService>();
            if (service != null)
            {
                service.RegisterProvider(new CustomUriProvider());
            }
        }

        private void XtraToolBarRichEditControl_Load(object sender, EventArgs e)
        {
            //this.richEditControl.Text = string.Empty;
        }

        private bool _RibbonMenuHide = false;

        /// <summary>
        /// RibbonMenu를 숨길지 여부를 지정한다
        /// </summary>
        public bool RibbonMenuHide
        {
            get { return _RibbonMenuHide; }
            set
            {
                _RibbonMenuHide = value;
                if (value)
                {
                    richEditControl.MenuManager.DisposeManager();
                }
            }
        }

        private bool _File_PrintVisible = true;

        /// <summary>
        /// File/Print 메뉴를 숨길지 여부를 지정한다.
        /// </summary>
        public bool File_PrintVisible
        {
            get { return _File_PrintVisible; }
            set
            {
                _File_PrintVisible = value;
                fileRibbonPage1.Visible = _File_PrintVisible;
            }
        }

        /// <summary>
        /// 내부 RichEditControl을 반환한다
        /// </summary>
        [Browsable(false)]
        public RichEditControl InnerRichEditControl
        {
            get { return this.richEditControl; }
        }

        /// <summary>
        /// Html문을 가져오거나, 설정한다
        /// </summary>
        [Browsable(false)]
        public string HtmlText
        {
            get { return this.richEditControl.Document.GetHtmlText(this.richEditControl.Document.Range, new CustomUriProvider()); }
            set
            {
                this.richEditControl.HtmlText = value;
                //byte[] bfileSrc = Encoding.UTF8.GetBytes(value);
                //using (MemoryStream ms = new MemoryStream(bfileSrc))
                //{
                //    this.richEditControl.LoadDocument(ms, DocumentFormat.Html);
                //}
            }
        }

        /// <summary>
        /// RichEditControl의 Text를 가져오거나, 설정한다
        /// </summary>
        [Browsable(false)]
        public new string Text
        {
            get { return this.richEditControl.Document.GetText(this.InnerRichEditControl.Document.Range); }
            set { this.richEditControl.Text = value; }
        }

        /// <summary>
        /// RichEdit의 문서를 RTF포맷으로 byte[]로 반환한다
        /// </summary>
        [Browsable(false)]
        public byte[] RtfDocumentByteArray
        {
            get
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    this.richEditControl.SaveDocument(ms, DocumentFormat.Rtf);
                    return ms.GetBuffer();
                }
            }
        }

        /// <summary>
        /// RTF파일형식으로 문서를 로드한다
        /// </summary>
        /// <param name="rtfDocSource"></param>
        public void LoadRtfDocument(byte[] rtfDocSource)
        {
            if (rtfDocSource != null && rtfDocSource.Length > 0)
            {
                using (MemoryStream ms = new MemoryStream(rtfDocSource))
                {
                    this.richEditControl.LoadDocument(ms, DocumentFormat.Rtf);
                }
            }
            else
            {
                this.richEditControl.Text = "";
            }
        }

        /// <summary>
        /// 문서 전체에 기본폰트로 리셋한다
        /// </summary>
        public void ResetDefaultFont()
        {
            CharacterProperties prop = this.richEditControl.Document.BeginUpdateCharacters(this.richEditControl.Document.Range);

            prop.FontName = "Tahoma";
            prop.FontSize = 9;

            this.richEditControl.Document.EndUpdateCharacters(prop);
        }

        /// <summary>
        /// 지정한 폰트 및 사이즈로 문서 전체에 기본폰트로 재설정한다
        /// </summary>
        /// <param name="fontName">폰트명</param>
        /// <param name="fontSize">폰트사이즈</param>
        public void ResetDefaultFont(string fontName, float fontSize)
        {
            CharacterProperties prop = this.richEditControl.Document.BeginUpdateCharacters(this.richEditControl.Document.Range);

            prop.FontName = fontName;
            prop.FontSize = fontSize;

            this.richEditControl.Document.EndUpdateCharacters(prop);
        }

        void checkSpellingItem_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //spellChecker1.Check(richEditControl);
        }
        void richEditControl_ReadOnlyChanged(object sender, EventArgs e)
        {
            //this.spellChecker1.Enabled = !richEditControl.ReadOnly;
        }

        private void richEditControl_StartHeaderFooterEditing(object sender, HeaderFooterEditingEventArgs e)
        {
            //headerFooterToolsRibbonPageCategory1.Visible = true;
            //ribbonControl1.SelectedPage = headerFooterToolsDesignRibbonPage1;
        }

        private void richEditControl_FinishHeaderFooterEditing(object sender, HeaderFooterEditingEventArgs e)
        {
            //headerFooterToolsRibbonPageCategory1.Visible = false;
        }

        private void richEditControl_SelectionChanged(object sender, EventArgs e)
        {
            //tableToolsRibbonPageCategory1.Visible = richEditControl.IsSelectionInTable();
        }


        /// <summary>
        /// 기본 A4용지 사이즈로 출력을 한다.
        /// </summary>
        public void ShowPrintPreview()
        {
            // Create a PrintingSystem component.
            PrintingSystem ps = new PrintingSystem();

            // Create a link that will print a control.
            PrintableComponentLink link = new PrintableComponentLink(ps);


            // Specify the control to be printed.
            link.Component = this.InnerRichEditControl;

            link.PaperKind = PaperKind.A4;
            link.Landscape = true;

            //// Subscribe to the CreateReportHeaderArea event used to generate the report header.
            //link.CreateReportHeaderArea += new CreateAreaEventHandler(CreateReportHeaderArea);

            // Generate the report.
            link.CreateDocument();
            // Show the report.
            link.ShowPreview();
        }

        //protected void CreateReportHeaderArea(object sender, CreateAreaEventArgs e)
        //{
        //    string reportHeader = ReportHeaderTitle;
        //    e.Graph.StringFormat = new BrickStringFormat(StringAlignment.Center);
        //    e.Graph.Font = new Font(this.Font.Name, 14, FontStyle.Bold);
        //    RectangleF rec = new RectangleF(0, 0, e.Graph.ClientPageSize.Width, 50);
        //    e.Graph.DrawString(reportHeader, Color.Black, rec, DevExpress.XtraPrinting.BorderSide.None);
        //}

        /// <summary>
        /// 파라미터 추출하는 메소드에서 사용할 포맷을 설정한다
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("파라미터 추출하는 메소드에서 사용할 포맷을 설정한다")]
        public RichEditOutputFormat OutputFormat
        {
            get;
            set;
        }


        #region IStdValidationControl 인터페이스 구현

        /// <summary>
        /// 컨트롤에 에러 메시지를 설정하고, 포커스 지정
        /// </summary>
        /// <param name="message"></param>
        public void CtrlShowErrorMessage(string message)
        {
            this.InnerRichEditControl.Focus();
        }

        private int _MinLength = 0;

        /// <summary>
        /// Control의 최소 자리수를 가져오거나/설정한다.
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("Control의 최소 자리수를 가져오거나/설정한다.")]
        public int MinLength
        {
            get { return _MinLength; }
            set { _MinLength = value; }
        }


        public bool RequiredValidation(bool isTrim)
        {
            return richEditControl.SetExRequiredValidation(isTrim);
        }

        public bool MinLengthValidation()
        {
            return richEditControl.SetExMinLengthValidation(this.MinLength);
        }

        #endregion

        #region IStdDataMappingControl 인터페이스 구현

        string _Key = string.Empty;

        /// <summary>
        /// 해당 컨트롤에 대한 DB Mapping Name을 설정하거나,가져온다
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("해당 컨트롤에 대한 DB Mapping Name을 설정하거나,가져온다")]
        public string Key
        {
            get { return _Key; }
            set { _Key = value; }
        }

        /// <summary>
        /// 지정한 값을 해당 컨트롤에 바인딩한다
        /// </summary>
        /// <param name="data"></param>
        public void DataBindControl(object data)
        {
            this.Text = (data != null ? data.ToString() : string.Empty);
        }

        /// <summary>
        /// 컨트롤내의 값을 가져온다
        /// </summary>
        /// <returns></returns>
        public object GetControlValue()
        {
            if (IsValueTrim)
                return (OutputFormat == RichEditOutputFormat.Text ? this.Text.Trim() : this.HtmlText.Trim());
            else
                return (OutputFormat == RichEditOutputFormat.Text ? this.Text : this.HtmlText);
        }

        bool _IsValueTrim = true;

        /// <summary>
        /// 해당 컨트롤내의 값을 가져오거나, 설정시 Trim처리할지 여부를 설정한다.
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("해당 컨트롤내의 값을 가져오거나, 설정시 Trim처리할지 여부를 설정한다.")]
        public bool IsValueTrim
        {
            get { return _IsValueTrim; }
            set { _IsValueTrim = value; }
        }

        #endregion
    }
}
