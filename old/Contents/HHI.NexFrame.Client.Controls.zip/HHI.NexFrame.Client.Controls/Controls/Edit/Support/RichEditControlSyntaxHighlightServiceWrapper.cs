﻿using DevExpress.Services;
using DevExpress.XtraRichEdit;
using DevExpress.XtraRichEdit.API.Native;
using DevExpress.XtraRichEdit.Services;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using HHI.NexFrame.Client.Controls;
using HHI.NexFrame.Client.Controls.Enums;
using HHI.NexFrame.Client.UI.Interface;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace HHI.NexFrame.Client.Controls
{
    public class RichEditControlSyntaxHighlightServiceWrapper : ISyntaxHighlightService
    {
        #region Ver 1
        //        RichEditControl control;
        //        static string[] str;
        //        List<int> paragraphHashes;
        //        static RichEditControlSyntaxHighlightServiceWrapper()
        //        {
        //            str = new string[] {
        //"AND"
        //,"BEGIN"
        //,"COUNT"
        //,"CREATE"
        //,"DBMS_OUTPUT"
        //,"DECLARE"
        //,"DELETE"
        //,"DUAL"
        //,"END"
        //,"EXISTS"
        //,"FOR"
        //,"FROM"
        //,"IDENTITY"
        //,"IN"
        //,"INDEX"
        //,"INDEX_DESC"
        //,"INSERT"
        //,"INTO"
        //,"IS"
        //,"LIKE"
        //,"LOOP"
        //,"LPAD"
        //,"MATCHED"
        //,"MAX"
        //,"MERGE"
        //,"MIN"
        //,"NOT"
        //,"NULL"
        //,"NUMBER"
        //,"NVL"
        //,"OFF"
        //,"ON"
        //,"OVER"
        //,"PURGE"
        //,"PUT_LINE"
        //,"RETURNING"
        //,"ROUND"
        //,"ROWNUM"
        //,"RPAD"
        //,"SELECT"
        //,"SET"
        //,"SUBSTR"
        //,"TABLE"
        //,"THEN"
        //,"TRIM"
        //,"USE"
        //,"UPDATE"
        //,"VALUES"
        //,"VARCHAR"
        //,"VARCHAR2"
        //,"WHERE"
        //,"WITH"
        //            };
        //            Array.Sort(str);
        //        }

        //        public RichEditControlSyntaxHighlightServiceWrapper(RichEditControl control)
        //        {
        //            this.control = control;
        //            paragraphHashes = new List<int>();

        //        }

        //        public void ResetCache()
        //        {
        //            paragraphHashes.Clear();
        //        }

        //        public void Execute()
        //        {
        //            Document doc = this.control.Document;
        //            int paragraphCount = doc.Paragraphs.Count;
        //            for (int i = 0; i < paragraphCount; i++)
        //            {
        //                HighlightParagraph(i);
        //            }
        //        }

        //        void HighlightParagraph(int paragraphIndex)
        //        {
        //            Document doc = this.control.Document;
        //            Paragraph paragraph = doc.Paragraphs[paragraphIndex];

        //            DocumentRange paragraphRange = null;
        //            try
        //            {
        //                paragraphRange = paragraph.Range;
        //            }
        //            catch { }

        //            if (paragraphRange != null)
        //            {
        //                int paragraphStart = paragraphRange.Start.ToInt();
        //                string text = doc.GetText(paragraphRange);
        //                int hash = text.GetHashCode();
        //                if (paragraphIndex < paragraphHashes.Count && paragraphHashes[paragraphIndex] == hash)
        //                    return;
        //                int length = text.Length;
        //                int prevWhiteSpaceIndex = -1;
        //                for (int i = 0; i < length; i++)
        //                {
        //                    char ch = text[i];
        //                    if (Char.IsWhiteSpace(ch) || Char.IsPunctuation(ch))
        //                    {
        //                        int wordLength = i - prevWhiteSpaceIndex - 1;
        //                        if (wordLength > 0)
        //                        {
        //                            int wordStart = prevWhiteSpaceIndex + 1;
        //                            string word = text.Substring(wordStart, wordLength);
        //                            int index = Array.BinarySearch(str, word.ToUpper());
        //                            DocumentRange range = doc.CreateRange(paragraphStart + wordStart, wordLength);
        //                            CharacterProperties cp = doc.BeginUpdateCharacters(range);
        //                            if (index >= 0)
        //                                cp.ForeColor = Color.Blue;
        //                            else
        //                                cp.ForeColor = Color.Black;
        //                            doc.EndUpdateCharacters(cp);
        //                        }
        //                        prevWhiteSpaceIndex = i;
        //                    }
        //                }
        //                for (int i = paragraphHashes.Count; i <= paragraphIndex; i++)
        //                    paragraphHashes.Add(String.Empty.GetHashCode());
        //                paragraphHashes[paragraphIndex] = hash;
        //            }
        //        }
        #endregion

        #region Ver 2
        RichEditControl control;
        static string[] str = { 
"AND"
,"ALL"
,"AS"
,"BEGIN"
,"BETWEEN"
,"BY"
,"CASE"
,"COUNT"
,"CREATE"
,"DBMS_OUTPUT"
,"DECLARE"
,"DECODE"
,"DELETE"
,"DUAL"
,"END"
,"ELSE"
,"EXISTS"
,"FOR"
,"FROM"
,"GROUP"
,"HAVING"
,"IDENTITY"
,"IF"
,"IN"
,"INDEX"
,"INDEX_DESC"
,"INSERT"
,"INTO"
,"IS"
,"LIKE"
,"LOOP"
,"LPAD"
,"MATCHED"
,"MAX"
,"MERGE"
,"MIN"
,"NOT"
,"NULL"
,"NUMBER"
,"NVL"
,"OF"
,"OFF"
,"ON"
,"ORDER"
,"OVER"
,"PARTITION"
,"PURGE"
,"PUT_LINE"
,"RETURNING"
,"ROUND"
,"ROWNUM"
,"RPAD"
,"SELECT"
,"SET"
,"SUBSTR"
,"TABLE"
,"TO_CHAR"
,"TO_NUMBER"
,"THEN"
,"TRIM"
,"TYPE"
,"UNION"
,"USE"
,"UPDATE"
,"VALUES"
,"VARCHAR"
,"VARCHAR2"
,"WHERE"
,"WITH"
                                  };
        SearchDirection direction = SearchDirection.Forward;
        SearchOptions options = SearchOptions.WholeWord | SearchOptions.None;
        public RichEditControlSyntaxHighlightServiceWrapper(RichEditControl control)
        {
            this.control = control;
        }
        #region ISyntaxHighlightService Members

        public void Execute()
        {
            Document doc = this.control.Document;
            this.control.Appearance.Text.Font = new System.Drawing.Font("Verdana", 9F);
            this.control.Appearance.Text.ForeColor = System.Drawing.Color.Black;
            this.control.Appearance.Text.Options.UseFont = true;
            this.control.Appearance.Text.Options.UseForeColor = true;
            foreach (string word in str)
            {
                ISearchResult result = control.Document.StartSearch(word, options, direction, doc.Range);
                while (result.FindNext())
                {
                    CharacterProperties charProperties = doc.BeginUpdateCharacters(result.CurrentResult);
                    charProperties.ForeColor = Color.DarkRed;
                    charProperties.Bold = true;
                    doc.EndUpdateCharacters(charProperties);
                }
            }
            // your code here                
        }

        #endregion

        #endregion

        #region Ver 3
        //        RichEditControl control;
        //            static string[] str;
        //            List<int> paragraphHashes;
        //            static RichEditControlSyntaxHighlightServiceWrapper()
        //            {
        //                str = new string[] { 
        //"AND"
        //,"ALL"
        //,"AS"
        //,"BEGIN"
        //,"BETWEEN"
        //,"BY"
        //,"CASE"
        //,"COUNT"
        //,"CREATE"
        //,"DBMS_OUTPUT"
        //,"DECLARE"
        //,"DECODE"
        //,"DELETE"
        //,"DUAL"
        //,"END"
        //,"ELSE"
        //,"EXISTS"
        //,"FOR"
        //,"FROM"
        //,"GROUP"
        //,"HAVING"
        //,"IDENTITY"
        //,"IF"
        //,"IN"
        //,"INDEX"
        //,"INDEX_DESC"
        //,"INSERT"
        //,"INTO"
        //,"IS"
        //,"LIKE"
        //,"LOOP"
        //,"LPAD"
        //,"MATCHED"
        //,"MAX"
        //,"MERGE"
        //,"MIN"
        //,"NOT"
        //,"NULL"
        //,"NUMBER"
        //,"NVL"
        //,"OF"
        //,"OFF"
        //,"ON"
        //,"ORDER"
        //,"OVER"
        //,"PARTITION"
        //,"PURGE"
        //,"PUT_LINE"
        //,"RETURNING"
        //,"ROUND"
        //,"ROWNUM"
        //,"RPAD"
        //,"SELECT"
        //,"SET"
        //,"SUBSTR"
        //,"TABLE"
        //,"TO_CHAR"
        //,"TO_NUMBER"
        //,"THEN"
        //,"TRIM"
        //,"TYPE"
        //,"UNION"
        //,"USE"
        //,"UPDATE"
        //,"VALUES"
        //,"VARCHAR"
        //,"VARCHAR2"
        //,"WHERE"
        //,"WITH"
        //                };
        //                Array.Sort(str);
        //            }
        //            public RichEditControlSyntaxHighlightServiceWrapper(RichEditControl control)
        //            {
        //                this.control = control;
        //                paragraphHashes = new List<int>();

        //            }
        //            public void ResetCache()
        //            {
        //                paragraphHashes.Clear();
        //            }
        //            #region ISyntaxHighlightService Members

        //            public void Execute()
        //            {
        //                Document doc = this.control.Document;
        //                int paragraphCount = doc.Paragraphs.Count;
        //                for (int i = 0; i < paragraphCount; i++)
        //                {
        //                    HighlightParagraph(i);

        //                } 
        //            }

        //            void HighlightParagraph(int paragraphIndex)
        //            {
        //                Document doc = this.control.Document;
        //                Paragraph paragraph = doc.Paragraphs[paragraphIndex];

        //                DocumentRange paragraphRange = null;
        //                try
        //                {
        //                    paragraphRange = paragraph.Range;
        //                }
        //                catch { }

        //                if (paragraphRange != null)
        //                {
        //                    int paragraphStart = paragraphRange.Start.ToInt();
        //                    string text = doc.GetText(paragraphRange);
        //                    int hash = text.GetHashCode();
        //                    if (paragraphIndex < paragraphHashes.Count && paragraphHashes[paragraphIndex] == hash)
        //                        return;
        //                    int length = text.Length;
        //                    int prevWhiteSpaceIndex = -1;
        //                    for (int i = 0; i < length; i++)
        //                    {
        //                        char ch = text[i];
        //                        if (Char.IsWhiteSpace(ch) || Char.IsPunctuation(ch))
        //                        {
        //                            int wordLength = i - prevWhiteSpaceIndex - 1;
        //                            if (wordLength > 0)
        //                            {
        //                                int wordStart = prevWhiteSpaceIndex + 1;
        //                                string word = text.Substring(wordStart, wordLength);
        //                                int index = Array.BinarySearch(str, word);
        //                                DocumentRange range = doc.CreateRange(paragraphStart + wordStart, wordLength);
        //                                CharacterProperties cp = doc.BeginUpdateCharacters(range);
        //                                if (index >= 0)
        //                                    cp.ForeColor = Color.Blue;
        //                                else
        //                                    cp.ForeColor = Color.Black;
        //                                doc.EndUpdateCharacters(cp);
        //                            }
        //                            prevWhiteSpaceIndex = i;

        //                        }
        //                    }
        //                    for (int i = paragraphHashes.Count; i <= paragraphIndex; i++)
        //                        paragraphHashes.Add(String.Empty.GetHashCode());
        //                    paragraphHashes[paragraphIndex] = hash;
        //                }
        //            }
        //            #endregion
        #endregion

        #region ISyntaxHighlightService 멤버


        public void ForceExecute()
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
