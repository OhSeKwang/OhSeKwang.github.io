﻿using DevExpress.Services;
using DevExpress.XtraRichEdit;
using DevExpress.XtraRichEdit.API.Native;
using DevExpress.XtraRichEdit.Services;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using HHI.NexFrame.Client.Controls;
using HHI.NexFrame.Client.Controls.Enums;
using HHI.NexFrame.Client.UI.Interface;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace HHI.NexFrame.Client.Controls
{
    public class XtraSyntaxRichEditControlExt : RichEditControl, IStdValidationControl, IStdTextEditDataMappingControl
    {
        public XtraSyntaxRichEditControlExt()
        {
            this.ActiveViewType = RichEditViewType.Simple;

            this.Options.HorizontalScrollbar.Visibility = RichEditScrollbarVisibility.Visible;

            ISyntaxHighlightService syntaxService = this.GetService<ISyntaxHighlightService>();
            RichEditControlSyntaxHighlightServiceWrapper syntaxWrapper = new RichEditControlSyntaxHighlightServiceWrapper(this);
            this.RemoveService(typeof(ISyntaxHighlightService));
            this.AddService(typeof(ISyntaxHighlightService), syntaxWrapper);

            //IKeyboardHandlerService keyboardService = this.GetService<IKeyboardHandlerService>();
            //RichEditControlKeyboardHandlerServiceWrapper keyboardWrapper = new RichEditControlKeyboardHandlerServiceWrapper(keyboardService);
            //this.RemoveService(typeof(IKeyboardHandlerService));
            //this.AddService(typeof(IKeyboardHandlerService), keyboardWrapper);

            OutputFormat = RichEditOutputFormat.Text;
        }

        /// <summary>
        /// 파라미터 추출하는 메소드에서 사용할 포맷을 설정한다
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("파라미터 추출하는 메소드에서 사용할 포맷을 설정한다")]
        public RichEditOutputFormat OutputFormat
        {
            get;
            set;
        }

        #region IStdValidationControl 인터페이스 구현

        /// <summary>
        /// 컨트롤에 에러 메시지를 설정하고, 포커스 지정
        /// </summary>
        /// <param name="message"></param>
        public void CtrlShowErrorMessage(string message)
        {
            this.Focus();
        }

        private int _MinLength = 0;

        /// <summary>
        /// Control의 최소 자리수를 가져오거나/설정한다.
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("Control의 최소 자리수를 가져오거나/설정한다.")]
        public int MinLength
        {
            get { return _MinLength; }
            set { _MinLength = value; }
        }


        public bool RequiredValidation(bool isTrim)
        {
            return this.SetExRequiredValidation(isTrim);
        }

        public bool MinLengthValidation()
        {
            return this.SetExMinLengthValidation(this.MinLength);
        }

        #endregion

        #region IStdDataMappingControl 인터페이스 구현

        string _Key = string.Empty;

        /// <summary>
        /// 해당 컨트롤에 대한 DB Mapping Name을 설정하거나,가져온다
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("해당 컨트롤에 대한 DB Mapping Name을 설정하거나,가져온다")]
        public string Key
        {
            get { return _Key; }
            set { _Key = value; }
        }

        /// <summary>
        /// 지정한 값을 해당 컨트롤에 바인딩한다
        /// </summary>
        /// <param name="data"></param>
        public void DataBindControl(object data)
        {
            this.Text = (data != null ? data.ToString() : string.Empty);
        }

        /// <summary>
        /// 컨트롤내의 값을 가져온다
        /// </summary>
        /// <returns></returns>
        public object GetControlValue()
        {
            if (IsValueTrim)
                return (OutputFormat == RichEditOutputFormat.Text ? this.Text.Trim() : this.HtmlText.Trim());
            else
                return (OutputFormat == RichEditOutputFormat.Text ? this.Text : this.HtmlText);
        }

        bool _IsValueTrim = true;

        /// <summary>
        /// 해당 컨트롤내의 값을 가져오거나, 설정시 Trim처리할지 여부를 설정한다.
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("해당 컨트롤내의 값을 가져오거나, 설정시 Trim처리할지 여부를 설정한다.")]
        public bool IsValueTrim
        {
            get { return _IsValueTrim; }
            set { _IsValueTrim = value; }
        }

        #endregion
    }
}
