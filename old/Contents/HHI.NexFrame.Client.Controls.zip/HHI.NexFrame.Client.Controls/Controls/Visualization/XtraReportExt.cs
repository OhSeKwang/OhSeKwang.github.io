﻿using DevExpress.XtraReports.UI;

namespace HHI.NexFrame.Client.Controls
{
    public class XtraReportExt : DevExpress.XtraReports.UI.XtraReport
    {
        public XtraReportExt()
        {

        }

        /// <summary>
        /// 미리보기
        /// </summary>
        public void ShowPreviewDialog()
        {
            // To use the ShowPreview methods, add a reference to DevExpress.XtraPrinting.v12.2.dll.
            //this.ShowPreview();
            XtraReportExtensions.ShowPreviewDialog(this);
        }

        /// <summary>
        /// 미리보기 닫기
        /// </summary>
        public void ClosePreview()
        {
            // To use the ShowPreview methods, add a reference to DevExpress.XtraPrinting.v12.2.dll.
            //this.ClosePreview();
            XtraReportExtensions.ClosePreview(this);
        }
    }
}