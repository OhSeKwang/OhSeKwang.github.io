﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls.Components
{
    /// <summary>
    /// 조선Core 프레임워크 Validation Component에서 수행할 Validation 유형을 정의한다.
    /// </summary>
    public enum ValidationType
    {
        Required = 0,
        MinLength = 1
    }
}
