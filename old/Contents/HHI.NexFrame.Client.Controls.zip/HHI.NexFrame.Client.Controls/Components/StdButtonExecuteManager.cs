﻿using DevExpress.XtraLayout;
using HHI.NexFrame.Client.Controls;
using HHI.NexFrame.Client.UI.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HHI.NexFrame.Client.Controls.Components
{
    [ProvideProperty("EnterEventConainer", typeof(Component))]
    [ProvideProperty("ExecuteButton", typeof(Control))]
    [DesignerCategory("")]
    [ToolboxItem(true)]
    public partial class StdButtonExecuteManager : Component, IExtenderProvider
    {
        //Enter실행할 컨트롤 집합[Component]
        private Dictionary<Component, bool> _baseLayoutItemTable = new Dictionary<Component, bool>();

        //Enter실행시 실행할 XtraButtonExt
        private Dictionary<XtraButtonExt, bool> _xtraButtonExtTable = new Dictionary<XtraButtonExt, bool>();

        public StdButtonExecuteManager()
        {
            InitializeComponent();
        }

        public StdButtonExecuteManager(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }
        
        public bool CanExtend(object extendee)
        {
            return extendee is LayoutControlGroup || extendee is XtraButtonExt;
        }

        #region 확장 속성 구현

        #region EnterEventConainer

        // 확장 속성의 get 메서드
        [DisplayName("_EnterEventConainer")]
        [DefaultValue(null)]
        [Description("엔터 실행할 컨트롤 LayoutContainer를 지정한다")]
        [Category("ShipBuilding_Core_Property")]
        public bool GetEnterEventConainer(Component control)
        {
            if (control is LayoutControlGroup)
            {
                bool fireEvent = false;

                _baseLayoutItemTable.TryGetValue(control, out fireEvent);
                return fireEvent;
            }
            else
            {
                return false;
            }
        }

        // 확장 속성의 set 메서드
        public void SetEnterEventConainer(Component control, bool fireEvent)
        {
            if (control is LayoutControlGroup)
            {
                if (_baseLayoutItemTable.ContainsKey(control) == true)
                {
                    _baseLayoutItemTable[control] = fireEvent;
                }
                else
                {
                    _baseLayoutItemTable.Add(control, fireEvent);
                }
            }
        }

        #endregion

        #region EnterEventConainer

        // 확장 속성의 get 메서드
        [DisplayName("_ExecuteButton")]
        [DefaultValue(null)]
        [Description("엔터시 실행할 XtraButtonExt을 지정한다")]
        [Category("ShipBuilding_Core_Property")]
        public bool GetExecuteButton(Control control)
        {
            if (control is XtraButtonExt)
            {
                bool execute = false;

                _xtraButtonExtTable.TryGetValue(control as XtraButtonExt, out execute);
                return execute;
            }
            else
                return false;
        }

        // 확장 속성의 set 메서드
        public void SetExecuteButton(Control control, bool execute)
        {
            if (control is XtraButtonExt)
            {
                if (_xtraButtonExtTable.ContainsKey(control as XtraButtonExt) == true)
                {
                    _xtraButtonExtTable[control as XtraButtonExt] = execute;
                }
                else
                {
                    _xtraButtonExtTable.Add(control as XtraButtonExt, execute);
                }
            }
        }

        #endregion

        #endregion

        #region 외부 공개 메서드 구현

        /// <summary>
        /// 디자인 타임에 설정된 컨트롤에 대하여 런타임시 지정한 컨트롤에 엔터 Event시 지정한 버튼을 실행한다.
        /// </summary>
        public void RegisterButtonExecEvent()
        {
            //디자인타임에서 추가된 컨트롤 리스트에 대하여 Validation유형에 맞게 검사를 수행한다.
            if (!ControlCommon.DesignMode)
            {
                List<IButtonControl> EnterExecuteButton = new List<IButtonControl>();

                foreach (var xtraButton in _xtraButtonExtTable)
                {
                    if (xtraButton.Value)
                        EnterExecuteButton.Add(xtraButton.Key);
                }

                foreach (var pair in _baseLayoutItemTable)
                {
                    var executable = pair.Value;

                    if (executable)
                    {
                        var executableControlGroup = pair.Key as LayoutControlGroup;

                        List<BaseLayoutItem> list = executableControlGroup.Items.ConvertToTypedList();

                        for (int i = 0; i < list.Count; i++)
                        {
                            var control = (list[i] as LayoutControlItem).Control;

                            if (control is IStdAutoFireEnterEvtControl)
                            {
                                (control as IStdAutoFireEnterEvtControl).EnterExecuteButton = EnterExecuteButton.ToArray();
                                control.KeyDown += new KeyEventHandler(Enter_KeyDown);
                            }
                        }

                    }
                }
            }
        }

        static void Enter_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (sender is IStdAutoFireEnterEvtControl)
                {
                    foreach (var item in (sender as IStdAutoFireEnterEvtControl).EnterExecuteButton)
                    {
                        if ((sender is XtraButtonExt))
                            (sender as XtraButtonExt).Focus();

                        item.PerformClick();
                    }
                }
            }
        }
        #endregion
    }
}
