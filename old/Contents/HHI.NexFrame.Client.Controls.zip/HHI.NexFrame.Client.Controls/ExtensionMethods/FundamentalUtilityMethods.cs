﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls
{
    public static class FundamentalUtils
    {
        /// <summary>
        /// 속성 값의 Description을 반환하는 확장 메소드 입니다.
        /// </summary>
        /// <typeparam name="T">Description이 정의된 Field 입니다.</typeparam>
        /// <param name="source">Description이 정의된 value값 입니다. </param>
        /// <returns>Description 어트리뷰트에 선언된 문자열을 반환 합니다.</returns>
        public static string GetDescriptionAttrString<T>(this T source)
        {
            FieldInfo fi = source.GetType().GetField(source.ToString());

            DescriptionAttribute[] attributes = (DescriptionAttribute[])fi.GetCustomAttributes(
                typeof(DescriptionAttribute), false);

            if (attributes != null && attributes.Length > 0) return attributes[0].Description;
            else return source.ToString();
        }
    }
}
