﻿using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using HHI.NexFrame.Client.Controls.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls
{
    public static class LookUpEditControlEx
    {
        [Obsolete("FillData 함수를 사용 하세요", false)]
        public static void LookUpBind(this LookUpEdit lookupEditor, DataTable dt, string strDisplayMember, string strValueMember, int dropdownRowsCnt = 20)
        {
            lookupEditor.Properties.Columns.Clear();

            lookupEditor.Properties.DataSource = dt;
            lookupEditor.Properties.DisplayMember = strDisplayMember;
            lookupEditor.Properties.ValueMember = strValueMember;
            if (dt.Rows.Count > dropdownRowsCnt)
                lookupEditor.Properties.DropDownRows = dropdownRowsCnt;

            LookUpColumnInfoCollection coll = lookupEditor.Properties.Columns;
            coll.Add(new LookUpColumnInfo(strDisplayMember, string.Empty, 0));

            lookupEditor.Properties.BestFitMode = BestFitMode.BestFitResizePopup;
        }
        [Obsolete("FillData 함수를 사용 하세요", false)]
        public static void LookUpBind(this LookUpEdit lookupEditor, DataTable dt, string strDisplayMember, string strValueMember, bool bAll, string strAllText, int dropdownRowsCnt = 20)
        {
            lookupEditor.Properties.Columns.Clear();

            DataTable dtData = dt.Copy();

            if (bAll)
            {
                if (dtData.Rows.Count > 0)
                {
                    dtData.Rows.InsertAt(dtData.NewRow(), 0);
                    dtData.Rows[0][0] = string.Empty;
                    dtData.Rows[0][1] = string.IsNullOrWhiteSpace(strAllText) ? string.Empty : strAllText;
                }
            }

            lookupEditor.Properties.DataSource = dtData;
            lookupEditor.Properties.DisplayMember = strDisplayMember;
            lookupEditor.Properties.ValueMember = strValueMember;
            if (dtData.Rows.Count > dropdownRowsCnt)
                lookupEditor.Properties.DropDownRows = dropdownRowsCnt;  // 콤보 row 

            LookUpColumnInfoCollection coll = lookupEditor.Properties.Columns;
            coll.Add(new LookUpColumnInfo(strDisplayMember, string.Empty, 0));

            lookupEditor.Properties.BestFitMode = BestFitMode.BestFitResizePopup;
        }
        [Obsolete("FillData 함수를 사용 하세요", false)]
        public static void LookUpBind(this RepositoryItemLookUpEdit lookupEditor, DataTable dt, string strDisplayMember, string strValueMember, int dropdownRowsCnt = 20)
        {
            lookupEditor.Columns.Clear();

            lookupEditor.DataSource = dt;
            lookupEditor.DisplayMember = strDisplayMember;
            lookupEditor.ValueMember = strValueMember;
            if (dt.Rows.Count > dropdownRowsCnt)
                lookupEditor.DropDownRows = dropdownRowsCnt;

            LookUpColumnInfoCollection coll = lookupEditor.Columns;
            coll.Add(new LookUpColumnInfo(strDisplayMember, string.Empty, 0));

            lookupEditor.BestFitMode = BestFitMode.BestFitResizePopup;

        }
        [Obsolete("FillData 함수를 사용 하세요", false)]
        public static void LookUpBind(this RepositoryItemLookUpEdit lookupEditor, DataTable dt, string strDisplayMember, string strValueMember, bool bAll, string strAllText, int dropdownRowsCnt = 20)
        {
            lookupEditor.Columns.Clear();

            DataTable dtData = dt.Copy();

            if (bAll)
            {
                if (dtData.Rows.Count > 0)
                {
                    dtData.Rows.InsertAt(dtData.NewRow(), 0);
                    dtData.Rows[0][0] = string.Empty;
                    dtData.Rows[0][1] = string.IsNullOrWhiteSpace(strAllText) ? string.Empty : strAllText;
                }
            }

            lookupEditor.DataSource = dtData;
            lookupEditor.DisplayMember = strDisplayMember;
            lookupEditor.ValueMember = strValueMember;
            if (dtData.Rows.Count > dropdownRowsCnt)
                lookupEditor.DropDownRows = dropdownRowsCnt;

            LookUpColumnInfoCollection coll = lookupEditor.Columns;
            coll.Add(new LookUpColumnInfo(strDisplayMember, string.Empty, 0));

            lookupEditor.BestFitMode = BestFitMode.BestFitResizePopup;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lookUpEdit"></param>
        /// <param name="dataSource"></param>
        /// <param name="displayMember"></param>
        /// <param name="valueMember"></param>
        /// <param name="addingItemMode"></param>
        /// <summary>
        /// LookUpEdit 콤보박스에 데이터를 바인딩 합니다.
        /// </summary>
        /// <param name="lookUpEdit"></param>
        /// <param name="dataSource">DataTable 개체</param>
        /// <param name="displayMember">화면에 보여지는 컬럼 명</param>
        /// <param name="valueMember">Value 값 컬럼 명</param>
        /// <param name="addingItemMode">AddingItemMode.None아 아니면 첫번 째 행에 자동으로 Item을 추가 합니다.</br>
        /// Select - 선택하세요, All - 전체</param>
        /// <param name="showHeader">Header를 보여 줄지 여부</param>
        /// <param name="showValueColum">Value 컬럼을 보여 줄지 여부</param>
        /// <param name="displayMemberCaption">showHeader가 true인 경우 헤더 Text</param>
        /// <param name="valueMemberCaption">showHeader, showValueColum이 true인 경우 헤더 Text</param>
        /// <param name="defaultDropdownRowsCount">Dropdown Item count</param>
        public static void FillData(this LookUpEdit lookUpEdit, DataTable dataSource, string displayMember, string valueMember, AddingItemMode addingItemMode,
            bool showHeader = false,
            bool showValueColum = false,
            string displayMemberCaption = "",
            string valueMemberCaption = "",
            int defaultDropdownRowsCount = 20)
        {
            lookUpEdit.Properties.Columns.Clear();

            DataRow dr = null;
            switch (addingItemMode)
            {
                case AddingItemMode.Select:
                    dr = dataSource.NewRow();
                    dr[displayMember] = addingItemMode.GetDescriptionAttrString();
                    dr[valueMember] = "__" + addingItemMode.ToString();
                    break;
                case AddingItemMode.All:
                    dr = dataSource.NewRow();
                    dr[displayMember] = addingItemMode.GetDescriptionAttrString();
                    dr[valueMember] = "__" + addingItemMode.ToString();
                    break;
            }

            if (dr != null)
                dataSource.Rows.InsertAt(dr, 0);

            lookUpEdit.Properties.DataSource = dataSource;
            lookUpEdit.Properties.DisplayMember = displayMember;
            lookUpEdit.Properties.ValueMember = valueMember;

            if (dataSource.Rows.Count > defaultDropdownRowsCount)
                lookUpEdit.Properties.DropDownRows = defaultDropdownRowsCount;

            lookUpEdit.Properties.ShowHeader = showHeader;

            LookUpColumnInfoCollection coll = lookUpEdit.Properties.Columns;

            if (showHeader && showValueColum)
                coll.Add(new LookUpColumnInfo(valueMember, valueMemberCaption, 0));
            
            coll.Add(new LookUpColumnInfo(displayMember, displayMemberCaption, 0));
            
            lookUpEdit.Properties.BestFitMode = BestFitMode.BestFitResizePopup;
        }

    }
}
