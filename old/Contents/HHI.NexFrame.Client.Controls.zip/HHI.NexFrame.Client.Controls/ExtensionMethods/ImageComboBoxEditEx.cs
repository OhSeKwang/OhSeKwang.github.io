﻿using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using HHI.NexFrame.Client.Controls.Enums;
using HHI.NexFrame.Core.Data.Model.WcfParameter;
using HHI.NexFrame.Core.WcfService.SystemChannel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls
{
    public static class ImageComboBoxEditEx
    {
        /// <summary>
        /// 이미지 콤보 에디터 바인딩
        /// </summary>
        /// <param name="comboEdit">ImageComboBoxEdit</param>
        /// <param name="TextKey">Text-Key</param>
        /// <param name="ValueKey">Value-Key</param>
        /// <param name="BindStyle">바인딩스타일/예약어 Ex){text} - {value}</param>
        /// <param name="DisplayTextOption">추가할 텍스트 옵션</param>
        /// <param name="DisplayText">추가할 텍스트</param>
        /// <param name="DisplayValue">추가할 Value</param>
        /// <param name="src">정보(datatable)</param>
        public static void ImageComboBind(this ImageComboBoxEdit comboEdit, string TextKey, string ValueKey, string BindStyle, ComboDisplayTextOption DisplayTextOption, string DisplayText, string DisplayValue, DataTable src, int dropdownRowsCnt = 20)
        {
            comboEdit.Properties.Items.Clear();
            //comboEdit.DescKey = null;
            if (!string.IsNullOrWhiteSpace(TextKey) && !string.IsNullOrWhiteSpace(ValueKey) && !string.IsNullOrWhiteSpace(BindStyle))
            {
                // 전체
                if (DisplayTextOption == ComboDisplayTextOption.top)
                {
                    comboEdit.Properties.Items.Add(new ImageComboBoxItem(DisplayText, DisplayValue, -1));
                }

                if (src != null)
                {
                    foreach (DataRow row in src.Rows)
                    {
                        string desc = string.Empty;
                        if (TextKey.Equals("CODEDSC") && ValueKey.Equals("CODEVALUE"))
                        {
                            desc = row["DSC"].ToString();
                        }
                        else
                        {
                            desc = " ";
                        }
                        //comboEdit.DescKey[i] = desc;
                        comboEdit.ImageComboBoxItemAdd(TextKey, ValueKey, BindStyle, row);
                        //i++;
                    }
                }

                if (DisplayTextOption == ComboDisplayTextOption.bottom)
                {
                    comboEdit.Properties.Items.Add(new ImageComboBoxItem(DisplayText, DisplayValue, -1));
                }

                if (comboEdit.Properties.Items.Count > 0)
                {
                    comboEdit.SelectedIndex = 0;
                }

                if (comboEdit.Properties.Items.Count > dropdownRowsCnt)
                    comboEdit.Properties.DropDownRows = dropdownRowsCnt;
            }

        }

        public static void ImageComboBoxItemAdd(this ImageComboBoxEdit comboEdit, string TextKey, string ValueKey, string BindStyle, DataRow row)
        {
            string text = row[TextKey].ToString();
            string value = row[ValueKey].ToString();
            string displayText = BindStyle.Replace("{text}", text).Replace("{value}", value);
            comboEdit.Properties.Items.Add(new ImageComboBoxItem(displayText, value, -1));
        }

        /// <summary>
        /// 그리드 이미지 콤보 에디터 바인딩
        /// </summary>
        /// <param name="comboEdit">RepositoryItemImageComboBox</param>
        /// <param name="TextKey">Text-Key</param>
        /// <param name="ValueKey">Value-Key</param>
        /// <param name="BindStyle">바인딩스타일/예약어 Ex){text} - {value}</param>
        /// <param name="DisplayTextOption">추가할 텍스트 옵션</param>
        /// <param name="DisplayText">추가할 텍스트</param>
        /// <param name="DisplayValue">추가할 Value</param>
        /// <param name="src">정보(datatable)</param>
        public static void ImageComboBind(this RepositoryItemImageComboBox comboEdit, string TextKey, string ValueKey, string BindStyle, ComboDisplayTextOption DisplayTextOption, string DisplayText, string DisplayValue, DataTable src, int dropdownRowsCnt = 20)
        {
            comboEdit.Items.Clear();
            if (!string.IsNullOrWhiteSpace(TextKey) && !string.IsNullOrWhiteSpace(ValueKey) && !string.IsNullOrWhiteSpace(BindStyle))
            {
                if (DisplayTextOption == ComboDisplayTextOption.top)
                {
                    comboEdit.Items.Add(new ImageComboBoxItem(DisplayText, DisplayValue, -1));
                }
                if (src != null)
                {
                    foreach (DataRow row in src.Rows)
                    {
                        string text = row[TextKey].ToString();
                        string value = row[ValueKey].ToString();
                        string displayText = BindStyle.Replace("{text}", text).Replace("{value}", value);

                        comboEdit.Items.Add(new ImageComboBoxItem(displayText, value, -1));
                    }
                }
                if (DisplayTextOption == ComboDisplayTextOption.bottom)
                {
                    comboEdit.Items.Add(new ImageComboBoxItem(DisplayText, DisplayValue, -1));
                }
            }
            if (comboEdit.Items.Count > dropdownRowsCnt)
                comboEdit.DropDownRows = dropdownRowsCnt;
        }

    }
}
