﻿using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using HHI.NexFrame.Client.Controls.Enums;
using HHI.NexFrame.Core.Data.Model.WcfParameter;
using HHI.NexFrame.Core.WcfService.SystemChannel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls
{
    public static class ImageComboBoxEditEx
    {
        /// <summary>
        /// 이미지 콤보 에디터 바인딩
        /// </summary>
        /// <param name="comboEdit">ImageComboBoxEdit</param>
        /// <param name="TextKey">Text-Key</param>
        /// <param name="ValueKey">Value-Key</param>
        /// <param name="BindStyle">바인딩스타일/예약어 Ex){text} - {value}</param>
        /// <param name="DisplayTextOption">추가할 텍스트 옵션</param>
        /// <param name="DisplayText">추가할 텍스트</param>
        /// <param name="DisplayValue">추가할 Value</param>
        /// <param name="src">정보(datatable)</param>
        [Obsolete("FillData 함수를 사용 하세요", false)]
        public static void ImageComboBind(this ImageComboBoxEdit comboEdit, string TextKey, string ValueKey, string BindStyle, 
            ComboDisplayTextOption DisplayTextOption, string DisplayText, string DisplayValue, DataTable src, int dropdownRowsCnt = 20)
        {
            comboEdit.Properties.Items.Clear();
            //comboEdit.DescKey = null;
            if (!string.IsNullOrWhiteSpace(TextKey) && !string.IsNullOrWhiteSpace(ValueKey) && !string.IsNullOrWhiteSpace(BindStyle))
            {
                // 전체
                if (DisplayTextOption == ComboDisplayTextOption.top)
                {
                    comboEdit.Properties.Items.Add(new ImageComboBoxItem(DisplayText, DisplayValue, -1));
                }

                if (src != null)
                {
                    foreach (DataRow row in src.Rows)
                    {
                        string desc = string.Empty;
                        if (TextKey.Equals("CODEDSC") && ValueKey.Equals("CODEVALUE"))
                        {
                            desc = row["DSC"].ToString();
                        }
                        else
                        {
                            desc = " ";
                        }
                        //comboEdit.DescKey[i] = desc;
                        comboEdit.ImageComboBoxItemAdd(TextKey, ValueKey, BindStyle, row);
                        //i++;
                    }
                }

                if (DisplayTextOption == ComboDisplayTextOption.bottom)
                {
                    comboEdit.Properties.Items.Add(new ImageComboBoxItem(DisplayText, DisplayValue, -1));
                }

                if (comboEdit.Properties.Items.Count > 0)
                {
                    comboEdit.SelectedIndex = 0;
                }

                if (comboEdit.Properties.Items.Count > dropdownRowsCnt)
                    comboEdit.Properties.DropDownRows = dropdownRowsCnt;
            }

        }

        [Obsolete("FillData 함수를 사용 하세요", false)]
        public static void ImageComboBoxItemAdd(this ImageComboBoxEdit comboEdit, string TextKey, string ValueKey, string BindStyle, DataRow row)
        {
            string text = row[TextKey].ToString();
            string value = row[ValueKey].ToString();
            string displayText = BindStyle.Replace("{text}", text).Replace("{value}", value);
            comboEdit.Properties.Items.Add(new ImageComboBoxItem(displayText, value, -1));
        }

        /// <summary>
        /// 그리드 이미지 콤보 에디터 바인딩
        /// </summary>
        /// <param name="comboEdit">RepositoryItemImageComboBox</param>
        /// <param name="TextKey">Text-Key</param>
        /// <param name="ValueKey">Value-Key</param>
        /// <param name="BindStyle">바인딩스타일/예약어 Ex){text} - {value}</param>
        /// <param name="DisplayTextOption">추가할 텍스트 옵션</param>
        /// <param name="DisplayText">추가할 텍스트</param>
        /// <param name="DisplayValue">추가할 Value</param>
        /// <param name="src">정보(datatable)</param>
        [Obsolete("FillData 함수를 사용 하세요", false)]
        public static void ImageComboBind(this RepositoryItemImageComboBox comboEdit, string TextKey, string ValueKey, string BindStyle, ComboDisplayTextOption DisplayTextOption, string DisplayText, string DisplayValue, DataTable src, int dropdownRowsCnt = 20)
        {
            comboEdit.Items.Clear();
            if (!string.IsNullOrWhiteSpace(TextKey) && !string.IsNullOrWhiteSpace(ValueKey) && !string.IsNullOrWhiteSpace(BindStyle))
            {
                if (DisplayTextOption == ComboDisplayTextOption.top)
                {
                    comboEdit.Items.Add(new ImageComboBoxItem(DisplayText, DisplayValue, -1));
                }
                if (src != null)
                {
                    foreach (DataRow row in src.Rows)
                    {
                        string text = row[TextKey].ToString();
                        string value = row[ValueKey].ToString();
                        string displayText = BindStyle.Replace("{text}", text).Replace("{value}", value);

                        comboEdit.Items.Add(new ImageComboBoxItem(displayText, value, -1));
                    }
                }
                if (DisplayTextOption == ComboDisplayTextOption.bottom)
                {
                    comboEdit.Items.Add(new ImageComboBoxItem(DisplayText, DisplayValue, -1));
                }
            }
            if (comboEdit.Items.Count > dropdownRowsCnt)
                comboEdit.DropDownRows = dropdownRowsCnt;
        }

        /// <summary>
        /// 이미지를 포함하는 ComboBox를 표현 합니다.
        /// </summary>
        /// <param name="imageComboBoxEdit">ImageComboBoxEdit 개체 입니다.</param>
        /// <param name="dataSource">콤보박스에 표현 할 개체</param>
        /// <param name="displayMember">화면에 보여지는 컬럼 명</param>
        /// <param name="valueMember">Value 값 컬럼 명</param>
        /// <param name="imageIndexMember">ImageList의 Index값을 가지고 있는 컬럼 명</param>
        /// <param name="imageCollection">이미지를 가지고 있는 ImageCollection 개체</param>
        /// <param name="addingItemMode">AddingItemMode.None아 아니면 첫번 째 행에 자동으로 Item을 추가 합니다.</br>
        /// </param>
        public static void FillData(this ImageComboBoxEdit imageComboBoxEdit,
            DataTable dataSource, string displayMember, string valueMember, string imageIndexMember, 
            ImageCollection imageCollection, 
            AddingItemMode addingItemMode,
            bool useLargeImage = false)
        {
            DataRow dr = null;
            switch (addingItemMode)
            {
                case AddingItemMode.Select:
                    dr = dataSource.NewRow();
                    dr[displayMember] = addingItemMode.GetDescriptionAttrString();
                    dr[valueMember] = "__" + addingItemMode.ToString();
                    dr[imageIndexMember] = -1;
                    break;
                case AddingItemMode.All:
                    dr = dataSource.NewRow();
                    dr[displayMember] = addingItemMode.GetDescriptionAttrString();
                    dr[valueMember] = "__" + addingItemMode.ToString();
                    dr[imageIndexMember] = -1;
                    break;
            }

            if (dr != null)
                dataSource.Rows.InsertAt(dr, 0);

            if (imageCollection != null)
            {
                if(useLargeImage)
                    imageComboBoxEdit.Properties.SmallImages = imageCollection;
                else
                    imageComboBoxEdit.Properties.LargeImages = imageCollection;
            }

            bool isImageColumnExist = dataSource.Columns.Contains(imageIndexMember) && imageCollection != null;
            foreach (DataRow row in dataSource.Rows)
            {
                int iImgIndex = 0;
                if (isImageColumnExist && int.TryParse(row[imageIndexMember].ToString(), out iImgIndex))
                {
                    ImageComboBoxItem imgItem = new ImageComboBoxItem(row[displayMember].ToString(), row[valueMember], Convert.ToInt16(row[imageIndexMember]));
                    imageComboBoxEdit.Properties.Items.Add(imgItem);
                }
                else
                {
                    // 이미지 빼고
                    ImageComboBoxItem imgItem = new ImageComboBoxItem(row[displayMember].ToString(), row[valueMember]);
                    imageComboBoxEdit.Properties.Items.Add(imgItem);
                }
            }

            if(imageComboBoxEdit.Properties.Items.Count > 0)
                imageComboBoxEdit.SelectedIndex = 0;
        }
    }
}
