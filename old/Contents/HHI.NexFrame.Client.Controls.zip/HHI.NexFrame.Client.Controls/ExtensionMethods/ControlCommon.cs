﻿using DevExpress.XtraLayout;
using HHI.NexFrame.Client.Controls.Enums;
using HHI.NexFrame.Client.UI.Interface;
using HHI.NexFrame.Core.Data.Model.WcfParameter;
using HHI.NexFrame.Core.WcfService.SystemChannel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HHI.NexFrame.Client.Controls
{
    public static class ControlCommon
    {
        public static bool DesignMode
        {
            get
            {
                return (System.Diagnostics.Process.GetCurrentProcess().ProcessName == "devenv");
            }
        }

        private static DateTime _SysCurrentDateTime = DateTime.Now;

        /// <summary>
        /// 데이터베이스의 시스템 시간을 반환한다
        /// </summary>
        public static DateTime SysCurrentDateTime
        {
            get
            {
                return _SysCurrentDateTime;
            }
            set
            {
                _SysCurrentDateTime = value;
            }
        }


        public static Color GetBgColorBySkin(EditColorSkinType skinType, bool IsFocus)
        {
            Color result = Color.White;

            if (skinType == EditColorSkinType.Normal)
                result = (IsFocus ? Color.FromArgb(209, 209, 209) : Color.White);
            else if (skinType == EditColorSkinType.ReadOnly)
                result = (IsFocus ? Color.FromArgb(235, 224, 196) : Color.FromArgb(237, 233, 206));
            else if (skinType == EditColorSkinType.Required)
                result = (IsFocus ? Color.FromArgb(241, 207, 197) : Color.FromArgb(255, 226, 217));
            //Skin1 ~ 5 ==> 다시정의해야함
            else if (skinType == EditColorSkinType.Skin1)
                result = (IsFocus ? Color.FromArgb(190, 226, 242) : Color.FromArgb(212, 231, 245));
            else if (skinType == EditColorSkinType.Skin2)
                result = (IsFocus ? Color.FromArgb(232, 237, 141) : Color.FromArgb(240, 243, 175));
            else if (skinType == EditColorSkinType.Skin3)
                result = (IsFocus ? Color.FromArgb(207, 242, 153) : Color.FromArgb(226, 247, 191));
            else if (skinType == EditColorSkinType.Skin4)
                result = (IsFocus ? Color.FromArgb(187, 254, 254) : Color.FromArgb(208, 254, 254));
            else if (skinType == EditColorSkinType.Skin5)
                result = (IsFocus ? Color.FromArgb(225, 225, 225) : Color.FromArgb(235, 235, 235));

            return result;
        }

        /// <summary>
        /// 컨트롤을 감싸고 있는 LayoutControlItem 의 caption text 를 반환한다.
        /// </summary>
        /// <returns></returns>
        public static string GetCaptionLayoutControlItem(this Control control)
        {
            string controlItemText = string.Empty;

            if (control.Parent is DevExpress.XtraLayout.LayoutControl)
            {
                LayoutControlItem controlItem = (control.Parent as DevExpress.XtraLayout.LayoutControl).GetItemByControl(control);

                controlItemText = controlItem.Text;
            }

            return controlItemText;
        }


        /// <summary>
        /// 공통코드 조회
        /// </summary>
        /// <param name="strCdclss"></param>
        /// <returns></returns>
        public static DataTable GetCodeInfo(string strCdclss)
        {
            DataPack parameter = new DataPack();
            parameter.DataList.Add("CDCLSS", strCdclss);

            return ShipBuildingSystemChannel.ProcessData(DbDataSourcePrefix.DefaultDataSource, false, "MENUMANGE.SCCOMMON.SEARCH_CODE", parameter).QuerySet.Tables[0];
        }


        /// <summary>
        /// 해당 지정한 컨트롤내의 MinLength 프로퍼티의 값을 가져온다.
        /// </summary>
        /// <param name="control"></param>
        /// <returns></returns>
        public static int GetMinLengthProperty(this Control control)
        {
            if (control is IStdValidationControl)
                return (control as IStdValidationControl).MinLength;
            else
                return 0;
        }

        /// <summary>
        /// 컨트롤내의 KEY 값을 가져온다
        /// </summary>
        /// <param name="ctrl"></param>
        /// <returns></returns>
        public static string GetControlKeyValue(this Control ctrl)
        {
            if (ctrl is IStdBaseDataMappingControl)
            {
                if ((ctrl as IStdBaseDataMappingControl).Key != null)
                    return (ctrl as IStdBaseDataMappingControl).Key;
            }

            return string.Empty;
        }

    }
}
