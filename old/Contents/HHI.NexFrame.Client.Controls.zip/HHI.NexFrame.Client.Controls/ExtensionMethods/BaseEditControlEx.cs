﻿using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using HHI.NexFrame.Client.Controls.Enums;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls
{
    public static class BaseEditControl
    {
        public static void SetFocusEnterColorSkin(this BaseEdit editCtrl, EditColorSkinType skinType)
        {
            editCtrl.BackColor = ControlCommon.GetBgColorBySkin(skinType, true); ;

            if (skinType == EditColorSkinType.Normal)
                editCtrl.ForeColor = Color.Black;
            else if (skinType == EditColorSkinType.ReadOnly)
                editCtrl.ForeColor = Color.FromArgb(132, 95, 3);
            else if (skinType == EditColorSkinType.Required)
                editCtrl.ForeColor = Color.Black;
            //Skin1 ~ 5 ==> 다시정의해야함
            else if (skinType == EditColorSkinType.Skin1)
                editCtrl.ForeColor = Color.Black;
            else if (skinType == EditColorSkinType.Skin2)
                editCtrl.ForeColor = Color.Black;
            else if (skinType == EditColorSkinType.Skin3)
                editCtrl.ForeColor = Color.Black;
            else if (skinType == EditColorSkinType.Skin4)
                editCtrl.ForeColor = Color.Black;
            else if (skinType == EditColorSkinType.Skin5)
                editCtrl.ForeColor = Color.Black;
        }

        public static void SetFocusLeaveColorSkin(this BaseEdit editCtrl, EditColorSkinType skinType)
        {
            editCtrl.BackColor = ControlCommon.GetBgColorBySkin(skinType, false);

            if (skinType == EditColorSkinType.Normal)
                editCtrl.ForeColor = Color.Black;
            else if (skinType == EditColorSkinType.ReadOnly)
                editCtrl.ForeColor = Color.FromArgb(132, 95, 3);
            else if (skinType == EditColorSkinType.Required)
                editCtrl.ForeColor = Color.Black;
            //Skin1 ~ 5 ==> 다시정의해야함
            else if (skinType == EditColorSkinType.Skin1)
                editCtrl.ForeColor = Color.Black;
            else if (skinType == EditColorSkinType.Skin2)
                editCtrl.ForeColor = Color.Black;
            else if (skinType == EditColorSkinType.Skin3)
                editCtrl.ForeColor = Color.Black;
            else if (skinType == EditColorSkinType.Skin4)
                editCtrl.ForeColor = Color.Black;
            else if (skinType == EditColorSkinType.Skin5)
                editCtrl.ForeColor = Color.Black;
        }

        /// <summary>
        /// 지정한 DevExpress Edit에 대한 필수입력여부를 체크한다
        /// </summary>
        /// <param name="isTrim">문자열 Trim여부</param>
        /// <param name="edit">DevExpress Edit 컨트롤</param>
        /// <returns></returns>
        public static bool SetExRequiredValidation(this BaseEdit edit, bool isTrim)
        {
            if (edit is PictureEdit)
            {
                if ((edit as PictureEdit).EditValue == null || (edit as PictureEdit).Image == null ||
                    ((edit as PictureEdit).Properties.PictureStoreMode == PictureStoreMode.ByteArray && ((edit as PictureEdit).EditValue as byte[]).Length == 0))
                    return false;
                else
                    return true;
            }
            else
            {
                if (isTrim)
                    return !string.IsNullOrWhiteSpace(edit.EditValue == null ? string.Empty : edit.EditValue.ToString());
                else
                    return !string.IsNullOrEmpty(edit.EditValue == null ? string.Empty : edit.EditValue.ToString());

            }
        }

        /// <summary>
        /// 지정한 DevExpress Edit에 대하여 minLength보다 값의 자리수가 작은지 여부를 체크한다.
        /// </summary>
        /// <param name="minLength">최소 자리수</param>
        /// <param name="edit">DevExpress Edit 컨트롤</param>
        /// <returns></returns>
        public static bool SetExMinLengthValidation(this BaseEdit edit, int minLength)
        {
            if (minLength > 0)
            {
                if (edit is PictureEdit)
                {
                    if ((edit as PictureEdit).EditValue == null || (edit as PictureEdit).Image == null ||
                        ((edit as PictureEdit).Properties.PictureStoreMode == PictureStoreMode.ByteArray && minLength > ((edit as PictureEdit).EditValue as byte[]).Length))
                        return false;
                    else
                        return true;
                }
                else
                {
                    if (minLength > edit.EditValue.ToString().Length)
                        return false;
                }
            }
            return true;

        }
    }
}
