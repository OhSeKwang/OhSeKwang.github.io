﻿using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraRichEdit;
using HHI.NexFrame.Client.Controls.Enums;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls
{
    public static class RichEditControlEx
    {
        /// <summary>
        /// 지정한 DevExpress Edit에 대한 필수입력여부를 체크한다
        /// </summary>
        /// <param name="isTrim">문자열 Trim여부</param>
        /// <param name="edit">DevExpress Edit 컨트롤</param>
        /// <returns></returns>
        public static bool SetExRequiredValidation(this RichEditControl edit, bool isTrim)
        {
            if (isTrim)
                return !string.IsNullOrWhiteSpace(edit.Text == null ? string.Empty : edit.Text);
            else
                return !string.IsNullOrEmpty(edit.Text == null ? string.Empty : edit.Text);
        }

        /// <summary>
        /// 지정한 DevExpress Edit에 대하여 minLength보다 값의 자리수가 작은지 여부를 체크한다.
        /// </summary>
        /// <param name="minLength">최소 자리수</param>
        /// <param name="edit">DevExpress Edit 컨트롤</param>
        /// <returns></returns>
        public static bool SetExMinLengthValidation(this RichEditControl edit, int minLength)
        {
            if (minLength > 0)
            {
                if (minLength > edit.Text.Length)
                    return false;
            }
            return true;

        }
    }
}
