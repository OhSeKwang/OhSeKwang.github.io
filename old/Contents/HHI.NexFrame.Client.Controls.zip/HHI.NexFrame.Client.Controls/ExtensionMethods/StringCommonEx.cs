﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls
{
    public static class StringCommon
    {
        /// <summary>
        /// 지정한 문자열을 날짜 형식으로 변형한다
        /// </summary>
        /// <param name="parseString"></param>
        /// <returns></returns>
        public static object ParseStringToDateTime(this string parseString)
        {
            try
            {
                if (parseString.IndexOf("-") == -1 && parseString.Length == 6)
                {
                    return DateTime.ParseExact(parseString, "yyyyMM", CultureInfo.InvariantCulture);
                }
                else if (parseString.IndexOf("-") == -1 && parseString.Length == 8)
                {
                    return DateTime.ParseExact(parseString, "yyyyMMdd", CultureInfo.InvariantCulture);
                }
                else if (parseString.IndexOf("-") == -1 && parseString.Length == 4)
                {
                    return DateTime.ParseExact(parseString, "yyyy", CultureInfo.InvariantCulture);
                }
                else if (parseString.IndexOf("-") == -1 && parseString.Length == 14)
                {
                    return DateTime.ParseExact(parseString, "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
                }
                else if (parseString.IndexOf("-") == -1 && parseString.Length == 12)
                {
                    return DateTime.ParseExact(parseString, "yyyyMMddHHmm", CultureInfo.InvariantCulture);
                }
                else if (parseString.IndexOf("-") == -1 && parseString.Length == 10)
                {
                    return DateTime.ParseExact(parseString, "yyyyMMddHH", CultureInfo.InvariantCulture);
                }
                else if (parseString.IndexOf("-") > -1 && parseString.Length == 7)
                {
                    return DateTime.ParseExact(parseString, "yyyy-MM", CultureInfo.InvariantCulture);
                }
                else if (parseString.IndexOf("-") > -1 && parseString.Length == 10)
                {
                    return DateTime.ParseExact(parseString, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                }
                else
                {
                    return null;
                }
            }
            catch
            {
                return null;
            }
        }
    }
}
