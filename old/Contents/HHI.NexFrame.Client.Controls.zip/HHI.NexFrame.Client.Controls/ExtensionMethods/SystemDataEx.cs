﻿using DevExpress.XtraLayout;
using HHI.NexFrame.Client.UI.Interface;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls
{
    public static class SystemDataEx
    {
        #region DataBind

        /// <summary>
        /// 해당 컨트롤 컨테이너내의 컨트롤자식들을 바인딩합니다
        /// </summary>
        /// <param name="row">DataRow</param>
        /// <param name="ctrl">Container컨트롤</param>
        public static void CtrlNestedDataBind(this DataRow row, System.Windows.Forms.Control ctrl)
        {
            IEnumerator ctrlIterator = ctrl.Controls.GetEnumerator();
            while (ctrlIterator.MoveNext())
            {
                System.Windows.Forms.Control ctx = (ctrlIterator.Current as System.Windows.Forms.Control);
                if (ctx != null)
                {
                    string bindFieldName = ctx.GetControlKeyValue();
                    if (!bindFieldName.Equals("") && row.Table.Columns.Contains(bindFieldName))
                    {
                        DataBindControl(ctx, row[bindFieldName]);
                    }
                    if (ctx.HasChildren)
                        CtrlNestedDataBind(row, ctx);
                }
            }
        }
        /// <summary>
        /// 해당 컨트롤 컨테이너내의 컨트롤자식들을 바인딩합니다
        /// </summary>
        /// <param name="row">DataRow</param>
        /// <param name="layoutControlGroup">Container컨트롤</param>
        public static void CtrlNestedDataBind(this DataRow row, LayoutControlGroup layoutControlGroup)
        {
            foreach (object ctrl in layoutControlGroup.Items)
            {
                if (ctrl is LayoutControlItem)
                {
                    LayoutControlItem item = ctrl as LayoutControlItem;

                    System.Windows.Forms.Control ctx = item.Control;
                    if (ctx != null)
                    {
                        string bindFieldName = ctx.GetControlKeyValue();
                        if (bindFieldName.Equals("DEALENDSCHDATE")) { }
                        if (!bindFieldName.Equals("") && row.Table.Columns.Contains(bindFieldName))
                        {
                            DataBindControl(ctx, row[bindFieldName]);
                        }
                    }
                }
                else if (ctrl is LayoutControlGroup)
                {
                    CtrlNestedDataBind(row, ctrl as LayoutControlGroup);
                }
                else if (ctrl is TabbedControlGroup)
                {
                    for (int i = 0; i < (ctrl as TabbedControlGroup).TabPages.GroupCount; i++)
                    {
                        CtrlNestedDataBind(row, (ctrl as TabbedControlGroup).TabPages[i] as LayoutControlGroup);
                    }
                }
            }
        }

        /// <summary>
        /// 해당하는 컨트롤에 데이터를 바인딩한다
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="data"></param>
        public static void DataBindControl(this System.Windows.Forms.Control ctx, object data)
        {
            if (ctx != null)
            {
                if (ctx is IStdBaseDataMappingControl)
                {
                    (ctx as IStdBaseDataMappingControl).DataBindControl(data);
                }
            }
        }

        public static string ToDateString(this object date, string format = "yyyyMMdd")
        {
            try
            {
                return ((DateTime)date).ToString(format);
            }
            catch
            {
                return string.Empty;
            }
        }

        #endregion
    }
}
