﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls.Enums
{
    public enum XtraGridViewType
    {
        None = 0,
        Default = 1,
        Default_ButtonAppend = 2,
        Default_ButtonRemove = 3,
        Default_ButtonAppendRemove = 4,
        Default_ShowGroupPanel = 5
    }
}
