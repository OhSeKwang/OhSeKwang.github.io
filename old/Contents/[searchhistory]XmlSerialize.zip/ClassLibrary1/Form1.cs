﻿using ClassLibrary2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace ClassLibrary1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SearchHistoryData searchHistory = new SearchHistoryData();
            searchHistory.FormList = new List<SearchForm>();
            SearchForm searchForm = new SearchForm();
            searchHistory.FormList.Add(searchForm);

            searchForm.MenuID = "EMP001_001";
            searchForm.Name = this.GetType().FullName;

            searchForm.Controls = new List<SearchControl>();

            SearchControl schCtrl = new SearchControl();
            schCtrl.Name = textBox1.Name;
            schCtrl.Value = textBox1.Text.Trim();
            schCtrl.ValueType = textBox1.Text.GetType().FullName;
            searchForm.Controls.Add(schCtrl);

            schCtrl = new SearchControl();
            schCtrl.Name = checkBox1.Name;
            schCtrl.Value = checkBox1.Checked.ToString(); ;
            schCtrl.ValueType = checkBox1.Checked.GetType().FullName;
            searchForm.Controls.Add(schCtrl);


            searchForm = new SearchForm();
            searchHistory.FormList.Add(searchForm);

            searchForm.MenuID = "EMP001_002";
            searchForm.Name = this.GetType().FullName;

            searchForm.Controls = new List<SearchControl>();

            schCtrl = new SearchControl();
            schCtrl.Name = textBox1.Name;
            schCtrl.Value = textBox1.Text.Trim();
            schCtrl.ValueType = textBox1.Text.GetType().FullName;
            searchForm.Controls.Add(schCtrl);

            schCtrl = new SearchControl();
            schCtrl.Name = checkBox1.Name;
            schCtrl.Value = checkBox1.Checked.ToString(); ;
            schCtrl.ValueType = checkBox1.Checked.GetType().FullName;
            searchForm.Controls.Add(schCtrl);

            XmlSerializer ser = new XmlSerializer(typeof(SearchHistoryData));
            TextWriter writer = new StreamWriter(this.GetFileName());
            ser.Serialize(writer, searchHistory);
            writer.Close();

            System.Diagnostics.Process.Start(this.GetFileName());
        }
        private string GetFileName()
        {
            string strFile = Path.GetFileNameWithoutExtension(this.GetType().Assembly.CodeBase) + ".xml";
            return strFile;
        }
    }
}
