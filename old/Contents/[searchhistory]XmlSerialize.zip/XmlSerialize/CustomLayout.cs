﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Mosti.Windows.Controls.GtGrid.Layout
{
    [XmlRoot("layout", Namespace="http://amis.mostisoft.com")]
    public class CustomLayout
    {
        [XmlElement("form")]
        public List<LayoutForm> FormList;
    }

    public class LayoutForm
    {
        [XmlAttribute("nm")]
        public String Name { get; set; }

        [XmlElement("grid")]
        public List<LayoutGrid> GridList { get; set; }
    }

    public class LayoutGrid
    {
        [XmlElement("column")]
        public List<LayoutColumn> ColumnList { get; set; }

        [XmlAttribute("nm")]
        public string Name { get; set; }
    }

    public class LayoutColumn
    {
        [XmlAttribute("key")]
        public string Key { get; set; }

        [XmlAttribute("order")]
        public int Order { get; set; }

        [XmlAttribute("width")]
        public int Width { get; set; }
    }
}
