﻿using Mosti.Windows.Controls.GtGrid.Layout;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;

namespace XmlSerialize
{
    public partial class Form2 : System.Windows.Forms.Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            XmlSerializer ser = new XmlSerializer(typeof(CustomLayout));
            TextWriter writer = new StreamWriter("test.xml");

            CustomLayout layout = new CustomLayout();
            List<LayoutForm> formList = new List<LayoutForm>();
            LayoutForm form = new LayoutForm();
            formList.Add(form);

            layout.FormList = formList;
            form.Name = "Application1.Form1";

            form.GridList = new List<LayoutGrid>();

            LayoutGrid grid1 = new LayoutGrid();
            grid1.Name = "grdSample";
            form.GridList.Add(grid1);
            grid1.ColumnList = new List<LayoutColumn>();
            LayoutColumn column1 = new LayoutColumn();
            column1.Key = "A";
            column1.Order = 1;
            column1.Width = 100;
            LayoutColumn column2 = new LayoutColumn();
            column2.Key = "B";
            column2.Order = 2;
            column2.Width = 150;
            grid1.ColumnList.Add(column1);
            grid1.ColumnList.Add(column2);

            LayoutGrid grid2 = new LayoutGrid();
            grid2.Name = "grdSample2";
            form.GridList.Add(grid2);
            grid2.ColumnList = new List<LayoutColumn>();
            LayoutColumn column3 = new LayoutColumn();
            column3.Key = "C";
            column3.Order = 3;
            column3.Width = 200;
            LayoutColumn column4 = new LayoutColumn();
            column4.Key = "D";
            column4.Order = 4;
            column4.Width = 250;

            grid2.ColumnList.Add(column3);
            grid2.ColumnList.Add(column4);

            /////////////////////////////////////////////////////////////

            form = new LayoutForm();
            formList.Add(form);

            layout.FormList = formList;
            form.Name = "Application1.Form2";

            form.GridList = new List<LayoutGrid>();

            grid1 = new LayoutGrid();
            grid1.Name = "grdSample";
            form.GridList.Add(grid1);
            grid1.ColumnList = new List<LayoutColumn>();
            column1 = new LayoutColumn();
            column1.Key = "A";
            column1.Order = 1;
            column1.Width = 100;
            column2 = new LayoutColumn();
            column2.Key = "B";
            column2.Order = 2;
            column2.Width = 150;
            grid1.ColumnList.Add(column1);
            grid1.ColumnList.Add(column2);

            grid2 = new LayoutGrid();
            grid2.Name = "grdSample2";
            form.GridList.Add(grid2);
            grid2.ColumnList = new List<LayoutColumn>();
            column3 = new LayoutColumn();
            column3.Key = "C";
            column3.Order = 3;
            column3.Width = 200;
            column4 = new LayoutColumn();
            column4.Key = "D";
            column4.Order = 4;
            column4.Width = 250;

            grid2.ColumnList.Add(column3);
            grid2.ColumnList.Add(column4);

            ser.Serialize(writer, layout);
            writer.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CustomLayout layout = null;
            XmlSerializer ser = new XmlSerializer(typeof(CustomLayout));
            using (XmlReader reader = XmlReader.Create("test.xml"))
            {
                layout = (CustomLayout)ser.Deserialize(reader);
            }
        }
    }
}
