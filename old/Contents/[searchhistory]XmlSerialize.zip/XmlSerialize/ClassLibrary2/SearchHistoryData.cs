﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace ClassLibrary2
{

    [XmlRoot("searchHistory")]
    public class SearchHistoryData
    {
        [XmlElement("form")]
        public List<SearchForm> FormList { get; set; }
    }

    public class SearchForm
    {
        private string _key = DateTime.Now.ToString("yyyyMMddHHMMss.fffff");
        [XmlElement("key")]
        public string Key
        {
            get { return _key; }
            set { _key = value; }
        }

        [XmlElement("uid")]
        public string UserID
        {
            get; set;
        }

        [XmlAttribute("menuid")]
        public string MenuID { get; set; }

        [XmlAttribute("name")]
        public string Name { get; set; }

        [XmlElement("control")]
        public List<SearchControl> Controls { get; set; }
    }

    public class SearchControl
    {
        XmlDocument xDoc = new XmlDocument();

        [XmlAttribute("name")]
        public string Name { get; set; }

        [XmlIgnore]
        public string Value 
        {
            get; set;
        }

        //[XmlText]
        [XmlElement("value")]
        public XmlNode[] CDataContent
        {
            get
            {
                var dummy = new XmlDocument();
                return new XmlNode[] { dummy.CreateCDataSection(Value) };
            }
            set
            {
                if (value == null)
                {
                    Value = null;
                    return;
                }

                if (value.Length != 1)
                {
                    throw new InvalidOperationException(
                        String.Format(
                            "Invalid array length {0}", value.Length));
                }

                var node0 = value[0];
                var cdata = node0 as XmlCDataSection;
                if (cdata == null)
                {
                    throw new InvalidOperationException(
                        String.Format(
                            "Invalid node type {0}", node0.NodeType));
                }

                Value = cdata.Data;
            }
        }

        [XmlElement("type")]
        public string ValueType { get; set; }
    }
}
