﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace HHI.NexFrame.Core.Data
{

    [XmlRoot("searchHistory", Namespace = "http://mostisoft.com")]
    public class SearchHistoryData
    {
        [XmlElement("form")]
        public List<SearchForm> FormList { get; set; }
    }

    public class SearchForm
    {
        [XmlAttribute("id")]
        public string MenuID { get; set; }

        [XmlAttribute("name")]
        public string Name { get; set; }

        [XmlElement("control")]
        public List<SearchControl> Controls { get; set; }
    }
    
    public class SearchControl
    {
        [XmlAttribute("name")]
        public string Name { get; set; }

        [XmlElement("value")]
        public string Value { get; set; }

        [XmlElement("type")]
        public string ValueType { get; set; }
    }
}
