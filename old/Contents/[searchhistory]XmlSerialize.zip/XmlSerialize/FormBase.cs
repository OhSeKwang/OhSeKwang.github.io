﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XmlSerialize
{
    public partial class FormBase : Form
    {
        public FormBase()
        {
            InitializeComponent();
        }

        protected override void WndProc(ref Message wMessage)
        {
            switch (wMessage.Msg)
            {
                case Win32API.WM_COPYDATA:
                    Win32API.COPYDATASTRUCT lParam1 = (Win32API.COPYDATASTRUCT)Marshal.PtrToStructure(wMessage.LParam, typeof(Win32API.COPYDATASTRUCT));
                    Win32API.COPYDATASTRUCT lParam2 = new Win32API.COPYDATASTRUCT();

                    lParam2 = (Win32API.COPYDATASTRUCT)wMessage.GetLParam(lParam2.GetType());
                    // MessageBox.Show("WM_COPYDATA : " + lParam1.lpData + "/ " + lParam2.lpData);
                    this.ReceiveFromWeb(lParam1.lpData);
                    break;
                default:
                    break;
            }

            base.WndProc(ref wMessage);
        }

        public virtual void ReceiveFromWeb(string message)
        {
        }
    }
}
