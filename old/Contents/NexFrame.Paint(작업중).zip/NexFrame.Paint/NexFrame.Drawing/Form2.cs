﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NexFrame.Drawing
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        Graphics g;
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                Image imag = Image.FromFile(open.FileName);
                g = CreateGraphics();
                this.g.DrawImage(imag, new Point(0, 0));
            }
        }
    }
}
