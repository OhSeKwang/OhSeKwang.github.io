﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;


namespace NexFrame.Drawing
{
    public partial class GtDrawingPanel : Panel
    {
        #region 전역변수
        public bool Brush = true;
        private Shapes DrawingShapes = new Shapes();    //Stores all the drawing data
        private bool IsPainting = false;                //Is the mouse currently down (PAINTING)
        private bool IsEraseing = false;                 //Is the mouse currently down (ERASEING)
        private Point LastPos = new Point(0, 0);        //Last Position, used to cut down on repative data.
        private Color CurrentColour = Color.Black;      //Deafult Colour
        private float CurrentWidth = 3;                //펜 굵기
        private int ShapeNum = 0;                       //record the shapes so they can be drawn sepratley.
        private Point MouseLoc = new Point(0, 0);       //Record the mouse position
        private bool IsMouseing = false;                //Draw the mouse?
        #endregion

        #region 생성자
        public GtDrawingPanel()
        {
            //InitializeComponent();
            this.GetType().GetMethod("SetStyle", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic).Invoke(this, new object[] { System.Windows.Forms.ControlStyles.UserPaint | System.Windows.Forms.ControlStyles.AllPaintingInWmPaint | System.Windows.Forms.ControlStyles.DoubleBuffer, true });
            this.MouseDown += new MouseEventHandler(GtDrawingPanel_MouseDown);
            this.MouseMove += new MouseEventHandler(GtDrawingPanel_MouseMove);
            this.MouseUp += new MouseEventHandler(GtDrawingPanel_MouseUp);
            this.Paint += new PaintEventHandler(GtDrawingPanel_Paint);
            this.MouseEnter += new EventHandler(GtDrawingPanel_MouseEnter);
            this.MouseLeave += new EventHandler(GtDrawingPanel_MouseLeave);
        }
        #endregion

        #region Event

        /// <summary>
        /// MouseLeave
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GtDrawingPanel_MouseLeave(object sender, EventArgs e)
        {
            //show the mouse, tell the re-drawing function to stop drawing it and force the panel to re-draw.
            //Cursor.Show(); Mouse Cursor 
            IsMouseing = false;
            this.Refresh();
        }

        /// <summary>
        /// MouseEnter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GtDrawingPanel_MouseEnter(object sender, EventArgs e)
        {
            //Hide the mouse cursor and tell the re-drawing function to draw the mouse
            //Cursor.Hide();
            IsMouseing = true;
        }

        /// <summary>
        /// MouseUp
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GtDrawingPanel_MouseUp(object sender, MouseEventArgs e)
        {
            if (IsPainting)
            {
                //Finished Painting.
                IsPainting = false;
            }
            if (IsEraseing)
            {
                //Finished Earsing.
                IsEraseing = false;
            }
        }

        /// <summary>
        /// MouseMove
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GtDrawingPanel_MouseMove(object sender, MouseEventArgs e)
        {
            MouseLoc = e.Location;
            //PAINTING
            if (IsPainting)
            {
                //check its not at the same place it was last time, saves on recording more data.
                if (LastPos != e.Location)
                {
                    //set this position as the last positon
                    LastPos = e.Location;
                    //store the position, width, colour and shape relation data
                    DrawingShapes.NewShape(LastPos, CurrentWidth, CurrentColour, ShapeNum);
                }
            }
            if (IsEraseing)
            {
                //Remove any point within a certain distance of the mouse
                DrawingShapes.RemoveShape(e.Location, 10);
            }
            //refresh the panel so it will be forced to re-draw.
            this.Refresh();
        }

        /// <summary>
        /// MouseDown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GtDrawingPanel_MouseDown(object sender, MouseEventArgs e)
        {
            //If we're painting...
            if (Brush)
            {
                //set it to mouse down, illatrate the shape being drawn and reset the last position
                IsPainting = true;
                ShapeNum++;
                LastPos = new Point(0, 0);
            }
            //but if we're eraseing...
            else
            {
                IsEraseing = true;
            }
        }

        /// <summary>
        /// OnPaint
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GtDrawingPanel_Paint(object sender, PaintEventArgs e)
        {
            //Apply a smoothing mode to smooth out the line.
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            //DRAW THE LINES
            for (int i = 0; i < DrawingShapes.NumberOfShapes() - 1; i++)
            {
                Shape T = DrawingShapes.GetShape(i);
                Shape T1 = DrawingShapes.GetShape(i + 1);
                //make sure shape the two ajoining shape numbers are part of the same shape
                if (T.ShapeNumber == T1.ShapeNumber)
                {
                    //create a new pen with its width and colour
                    Pen p = new Pen(T.Colour, T.Width);
                    p.StartCap = System.Drawing.Drawing2D.LineCap.Round;
                    p.EndCap = System.Drawing.Drawing2D.LineCap.Round;
                    //draw a line between the two ajoining points
                    e.Graphics.DrawLine(p, T.Location, T1.Location);
                    //get rid of the pen when finished
                    p.Dispose();
                }
            }
            //If mouse is on the panel, draw the mouse
            if (IsMouseing)
            {
                e.Graphics.DrawEllipse(new Pen(Color.White, 0.5f), MouseLoc.X - (CurrentWidth / 2), MouseLoc.Y - (CurrentWidth / 2), CurrentWidth, CurrentWidth);
            }
        }

        #endregion

        #region API

        /// <summary>
        /// Load
        /// </summary>
        public void LoadSignature()
        {
            Stream StreamRead;
            OpenFileDialog DialogueCharger = new OpenFileDialog();
            DialogueCharger.DefaultExt = "sign";
            DialogueCharger.Title = "Load sign";
            DialogueCharger.Filter = "frame files (*.sign)|*.sign|All files (*.*)|*.*";
            if (DialogueCharger.ShowDialog() == DialogResult.OK)
            {
                if ((StreamRead = DialogueCharger.OpenFile()) != null)
                {
                    BinaryFormatter BinaryRead = new BinaryFormatter();
                    this.DrawingShapes = (Shapes)BinaryRead.Deserialize(StreamRead);
                    StreamRead.Close();
                    // Invalidate();
                }
            }
        }

        Graphics g;
        public void LoadImage()
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                Image imag = Image.FromFile(open.FileName);
                g = CreateGraphics();
                this.g.DrawImage(imag, new Point(0, 0));
                //Invalidate();
               // this.BackgroundImage = imag;

            }
        }



        /// <summary>
        /// 사진저장
        /// </summary>
        public void SavePicture()
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Title = "Save as Picture";
            dialog.Filter = "Images|*.png;*.bmp;*.jpg";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                int width = Convert.ToInt32(this.Width); //Panel Width
                int height = Convert.ToInt32(this.Height); //Panel Height
                Bitmap bmp = new Bitmap(width, height); //Bitmap 생성
                this.DrawToBitmap(bmp, new Rectangle(0, 0, width, height)); //Panel Image 저장 시작점(0,0) 너비(width) 높이 Height
                bmp.Save(dialog.FileName, ImageFormat.Jpeg);
            }
        }

        /// <summary>
        /// 서명저장
        /// </summary>
        public void SaveSignature()
        {   
            Stream StreamWrite;
            SaveFileDialog DialogueSauver = new SaveFileDialog();
            DialogueSauver.DefaultExt = "sign";
            DialogueSauver.Title = "Save as sign";
            DialogueSauver.Filter = "sign files (*.sign)|*.sign|All files (*.*)|*.*";
            if (DialogueSauver.ShowDialog() == DialogResult.OK)
            {
                if ((StreamWrite = DialogueSauver.OpenFile()) != null)
                {
                    BinaryFormatter BinaryWrite = new BinaryFormatter();

                    BinaryWrite.Serialize(StreamWrite, this.DrawingShapes);
                    StreamWrite.Close();
                }
            }
        }

        /// <summary>
        /// ColorChange
        /// </summary>
        public void ColorChange()
        {
            //Show and Get the result of the colour dialog
            ColorDialog colorDialog = new ColorDialog();
            DialogResult D = colorDialog.ShowDialog();
            if (D == DialogResult.OK)
            {
                //Apply the new colour
                CurrentColour = colorDialog.Color;
            }
        }

        /// <summary>
        /// Clear
        /// </summary>
        public void Clear()
        {
            //Reset the list, removeing all shapes.
            DrawingShapes = new Shapes();
            this.Refresh();
            Brush = true;
        }

        #endregion
    }

    #region Shape Class
    [Serializable]
    public class Shape
    {
        public Point Location;          //position of the point
        public float Width;             //width of the line
        public Color Colour;            //colour of the line
        public int ShapeNumber;         //part of which shape it belongs to

        //CONSTRUCTOR
        public Shape(Point L, float W, Color C, int S)
        {
            Location = L;               //Stores the Location
            Width = W;                  //Stores the width
            Colour = C;                 //Stores the colour
            ShapeNumber = S;            //Stores the shape number
        }
    }
    #endregion

    #region Shapes Class
    [Serializable]
    public class Shapes
    {
        private List<Shape> _Shapes;    //Stores all the shapes

        public Shapes()
        {
            _Shapes = new List<Shape>();
        }
        //Returns the number of shapes being stored.
        public int NumberOfShapes()
        {
            return _Shapes.Count;
        }
        //Add a shape to the database, recording its position, width, colour and shape relation information
        public void NewShape(Point L, float W, Color C, int S)
        {
            _Shapes.Add(new Shape(L, W, C, S));
        }
        //returns a shape of the requested data.
        public Shape GetShape(int Index)
        {
            return _Shapes[Index];
        }
        //Removes any point data within a certain threshold of a point.
        public void RemoveShape(Point L, float threshold)
        {
            for (int i = 0; i < _Shapes.Count; i++)
            {
                //Finds if a point is within a certain distance of the point to remove.
                if ((Math.Abs(L.X - _Shapes[i].Location.X) < threshold) && (Math.Abs(L.Y - _Shapes[i].Location.Y) < threshold))
                {
                    //removes all data for that number
                    _Shapes.RemoveAt(i);

                    //goes through the rest of the data and adds an extra 1 to defined them as a seprate shape and shuffles on the effect.
                    for (int n = i; n < _Shapes.Count; n++)
                    {
                        _Shapes[n].ShapeNumber += 1;
                    }
                    //Go back a step so we dont miss a point.
                    i -= 1;
                }
            }
        }
    }
    #endregion
}
