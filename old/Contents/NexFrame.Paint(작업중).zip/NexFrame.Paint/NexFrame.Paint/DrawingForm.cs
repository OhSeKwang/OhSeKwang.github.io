﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NexFrame.Paint
{
    public partial class DrawingForm : Form
    {
        #region ▶ 전역변수

        private Image _image;

        #endregion

        #region ▶ 생성자

        public DrawingForm()
        {
            InitializeComponent();
        }

        public DrawingForm(Image image)
        {
            InitializeComponent();
            _image = image;
            this.Load += DrawingForm_Load;
            btnPenColor.Click += btnPenColor_Click;
        }

        #endregion

        #region ▶ Event

        void DrawingForm_Load(object sender, EventArgs e)
        {
            pnlDrawing.BackgroundImage = _image;
        }

        void btnPenColor_Click(object sender, EventArgs e)
        {
            pnlDrawing.ColorChange(); //색상변경
        }

        #endregion

        #region ▶ Method


        #endregion
      
    }
}
