﻿namespace NexFrame.Paint
{
    partial class DrawingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnuTop = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnPenColor = new System.Windows.Forms.Button();
            this.pnlDrawing = new NexFrame.Paint.DrawingPanel();
            this.button2 = new System.Windows.Forms.Button();
            this.mnuTop.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuTop
            // 
            this.mnuTop.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.mnuTop.Location = new System.Drawing.Point(0, 0);
            this.mnuTop.Name = "mnuTop";
            this.mnuTop.Size = new System.Drawing.Size(819, 24);
            this.mnuTop.TabIndex = 0;
            this.mnuTop.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(57, 20);
            this.toolStripMenuItem1.Text = "파일(F)";
            // 
            // pnlTop
            // 
            this.pnlTop.Controls.Add(this.button2);
            this.pnlTop.Controls.Add(this.btnPenColor);
            this.pnlTop.Controls.Add(this.button1);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 24);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(819, 50);
            this.pnlTop.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 7);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 37);
            this.button1.TabIndex = 0;
            this.button1.Text = "디자인 하기";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnPenColor
            // 
            this.btnPenColor.Location = new System.Drawing.Point(112, 7);
            this.btnPenColor.Name = "btnPenColor";
            this.btnPenColor.Size = new System.Drawing.Size(94, 37);
            this.btnPenColor.TabIndex = 1;
            this.btnPenColor.Text = "펜 색변경";
            this.btnPenColor.UseVisualStyleBackColor = true;
            // 
            // pnlDrawing
            // 
            this.pnlDrawing.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pnlDrawing.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDrawing.Location = new System.Drawing.Point(0, 74);
            this.pnlDrawing.Name = "pnlDrawing";
            this.pnlDrawing.Size = new System.Drawing.Size(819, 584);
            this.pnlDrawing.TabIndex = 2;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(212, 7);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(94, 37);
            this.button2.TabIndex = 2;
            this.button2.Text = "펜 색변경";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // DrawingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(819, 658);
            this.Controls.Add(this.pnlDrawing);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.mnuTop);
            this.MainMenuStrip = this.mnuTop;
            this.Name = "DrawingForm";
            this.Text = "DrawingFrom";
            this.mnuTop.ResumeLayout(false);
            this.mnuTop.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuTop;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Button button1;
        private DrawingPanel pnlDrawing;
        private System.Windows.Forms.Button btnPenColor;
        private System.Windows.Forms.Button button2;
    }
}