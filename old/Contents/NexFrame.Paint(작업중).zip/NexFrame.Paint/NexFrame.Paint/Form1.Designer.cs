﻿namespace NexFrame.Paint
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPaint = new System.Windows.Forms.Button();
            this.cboMoniter = new System.Windows.Forms.ComboBox();
            this.btnAllPaint = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnModift = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnPaint
            // 
            this.btnPaint.Location = new System.Drawing.Point(12, 12);
            this.btnPaint.Name = "btnPaint";
            this.btnPaint.Size = new System.Drawing.Size(105, 34);
            this.btnPaint.TabIndex = 0;
            this.btnPaint.Text = "화면 캡쳐시작";
            this.btnPaint.UseVisualStyleBackColor = true;
            // 
            // cboMoniter
            // 
            this.cboMoniter.FormattingEnabled = true;
            this.cboMoniter.Location = new System.Drawing.Point(170, 27);
            this.cboMoniter.Name = "cboMoniter";
            this.cboMoniter.Size = new System.Drawing.Size(121, 20);
            this.cboMoniter.TabIndex = 1;
            // 
            // btnAllPaint
            // 
            this.btnAllPaint.Location = new System.Drawing.Point(305, 19);
            this.btnAllPaint.Name = "btnAllPaint";
            this.btnAllPaint.Size = new System.Drawing.Size(105, 35);
            this.btnAllPaint.TabIndex = 2;
            this.btnAllPaint.Text = "전체영역캡쳐";
            this.btnAllPaint.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(168, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "주모니터가 1번 입니다.";
            // 
            // btnModift
            // 
            this.btnModift.Location = new System.Drawing.Point(416, 19);
            this.btnModift.Name = "btnModift";
            this.btnModift.Size = new System.Drawing.Size(105, 35);
            this.btnModift.TabIndex = 4;
            this.btnModift.Text = "편집";
            this.btnModift.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(567, 127);
            this.Controls.Add(this.btnModift);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAllPaint);
            this.Controls.Add(this.cboMoniter);
            this.Controls.Add(this.btnPaint);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPaint;
        private System.Windows.Forms.ComboBox cboMoniter;
        private System.Windows.Forms.Button btnAllPaint;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnModift;
    }
}

