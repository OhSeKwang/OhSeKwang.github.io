﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NexFrame.Paint
{
    public class ScreenCapture
    {
        #region ▶ 전역변수

        private static Rectangle canvasBounds = Screen.GetBounds(Point.Empty);

        #endregion

        #region ▶ 생성자

        public ScreenCapture()
        {

        }

        #endregion

        #region ▶ Method

        /// <summary>
        /// 화면을 캡쳐 합니다.
        /// </summary>
        public static bool SetCanvas()
        {
            using (ScreenCaptureForm canvas = new ScreenCaptureForm())
            {
                if (canvas.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    canvasBounds = canvas.GetRectangle();
                    SetAreaSetting();
                    return true;
                }
                else
                    return false;
            }
        }

        /// <summary>
        /// 모니터 영역을 계산해서 해당하는 부분을 캡쳐 한다.
        /// 모니터가 3개일 경우 케이스 확인후 처리 필요
        /// </summary>
        private static void SetAreaSetting()
        {
            Rectangle fullScrenn_bounds = Rectangle.Empty; //전체 영역 확인
            if (Screen.AllScreens.Count() > 1)
            {
                //int screenCount = Screen.AllScreens.Count() - 1; 
                foreach (var screen in Screen.AllScreens)
                {
                    fullScrenn_bounds = Rectangle.Union(fullScrenn_bounds, screen.Bounds);
                }
                /*
                 주모니터가 오른쪽 보조모니터 : 주모니터 (-x값이나옴)
                 반대인경우는 이슈가 발생하지 않음
                 */
                if(fullScrenn_bounds.X <0)
                {
                    canvasBounds.X += (fullScrenn_bounds.X);
                }
            }
        }

        /// <summary>
        /// 화면을 가져 옵니다.
        /// </summary>
        /// <returns></returns>
        public static Bitmap GetSnapShot()
        {
            using (Image image = new Bitmap(canvasBounds.Width, canvasBounds.Height))
            {
                using (Graphics graphics = Graphics.FromImage(image))
                {
                    graphics.CopyFromScreen(new Point(canvasBounds.Left, canvasBounds.Top), Point.Empty, canvasBounds.Size);
                }
                return new Bitmap(SetBorder(image, Color.Black, 0)); //보더는 그리지 않는다.
            }
        }

        /// <summary>
        /// Image Board 영역 처리
        /// </summary>
        /// <param name="srcImg"></param>
        /// <param name="color"></param>
        /// <param name="width"></param>
        /// <returns></returns>
        private static Image SetBorder(Image srcImg, Color color, int width)
        {
            //그래픽 객체를 생성 합니다.
            Image dstImg = srcImg.Clone() as Image;
            Graphics g = Graphics.FromImage(dstImg);

            // Create the pen
            Pen pBorder = new Pen(color, width)
            {
                Alignment = PenAlignment.Center
            };

            // 캡쳐영역에 1px 영역에 보더를 그립니다.
            g.DrawRectangle(pBorder, 0, 0, dstImg.Width - 1, dstImg.Height - 1);

            // Clean up
            pBorder.Dispose();
            g.Save();
            g.Dispose();

            // Return
            return dstImg;
        }

        /// <summary>
        /// SaveFileDialogImages SaveFileDialog 를 호출 합니다.
        /// </summary>
        /// <param name="images"></param>
        public static void SaveFileDialogImages(Bitmap images)
        {
            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Filter = "JPeg Image|*.jpg|Bitmap Image|*.bmp|Gif Image|*.gif|Png Image|*.png";
                dialog.Title = "Save an Image File";
                ImageFormat format = ImageFormat.Png;
                dialog.ShowDialog();
                if (dialog.FileName != "")
                {
                    string ext = System.IO.Path.GetExtension(dialog.FileName);
                    switch (ext)
                    {
                        case ".jpg":
                            format = ImageFormat.Jpeg;
                            break;
                        case ".bmp":
                            format = ImageFormat.Bmp;
                            break;
                        case ".gif":
                            format = ImageFormat.Gif;
                            break;
                        case ".png":
                            format = ImageFormat.Png;
                            break;
                    }
                    images.Save(dialog.FileName, format);
                }
            }
        }

        /// <summary>
        /// 폴더 다이얼로그를 호출 해줍니다.
        /// </summary>
        /// <param name="images"></param>
        public static void SaveFolderDialogImages(Bitmap images)
        {
            using (FolderBrowserDialog dialog = new FolderBrowserDialog())
            {
                if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    images.Save(dialog.SelectedPath + "\\Snap_" + Guid.NewGuid() + ".bmp");
                }
            }
        }

        #endregion
    }
}

