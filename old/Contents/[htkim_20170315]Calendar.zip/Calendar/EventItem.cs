﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication30
{
    public class EventItem
    {
        public DateTime? _eventTime = null;
        public DateTime? EventTime
        {
            get
            {
                return _eventTime;
            }
            set
            {
                _eventTime = value;
            }
        }

        private string[] _eventSource = new string[] { };
        public string[] EventSource
        {
            get { return _eventSource; }
            set { _eventSource = value; }
        }
    }
}
