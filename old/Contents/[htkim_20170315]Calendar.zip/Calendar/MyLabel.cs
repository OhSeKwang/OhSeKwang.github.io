﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApplication30
{
    public class MyLabel : Label
    {
        public MyLabel()
        {
            this.DoubleBuffered = true;
            this.Dock = DockStyle.Top;
        }
        public static void Label_Click(object sender, EventArgs e)
        {
            MyLabel txt = (MyLabel)sender;
            MessageBox.Show(txt.Parent.Name +" Panel / "+ txt.Name +" Label");
        }
    }
}
