﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication30
{
    public class HtHeaderLabel : Label
    {
        public HtHeaderLabel()
        {
            this.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.AutoSize = false;
            this.Dock = DockStyle.Top;
            this.Margin = new Padding(1, 1, 0, 0);
        }

        /// <summary>
        /// 토요일 컬럼은 Margin 값을 다르게 설정 해야 합니다.
        /// </summary>
        /// <param name="isLastColumn"></param>
        public HtHeaderLabel(bool isLastColumn) :this()
        {
            this.Margin = new Padding(1, 1, 1, 0);
        }
    }
}
