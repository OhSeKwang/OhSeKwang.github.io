﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication30
{
    class GetDate
    {
        public static DateTime Date()
        {
            return DateTime.Today;
        }
        public static int Firstday(DateTime today)
        {
            return (int)today.AddDays(-today.Day + 1).DayOfWeek;
        }
        public static int Lastday(DateTime today)
        {
            return DateTime.DaysInMonth(today.Year, today.Month);
        }
        public static List<string> Listday(DateTime today)
        {
            return Enumerable.Repeat(" ", Firstday(today))
                .Concat(Enumerable.Range(1, Lastday(today))
                .Select(i => i.ToString())).ToList();
        }
    }
}
