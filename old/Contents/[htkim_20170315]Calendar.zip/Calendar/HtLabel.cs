﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication30
{
    public class HtLabel : Label
    {
        public HtLabel()
        {
            this.DoubleBuffered = true;

            this.Padding = new Padding(8);

            this.MouseEnter += (s1, e1) =>
            {
                this.BackColor = this.MouseEnterColor;
            };

            this.MouseLeave += (s2, e2) =>
            {
                this.BackColor = this.MouseLeaveColor;
            };
        }

        public Color _mouseEnterColor = SystemColors.ActiveCaption;
        public Color MouseEnterColor
        {
            get { return _mouseEnterColor; }
            set { _mouseEnterColor = value; }
        }

        public Color _mouseLeaveColor = SystemColors.Control;
        public Color MouseLeaveColor
        {
            get
            {
                return _mouseLeaveColor;
            }
            set
            {
                this._mouseLeaveColor = value;
            }
        }

        protected override void OnCreateControl()
        {
            this.MouseLeaveColor = this.BackColor;
            base.OnCreateControl();
        }

    }
}
