﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls.Enums
{
    /// <summary>
    /// Textbox , ButtonEdit , ComboEdit의 Custom 색상을 정의한다.
    /// </summary>
    public enum EditColorSkinType
    {
        Required = 0,
        ReadOnly = 1,
        Skin1 = 2,
        Skin2 = 3,
        Skin3 = 4,
        Skin4 = 5,
        Skin5 = 6,
        Normal = 99
    }
}
