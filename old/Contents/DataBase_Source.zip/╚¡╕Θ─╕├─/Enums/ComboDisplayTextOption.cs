﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls.Enums
{
    public enum ComboDisplayTextOption
    {
        top = 0,
        bottom = 1,
        none = 2
    }
}
