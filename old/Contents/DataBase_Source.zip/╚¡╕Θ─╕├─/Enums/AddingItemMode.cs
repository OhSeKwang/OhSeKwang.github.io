﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls.Enums
{
    public enum AddingItemMode
    {
        None,
        [Description("선택하세요")]
        Select,
        [Description("전체")]
        All
    }
}
