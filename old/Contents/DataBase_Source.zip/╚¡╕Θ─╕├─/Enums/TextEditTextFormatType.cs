﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls.Enums
{
    public enum TextEditTextFormatType
    {
        CustomType = 0,
        None = 1,
        IP = 2,
        이메일 = 3,
        휴대폰 = 4,
        전화번호 = 5,
        사업자번호 = 6,
        주민번호 = 7,
        계좌번호 = 8,
        FAX번호 = 9,
        숫자문자조합 = 10,
        홈페이지 = 11
    }
}
