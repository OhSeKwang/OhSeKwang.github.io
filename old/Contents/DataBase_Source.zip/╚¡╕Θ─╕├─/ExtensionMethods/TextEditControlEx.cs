﻿using DevExpress.XtraEditors;
using HHI.NexFrame.Client.Controls.Enums;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHI.NexFrame.Client.Controls
{
    public static class TextEditControl
    {
        public static void SetExEditTextFormat(this TextEdit editCtrl, TextEditTextFormatType FormatType)
        {
            if (FormatType.Equals(TextEditTextFormatType.CustomType))
            {
            }
            else
            {
                if (FormatType.Equals(TextEditTextFormatType.None))
                {
                    (editCtrl).Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.None;
                    (editCtrl).Properties.Mask.EditMask = "";
                }
                else if (FormatType == TextEditTextFormatType.IP)
                {
                    (editCtrl).Properties.Mask.EditMask = @"(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)";
                    (editCtrl).Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx;
                }
                else if (FormatType == TextEditTextFormatType.이메일)
                {
                    (editCtrl).Properties.Mask.EditMask = @"([0-9a-zA-Z_.-]+)@([0-9a-zA-Z_-]+)(\.([0-9a-zA-Z_-]{2,6}))+";
                    (editCtrl).Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx;
                }
                else if (FormatType == TextEditTextFormatType.전화번호)
                {
                    (editCtrl).Properties.Mask.EditMask = @"[0-9-]{4,30}";
                    (editCtrl).Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx;
                }
                else if (FormatType == TextEditTextFormatType.FAX번호)
                {
                    (editCtrl).Properties.Mask.EditMask = @"[0-9-]{4,30}";
                    (editCtrl).Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx;
                }
                else if (FormatType == TextEditTextFormatType.휴대폰)
                {
                    //(editCtrl).Properties.Mask.EditMask = @"[010|016|017|018|019|011]{3}\-\d{3,4}\-\d{4}";
                    (editCtrl).Properties.Mask.EditMask = @"[0-9-]{4,30}";
                    (editCtrl).Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx;
                }
                else if (FormatType == TextEditTextFormatType.사업자번호)
                {
                    //(editCtrl).Properties.Mask.EditMask = @"\d{3}-\d{2}-\d{5}";
                    (editCtrl).Properties.Mask.EditMask = @"[0-9a-zA-Z]{1,50}";
                    (editCtrl).Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx;
                }
                else if (FormatType == TextEditTextFormatType.주민번호)
                {
                    (editCtrl).Properties.Mask.EditMask = @"\d{6}-\d{7}";
                    (editCtrl).Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx;
                }
                else if (FormatType == TextEditTextFormatType.계좌번호)
                {
                    (editCtrl).Properties.Mask.EditMask = @"(\d|-)+";
                    (editCtrl).Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx;
                }
                else if (FormatType == TextEditTextFormatType.숫자문자조합)
                {
                    (editCtrl).Properties.Mask.EditMask = @"[0-9a-zA-Z_-]+";
                    (editCtrl).Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx;
                }
                else if (FormatType == TextEditTextFormatType.홈페이지)
                {
                    (editCtrl).Properties.Mask.EditMask = @"http://([0-9a-zA-Z_-.]+)";
                    (editCtrl).Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx;
                }
            }
        }
    }
}
