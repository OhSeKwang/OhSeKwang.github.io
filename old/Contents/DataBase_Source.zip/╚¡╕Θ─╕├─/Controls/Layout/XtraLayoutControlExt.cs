﻿using DevExpress.XtraLayout;

namespace HHI.NexFrame.Client.Controls
{
    public class XtraLayoutControlExt : LayoutControl
    {
        public XtraLayoutControlExt()
        {
        }
    }
}
