﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HHI.NexFrame.Client.Controls
{
    public partial class ScreenCaptureForm : Form
    {
        #region ▶ 전역변수

        Point startPos;                              // 마우스 다운 Position
        Point currentPos;                            // 캡쳐 Position
        bool drawing;                                // Drawing 유무 확인
        Rectangle fullScrenn_bounds;                 // 전체 영역 확인

        Color _drawPen = Color.Black;                // 드래그 영역에 Border Color를 설정합니다.
        private int _borderThickness = 1;            // 드래그 영역 두께를 설정 합니다.
        Color _dragFillColor = Color.FromArgb(78,65,128,206);         // 드래그 영역에 내부 Color를 설정합니다.

        #endregion

        #region ▶ 생성자

        public ScreenCaptureForm()
        {
            InitializeComponent();

            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None; //None Style설정
            this.StartPosition = FormStartPosition.Manual;                    //해당하는 폼을 Manual 처리
            fullScrenn_bounds = Rectangle.Empty;
            foreach (var screen in Screen.AllScreens)
            {
                fullScrenn_bounds = Rectangle.Union(fullScrenn_bounds, screen.Bounds);
            }
            this.ClientSize = new Size(fullScrenn_bounds.Width, fullScrenn_bounds.Height); //Client Size
            this.Location = new Point(fullScrenn_bounds.Left, fullScrenn_bounds.Top);      //Loaction

            this.BackColor = Color.White;
            this.Opacity = 0.75;
            this.Cursor = Cursors.Cross;
            this.MouseDown += Canvas_MouseDown;
            this.MouseMove += Canvas_MouseMove;
            this.MouseUp += Canvas_MouseUp;
            this.Paint += Canvas_Paint;
            this.KeyDown += Canvas_KeyDown;
            this.DoubleBuffered = true;
            
            
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);

        }

        #endregion

        #region ▶ Method

        /// <summary>
        /// 영역을 계산해서 린터 합니다.
        /// </summary>
        /// <returns></returns>
        public Rectangle GetRectangle()
        {
            return new Rectangle(Math.Min(startPos.X, currentPos.X), Math.Min(startPos.Y, currentPos.Y), Math.Abs(startPos.X - currentPos.X), Math.Abs(startPos.Y - currentPos.Y));
        }

        #endregion

        #region ▶ Event

        private void Canvas_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
                this.Close();
            }
        }

        private void Canvas_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                currentPos = startPos = e.Location;
                drawing = true;
            }
        }

        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                currentPos = e.Location;
                if (drawing) this.Invalidate();
            }
        }

        private void Canvas_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.DialogResult = System.Windows.Forms.DialogResult.OK;
                this.Close();
            }
            else
            {
                this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
                this.Close();
            }
        }

        private void Canvas_Paint(object sender, PaintEventArgs e)
        {
            if (drawing)
            {
                Pen p = new Pen(_drawPen, _borderThickness);
                e.Graphics.DrawRectangle(p, GetRectangle());  //마우스 드래그 영역을 그립니다.

                //사각형 내부에 색을 지정합니다.
                e.Graphics.FillRectangle(new SolidBrush(_dragFillColor),
                    new Rectangle(Math.Min(startPos.X, currentPos.X) + _borderThickness,  //시작위치  X
                        Math.Min(startPos.Y, currentPos.Y) + _borderThickness,             //시작위치  Y
                        Math.Abs(startPos.X - currentPos.X) - _borderThickness,           //Width
                        Math.Abs(startPos.Y - currentPos.Y) - _borderThickness));        //Height

                p.Dispose();

            }
        }

        #endregion
    }
}
