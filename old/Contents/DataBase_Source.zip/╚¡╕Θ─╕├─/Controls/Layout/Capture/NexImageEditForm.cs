﻿using DevExpress.XtraEditors;
using HHI.NexFrame.Client.Controls;
using HHI.NexFrame.Client.Controls.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace HHI.NexFrame.Client.Controls
{
    public partial class NexImageEditForm : XtraForm
    {
        #region ▶ 전역변수

        private Image _image;
        private Color _selectColor = Color.Red;
        private bool _newCapture = false;

        //사용않함
        //public event ImageChangeHandler ImageChanged; 
        //public delegate void ImageChangeHandler(Image image);

        #endregion

        #region ▶ 생성자

        public NexImageEditForm()
        {
            InitializeComponent();
        }

        public NexImageEditForm(Image image)
        {
            InitializeComponent();
            InitSetting();
            _image = image;
            pnlDrawing.Size = new Size(image.Width, image.Height);
            this.Shown += NexImageEditForm_Shown;
        }

        private void InitSetting()
        {
            //drpPenColor2.ShowDropDown();
            //barTopMenu.Appearance.BackColor = Color.Red;
            //barTopMenu.Appearance.BackColor2 = Color.Red;
            //barTopMenu.Appearance.Options.UseBackColor = true;


            //barAndDockingController1.LookAndFeel.UseDefaultLookAndFeel = false;
            //barAndDockingController1.LookAndFeel.Style = DevExpress.LookAndFeel.LookAndFeelStyle.Flat;
            //barAndDockingController1.AppearancesBar.Bar.BackColor = barAndDockingController1.AppearancesBar.MainMenu.BackColor = Color.FromArgb(66, 68, 70);
            //barAndDockingController1.AppearancesBar.Bar.BackColor = barAndDockingController1.AppearancesBar.MainMenu.ForeColor = Color.White;

            
            
           
        }

        #endregion

        #region ▶ Event


        void NexImageEditForm_Shown(object sender, EventArgs e)
        {
            pnlDrawing.Image = _image;


            //Pen
            tolBlackPen.ItemClick += tolPenColorChange;                           //Black Pen
            tolBluePen.ItemClick += tolPenColorChange;                            //Blue Pen
            tolRedPen.ItemClick += tolPenColorChange;                             //Red Pen
            tolCustomPen.ItemClick += tolCustomPen_Click;                         //사용자 지정 Pen
            tolNewCapture.ItemClick += NewCapture_ItemClick;

            //ToolStripMenuItem
            tolSaveAs.ItemClick += SaveImage_Click;                                //다른이름으로 저장
            tolSenEmail.ItemClick += SendEmail_Click;                              //Email 전송
            tolCopy.ItemClick += CopyImage_Click;                                  //Copy
            tolEnd.ItemClick += tolEnd_Click;                                      //종료
            tolHighlighter.ItemClick += Highlighter_Click;                         //Highlighter
            tolEraser.ItemClick += Eraser_Click;                                   //지우개

            //Button
            btnSave.ItemClick += SaveImage_Click;                                 //다른이름 저장
            btnCopy.ItemClick += CopyImage_Click;                                 //클립보드 복사
            btnEraser.ItemClick += Eraser_Click;                                  //그림 삭제
            btnHighlighter.ItemClick += Highlighter_Click;                        //형광펜
            btnEmail.ItemClick += SendEmail_Click;
            drpPenColor.ItemClick += drpPenColor_ItemClick;
            btnRedPen.ItemClick += PenColor_ItemClick;
            btnBluePen.ItemClick += PenColor_ItemClick;
            btnBlackPen.ItemClick += PenColor_ItemClick;
            btnCapture.ItemClick += NewCapture_ItemClick;
        }



        /// <summary>
        /// 새캡쳐
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void NewCapture_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            this.Close();
            _newCapture = true;
            
        }

        /// <summary>
        /// 저장
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void SaveImage_Click(object sender, EventArgs e)
        {
            this.Close();
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            ReturnImage = pnlDrawing.GetSnapShot();
        }

        /// <summary>
        /// Email 전송
        /// 생성 확인
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void SendEmail_Click(object sender, EventArgs e)
        {
            try
            {
                //Email Code 살리기
                //생성된 이미지 삭제 로직 추가하기
                //실제 전송후 삭제 확인하기.
                Microsoft.Office.Interop.Outlook.Application outlookApp = new Microsoft.Office.Interop.Outlook.Application();
                Microsoft.Office.Interop.Outlook.MailItem mailItem = (Microsoft.Office.Interop.Outlook.MailItem)outlookApp.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);

                mailItem.Subject = "장애신고";

                //Image를 저장후에 보내야 한다.
                //삭제 및 위치 상의후 변경하기
                //전송 테스트 후 파일 지우기
                Image image = pnlDrawing.GetSnapShot();
                string strImageCode = Encode();
                string strtempImage = Path.Combine(Path.GetDirectoryName(System.Windows.Forms.Application.ExecutablePath), strImageCode + ".jpg");
                image.Save(strtempImage, ImageFormat.Jpeg); //경로 변경 확인 필요

                Microsoft.Office.Interop.Outlook.Attachment attachment = mailItem.Attachments.Add(
                strtempImage.Replace("\\", "//")
                , Microsoft.Office.Interop.Outlook.OlAttachmentType.olEmbeddeditem
                , null
                , strtempImage.Replace("\\", "//")
                );
                attachment.PropertyAccessor.SetProperty("http://schemas.microsoft.com/mapi/proptag/0x3712001E", strImageCode);
                mailItem.BodyFormat = Microsoft.Office.Interop.Outlook.OlBodyFormat.olFormatRichText;
                mailItem.HTMLBody = String.Format(
                      "<body><img src=\"cid:{0}\"></body>"
                     , strImageCode
                     );
                mailItem.Importance = Microsoft.Office.Interop.Outlook.OlImportance.olImportanceNormal;
                mailItem.Attachments.Add(strtempImage.Replace("\\", "//")); //첨부파일 추가

                mailItem.Display(false);
            }
            catch (System.Exception)
            {
                throw;
            }

        }


        /// <summary>
        /// Email 첨부파일
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void tolSendEmailFile_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 복사
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void CopyImage_Click(object sender, EventArgs e)
        {
            Clipboard.Clear();
            Image image = pnlDrawing.GetSnapShot();
            Clipboard.SetImage(image);
        }

        /// <summary>
        /// 펜 칼라 변경
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tolPenColorChange(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            string strSelectName = e.Item.Name;
            SetPenColorChange(strSelectName);
        }

        /// <summary>
        /// 펜 칼라 변경
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void cboPenColor_SelectedValueChanged(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 펜 생상을 변경 합니다.
        /// </summary>
        /// <param name="penColor"></param>
        private void SetPenColorChange(string penColor)
        {
            pnlDrawing.DrawingMode = DrawingMode.Pen;
            pnlDrawing.Brush = true;
            switch (penColor.Replace("tol", ""))
            {
                case "RedPen":
                    pnlDrawing.PenColor = Color.Red;
                    _selectColor = Color.Red;
                    drpPenColor.Glyph = Resources.HighlighterPen;
                    break;
                case "BluePen":
                    pnlDrawing.PenColor = Color.Blue;
                    _selectColor = Color.Blue;
                    drpPenColor.Glyph = Resources.Pen_Blue;
                    break;
                case "BlackPen":
                    pnlDrawing.PenColor = Color.Black;
                    _selectColor = Color.Black;
                    drpPenColor.Glyph = Resources.Pen_Black;
                    break;
                default:
                    pnlDrawing.PenColor = Color.Red;
                    _selectColor = Color.Red;
                    drpPenColor.Glyph = Resources.HighlighterPen;
                    break;
            }
        }

        /// <summary>
        /// 사용자 지정펜
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void tolCustomPen_Click(object sender, EventArgs e)
        {
            pnlDrawing.DrawingMode = DrawingMode.Pen;
            pnlDrawing.Brush = true;
            pnlDrawing.ColorChange(); //색상변경
        }

        /// <summary>
        /// 형광펜
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Highlighter_Click(object sender, EventArgs e)
        {
            pnlDrawing.Brush = true;
            pnlDrawing.DrawingMode = DrawingMode.Highlighter;
        }


        /// <summary>
        /// 지우개
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Eraser_Click(object sender, EventArgs e)
        {
            pnlDrawing.Brush = false;
        }

        /// <summary>
        /// 종료
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        void tolEnd_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 사용자 지정펜
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnPenColor_Click(object sender, EventArgs e)
        {
            pnlDrawing.ColorChange(); //색상변경
        }

        /// <summary>
        /// 색을 변경 합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PenColor_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            switch (e.Item.Name)
            {
                case "btnRedPen":
                    drpPenColor.Glyph = Resources.HighlighterPen;
                    break;
                case "btnBluePen":
                    drpPenColor.Glyph = Resources.Pen_Blue;
                    break;
                case "btnBlackPen":
                    drpPenColor.Glyph = Resources.Pen_Black;
                    break;
                default:
                    break;
            }

            SetPenColorChange(e.Item.Name.Replace("btn", ""));
        }

        /// <summary>
        ///  색을 칠합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void drpPenColor_Click(object sender, EventArgs e)
        {
            pnlDrawing.Brush = true;
            pnlDrawing.PenColor = _selectColor;
            pnlDrawing.DrawingMode = DrawingMode.Pen;
        }

        private void drpPenColor_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            pnlDrawing.Brush = true;
            pnlDrawing.PenColor = _selectColor;
            pnlDrawing.DrawingMode = DrawingMode.Pen;
        }

        private void NexImageEditForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
            if (_newCapture == true)
                this.DialogResult = System.Windows.Forms.DialogResult.No;
            else
                this.DialogResult = System.Windows.Forms.DialogResult.OK;

        }

        #endregion

        #region Method

        /// <summary>
        /// 유니크값 생성
        /// </summary>
        /// <returns></returns>
        public string Encode()
        {
            DateTime _now = DateTime.Now;
            string _dd = _now.ToString("dd");
            string _hh = _now.Hour.ToString();
            string _min = _now.Minute.ToString();
            string _ss = _now.Second.ToString();

            string _uniqueId = _dd + _hh + _min + _ss;
            return _uniqueId;
        }

        public Image ReturnImage { get; private set; }

        #endregion

       
    }
}
