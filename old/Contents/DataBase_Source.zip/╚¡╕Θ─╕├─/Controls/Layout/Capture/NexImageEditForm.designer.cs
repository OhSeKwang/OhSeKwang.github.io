﻿namespace HHI.NexFrame.Client.Controls
{
    partial class NexImageEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NexImageEditForm));
            this.popupMenu1 = new DevExpress.XtraBars.PopupMenu(this.components);
            this.barManager = new DevExpress.XtraBars.BarManager(this.components);
            this.barToolBox = new DevExpress.XtraBars.Bar();
            this.btnCapture = new DevExpress.XtraBars.BarButtonItem();
            this.btnSave = new DevExpress.XtraBars.BarButtonItem();
            this.btnCopy = new DevExpress.XtraBars.BarButtonItem();
            this.drpPenColor = new DevExpress.XtraBars.BarButtonItem();
            this.popupMenu2 = new DevExpress.XtraBars.PopupMenu(this.components);
            this.btnRedPen = new DevExpress.XtraBars.BarButtonItem();
            this.btnBluePen = new DevExpress.XtraBars.BarButtonItem();
            this.btnBlackPen = new DevExpress.XtraBars.BarButtonItem();
            this.btnHighlighter = new DevExpress.XtraBars.BarButtonItem();
            this.btnEraser = new DevExpress.XtraBars.BarButtonItem();
            this.btnEmail = new DevExpress.XtraBars.BarButtonItem();
            this.barTopMenu = new DevExpress.XtraBars.Bar();
            this.tolFile = new DevExpress.XtraBars.BarSubItem();
            this.tolSaveAs = new DevExpress.XtraBars.BarButtonItem();
            this.tolSend = new DevExpress.XtraBars.BarSubItem();
            this.tolSenEmail = new DevExpress.XtraBars.BarButtonItem();
            this.tolEnd = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem6 = new DevExpress.XtraBars.BarSubItem();
            this.tolCopy = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem7 = new DevExpress.XtraBars.BarSubItem();
            this.tolPen = new DevExpress.XtraBars.BarSubItem();
            this.tolRedPen = new DevExpress.XtraBars.BarButtonItem();
            this.tolBluePen = new DevExpress.XtraBars.BarButtonItem();
            this.tolBlackPen = new DevExpress.XtraBars.BarButtonItem();
            this.tolCustomPen = new DevExpress.XtraBars.BarButtonItem();
            this.tolHighlighter = new DevExpress.XtraBars.BarButtonItem();
            this.tolEraser = new DevExpress.XtraBars.BarButtonItem();
            this.bar3 = new DevExpress.XtraBars.Bar();
            this.barAndDockingController1 = new DevExpress.XtraBars.BarAndDockingController(this.components);
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.barEditItem1 = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.barSubItem1 = new DevExpress.XtraBars.BarSubItem();
            this.barSubItem2 = new DevExpress.XtraBars.BarSubItem();
            this.barListItem1 = new DevExpress.XtraBars.BarListItem();
            this.barLinkContainerItem1 = new DevExpress.XtraBars.BarLinkContainerItem();
            this.barLinkContainerItem2 = new DevExpress.XtraBars.BarLinkContainerItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barToolbarsListItem1 = new DevExpress.XtraBars.BarToolbarsListItem();
            this.barLinkContainerItem3 = new DevExpress.XtraBars.BarLinkContainerItem();
            this.barLinkContainerItem4 = new DevExpress.XtraBars.BarLinkContainerItem();
            this.barSubItem3 = new DevExpress.XtraBars.BarSubItem();
            this.barSubItem4 = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.barStaticItem1 = new DevExpress.XtraBars.BarStaticItem();
            this.barSubItem8 = new DevExpress.XtraBars.BarSubItem();
            this.barStaticItem2 = new DevExpress.XtraBars.BarStaticItem();
            this.barHeaderItem1 = new DevExpress.XtraBars.BarHeaderItem();
            this.barHeaderItem2 = new DevExpress.XtraBars.BarHeaderItem();
            this.barStaticItem3 = new DevExpress.XtraBars.BarStaticItem();
            this.barButtonItem4 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem6 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem20 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem21 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem22 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem23 = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem11 = new DevExpress.XtraBars.BarSubItem();
            this.barToolbarsListItem2 = new DevExpress.XtraBars.BarToolbarsListItem();
            this.barButtonItem24 = new DevExpress.XtraBars.BarButtonItem();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pnlDrawing = new HHI.NexFrame.Client.Controls.DrawingPanel();
            this.tolNewCapture = new DevExpress.XtraBars.BarButtonItem();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barAndDockingController1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pnlDrawing)).BeginInit();
            this.SuspendLayout();
            // 
            // popupMenu1
            // 
            this.popupMenu1.Manager = this.barManager;
            this.popupMenu1.Name = "popupMenu1";
            // 
            // barManager
            // 
            this.barManager.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.barToolBox,
            this.barTopMenu,
            this.bar3});
            this.barManager.Controller = this.barAndDockingController1;
            this.barManager.DockControls.Add(this.barDockControlTop);
            this.barManager.DockControls.Add(this.barDockControlBottom);
            this.barManager.DockControls.Add(this.barDockControlLeft);
            this.barManager.DockControls.Add(this.barDockControlRight);
            this.barManager.Form = this;
            this.barManager.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.barEditItem1,
            this.barSubItem1,
            this.barSubItem2,
            this.barListItem1,
            this.barLinkContainerItem1,
            this.barLinkContainerItem2,
            this.barToolbarsListItem1,
            this.barButtonItem1,
            this.barLinkContainerItem3,
            this.barLinkContainerItem4,
            this.barSubItem3,
            this.barSubItem4,
            this.tolFile,
            this.barSubItem6,
            this.barSubItem7,
            this.barButtonItem2,
            this.barButtonItem3,
            this.barStaticItem1,
            this.barSubItem8,
            this.barStaticItem2,
            this.barHeaderItem1,
            this.barHeaderItem2,
            this.barStaticItem3,
            this.barButtonItem4,
            this.barButtonItem5,
            this.barButtonItem6,
            this.tolSaveAs,
            this.tolSend,
            this.tolSenEmail,
            this.tolEnd,
            this.tolCopy,
            this.tolPen,
            this.tolHighlighter,
            this.tolEraser,
            this.tolRedPen,
            this.tolBluePen,
            this.tolBlackPen,
            this.tolCustomPen,
            this.btnSave,
            this.btnCopy,
            this.btnEmail,
            this.barButtonItem20,
            this.barButtonItem21,
            this.barButtonItem22,
            this.barButtonItem23,
            this.barSubItem11,
            this.barToolbarsListItem2,
            this.barButtonItem24,
            this.drpPenColor,
            this.btnRedPen,
            this.btnBluePen,
            this.btnBlackPen,
            this.btnHighlighter,
            this.btnEraser,
            this.btnCapture,
            this.tolNewCapture});
            this.barManager.MainMenu = this.barTopMenu;
            this.barManager.MaxItemId = 56;
            this.barManager.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTextEdit1});
            this.barManager.StatusBar = this.bar3;
            // 
            // barToolBox
            // 
            this.barToolBox.BarName = "Tools";
            this.barToolBox.DockCol = 0;
            this.barToolBox.DockRow = 1;
            this.barToolBox.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.barToolBox.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btnCapture),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnSave, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnCopy),
            new DevExpress.XtraBars.LinkPersistInfo(this.drpPenColor, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnHighlighter),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnEraser),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnEmail, true)});
            this.barToolBox.Text = "Tools";
            // 
            // btnCapture
            // 
            this.btnCapture.Caption = "New Capture";
            this.btnCapture.Glyph = global::HHI.NexFrame.Client.Controls.Properties.Resources.Capture;
            this.btnCapture.Id = 54;
            this.btnCapture.Name = "btnCapture";
            // 
            // btnSave
            // 
            this.btnSave.Caption = "저장";
            this.btnSave.Glyph = global::HHI.NexFrame.Client.Controls.Properties.Resources.save;
            this.btnSave.Id = 38;
            this.btnSave.Name = "btnSave";
            // 
            // btnCopy
            // 
            this.btnCopy.Caption = "복사";
            this.btnCopy.Glyph = global::HHI.NexFrame.Client.Controls.Properties.Resources.Copy;
            this.btnCopy.Id = 39;
            this.btnCopy.Name = "btnCopy";
            // 
            // drpPenColor
            // 
            this.drpPenColor.ActAsDropDown = true;
            this.drpPenColor.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.drpPenColor.Caption = "펜";
            this.drpPenColor.DropDownControl = this.popupMenu2;
            this.drpPenColor.Glyph = global::HHI.NexFrame.Client.Controls.Properties.Resources.Pen_Red;
            this.drpPenColor.Id = 48;
            this.drpPenColor.Name = "drpPenColor";
            // 
            // popupMenu2
            // 
            this.popupMenu2.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btnRedPen),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnBluePen),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnBlackPen)});
            this.popupMenu2.Manager = this.barManager;
            this.popupMenu2.Name = "popupMenu2";
            // 
            // btnRedPen
            // 
            this.btnRedPen.Caption = "빨간 펜(&R)";
            this.btnRedPen.Id = 49;
            this.btnRedPen.Name = "btnRedPen";
            // 
            // btnBluePen
            // 
            this.btnBluePen.Caption = "파란 펜(&B)";
            this.btnBluePen.Id = 50;
            this.btnBluePen.Name = "btnBluePen";
            // 
            // btnBlackPen
            // 
            this.btnBlackPen.Caption = "검은 펜(&L)";
            this.btnBlackPen.Id = 51;
            this.btnBlackPen.Name = "btnBlackPen";
            // 
            // btnHighlighter
            // 
            this.btnHighlighter.Caption = "형광펜";
            this.btnHighlighter.Glyph = ((System.Drawing.Image)(resources.GetObject("btnHighlighter.Glyph")));
            this.btnHighlighter.Id = 52;
            this.btnHighlighter.Name = "btnHighlighter";
            // 
            // btnEraser
            // 
            this.btnEraser.Caption = "지우개";
            this.btnEraser.Glyph = global::HHI.NexFrame.Client.Controls.Properties.Resources.Eraser;
            this.btnEraser.Id = 53;
            this.btnEraser.Name = "btnEraser";
            // 
            // btnEmail
            // 
            this.btnEmail.Caption = "메일";
            this.btnEmail.Glyph = global::HHI.NexFrame.Client.Controls.Properties.Resources.Email;
            this.btnEmail.Id = 40;
            this.btnEmail.Name = "btnEmail";
            // 
            // barTopMenu
            // 
            this.barTopMenu.BarName = "Main menu";
            this.barTopMenu.DockCol = 0;
            this.barTopMenu.DockRow = 0;
            this.barTopMenu.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.barTopMenu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.tolFile),
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem6),
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem7)});
            this.barTopMenu.OptionsBar.MultiLine = true;
            this.barTopMenu.OptionsBar.UseWholeRow = true;
            this.barTopMenu.Text = "Main menu";
            // 
            // tolFile
            // 
            this.tolFile.Caption = "파일(&F)";
            this.tolFile.Id = 12;
            this.tolFile.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.tolNewCapture),
            new DevExpress.XtraBars.LinkPersistInfo(this.tolSaveAs),
            new DevExpress.XtraBars.LinkPersistInfo(this.tolSend),
            new DevExpress.XtraBars.LinkPersistInfo(this.tolEnd)});
            this.tolFile.Name = "tolFile";
            this.tolFile.ShowItemShortcut = DevExpress.Utils.DefaultBoolean.True;
            // 
            // tolSaveAs
            // 
            this.tolSaveAs.Caption = "저장";
            this.tolSaveAs.Id = 26;
            this.tolSaveAs.Name = "tolSaveAs";
            this.tolSaveAs.ShortcutKeyDisplayString = "Ctrl+S";
            this.tolSaveAs.ShowItemShortcut = DevExpress.Utils.DefaultBoolean.True;
            // 
            // tolSend
            // 
            this.tolSend.Caption = "보내기(&T)";
            this.tolSend.Id = 27;
            this.tolSend.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.tolSenEmail)});
            this.tolSend.Name = "tolSend";
            this.tolSend.ShowItemShortcut = DevExpress.Utils.DefaultBoolean.False;
            // 
            // tolSenEmail
            // 
            this.tolSenEmail.Caption = "전자 메일 수신자";
            this.tolSenEmail.Id = 28;
            this.tolSenEmail.Name = "tolSenEmail";
            // 
            // tolEnd
            // 
            this.tolEnd.Caption = "끝내기(&X)";
            this.tolEnd.Id = 29;
            this.tolEnd.Name = "tolEnd";
            this.tolEnd.ShowItemShortcut = DevExpress.Utils.DefaultBoolean.False;
            // 
            // barSubItem6
            // 
            this.barSubItem6.Caption = "편집(&E)";
            this.barSubItem6.Id = 13;
            this.barSubItem6.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.tolCopy)});
            this.barSubItem6.Name = "barSubItem6";
            // 
            // tolCopy
            // 
            this.tolCopy.Caption = "복사";
            this.tolCopy.Id = 30;
            this.tolCopy.Name = "tolCopy";
            this.tolCopy.ShortcutKeyDisplayString = "Ctrl+C";
            this.tolCopy.ShowItemShortcut = DevExpress.Utils.DefaultBoolean.True;
            // 
            // barSubItem7
            // 
            this.barSubItem7.Caption = "도구(&T)";
            this.barSubItem7.Id = 14;
            this.barSubItem7.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.tolPen),
            new DevExpress.XtraBars.LinkPersistInfo(this.tolHighlighter),
            new DevExpress.XtraBars.LinkPersistInfo(this.tolEraser)});
            this.barSubItem7.Name = "barSubItem7";
            // 
            // tolPen
            // 
            this.tolPen.Caption = "펜(&P)";
            this.tolPen.Id = 31;
            this.tolPen.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.tolRedPen),
            new DevExpress.XtraBars.LinkPersistInfo(this.tolBluePen),
            new DevExpress.XtraBars.LinkPersistInfo(this.tolBlackPen),
            new DevExpress.XtraBars.LinkPersistInfo(this.tolCustomPen)});
            this.tolPen.Name = "tolPen";
            // 
            // tolRedPen
            // 
            this.tolRedPen.Caption = "빨간 펜(&R)";
            this.tolRedPen.Id = 34;
            this.tolRedPen.Name = "tolRedPen";
            this.tolRedPen.ShortcutKeyDisplayString = "Ctrl+R";
            this.tolRedPen.ShowItemShortcut = DevExpress.Utils.DefaultBoolean.True;
            // 
            // tolBluePen
            // 
            this.tolBluePen.Caption = "파란 펜(&B)";
            this.tolBluePen.Id = 35;
            this.tolBluePen.Name = "tolBluePen";
            this.tolBluePen.ShortcutKeyDisplayString = "Ctrl+B";
            this.tolBluePen.ShowItemShortcut = DevExpress.Utils.DefaultBoolean.True;
            // 
            // tolBlackPen
            // 
            this.tolBlackPen.Caption = "검은 펜(&L)";
            this.tolBlackPen.Id = 36;
            this.tolBlackPen.Name = "tolBlackPen";
            this.tolBlackPen.ShortcutKeyDisplayString = "Ctrl+L";
            this.tolBlackPen.ShowItemShortcut = DevExpress.Utils.DefaultBoolean.True;
            // 
            // tolCustomPen
            // 
            this.tolCustomPen.Caption = "사용자 지정 펜..(&C)";
            this.tolCustomPen.Id = 37;
            this.tolCustomPen.Name = "tolCustomPen";
            this.tolCustomPen.ShortcutKeyDisplayString = "Ctrl+C";
            this.tolCustomPen.ShowItemShortcut = DevExpress.Utils.DefaultBoolean.True;
            // 
            // tolHighlighter
            // 
            this.tolHighlighter.Caption = "형광펜(&H)";
            this.tolHighlighter.Id = 32;
            this.tolHighlighter.Name = "tolHighlighter";
            // 
            // tolEraser
            // 
            this.tolEraser.Caption = "지우개";
            this.tolEraser.Id = 33;
            this.tolEraser.Name = "tolEraser";
            // 
            // bar3
            // 
            this.bar3.BarName = "Status bar";
            this.bar3.CanDockStyle = DevExpress.XtraBars.BarCanDockStyle.Bottom;
            this.bar3.DockCol = 0;
            this.bar3.DockRow = 0;
            this.bar3.DockStyle = DevExpress.XtraBars.BarDockStyle.Bottom;
            this.bar3.OptionsBar.AllowQuickCustomization = false;
            this.bar3.OptionsBar.DrawDragBorder = false;
            this.bar3.OptionsBar.UseWholeRow = true;
            this.bar3.Text = "Status bar";
            // 
            // barAndDockingController1
            // 
            this.barAndDockingController1.PropertiesBar.DefaultGlyphSize = new System.Drawing.Size(16, 16);
            this.barAndDockingController1.PropertiesBar.DefaultLargeGlyphSize = new System.Drawing.Size(32, 32);
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(1, 1);
            this.barDockControlTop.Size = new System.Drawing.Size(922, 69);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(1, 749);
            this.barDockControlBottom.Size = new System.Drawing.Size(922, 17);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(1, 70);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 679);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(923, 70);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 679);
            // 
            // barEditItem1
            // 
            this.barEditItem1.Caption = "파일";
            this.barEditItem1.Edit = this.repositoryItemTextEdit1;
            this.barEditItem1.Id = 0;
            this.barEditItem1.Name = "barEditItem1";
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AutoHeight = false;
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // barSubItem1
            // 
            this.barSubItem1.Caption = "파일";
            this.barSubItem1.Id = 1;
            this.barSubItem1.Name = "barSubItem1";
            // 
            // barSubItem2
            // 
            this.barSubItem2.Caption = "편집";
            this.barSubItem2.Id = 2;
            this.barSubItem2.Name = "barSubItem2";
            // 
            // barListItem1
            // 
            this.barListItem1.Caption = "도구";
            this.barListItem1.Id = 3;
            this.barListItem1.Name = "barListItem1";
            // 
            // barLinkContainerItem1
            // 
            this.barLinkContainerItem1.Caption = "22";
            this.barLinkContainerItem1.Id = 4;
            this.barLinkContainerItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barLinkContainerItem2),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem1)});
            this.barLinkContainerItem1.Name = "barLinkContainerItem1";
            // 
            // barLinkContainerItem2
            // 
            this.barLinkContainerItem2.Caption = "barLinkContainerItem2";
            this.barLinkContainerItem2.Id = 5;
            this.barLinkContainerItem2.Name = "barLinkContainerItem2";
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "barButtonItem1";
            this.barButtonItem1.Id = 7;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // barToolbarsListItem1
            // 
            this.barToolbarsListItem1.Caption = "barToolbarsListItem1";
            this.barToolbarsListItem1.Id = 6;
            this.barToolbarsListItem1.Name = "barToolbarsListItem1";
            // 
            // barLinkContainerItem3
            // 
            this.barLinkContainerItem3.Caption = "barLinkContainerItem3";
            this.barLinkContainerItem3.Id = 8;
            this.barLinkContainerItem3.Name = "barLinkContainerItem3";
            // 
            // barLinkContainerItem4
            // 
            this.barLinkContainerItem4.Id = 9;
            this.barLinkContainerItem4.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem3)});
            this.barLinkContainerItem4.Name = "barLinkContainerItem4";
            // 
            // barSubItem3
            // 
            this.barSubItem3.Caption = "저장";
            this.barSubItem3.Id = 10;
            this.barSubItem3.Name = "barSubItem3";
            // 
            // barSubItem4
            // 
            this.barSubItem4.Caption = "barSubItem4";
            this.barSubItem4.Id = 11;
            this.barSubItem4.Name = "barSubItem4";
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "barButtonItem2";
            this.barButtonItem2.Glyph = global::HHI.NexFrame.Client.Controls.Properties.Resources.save;
            this.barButtonItem2.Id = 15;
            this.barButtonItem2.LargeGlyph = global::HHI.NexFrame.Client.Controls.Properties.Resources.save;
            this.barButtonItem2.Name = "barButtonItem2";
            this.barButtonItem2.Size = new System.Drawing.Size(32, 32);
            // 
            // barButtonItem3
            // 
            this.barButtonItem3.Caption = "barButtonItem3";
            this.barButtonItem3.Glyph = global::HHI.NexFrame.Client.Controls.Properties.Resources.Copy;
            this.barButtonItem3.Id = 16;
            this.barButtonItem3.Name = "barButtonItem3";
            this.barButtonItem3.Size = new System.Drawing.Size(32, 32);
            // 
            // barStaticItem1
            // 
            this.barStaticItem1.Caption = "저장";
            this.barStaticItem1.Id = 17;
            this.barStaticItem1.Name = "barStaticItem1";
            this.barStaticItem1.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // barSubItem8
            // 
            this.barSubItem8.Caption = "보내기";
            this.barSubItem8.Id = 18;
            this.barSubItem8.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barStaticItem2)});
            this.barSubItem8.Name = "barSubItem8";
            // 
            // barStaticItem2
            // 
            this.barStaticItem2.Caption = "전자 메일 수신자";
            this.barStaticItem2.Id = 19;
            this.barStaticItem2.Name = "barStaticItem2";
            this.barStaticItem2.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // barHeaderItem1
            // 
            this.barHeaderItem1.Caption = "끝내기";
            this.barHeaderItem1.Id = 20;
            this.barHeaderItem1.Name = "barHeaderItem1";
            // 
            // barHeaderItem2
            // 
            this.barHeaderItem2.Caption = "끝내기";
            this.barHeaderItem2.Id = 21;
            this.barHeaderItem2.Name = "barHeaderItem2";
            // 
            // barStaticItem3
            // 
            this.barStaticItem3.Caption = "끝내기";
            this.barStaticItem3.Id = 22;
            this.barStaticItem3.Name = "barStaticItem3";
            this.barStaticItem3.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // barButtonItem4
            // 
            this.barButtonItem4.Caption = "barButtonItem4";
            this.barButtonItem4.Id = 23;
            this.barButtonItem4.Name = "barButtonItem4";
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Caption = "barButtonItem5";
            this.barButtonItem5.Id = 24;
            this.barButtonItem5.Name = "barButtonItem5";
            // 
            // barButtonItem6
            // 
            this.barButtonItem6.Id = 25;
            this.barButtonItem6.Name = "barButtonItem6";
            // 
            // barButtonItem20
            // 
            this.barButtonItem20.Caption = "barButtonItem20";
            this.barButtonItem20.Id = 41;
            this.barButtonItem20.Name = "barButtonItem20";
            // 
            // barButtonItem21
            // 
            this.barButtonItem21.Caption = "barButtonItem21";
            this.barButtonItem21.Id = 42;
            this.barButtonItem21.Name = "barButtonItem21";
            // 
            // barButtonItem22
            // 
            this.barButtonItem22.Caption = "barButtonItem22";
            this.barButtonItem22.Id = 43;
            this.barButtonItem22.Name = "barButtonItem22";
            // 
            // barButtonItem23
            // 
            this.barButtonItem23.Caption = "barButtonItem23";
            this.barButtonItem23.Id = 44;
            this.barButtonItem23.Name = "barButtonItem23";
            // 
            // barSubItem11
            // 
            this.barSubItem11.Caption = "barSubItem11";
            this.barSubItem11.Id = 45;
            this.barSubItem11.Name = "barSubItem11";
            // 
            // barToolbarsListItem2
            // 
            this.barToolbarsListItem2.Caption = "barToolbarsListItem2";
            this.barToolbarsListItem2.Id = 46;
            this.barToolbarsListItem2.Name = "barToolbarsListItem2";
            // 
            // barButtonItem24
            // 
            this.barButtonItem24.ActAsDropDown = true;
            this.barButtonItem24.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.barButtonItem24.Caption = "barButtonItem24";
            this.barButtonItem24.Id = 47;
            this.barButtonItem24.Name = "barButtonItem24";
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(1, 70);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(922, 5);
            this.panel2.TabIndex = 14;
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.AutoScrollMinSize = new System.Drawing.Size(10, 10);
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.pnlDrawing);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(1, 75);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(922, 674);
            this.panel3.TabIndex = 15;
            // 
            // pnlDrawing
            // 
            this.pnlDrawing.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pnlDrawing.DrawingMode = HHI.NexFrame.Client.Controls.DrawingMode.Pen;
            this.pnlDrawing.Location = new System.Drawing.Point(0, 0);
            this.pnlDrawing.Name = "pnlDrawing";
            this.pnlDrawing.PenColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pnlDrawing.PenWidth = 5F;
            this.pnlDrawing.Size = new System.Drawing.Size(924, 682);
            this.pnlDrawing.TabIndex = 0;
            this.pnlDrawing.TabStop = false;
            // 
            // tolNewCapture
            // 
            this.tolNewCapture.Caption = "새 캡쳐";
            this.tolNewCapture.Id = 55;
            this.tolNewCapture.Name = "tolNewCapture";
            this.tolNewCapture.ShortcutKeyDisplayString = "Ctrl+N";
            this.tolNewCapture.ShowItemShortcut = DevExpress.Utils.DefaultBoolean.True;
            // 
            // NexImageEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(924, 767);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Name = "NexImageEditForm";
            this.Padding = new System.Windows.Forms.Padding(1);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "캡처 도구";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.NexImageEditForm_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barAndDockingController1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pnlDrawing)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.PopupMenu popupMenu1;
        private System.Windows.Forms.Panel panel3;
        private DrawingPanel pnlDrawing;
        private System.Windows.Forms.Panel panel2;
        private DevExpress.XtraBars.BarManager barManager;
        private DevExpress.XtraBars.Bar barToolBox;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
        private DevExpress.XtraBars.Bar barTopMenu;
        private DevExpress.XtraBars.BarSubItem tolFile;
        private DevExpress.XtraBars.BarSubItem barSubItem6;
        private DevExpress.XtraBars.BarSubItem barSubItem7;
        private DevExpress.XtraBars.Bar bar3;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.BarEditItem barEditItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraBars.BarSubItem barSubItem1;
        private DevExpress.XtraBars.BarSubItem barSubItem2;
        private DevExpress.XtraBars.BarListItem barListItem1;
        private DevExpress.XtraBars.BarLinkContainerItem barLinkContainerItem1;
        private DevExpress.XtraBars.BarLinkContainerItem barLinkContainerItem2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarToolbarsListItem barToolbarsListItem1;
        private DevExpress.XtraBars.BarLinkContainerItem barLinkContainerItem3;
        private DevExpress.XtraBars.BarLinkContainerItem barLinkContainerItem4;
        private DevExpress.XtraBars.BarSubItem barSubItem3;
        private DevExpress.XtraBars.BarSubItem barSubItem4;
        private DevExpress.XtraBars.BarStaticItem barStaticItem1;
        private DevExpress.XtraBars.BarSubItem barSubItem8;
        private DevExpress.XtraBars.BarStaticItem barStaticItem2;
        private DevExpress.XtraBars.BarStaticItem barStaticItem3;
        private DevExpress.XtraBars.BarHeaderItem barHeaderItem1;
        private DevExpress.XtraBars.BarHeaderItem barHeaderItem2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem4;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraBars.BarButtonItem btnSave;
        private DevExpress.XtraBars.BarButtonItem btnCopy;
        private DevExpress.XtraBars.BarButtonItem btnEmail;
        private DevExpress.XtraBars.BarButtonItem drpPenColor;
        private DevExpress.XtraBars.PopupMenu popupMenu2;
        private DevExpress.XtraBars.BarButtonItem btnRedPen;
        private DevExpress.XtraBars.BarButtonItem btnBluePen;
        private DevExpress.XtraBars.BarButtonItem btnBlackPen;
        private DevExpress.XtraBars.BarButtonItem btnHighlighter;
        private DevExpress.XtraBars.BarButtonItem btnEraser;
        private DevExpress.XtraBars.BarButtonItem tolSaveAs;
        private DevExpress.XtraBars.BarSubItem tolSend;
        private DevExpress.XtraBars.BarButtonItem tolSenEmail;
        private DevExpress.XtraBars.BarButtonItem tolEnd;
        private DevExpress.XtraBars.BarButtonItem tolCopy;
        private DevExpress.XtraBars.BarSubItem tolPen;
        private DevExpress.XtraBars.BarButtonItem tolRedPen;
        private DevExpress.XtraBars.BarButtonItem tolBluePen;
        private DevExpress.XtraBars.BarButtonItem tolBlackPen;
        private DevExpress.XtraBars.BarButtonItem tolCustomPen;
        private DevExpress.XtraBars.BarButtonItem tolHighlighter;
        private DevExpress.XtraBars.BarButtonItem tolEraser;
        private DevExpress.XtraBars.BarButtonItem barButtonItem6;
        private DevExpress.XtraBars.BarButtonItem barButtonItem20;
        private DevExpress.XtraBars.BarButtonItem barButtonItem21;
        private DevExpress.XtraBars.BarButtonItem barButtonItem22;
        private DevExpress.XtraBars.BarButtonItem barButtonItem23;
        private DevExpress.XtraBars.BarSubItem barSubItem11;
        private DevExpress.XtraBars.BarToolbarsListItem barToolbarsListItem2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem24;
        private DevExpress.XtraBars.BarAndDockingController barAndDockingController1;
        private DevExpress.XtraBars.BarButtonItem btnCapture;
        private DevExpress.XtraBars.BarButtonItem tolNewCapture;
    }
}