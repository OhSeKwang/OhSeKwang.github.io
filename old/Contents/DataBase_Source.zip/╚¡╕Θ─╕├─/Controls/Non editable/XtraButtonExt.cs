﻿using DevExpress.XtraEditors;
using System;
using System.ComponentModel;

namespace HHI.NexFrame.Client.Controls
{
    [DefaultProperty("ButtonAuthority")]
    public class XtraButtonExt : SimpleButton
    {
        public XtraButtonExt()
        {
            _UseSplasher = false;
        }

        bool _IsExecuteWdworkerLog = true;

        /// <summary>
        /// 버튼을 클릭시 스플래시를 사용할 지 여부를 지정
        /// </summary>
        [Category("_Framework")]
        [DescriptionAttribute("버튼 클릭시 우드워커에 로그를 남길지 여부를 지정")]
        public bool IsExecuteWdworkerLog
        {
            get { return _IsExecuteWdworkerLog; }
            set { _IsExecuteWdworkerLog = value; }
        }

        private bool _UseSplasher;

        /// <summary>
        /// 버튼을 클릭시 스플래시를 사용할 지 여부를 지정
        /// </summary>
        [Category("_Framework")]
        [DescriptionAttribute("버튼을 클릭시 스플래시를 사용할 지 여부를 지정")]
        public bool UseSplasher
        {
            get { return _UseSplasher; }
            set { _UseSplasher = value; }
        }

        protected override void OnClick(EventArgs e)
        {
            /*
             * 우드워커 버튼실행 로그관련....처리코드....
             */

            base.OnClick(e);
        }
    }
}