﻿using DevExpress.XtraEditors;
using HHI.NexFrame.Client.Controls;
using HHI.NexFrame.Client.Controls.Enums;
using HHI.NexFrame.Client.UI.Interface;
using System.ComponentModel;
using System.Drawing;

namespace HHI.NexFrame.Client.Controls
{
    public class XtraLabelExt : LabelControl, IStdValidationControl
    {
        private string _Key = string.Empty;

        /// <summary>
        /// 쿼리 파라미터 맵핑될명을 지정합니다
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("쿼리 파라미터 맵핑될명을 지정합니다")]
        public string Key
        {
            get { return _Key; }
            set { _Key = value; }
        }

        private bool _IsTransparent;

        /// <summary>
        /// background 투명여부를 지정합니다
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("background 투명여부를 지정합니다")]
        public bool IsTransparent
        {
            get { return _IsTransparent; }
            set
            {
                this._IsTransparent = value;
                if (value)
                {
                    this.BackColor = Color.Transparent;
                    this.BringToFront();
                }
            }
        }
        #region IStdValidationControl 인터페이스 구현

        /// <summary>
        /// 컨트롤에 에러 메시지를 설정하고, 포커스 지정
        /// </summary>
        /// <param name="message"></param>
        public void CtrlShowErrorMessage(string message)
        {
            this.Focus();
        }

        private int _MinLength = 0;

        /// <summary>
        /// Control의 최소 자리수를 가져오거나/설정한다.
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("Control의 최소 자리수를 가져오거나/설정한다.")]
        public int MinLength
        {
            get { return _MinLength; }
            set { _MinLength = value; }
        }


        public bool RequiredValidation(bool isTrim)
        {
            return this.SetExRequiredValidation(isTrim);
        }

        public bool MinLengthValidation()
        {
            return this.SetExMinLengthValidation(this.MinLength);
        }

        #endregion
    }
}
