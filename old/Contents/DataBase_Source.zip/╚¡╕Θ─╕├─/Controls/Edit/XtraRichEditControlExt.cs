﻿using DevExpress.Office.Services;
using DevExpress.Office.Utils;
using DevExpress.XtraPrinting;
using DevExpress.XtraRichEdit;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using HHI.NexFrame.Client.Controls;
using HHI.NexFrame.Client.Controls.Enums;
using HHI.NexFrame.Client.UI.Interface;
using System;
using System.ComponentModel;
using System.Drawing.Printing;
using System.IO;
using DevExpress.XtraRichEdit.API.Native;

namespace HHI.NexFrame.Client.Controls
{
    public class XtraRichEditControlExt : RichEditControl, IStdValidationControl, IStdTextEditDataMappingControl
    {
        public XtraRichEditControlExt()
            : base()
        {
            OutputFormat = RichEditOutputFormat.Html;
            this.DocumentLoaded += new EventHandler(XtraRichEditControlExt_DocumentLoaded);
        }

        void XtraRichEditControlExt_DocumentLoaded(object sender, EventArgs e)
        {
            IUriProviderService service = this.GetService<IUriProviderService>();
            if (service != null)
            {
                service.RegisterProvider(new CustomUriProvider());
            }
        }

        /// <summary>
        /// RTF파일형식[Byte Array]으로 문서를 로드한다
        /// </summary>
        /// <param name="rtfDocSource"></param>
        public void LoadRtfDocument(byte[] rtfDocSource)
        {
            using (MemoryStream ms = new MemoryStream(rtfDocSource))
            {
                this.LoadDocument(ms, DocumentFormat.Rtf);
            }
        }

        /// <summary>
        /// 지정한 파일형식[Byte Array]으로 문서를 로드한다
        /// </summary>
        /// <param name="docSource"></param>
        /// <param name="docFormat"></param>
        public void LoadDocument(byte[] docSource, DocumentFormat docFormat)
        {
            using (MemoryStream ms = new MemoryStream(docSource))
            {
                this.LoadDocument(ms, docFormat);
            }
        }

        /// <summary>
        /// RTF파일형식[로컬경로]으로 문서를 로드한다
        /// </summary>
        /// <param name="localPath"></param>
        public void LoadRtfDocument(string localPath)
        {
            using (StreamReader sr = new StreamReader(localPath))
            {
                byte[] rtfDoc = new byte[sr.BaseStream.Length];
                sr.BaseStream.Read(rtfDoc, 0, rtfDoc.Length);

                this.LoadRtfDocument(rtfDoc);
            }
        }

        /// <summary>
        /// 문서 전체에 기본폰트로 리셋한다
        /// </summary>
        public void ResetDefaultFont()
        {
            CharacterProperties prop = this.Document.BeginUpdateCharacters(this.Document.Range);

            prop.FontName = "Tahoma";
            prop.FontSize = 9;

            this.Document.EndUpdateCharacters(prop);
        }

        /// <summary>
        /// 지정한 폰트 및 사이즈로 문서 전체에 기본폰트로 재설정한다
        /// </summary>
        /// <param name="fontName">폰트명</param>
        /// <param name="fontSize">폰트사이즈</param>
        public void ResetDefaultFont(string fontName, float fontSize)
        {
            CharacterProperties prop = this.Document.BeginUpdateCharacters(this.Document.Range);

            prop.FontName = fontName;
            prop.FontSize = fontSize;

            this.Document.EndUpdateCharacters(prop);
        }

        /// <summary>
        /// 기본 A4용지 사이즈로 출력을 한다.
        /// </summary>
        public new void ShowPrintPreview()
        {
            // Create a PrintingSystem component.
            PrintingSystem ps = new PrintingSystem();

            // Create a link that will print a control.
            PrintableComponentLink link = new PrintableComponentLink(ps);


            // Specify the control to be printed.
            link.Component = this;

            link.PaperKind = PaperKind.A4;
            link.Landscape = true;

            //// Subscribe to the CreateReportHeaderArea event used to generate the report header.
            //link.CreateReportHeaderArea += new CreateAreaEventHandler(CreateReportHeaderArea);

            // Generate the report.
            link.CreateDocument();
            // Show the report.
            link.ShowPreview();
        }

        //protected void CreateReportHeaderArea(object sender, CreateAreaEventArgs e)
        //{
        //    string reportHeader = ReportHeaderTitle;
        //    e.Graph.StringFormat = new BrickStringFormat(StringAlignment.Center);
        //    e.Graph.Font = new Font(this.Font.Name, 14, FontStyle.Bold);
        //    RectangleF rec = new RectangleF(0, 0, e.Graph.ClientPageSize.Width, 50);
        //    e.Graph.DrawString(reportHeader, Color.Black, rec, DevExpress.XtraPrinting.BorderSide.None);
        //}


        /// <summary>
        /// 파라미터 추출하는 메소드에서 사용할 포맷을 설정한다
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("파라미터 추출하는 메소드에서 사용할 포맷을 설정한다")]
        public RichEditOutputFormat OutputFormat
        {
            get;
            set;
        }

        #region IStdValidationControl 인터페이스 구현

        /// <summary>
        /// 컨트롤에 에러 메시지를 설정하고, 포커스 지정
        /// </summary>
        /// <param name="message"></param>
        public void CtrlShowErrorMessage(string message)
        {
            this.Focus();
        }

        private int _MinLength = 0;

        /// <summary>
        /// Control의 최소 자리수를 가져오거나/설정한다.
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("Control의 최소 자리수를 가져오거나/설정한다.")]
        public int MinLength
        {
            get { return _MinLength; }
            set { _MinLength = value; }
        }


        public bool RequiredValidation(bool isTrim)
        {
            return this.SetExRequiredValidation(isTrim);
        }

        public bool MinLengthValidation()
        {
            return this.SetExMinLengthValidation(this.MinLength);
        }

        #endregion

        #region IStdDataMappingControl 인터페이스 구현

        string _Key = string.Empty;

        /// <summary>
        /// 해당 컨트롤에 대한 DB Mapping Name을 설정하거나,가져온다
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("해당 컨트롤에 대한 DB Mapping Name을 설정하거나,가져온다")]
        public string Key
        {
            get { return _Key; }
            set { _Key = value; }
        }

        /// <summary>
        /// 지정한 값을 해당 컨트롤에 바인딩한다
        /// </summary>
        /// <param name="data"></param>
        public void DataBindControl(object data)
        {
            this.Text = (data != null ? data.ToString() : string.Empty);
        }

        /// <summary>
        /// 컨트롤내의 값을 가져온다
        /// </summary>
        /// <returns></returns>
        public object GetControlValue()
        {
            if (IsValueTrim)
                return (OutputFormat == RichEditOutputFormat.Text ? this.Text.Trim() : this.HtmlText.Trim());
            else
                return (OutputFormat == RichEditOutputFormat.Text ? this.Text : this.HtmlText);
        }

        bool _IsValueTrim = true;

        /// <summary>
        /// 해당 컨트롤내의 값을 가져오거나, 설정시 Trim처리할지 여부를 설정한다.
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("해당 컨트롤내의 값을 가져오거나, 설정시 Trim처리할지 여부를 설정한다.")]
        public bool IsValueTrim
        {
            get { return _IsValueTrim; }
            set { _IsValueTrim = value; }
        }
        
        #endregion
    }

    /// <summary>
    /// RichEdit Output Format을 지정한다
    /// </summary>
    public enum RichEditOutputFormat
    {
        Text = 0,
        Html = 1
    }

    public class CustomUriProvider : IUriProvider
    {
        #region IUriProvider Members
        public string CreateCssUri(string rootUri, string styleText, string relativeUri)
        {
            return String.Empty;
        }

        public string CreateImageUri(string rootUri, OfficeImage image, string relativeUri)
        {
            return image.Uri;
        }
        #endregion
    }

}
