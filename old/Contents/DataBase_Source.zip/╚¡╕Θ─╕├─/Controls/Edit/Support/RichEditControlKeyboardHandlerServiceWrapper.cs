﻿using DevExpress.Services;
using DevExpress.XtraRichEdit;
using DevExpress.XtraRichEdit.API.Native;
using DevExpress.XtraRichEdit.Services;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using HHI.NexFrame.Client.Controls;
using HHI.NexFrame.Client.Controls.Enums;
using HHI.NexFrame.Client.UI.Interface;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace HHI.NexFrame.Client.Controls
{
    public class RichEditControlKeyboardHandlerServiceWrapper : KeyboardHandlerServiceWrapper
    {
        public RichEditControlKeyboardHandlerServiceWrapper(IKeyboardHandlerService service)
            : base(service) { }

        public override void OnKeyDown(KeyEventArgs e)
        {
            //if (((e.KeyCode == Keys.C) || (e.KeyCode == Keys.X) ||
            //    (e.KeyCode == Keys.Insert)) && e.Control)
            //{
            //    return;
            //}
            base.OnKeyDown(e);
        }
    }
}
