﻿using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using HHI.NexFrame.Client.Controls;
using HHI.NexFrame.Client.Controls.Enums;
using HHI.NexFrame.Client.UI.Interface;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;


namespace HHI.NexFrame.Client.Controls
{
    public partial class XtraMRUEditExt : MRUEdit, IStdValidationControl, IStdTextEditDataMappingControl, IStdAutoFireEnterEvtControl
    {
        protected override void OnLoaded()
        {
            base.OnLoaded();

            this.Properties.Mask.UseMaskAsDisplayFormat = true;
            if (!ControlCommon.DesignMode)
            {
                this.Padding = new System.Windows.Forms.Padding(20, 0, 10, 0);
            }
        }

        public override string Text
        {
            get
            {
                if (this.EditValue == null)
                    return string.Empty;
                else
                {
                    return this.EditValue.ToString();
                }
            }
        }

        public TextEditTextFormatType _TextFormat = TextEditTextFormatType.None;





        /// <summary>
        /// 포커스시 BackColor를 지정합니다
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("포커스시 BackColor를 지정합니다")]
        [Browsable(false)]
        public Color FocusColor
        {
            get;
            set;
        }

        private EditColorSkinType _ColorSkin = EditColorSkinType.Normal;

        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("ColorSkin을 지정합니다")]
        public EditColorSkinType ColorSkin
        {
            get { return _ColorSkin; }
            set
            {
                _ColorSkin = value;
                this.SetFocusLeaveColorSkin(this.ColorSkin);
            }
        }

        protected override void OnLeave(EventArgs e)
        {
            this.SetFocusLeaveColorSkin(this.ColorSkin);

            base.OnLeave(e);
        }

        protected override void OnEnter(EventArgs e)
        {
            this.SetFocusEnterColorSkin(this.ColorSkin);

            base.OnEnter(e);
        }

        /// <summary>
        /// 컨트롤에 에러 메시지를 설정하고, 포커스 지정
        /// </summary>
        /// <param name="message"></param>
        public void CtrlShowErrorMessage(string message)
        {
            this.ErrorText = message;
            this.Focus();
        }

        #region IStdValidationControl 인터페이스 구현

        private int _MinLength = 0;

        /// <summary>
        /// Control의 최소 자리수를 가져오거나/설정한다.
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("Control의 최소 자리수를 가져오거나/설정한다.")]
        public int MinLength
        {
            get { return _MinLength; }
            set { _MinLength = value; }
        }

        public bool RequiredValidation(bool isTrim)
        {
            return this.SetExRequiredValidation(isTrim);
        }

        public bool MinLengthValidation()
        {
            return this.SetExMinLengthValidation(this.MinLength);
        }

        #endregion

        #region IStdDataMappingControl 인터페이스 구현

        string _Key = string.Empty;

        /// <summary>
        /// 해당 컨트롤에 대한 DB Mapping Name을 설정하거나,가져온다
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("해당 컨트롤에 대한 DB Mapping Name을 설정하거나,가져온다")]
        public string Key
        {
            get { return _Key; }
            set { _Key = value; }
        }

        /// <summary>
        /// 지정한 값을 해당 컨트롤에 바인딩한다
        /// </summary>
        /// <param name="data"></param>
        public void DataBindControl(object data)
        {
            this.Text = (data != null ? data.ToString() : string.Empty);
        }

        /// <summary>
        /// 컨트롤내의 값을 가져온다
        /// </summary>
        /// <returns></returns>
        public object GetControlValue()
        {
            if (IsValueTrim)
                return this.Text.Trim();
            else
                return this.Text;
        }

        bool _IsValueTrim = true;

        /// <summary>
        /// 해당 컨트롤내의 값을 가져오거나, 설정시 Trim처리할지 여부를 설정한다.
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("해당 컨트롤내의 값을 가져오거나, 설정시 Trim처리할지 여부를 설정한다.")]
        public bool IsValueTrim
        {
            get { return _IsValueTrim; }
            set { _IsValueTrim = value; }
        }

        #endregion

        /// <summary>
        /// 엔터시 실행할 버튼 리스트를 가져오거나,설정한다
        /// </summary>
        
        public IButtonControl[] EnterExecuteButton
        {
            get;
            set;
        }
    }
}
