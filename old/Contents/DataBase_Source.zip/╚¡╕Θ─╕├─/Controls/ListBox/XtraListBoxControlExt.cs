﻿using DevExpress.XtraEditors;
using HHI.NexFrame.Client.Controls;
using HHI.NexFrame.Client.Controls.Enums;
using HHI.NexFrame.Client.UI.Interface;
using System.ComponentModel;
using System.Windows.Forms;

namespace HHI.NexFrame.Client.Controls
{
    public class XtraListBoxControlExt : ListBoxControl, IStdValidationControl, IStdAutoFireEnterEvtControl
    {
        private string _Key = string.Empty;

        /// <summary>
        /// 쿼리 파라미터 맵핑될명을 지정합니다
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("쿼리 파라미터 맵핑될명을 지정합니다")]
        public string Key
        {
            get { return _Key; }
            set { _Key = value; }
        }

        #region IStdValidationControl 인터페이스 구현

        /// <summary>
        /// 컨트롤에 에러 메시지를 설정하고, 포커스 지정
        /// </summary>
        /// <param name="message"></param>
        public void CtrlShowErrorMessage(string message)
        {
            this.Focus();
        }

        private int _MinLength = 0;

        /// <summary>
        /// 사용안함
        /// </summary>
        [Category("ShipBuilding_Core_Property")]
        [DescriptionAttribute("사용안함")]
        public int MinLength
        {
            get { return _MinLength; }
            set { _MinLength = value; }
        }


        public bool RequiredValidation(bool isTrim)
        {
            return this.Items.Count > 0;
        }

        public bool MinLengthValidation()
        {
            return true;
        }

        #endregion

        /// <summary>
        /// 엔터시 실행할 버튼 리스트를 가져오거나,설정한다
        /// </summary>
        
        public IButtonControl[] EnterExecuteButton
        {
            get;
            set;
        }
    }
}
