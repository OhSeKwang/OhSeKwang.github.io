﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace HHI.NexFrame.Client.Controls.Components
{
    // ; 으로 구분된 문자열을 string[] 로 변환해 주는(혹은 반대의 상황) 타입 변환기 구현
    // 이 클래스는 StdSecurityManager의 AllowedAccess 속성을 위해 사용된다.
    internal class AccessListTypeConverter : TypeConverter
    {
        public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
        {
            if (sourceType == typeof(string))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
        {
            if (destinationType == typeof(string[]))
            {
                return true;
            }
            return CanConvertTo(context, destinationType);
        }

        public override object ConvertFrom(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value)
        {
            string strValue = value as String;
            if (strValue != null)
            {
                string[] resultValue = strValue.Split(';');
                return resultValue;
            }
            return base.ConvertFrom(context, culture, value);
        }

        public override object ConvertTo(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value, Type destinationType)
        {
            string[] strArray = value as string[];
            if (strArray != null)
            {
                var resultValue = String.Join(";", strArray);
                return resultValue;
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }
    }
}
