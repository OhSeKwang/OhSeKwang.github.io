﻿using DevExpress.XtraEditors;
using HHI.NexFrame.Client.UI.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HHI.NexFrame.Client.Controls.Components
{
    
    
    [ProvideProperty("Validation", typeof(Control))]
    [DesignerCategory("")]
    [ToolboxItem(true)]
    public partial class StdValidationManager : Component, IExtenderProvider
    {
        // Validation 체크할 대상 컨트롤 집합
        private Dictionary<Control, ValidationType[]> _controlValidationTable = new Dictionary<Control, ValidationType[]>();

        public StdValidationManager()
        {
            InitializeComponent();

            IsNullorWhiteSpace = true;
            IsShowErrorMessage = true;
        }

        public StdValidationManager(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }

        public bool CanExtend(object extendee)
        {
            var control = extendee as Control;
            if (control != null)
            {
                return true;
            }
            return false;
        }
        
        #region 확장 속성 구현

        /// <summary>
        /// 문자열인 경우 공백은 Trim해서 체크할지 여부를 지정한다
        /// </summary>
        [Description("문자열인 경우 공백은 Trim해서 체크할지 여부를 지정한다")]
        [Category("ShipBuilding_Core_Property")]
        public bool IsNullorWhiteSpace
        {
            get;
            set;
        }

        /// <summary>
        /// 유효성 검사 실패시 메시지를 출력할지 여부를 지정하거나/지정한다.
        /// </summary>
        [Description("유효성 검사 실패시 메시지를 출력할지 여부를 지정하거나/지정한다.")]
        [Category("ShipBuilding_Core_Property")]
        public bool IsShowErrorMessage
        {
            get;
            set;
        }

        // 확장 속성의 get 메서드
        [DisplayName("_Validation")]
        [DefaultValue(null)]
        [Description("Validation체크대상여부를 지정한다.")]
        [Category("ShipBuilding_Core_Property")]
        //[TypeConverter(typeof(ValidationListTypeConverter))]
        public ValidationType[] GetValidation(Control control)
        {
            ValidationType[] validationList = null;

            _controlValidationTable.TryGetValue(control, out validationList);
            return validationList;
        }

        // 확장 속성의 set 메서드
        public void SetValidation(Control control, ValidationType[] validationList)
        {
            if (_controlValidationTable.ContainsKey(control) == true)
            {
                _controlValidationTable[control] = validationList;
            }
            else
            {
                _controlValidationTable.Add(control, validationList);
            }
        }

        #endregion

        #region 외부 공개 메서드 구현

        /// <summary>
        /// 디자인 타임에 설정된 컨트롤에 대하여 유효성 체크를 한다
        /// </summary>
        public bool Validation()
        {
            //디자인타임에서 추가된 컨트롤 리스트에 대하여 Validation유형에 맞게 검사를 수행한다.
            foreach (var pair in _controlValidationTable)
            {
                var validationList = pair.Value;
                var control = pair.Key;

                foreach (var validationType in validationList)
                {
                    //// IStdValidationControl 인터페이스를 구현하는 컨트롤은 Validation 검사를 위임한다.
                    var stdValidationControl = control as IStdValidationControl;
                    
                    //컨트롤에 대한 권한 검사 결과 임시변수
                    bool IsSuccess = true;
                    int minLength = 0;
                    string domainName = string.Empty;

                    if (stdValidationControl != null)
                    {
                        if (validationType == ValidationType.Required)
                            IsSuccess = stdValidationControl.RequiredValidation(IsNullorWhiteSpace);
                        else if (validationType == ValidationType.MinLength)
                            IsSuccess = stdValidationControl.MinLengthValidation();
                    }
                    //일반 컨트롤은 개별적으로 Validation검사를 한다
                    else
                    {
                        if (validationType == ValidationType.Required)
                        {
                            //DevExpress Control...
                            if (control is BaseEdit)
                                IsSuccess = (control as BaseEdit).SetExRequiredValidation(IsNullorWhiteSpace);
                            //아래에 다른 써드파티 또는 윈폼컨트롤 타입을 체크소스 추가하면 됨...
                        }
                        else if (validationType == ValidationType.MinLength)
                        {
                            throw new HHIException("MinLength Validation은 써드파티 상속받은 컨트롤만 지원이 됩니다");
                        }
                    }

                    if(!IsSuccess)
                    {
                        if(IsShowErrorMessage)
                        {
                            domainName = control.GetCaptionLayoutControlItem();
                            string errorMsg = string.Empty;

                            if (validationType == ValidationType.Required)
                            {
                                errorMsg = string.Format("{0}은(는) 필수입력입니다.", domainName);
                            }
                            else if (validationType == ValidationType.MinLength)
                            {
                                minLength = control.GetMinLengthProperty();
                                errorMsg = string.Format("{0}은(는) {1}자리 이상 입력 또는 선택을 하세요", domainName, minLength);
                            }

                            XtraMessageBox.Show(errorMsg, "Error");

                            if (stdValidationControl != null)
                            {
                                stdValidationControl.CtrlShowErrorMessage(errorMsg);
                            }
                        }

                        return false;
                    }
                }
            }

            return true;
        }
        
        #endregion
    }
}
