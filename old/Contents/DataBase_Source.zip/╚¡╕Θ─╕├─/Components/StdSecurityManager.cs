﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HHI.Security;
using HHI.NexFrame.Client.UI.Interface;
using HHI.NexFrame.Core.Security;

namespace HHI.NexFrame.Client.Controls.Components
{
    /// <summary>
    /// 컨트롤에 대해 권한에 따라 자동으로 enable/disable을 수행해 주는 컴포넌트.
    /// </summary>
    [ProvideProperty("AllowedAccess", typeof(Control))]
    [DesignerCategory("")]
    [ToolboxItem(true)]
    public partial class StdSecurityManager : Component, IExtenderProvider
    {
        // 컨트롤별 권한 정보를 담는 테이블
        private Dictionary<Control, string[]> _controlSecurityTable = new Dictionary<Control, string[]>();

        #region 생성자

        public StdSecurityManager()
        {
        }

        // 디자이너 상에 컴포넌트를 올려놓기 위해 필요한 생성자이다.
        public StdSecurityManager(IContainer container)
        {
            container.Add(this);
        }
        #endregion

        #region IExtenderProvider 인터페이스 구현

        // 각 컨트롤에 대해 이 메서드가 호출되어 속성을 확장(extend)할 수 있는지 여부를 결정한다.
        public bool CanExtend(object extendee)
        {
            var control = extendee as Control;
            if (control != null)
            {
                return true;
            }
            return false;
        }

        #endregion

        #region 확장 속성 구현

        // 확장 속성의 get 메서드
        [DisplayName("_AllowedAccess")]
        [DefaultValue(null)]
        [Description("컨트롤의 권한을 나열합니다.")]
        [Category("Framework")]
        [TypeConverter(typeof(AccessListTypeConverter))]
        public string[] GetAllowedAccess(Control control)
        {
            string[] accessList = null;

            _controlSecurityTable.TryGetValue(control, out accessList);
            return accessList;
        }

        // 확장 속성의 set 메서드
        public void SetAllowedAccess(Control control, string[] accessList)
        {
            if (_controlSecurityTable.ContainsKey(control) == true)
            {
                _controlSecurityTable[control] = accessList;
            }
            else
            {
                _controlSecurityTable.Add(control, accessList);
            }
        }

        #endregion

        #region 외부 공개 메서드 구현

        /// <summary>
        /// 디자인 타임에 권한 정보가 설정된 모든 컨트롤들에 대해 주어진 SecurityContext 객체를 검사하여 
        /// 권한이 없는 경우 컨트롤을 disable 시킨다.
        /// </summary>
        /// <param name="ctx">SecurityContext 혹은 그 파생 객체</param>
        public void ApplySecurity(SecurityContext ctx)
        {
            // 설정된 각 컨트롤들에 대해 권한에 따라 disable을 수행한다.
            // 주) 명시적으로 enable 시키지는 않는다. 기본 설정이 disable 상태일 수도 있기 때문이다.
            foreach (var pair in _controlSecurityTable)
            {
                var accessList = pair.Value;
                var control = pair.Key;
                // IStdControl 인터페이스를 구현하는 컨트롤은 권한 검사를 위임한다.
                var stdControl = control as IStdControl;
                if (stdControl != null)
                {
                    stdControl.ApplySecurity(accessList, ctx);
                }
                else
                {
                    control.Enabled = control.Enabled & GetEnabledBySecurity(accessList, ctx); ;
                }
            }
        }

        /// <summary>
        /// 권한 검사를 수행하여 컨트롤을 enable/disable 한다.
        /// 만약 권한이 없는 경우라면 컨트롤은 결코 enable 되지 않는다.
        /// </summary>
        /// <param name="control">enable/disable 대상 컨트롤</param>
        /// <param name="ctx">SecurityContext 객체</param>
        /// <param name="enable">enable/disable 여부</param>
        public void EnableControl(Control control, SecurityContext ctx, bool enable)
        {
            string[] accessList = null;

            if (enable == true && _controlSecurityTable.TryGetValue(control, out accessList) == true)
            {
                var stdControl = control as IStdControl;
                if (stdControl != null)
                {
                    stdControl.ApplySecurity(accessList, ctx);
                }
                else
                {
                    control.Enabled = enable & GetEnabledBySecurity(accessList, ctx);
                }
            }
            else
            {
                control.Enabled = enable;
            }
        }
        
        /// <summary>
        /// 주어진 컨트롤이 요구하는 권한과 SecurityContext를 검사하여 권한이 있는지 여부를 반환한다.
        /// </summary>
        /// <param name="control">검사 대상 컨트롤</param>
        /// <param name="ctx">SecurityContext 객체</param>
        /// <returns>컨트롤이 요구하는 권한이 있는 경우 true, 권한이 없는 경우 false를 반환한다. 컨트롤에 설정된 권한 정보가 없는 경우 null을 반환한다.</returns>
        public bool? GetControlAuthrority(Control control, SecurityContext ctx)
        {
            bool? result = null;
            string[] accessList = null;

            if (_controlSecurityTable.TryGetValue(control, out accessList) == true)
            {
                result = GetEnabledBySecurity(accessList, ctx);
            }
            return result;
        }

        // 주어진 SecurityContext와 액세스 허용을 검사하여 권한이 있는지 여부를 반환한다.
        public static bool GetEnabledBySecurity(string[] accessList, SecurityContext ctx)
        {
            var enabled = true;

            foreach (var accessName in accessList)
            {
                switch (accessName)
                {
                    case StdSecurityContext.SelectAccessName:
                        if (ctx.CanSelect == false)
                        {
                            enabled = false;
                        }
                        break;
                    case StdSecurityContext.SaveAccessName:
                        if (ctx.CanSave == false)
                        {
                            enabled = false;
                        }
                        break;
                    case StdSecurityContext.InsertAccessName:
                        if (ctx.CanInsert == false)
                        {
                            enabled = false;
                        }
                        break;
                    case StdSecurityContext.UpdateAccessName:
                        if (ctx.CanUpdate == false)
                        {
                            enabled = false;
                        }
                        break;
                    case StdSecurityContext.DeleteAccessName:
                        if (ctx.CanDelete == false)
                        {
                            enabled = false;
                        }
                        break;
                    default:
                        var stdCtx = ctx as StdSecurityContext;
                        if (stdCtx == null || stdCtx[accessName] == false)
                        {
                            enabled = false;
                        }
                        break;
                }
            }
            return enabled;
        }

        #endregion
    }
}
