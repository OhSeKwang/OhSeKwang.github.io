﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication15
{
    public partial class UserControlBase : UserControl
    {
        public event EventHandler Shown;

        public UserControlBase()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (!this.DesignMode)
            {
                // Form의 Shown과 동일한 기능 사용..
                bool isHandleCreated = base.IsHandleCreated;
                if (isHandleCreated)
                {
                    base.BeginInvoke(new MethodInvoker(this.ShownDispatcher));
                }
            }
        }

        private void ShownDispatcher()
        {
            this.Refresh();
            this.OnShown(EventArgs.Empty);
        }

        protected virtual void OnShown(EventArgs e)
        {
            if (Shown != null)
                Shown(this, e);
        }
    }
}
