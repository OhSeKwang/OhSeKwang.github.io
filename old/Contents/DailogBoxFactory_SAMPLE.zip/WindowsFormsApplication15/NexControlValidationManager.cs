﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication15
{
    [ProvideProperty("Names", typeof(Control))]
    [DesignerCategory("NexFrame.Controls")]
    [ToolboxItem(true)]
    public partial class NexControlValidationManager : Component, IExtenderProvider
    {
        // Validation 체크할 대상 컨트롤 집합
        private Dictionary<Control, string[]> nameList = new Dictionary<Control, string[]>();
        public NexControlValidationManager()
        {
            this.InitializeComponent();
        }

        public bool CanExtend(object extendee)
        {
            Control control = extendee as Control;

            if(control != null)
            {
                return true;
            }
            return false;
        }

        [DisplayName("NexNames")]
        [DefaultValue(null)]
        [Category("NexFrame.Controls")]
        public string [] GetNames(Control control)
        {
            string[] arrNames = null;

            nameList.TryGetValue(control, out arrNames);
         
            return arrNames;
        }

        public void SetNames(Control control, string [] names)
        {
            if (nameList.ContainsKey(control) == true)
            {
                nameList[control] = names;
            }
            else
            {
                nameList.Add(control, names);
            }
        }

        /// <summary>
        /// 디자인 타임에 설정된 컨트롤에 대하여 유효성 체크를 한다
        /// </summary>
        public bool CheckValidate()
        {

            foreach (var item in nameList.OrderBy(a => a.Key.TabIndex))
            {
                MessageBox.Show(string.Format("{0} / {1}", item.Key.Name, this.ToJoinString(item.Value, ",")));
            }
            return true;
        }

        /// <summary>
        /// string [] 개체를 컬렉션을 value1,value2,value3 형태의 문자열로 반환 합니다.
        /// </summary>
        /// <param name="sources">변환할 원본데이터 입니다.</param>
        /// <param name="separator">문자열로 변환 시 사용 할 구분자를 지정 합니다.</param>
        /// <returns>string 문자열 입니다.</returns>
        public string ToJoinString(string[] sources, string separator)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            if (sources != null && sources.Length > 0)
            {
                foreach (string source in sources.Take(sources.Length - 1))
                {
                    sb.AppendFormat("{0}{1}", source, separator);
                }
                sb.AppendFormat("{0}", sources[sources.Length - 1]);
            }

            return sb.ToString();
        }
    }

    /// <summary>
    /// 조선Core 프레임워크 Validation Component에서 수행할 Validation 유형을 정의한다.
    /// </summary>
    public enum ValidationType
    {
        NonBlank = 0,
        MaxLength = 1
    }
}
