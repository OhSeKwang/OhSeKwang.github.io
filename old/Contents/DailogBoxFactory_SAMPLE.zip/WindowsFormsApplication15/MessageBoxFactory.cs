﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication15
{
    // 기본 DialogBox
    public static class DialogBox
    {
        private static DialogBoxBase _DialogBoxFactory = null;

        // CutomDialogBox 지원하기 위해
        public static DialogBoxBase DialogBoxFactory
        {
            get
            {
                if(_DialogBoxFactory == null)
                    _DialogBoxFactory = new DialogBoxBase();  
                
                return _DialogBoxFactory;;
            }
            set
            {
                _DialogBoxFactory = value;
            }
        }

        public static DialogResult ShowDialog(string caption, string message)
        {
            return ShowDialog(null, caption, message);
        }

        public static DialogResult ShowDialog(IWin32Window owner, string caption, string message)
        {
            DialogResult dlgResult = DialogResult.None;
            using (Form frm = DialogBox.DialogBoxFactory.GetCustomDialogBox(owner, caption, message))
            {
                dlgResult = frm.ShowDialog();
            }

            return dlgResult;
        }

        public static Form Show(string caption, string message)
        {
            return Show(null, caption, message);
        }

        public static Form Show(IWin32Window owner, string caption, string message)
        {
            Form frm = DialogBox.DialogBoxFactory.GetCustomDialogBox(owner, caption, message);
            frm.Deactivate += frm_Deactivate;

            if (owner != null)
                frm.Show(owner);
            else
                frm.Show();

            return frm;
        }

        // Form 강제 Dispose
        static void frm_Deactivate(object sender, EventArgs e)
        {
            ((Form)sender).Dispose();
        }
    }


    public class MyOnlyDialog : DialogBoxBase
    {
        public override Form GetCustomDialogBox(IWin32Window owner, string message, string caption)
        {
            MyMessageBox msgBox = new MyMessageBox();
            msgBox.Text = caption;
            msgBox.label1.Text = message;
            return msgBox;
        }
    }


    public class DialogBoxBase
    {
        public virtual Form GetCustomDialogBox(IWin32Window owner, string message, string caption)
        {
            DefaultMessageBox msgBox = new DefaultMessageBox();
            msgBox.Text = caption;
            msgBox.label1.Text = message;
            return msgBox;
        }
    }
}
