﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication15
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            nexControlValidationManager1.CheckValidate();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("_Laod");
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            MessageBox.Show("_Shown");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogBox.DialogBoxFactory = new MyOnlyDialog();
            Form frm = DialogBox.DialogBoxFactory.GetCustomDialogBox(this, "My first dialog", "My Msg Factory");
            frm.ShowDialog();
            

            DialogBox.ShowDialog(this, "My first dialog", "My Msg Factory");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form frm = DialogBox.Show(this, "My first dialog", "My Msg Factory");
            frm.FormClosed += frm_FormClosed;
        }

        void frm_FormClosed(object sender, FormClosedEventArgs e)
        {
            MessageBox.Show("dd");
        }
    }
}
