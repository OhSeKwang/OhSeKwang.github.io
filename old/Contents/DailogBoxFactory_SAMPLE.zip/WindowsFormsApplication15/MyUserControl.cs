﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HHI.Windows.Forms;

namespace WindowsFormsApplication15
{
    public partial class MyUserControl : UserControlBase
    {
        public MyUserControl()
        {
            InitializeComponent();
            this.Shown +=MyUserControl_Shown;
        }

        private void MyUserControl_Load(object sender, EventArgs e)
        {
            if(!this.DesignMode)
                MessageBox.Show("_load");
        }

        private void MyUserControl_Shown(object sender, EventArgs e)
        {
            if (!this.DesignMode)
                MessageBox.Show("_Shown");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MsgBox.Show(this, "TEST", "CAPTION", MessageBoxButtons.YesNo, null);

            // MsgBox.FormFactory.CreateMessageBoxForm(

        }


    }
}
