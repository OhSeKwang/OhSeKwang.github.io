﻿using System;
using System.ComponentModel;
using System.Drawing.Design;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace HHI.Windows.Forms.Design
{
    [EditorBrowsable(EditorBrowsableState.Never), ToolboxItem(false)]
    internal class WdxLanguageEditor : UITypeEditor
    {
        public override UITypeEditorEditStyle GetEditStyle(ITypeDescriptorContext context)
        {
            return UITypeEditorEditStyle.Modal;
        }

        public override object EditValue(ITypeDescriptorContext context, IServiceProvider provider, object value)
        {
            string propertyValue = string.Empty;
            bool flag = value != null;
            if (flag)
            {
                propertyValue = string.Join(";", value as string[]);
            }
            IWindowsFormsEditorService windowsFormsEditorService = provider.GetService(typeof(IWindowsFormsEditorService)) as IWindowsFormsEditorService;
            bool flag2 = windowsFormsEditorService != null;
            if (flag2)
            {
                WdxLanguageEditorForm wdxLanguageEditorForm = new WdxLanguageEditorForm(propertyValue);
                DialogResult dialogResult = windowsFormsEditorService.ShowDialog(wdxLanguageEditorForm);
                bool flag3 = dialogResult == DialogResult.OK;
                if (flag3)
                {
                    value = wdxLanguageEditorForm.PropertyValue.Trim(new char[]
					{
						';'
					}).Split(new char[]
					{
						';'
					});
                }
            }
            return value;
        }
    }
}
