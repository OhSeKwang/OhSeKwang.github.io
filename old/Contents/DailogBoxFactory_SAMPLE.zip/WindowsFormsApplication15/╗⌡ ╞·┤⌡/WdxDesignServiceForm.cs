﻿using HHI.Windows.Forms.Properties;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace HHI.Windows.Forms.Design
{
    [ToolboxItem(false)]
    internal class WdxDesignServiceForm : Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        private Button btnOK;

        private Label label1;

        private Label label2;

        private TextBox txtUrl;

        public WdxDesignServiceForm()
        {
            this.InitializeComponent();
            this.txtUrl.Text = Settings.Default.DesignServiceUrl;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            Settings.Default.DesignServiceUrl = this.txtUrl.Text;
            Settings.Default.Save();
            base.DialogResult = DialogResult.OK;
            base.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            base.DialogResult = DialogResult.Cancel;
            base.Close();
        }

        internal static string GetDesignServiceUrl()
        {
            bool flag = string.IsNullOrWhiteSpace(Settings.Default.DesignServiceUrl);
            if (flag)
            {
                WdxDesignServiceForm wdxDesignServiceForm = new WdxDesignServiceForm();
                wdxDesignServiceForm.ShowDialog();
            }
            return Settings.Default.DesignServiceUrl;
        }

        //internal static IWdxDesignService CreateDesignService()
        //{
        //    string designServiceUrl = WdxDesignServiceForm.GetDesignServiceUrl();
        //    System.ServiceModel.Channels.Binding binding = new BasicHttpBinding();
        //    return ClientFactory.CreateChannel<IWdxDesignService>(null, designServiceUrl, binding);
        //}

        internal static bool Reset(IWin32Window owner)
        {
            WdxDesignServiceForm wdxDesignServiceForm = new WdxDesignServiceForm();
            return wdxDesignServiceForm.ShowDialog(owner) == DialogResult.OK;
        }

        private void txtUrl_KeyDown(object sender, KeyEventArgs e)
        {
            bool flag = e.KeyCode == Keys.Return;
            if (flag)
            {
                this.btnOK.PerformClick();
            }
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            bool flag = disposing && this.components != null;
            if (flag)
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOK = new Button();
            this.label1 = new Label();
            this.label2 = new Label();
            this.txtUrl = new TextBox();
            base.SuspendLayout();
            this.btnOK.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
            this.btnOK.Location = new Point(331, 53);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new Size(75, 23);
            this.btnOK.TabIndex = 1;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new EventHandler(this.btnOK_Click);
            this.label1.AutoSize = true;
            this.label1.Location = new Point(48, 30);
            this.label1.Name = "label1";
            this.label1.Size = new Size(270, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "예) http://localhost:3314/StdDesignService.svc";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(4, 9);
            this.label2.Name = "label2";
            this.label2.Size = new Size(40, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "URL : ";
            this.txtUrl.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
            this.txtUrl.Location = new Point(50, 4);
            this.txtUrl.Name = "txtUrl";
            this.txtUrl.Size = new Size(356, 21);
            this.txtUrl.TabIndex = 0;
            this.txtUrl.KeyDown += new KeyEventHandler(this.txtUrl_KeyDown);
            base.AutoScaleDimensions = new SizeF(7f, 12f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(411, 80);
            base.Controls.Add(this.txtUrl);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.btnOK);
            base.FormBorderStyle = FormBorderStyle.SizableToolWindow;
            base.Name = "WdxDesignServiceForm";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "서비스 경로 설정";
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}
