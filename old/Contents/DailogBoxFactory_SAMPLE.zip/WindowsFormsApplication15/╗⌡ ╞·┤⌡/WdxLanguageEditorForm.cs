﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace HHI.Windows.Forms.Design
{
    [EditorBrowsable(EditorBrowsableState.Never), ToolboxItem(false)]
    internal class WdxLanguageEditorForm : Form
    {
        private string _initPropertyValue = null;

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        private DataGridView dgvResult;

        private Label label1;

        private Button btnRetrieve;

        private Button btnOK;

        private Button btnCancel;

        private TextBox txtSearchText;

        private Label label2;

        private TextBox txtResult;

        private Label label4;

        private ComboBox cbSystemCode;

        private TableLayoutPanel tableLayoutPanel1;

        private GroupBox groupBox1;

        private GroupBox groupBox2;

        private DataGridView dgvSelected;

        private Button btnDelete;

        private TableLayoutPanel tableLayoutPanel2;

        private Button btnAdd;

        private TableLayoutPanel tableLayoutPanel3;

        private TableLayoutPanel tableLayoutPanel4;

        private FlowLayoutPanel flowLayoutPanel1;

        private Button btnReset;

        private DataGridViewTextBoxColumn SProperty;

        private DataGridViewTextBoxColumn SKeyCode;

        private DataGridViewTextBoxColumn MSG_CD;

        private DataGridViewTextBoxColumn MSG_TEXT;

        private DataGridViewTextBoxColumn LANG_CD;

        public string PropertyValue
        {
            get
            {
                return this.txtResult.Text;
            }
        }

        public WdxLanguageEditorForm()
        {
            this.InitializeComponent();
        }

        public WdxLanguageEditorForm(string propertyValue)
        {
            this.InitializeComponent();
            this._initPropertyValue = propertyValue;
        }

        private void StdLanguageEditorForm_Shown(object sender, EventArgs e)
        {
            this.InitializeEditor();
        }

        private void InitializeEditor()
        {
            try
            {
                this.InitSelectedList(this._initPropertyValue);
                this.InitSystemList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void InitSelectedList(string propertyValue)
        {
            DataSet dataSet = new DataSet();
            DataTable dataTable = dataSet.Tables.Add();
            dataTable.Columns.Add(new DataColumn("KeyCode"));
            dataTable.Columns.Add(new DataColumn("Property"));
            this.dgvSelected.DataSource = dataSet.Tables[0];
            bool flag = propertyValue.Length > 0;
            if (flag)
            {
                this.txtResult.Text = propertyValue;
                string[] array = propertyValue.Split(new char[]
				{
					';'
				});
                string[] array2 = array;
                for (int i = 0; i < array2.Length; i++)
                {
                    string text = array2[i];
                    string value = string.Empty;
                    string value2 = string.Empty;
                    string[] array3 = text.Split(new char[]
					{
						','
					});
                    bool flag2 = array3.Length > 1;
                    if (flag2)
                    {
                        value = array3[0];
                        value2 = array3[1];
                    }
                    bool flag3 = string.IsNullOrEmpty(value);
                    if (!flag3)
                    {
                        DataRow dataRow = dataTable.NewRow();
                        dataRow[0] = value;
                        dataRow[1] = value2;
                        dataTable.Rows.Add(dataRow);
                    }
                }
            }
        }

        private void InitSystemList()
        {
            using (IWdxDesignService wdxDesignService = WdxDesignServiceForm.CreateDesignService())
            {
                DataSet systemList = wdxDesignService.GetSystemList();
                DataRow dataRow = systemList.Tables[0].NewRow();
                dataRow["SYSTEM_CD"] = null;
                dataRow["SYSTEM_NM"] = "전체";
                systemList.Tables[0].Rows.InsertAt(dataRow, 0);
                this.cbSystemCode.ValueMember = "SYSTEM_CD";
                this.cbSystemCode.DisplayMember = "SYSTEM_NM";
                this.cbSystemCode.DataSource = systemList.Tables[0];
            }
        }

        /// <summary>
        /// 다국어 정보 검색
        /// </summary>
        private void GetLanguageInfoList()
        {
            using (IWdxDesignService wdxDesignService = WdxDesignServiceForm.CreateDesignService())
            {
                string systemID = Convert.ToString(this.cbSystemCode.SelectedValue);
                DataSet languageList = wdxDesignService.GetLanguageList(systemID);
                this.dgvResult.DataSource = languageList.Tables[0];
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            string text = string.Empty;
            foreach (DataGridViewRow dataGridViewRow in ((IEnumerable)this.dgvSelected.Rows))
            {
                string arg = dataGridViewRow.Cells["SKeyCode"].Value.ToString();
                string arg2 = dataGridViewRow.Cells["SProperty"].Value.ToString();
                text += string.Format("{0},{1};", arg, arg2);
            }
            this.txtResult.Text = text;
            base.DialogResult = DialogResult.OK;
            base.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            base.DialogResult = DialogResult.Cancel;
            base.Close();
        }

        private void btnRetrieve_Click(object sender, EventArgs e)
        {
            try
            {
                this.GetLanguageInfoList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void txtSearchText_KeyUp(object sender, KeyEventArgs e)
        {
            string rowFilter = string.Format("MSG_TEXT LIKE '*{0}*'", this.txtSearchText.Text);
            (this.dgvResult.DataSource as DataTable).DefaultView.RowFilter = rowFilter;
        }

        private void dgvResult_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            bool flag = e.RowIndex > -1;
            if (flag)
            {
                this.AddRow(e.RowIndex);
            }
        }

        private void cbSystemCode_SelectedValueChanged(object sender, EventArgs e)
        {
            this.GetLanguageInfoList();
        }

        /// <summary>
        /// 행추가
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            bool flag = this.dgvResult.SelectedRows.Count > 0;
            if (flag)
            {
                foreach (DataGridViewRow dataGridViewRow in this.dgvResult.SelectedRows)
                {
                    this.AddRow(dataGridViewRow.Index);
                }
            }
        }

        /// <summary>
        /// 행삭제 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            bool flag = this.dgvSelected.SelectedRows.Count > 0;
            if (flag)
            {
                foreach (DataGridViewRow dataGridViewRow in this.dgvSelected.SelectedRows)
                {
                    this.dgvSelected.Rows.Remove(dataGridViewRow);
                }
            }
        }

        private void dgvSelected_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            string text = string.Empty;
            foreach (DataGridViewRow dataGridViewRow in ((IEnumerable)this.dgvSelected.Rows))
            {
                string arg = dataGridViewRow.Cells["SKeyCode"].Value.ToString();
                string arg2 = dataGridViewRow.Cells["SProperty"].Value.ToString();
                text += string.Format("{0},{1};", arg, arg2);
            }
            this.txtResult.Text = text;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            WdxDesignServiceForm.Reset(this);
            this.InitializeEditor();
        }

        /// <summary>
        /// 행 추가
        /// </summary>
        /// <param name="rowIndex"></param>
        private void AddRow(int rowIndex)
        {
            DataGridViewRow dataGridViewRow = this.dgvResult.Rows[rowIndex];
            string value = dataGridViewRow.Cells["MSG_CD"].Value.ToString();
            DataTable dataTable = this.dgvSelected.DataSource as DataTable;
            DataRow dataRow = dataTable.NewRow();
            dataRow["KeyCode"] = value;
            dataRow["Property"] = "Text";
            dataTable.Rows.Add(dataRow);
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            bool flag = disposing && this.components != null;
            if (flag)
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvResult = new DataGridView();
            this.MSG_CD = new DataGridViewTextBoxColumn();
            this.MSG_TEXT = new DataGridViewTextBoxColumn();
            this.LANG_CD = new DataGridViewTextBoxColumn();
            this.label1 = new Label();
            this.btnRetrieve = new Button();
            this.btnOK = new Button();
            this.btnCancel = new Button();
            this.txtSearchText = new TextBox();
            this.label2 = new Label();
            this.txtResult = new TextBox();
            this.label4 = new Label();
            this.cbSystemCode = new ComboBox();
            this.tableLayoutPanel1 = new TableLayoutPanel();
            this.groupBox1 = new GroupBox();
            this.groupBox2 = new GroupBox();
            this.dgvSelected = new DataGridView();
            this.SProperty = new DataGridViewTextBoxColumn();
            this.SKeyCode = new DataGridViewTextBoxColumn();
            this.tableLayoutPanel2 = new TableLayoutPanel();
            this.btnDelete = new Button();
            this.btnAdd = new Button();
            this.tableLayoutPanel3 = new TableLayoutPanel();
            this.tableLayoutPanel4 = new TableLayoutPanel();
            this.flowLayoutPanel1 = new FlowLayoutPanel();
            this.btnReset = new Button();
            ((ISupportInitialize)this.dgvResult).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((ISupportInitialize)this.dgvSelected).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            base.SuspendLayout();
            this.dgvResult.AllowUserToAddRows = false;
            this.dgvResult.AllowUserToDeleteRows = false;
            this.dgvResult.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvResult.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResult.Columns.AddRange(new DataGridViewColumn[]
			{
				this.MSG_CD,
				this.MSG_TEXT,
				this.LANG_CD
			});
            this.dgvResult.Dock = DockStyle.Fill;
            this.dgvResult.Location = new Point(3, 17);
            this.dgvResult.Name = "dgvResult";
            this.dgvResult.ReadOnly = true;
            this.dgvResult.RowHeadersVisible = false;
            this.dgvResult.RowTemplate.Height = 23;
            this.dgvResult.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvResult.Size = new Size(318, 226);
            this.dgvResult.TabIndex = 0;
            this.dgvResult.CellDoubleClick += new DataGridViewCellEventHandler(this.dgvResult_CellDoubleClick);
            this.MSG_CD.DataPropertyName = "MSG_CD";
            this.MSG_CD.HeaderText = "다국어 코드";
            this.MSG_CD.Name = "MSG_CD";
            this.MSG_CD.ReadOnly = true;
            this.MSG_TEXT.DataPropertyName = "MSG_TEXT";
            this.MSG_TEXT.HeaderText = "문자열";
            this.MSG_TEXT.Name = "MSG_TEXT";
            this.MSG_TEXT.ReadOnly = true;
            this.LANG_CD.DataPropertyName = "LANG_CD";
            this.LANG_CD.FillWeight = 70f;
            this.LANG_CD.HeaderText = "언어정보";
            this.LANG_CD.Name = "LANG_CD";
            this.LANG_CD.ReadOnly = true;
            this.label1.Dock = DockStyle.Fill;
            this.label1.ImageAlign = ContentAlignment.TopLeft;
            this.label1.Location = new Point(3, 25);
            this.label1.Name = "label1";
            this.label1.Size = new Size(74, 28);
            this.label1.TabIndex = 1;
            this.label1.Text = "다국어 코드";
            this.label1.TextAlign = ContentAlignment.MiddleLeft;
            this.btnRetrieve.Dock = DockStyle.Fill;
            this.btnRetrieve.Location = new Point(507, 3);
            this.btnRetrieve.Name = "btnRetrieve";
            this.tableLayoutPanel3.SetRowSpan(this.btnRetrieve, 2);
            this.btnRetrieve.Size = new Size(64, 47);
            this.btnRetrieve.TabIndex = 1;
            this.btnRetrieve.Text = "검색";
            this.btnRetrieve.UseVisualStyleBackColor = true;
            this.btnRetrieve.Click += new EventHandler(this.btnRetrieve_Click);
            this.btnOK.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
            this.btnOK.Location = new Point(360, 3);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new Size(75, 23);
            this.btnOK.TabIndex = 2;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new EventHandler(this.btnOK_Click);
            this.btnCancel.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
            this.btnCancel.Location = new Point(441, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new Size(75, 23);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new EventHandler(this.btnCancel_Click);
            this.txtSearchText.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
            this.tableLayoutPanel3.SetColumnSpan(this.txtSearchText, 3);
            this.txtSearchText.Location = new Point(83, 28);
            this.txtSearchText.Name = "txtSearchText";
            this.txtSearchText.Size = new Size(418, 21);
            this.txtSearchText.TabIndex = 0;
            this.txtSearchText.KeyUp += new KeyEventHandler(this.txtSearchText_KeyUp);
            this.label2.Dock = DockStyle.Fill;
            this.label2.ImageAlign = ContentAlignment.TopLeft;
            this.label2.Location = new Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new Size(49, 25);
            this.label2.TabIndex = 6;
            this.label2.Text = "결과";
            this.label2.TextAlign = ContentAlignment.MiddleLeft;
            this.txtResult.BackColor = SystemColors.Control;
            this.txtResult.Dock = DockStyle.Fill;
            this.txtResult.Location = new Point(58, 3);
            this.txtResult.Name = "txtResult";
            this.txtResult.ReadOnly = true;
            this.txtResult.Size = new Size(513, 21);
            this.txtResult.TabIndex = 7;
            this.label4.Dock = DockStyle.Fill;
            this.label4.ImageAlign = ContentAlignment.TopLeft;
            this.label4.Location = new Point(3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new Size(74, 25);
            this.label4.TabIndex = 8;
            this.label4.Text = "시스템";
            this.label4.TextAlign = ContentAlignment.MiddleLeft;
            this.cbSystemCode.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
            this.tableLayoutPanel3.SetColumnSpan(this.cbSystemCode, 3);
            this.cbSystemCode.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cbSystemCode.FormattingEnabled = true;
            this.cbSystemCode.Location = new Point(83, 3);
            this.cbSystemCode.Name = "cbSystemCode";
            this.cbSystemCode.Size = new Size(418, 20);
            this.cbSystemCode.TabIndex = 9;
            this.cbSystemCode.SelectedValueChanged += new EventHandler(this.cbSystemCode_SelectedValueChanged);
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40f));
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 25f));
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 60f));
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupBox2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel1.Dock = DockStyle.Fill;
            this.tableLayoutPanel1.Location = new Point(0, 53);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            this.tableLayoutPanel1.Size = new Size(574, 252);
            this.tableLayoutPanel1.TabIndex = 10;
            this.groupBox1.Controls.Add(this.dgvResult);
            this.groupBox1.Dock = DockStyle.Fill;
            this.groupBox1.Location = new Point(247, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(324, 246);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "다국어 목록";
            this.groupBox2.Controls.Add(this.dgvSelected);
            this.groupBox2.Dock = DockStyle.Fill;
            this.groupBox2.Location = new Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(213, 246);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "매핑 정보";
            this.dgvSelected.AllowUserToAddRows = false;
            this.dgvSelected.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSelected.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSelected.Columns.AddRange(new DataGridViewColumn[]
			{
				this.SProperty,
				this.SKeyCode
			});
            this.dgvSelected.Dock = DockStyle.Fill;
            this.dgvSelected.Location = new Point(3, 17);
            this.dgvSelected.Name = "dgvSelected";
            this.dgvSelected.RowHeadersVisible = false;
            this.dgvSelected.RowTemplate.Height = 23;
            this.dgvSelected.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvSelected.Size = new Size(207, 226);
            this.dgvSelected.TabIndex = 0;
            this.dgvSelected.CellEndEdit += new DataGridViewCellEventHandler(this.dgvSelected_CellEndEdit);
            this.SProperty.DataPropertyName = "Property";
            this.SProperty.HeaderText = "속성명";
            this.SProperty.Name = "SProperty";
            this.SKeyCode.DataPropertyName = "KeyCode";
            this.SKeyCode.HeaderText = "다국어 코드";
            this.SKeyCode.Name = "SKeyCode";
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            this.tableLayoutPanel2.Controls.Add(this.btnDelete, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.btnAdd, 0, 1);
            this.tableLayoutPanel2.Dock = DockStyle.Fill;
            this.tableLayoutPanel2.Location = new Point(219, 0);
            this.tableLayoutPanel2.Margin = new Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
            this.tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 30f));
            this.tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 30f));
            this.tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
            this.tableLayoutPanel2.Size = new Size(25, 252);
            this.tableLayoutPanel2.TabIndex = 2;
            this.btnDelete.Dock = DockStyle.Fill;
            this.btnDelete.Location = new Point(0, 126);
            this.btnDelete.Margin = new Padding(0);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new Size(25, 30);
            this.btnDelete.TabIndex = 0;
            this.btnDelete.Text = "▶";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new EventHandler(this.btnDelete_Click);
            this.btnAdd.Dock = DockStyle.Fill;
            this.btnAdd.Location = new Point(0, 96);
            this.btnAdd.Margin = new Padding(0);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new Size(25, 30);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "◀";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new EventHandler(this.btnAdd_Click);
            this.tableLayoutPanel3.ColumnCount = 5;
            this.tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 80f));
            this.tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
            this.tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 60f));
            this.tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
            this.tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 70f));
            this.tableLayoutPanel3.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.cbSystemCode, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.txtSearchText, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.btnRetrieve, 4, 0);
            this.tableLayoutPanel3.Dock = DockStyle.Top;
            this.tableLayoutPanel3.Location = new Point(0, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Absolute, 25f));
            this.tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Absolute, 25f));
            this.tableLayoutPanel3.Size = new Size(574, 53);
            this.tableLayoutPanel3.TabIndex = 11;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 55f));
            this.tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            this.tableLayoutPanel4.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.txtResult, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.flowLayoutPanel1, 1, 1);
            this.tableLayoutPanel4.Dock = DockStyle.Bottom;
            this.tableLayoutPanel4.Location = new Point(0, 305);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 25f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 25f));
            this.tableLayoutPanel4.Size = new Size(574, 57);
            this.tableLayoutPanel4.TabIndex = 12;
            this.flowLayoutPanel1.Controls.Add(this.btnCancel);
            this.flowLayoutPanel1.Controls.Add(this.btnOK);
            this.flowLayoutPanel1.Controls.Add(this.btnReset);
            this.flowLayoutPanel1.Dock = DockStyle.Fill;
            this.flowLayoutPanel1.FlowDirection = FlowDirection.RightToLeft;
            this.flowLayoutPanel1.Location = new Point(55, 25);
            this.flowLayoutPanel1.Margin = new Padding(0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new Size(519, 32);
            this.flowLayoutPanel1.TabIndex = 8;
            this.btnReset.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
            this.btnReset.Location = new Point(279, 3);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new Size(75, 23);
            this.btnReset.TabIndex = 4;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new EventHandler(this.btnReset_Click);
            base.AutoScaleDimensions = new SizeF(7f, 12f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(574, 362);
            base.Controls.Add(this.tableLayoutPanel1);
            base.Controls.Add(this.tableLayoutPanel3);
            base.Controls.Add(this.tableLayoutPanel4);
            base.Name = "WdxLanguageEditorForm";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "다국어 코드 설정";
            base.Shown += new EventHandler(this.StdLanguageEditorForm_Shown);
            ((ISupportInitialize)this.dgvResult).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((ISupportInitialize)this.dgvSelected).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            base.ResumeLayout(false);
        }
    }
}
