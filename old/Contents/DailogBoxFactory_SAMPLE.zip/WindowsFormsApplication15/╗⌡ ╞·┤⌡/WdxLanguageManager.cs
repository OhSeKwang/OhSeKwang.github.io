﻿using HHI.Windows.Forms.Design;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing.Design;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;

namespace HHI.Windows.Forms
{
    [DesignerCategory("Code"), ProvideProperty("LanguageCode", typeof(Component))]
    public class WdxLanguageManager : Component, IExtenderProvider
    {
        private Dictionary<Component, string[]> _dicControls = new Dictionary<Component, string[]>();

        private static Dictionary<string, Dictionary<string, string>> _CultureTable = new Dictionary<string, Dictionary<string, string>>();

        private static object _SyncObject = new object();

        public WdxLanguageManager()
        {
        }

        public WdxLanguageManager(IContainer container)
        {
            container.Add(this);
        }

        public bool CanExtend(object extendee)
        {
            bool flag = extendee is IExtenderProvider;
            bool result;
            if (flag)
            {
                result = false;
            }
            else
            {
                Component component = extendee as Component;
                Form form = extendee as Form;
                bool flag2 = component != null && form == null;
                result = flag2;
            }
            return result;
        }

        /// <summary>
        /// 다국어코드 속성의 get 메서드 
        /// </summary>
        /// <param name="control"></param>
        /// <returns></returns>
        [Category("WDWorker"), DefaultValue(null), Description("다국어코드 및 컨트롤에 적용할 속성을 나열합니다."), DisplayName("_LanguageCode"), Editor(typeof(WdxLanguageEditor), typeof(UITypeEditor)), TypeConverter(typeof(StringArrayConverter))]
        public string[] GetLanguageCode(Component control)
        {
            string[] result = null;
            this._dicControls.TryGetValue(control, out result);
            return result;
        }

        /// <summary>
        /// 다국어코드 속성의 set 메서드
        /// </summary>
        /// <param name="control"></param>
        /// <param name="value"></param>
        public void SetLanguageCode(Component control, string[] value)
        {
            bool flag = this._dicControls.ContainsKey(control);
            if (flag)
            {
                this._dicControls[control] = value;
            }
            else
            {
                this._dicControls.Add(control, value);
            }
        }

        /// <summary>
        /// 다국어 코드를 문자열로 전환합니다.
        /// </summary>
        public void ApplyAll()
        {
            foreach (KeyValuePair<Component, string[]> current in this._dicControls)
            {
                Component key = current.Key;
                string[] value = current.Value;
                bool flag = value == null;
                if (!flag)
                {
                    Dictionary<string, string> langTable = WdxLanguageManager.GetLangTable(null);
                    string[] array = value;
                    for (int i = 0; i < array.Length; i++)
                    {
                        string text = array[i];
                        bool flag2 = string.IsNullOrWhiteSpace(text);
                        if (!flag2)
                        {
                            try
                            {
                                string[] array2 = text.Split(new char[]
								{
									','
								});
                                string text2 = array2[0];
                                string name = array2[1];
                                bool flag3 = langTable.ContainsKey(text2);
                                string value2;
                                if (flag3)
                                {
                                    value2 = langTable[text2];
                                }
                                else
                                {
                                    value2 = "@" + text2;
                                }
                                PropertyInfo property = key.GetType().GetProperty(name);
                                property.SetValue(key, value2, null);
                            }
                            catch
                            {
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 지정한 언어 코드의 다국어 테이블을 가져옵니다. 
        /// </summary>
        /// <param name="langCode">언어코드입니다.</param>
        /// <returns>다국어 테이블입니다.</returns>
        public static Dictionary<string, string> GetLangTable(string langCode)
        {
            bool flag = string.IsNullOrEmpty(langCode);
            if (flag)
            {
                langCode = Thread.CurrentThread.CurrentUICulture.TwoLetterISOLanguageName.ToUpper();
            }
            bool flag2 = !WdxLanguageManager._CultureTable.ContainsKey(langCode);
            if (flag2)
            {
                object syncObject = WdxLanguageManager._SyncObject;
                lock (syncObject)
                {
                    bool flag4 = !WdxLanguageManager._CultureTable.ContainsKey(langCode);
                    if (flag4)
                    {
                        DataSet languageTable = WdxServices.GetLanguageTable(langCode);
                        Dictionary<string, string> dictionary = new Dictionary<string, string>();
                        foreach (DataRow dataRow in languageTable.Tables[0].Rows)
                        {
                            string key = Convert.ToString(dataRow["MSG_CD"]);
                            string value = Convert.ToString(dataRow["MSG_TEXT"]);
                            dictionary[key] = value;
                        }
                        WdxLanguageManager._CultureTable[langCode] = dictionary;
                    }
                }
            }
            return WdxLanguageManager._CultureTable[langCode];
        }
    }
}
