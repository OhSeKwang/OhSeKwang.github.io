﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication30
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            //EventList 클래스에 들어갈 임의의 테스트 데이터
            EventList test1 = new EventList();
            test1.eventDay = DateTime.ParseExact("20170327", "yyyyMMdd", null);
            test1.eventList = new string[] { "코딩", "테스트" };
            EventList test = new EventList();
            test.eventDay = DateTime.ParseExact("20170312", "yyyyMMdd", null);
            test.eventList = new string[] { "운동", "학습" };
            List<EventList> list = new List<EventList>();
            list.Add(test1);
            list.Add(test);
            myTableLayoutPanel1.EventSource = list;
            this.Text = myTableLayoutPanel1.Date.Year + "년 " + myTableLayoutPanel1.Date.Month + "월";


        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            DateTime a = DateTime.ParseExact(monthCalendar1.SelectionRange.End.Year.ToString() + monthCalendar1.SelectionRange.End.Month.ToString("D2") + "01", "yyyyMMdd", null);
            myTableLayoutPanel1.Date = a;
            this.Text = monthCalendar1.SelectionRange.End.Year + "년 " + monthCalendar1.SelectionRange.End.Month + "월";
        }

        private void myTableLayoutPanel1_CellPaint(object sender, TableLayoutCellPaintEventArgs e)
        {
            monthCalendar1.SetSelectionRange(DateTime.ParseExact(myTableLayoutPanel1.Date.Year.ToString() + "-" + myTableLayoutPanel1.Date.Month.ToString("D2") + "-01", "yyyy-MM-dd", null),
                DateTime.ParseExact(myTableLayoutPanel1.Date.Year.ToString() + "-" + myTableLayoutPanel1.Date.Month.ToString("D2") + "-01", "yyyy-MM-dd", null));
        }

    }
}
