﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication30
{
    public class MyPanel : Panel
    {
        public MyPanel()
        {
            this.DoubleBuffered = true;
            this.Margin = new Padding(1);
            this.Padding = new Padding(5, 30, 5, 0);
            this.Dock = DockStyle.Fill;
            this.Location = new Point(0, 0);
        }
    }
}
