﻿namespace WindowsFormsApplication30
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.myCalendar1 = new WindowsFormsApplication30.HtCalendar();
            this.myPanel1 = new WindowsFormsApplication30.MyPanel();
            this.myPanel2 = new WindowsFormsApplication30.MyPanel();
            this.myPanel3 = new WindowsFormsApplication30.MyPanel();
            this.myPanel4 = new WindowsFormsApplication30.MyPanel();
            this.myPanel5 = new WindowsFormsApplication30.MyPanel();
            this.myPanel6 = new WindowsFormsApplication30.MyPanel();
            this.htPanel1 = new WindowsFormsApplication30.HtPanel();
            this.htLabel5 = new WindowsFormsApplication30.HtLabel();
            this.htLabel1 = new WindowsFormsApplication30.HtLabel();
            this.htPanel3 = new WindowsFormsApplication30.HtPanel();
            this.htLabel2 = new WindowsFormsApplication30.HtLabel();
            this.htPanel4 = new WindowsFormsApplication30.HtPanel();
            this.htLabel3 = new WindowsFormsApplication30.HtLabel();
            this.htPanel5 = new WindowsFormsApplication30.HtPanel();
            this.htLabel4 = new WindowsFormsApplication30.HtLabel();
            this.htHeaderLabel1 = new WindowsFormsApplication30.HtHeaderLabel();
            this.htHeaderLabel2 = new WindowsFormsApplication30.HtHeaderLabel();
            this.htHeaderLabel3 = new WindowsFormsApplication30.HtHeaderLabel();
            this.htHeaderLabel4 = new WindowsFormsApplication30.HtHeaderLabel();
            this.htHeaderLabel5 = new WindowsFormsApplication30.HtHeaderLabel();
            this.htHeaderLabel6 = new WindowsFormsApplication30.HtHeaderLabel();
            this.htHeaderLabel7 = new WindowsFormsApplication30.HtHeaderLabel();
            this.myCalendar1.SuspendLayout();
            this.htPanel1.SuspendLayout();
            this.htPanel3.SuspendLayout();
            this.htPanel4.SuspendLayout();
            this.htPanel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // myCalendar1
            // 
            this.myCalendar1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.myCalendar1.ColumnCount = 7;
            this.myCalendar1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.myCalendar1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.myCalendar1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.myCalendar1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.myCalendar1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.myCalendar1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.myCalendar1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.myCalendar1.Controls.Add(this.myPanel1, 0, 1);
            this.myCalendar1.Controls.Add(this.myPanel2, 1, 2);
            this.myCalendar1.Controls.Add(this.myPanel3, 2, 3);
            this.myCalendar1.Controls.Add(this.myPanel4, 3, 4);
            this.myCalendar1.Controls.Add(this.myPanel5, 4, 5);
            this.myCalendar1.Controls.Add(this.myPanel6, 5, 6);
            this.myCalendar1.Controls.Add(this.htPanel1, 3, 1);
            this.myCalendar1.Controls.Add(this.htPanel3, 4, 1);
            this.myCalendar1.Controls.Add(this.htPanel4, 4, 2);
            this.myCalendar1.Controls.Add(this.htPanel5, 3, 2);
            this.myCalendar1.Controls.Add(this.htHeaderLabel1, 0, 0);
            this.myCalendar1.Controls.Add(this.htHeaderLabel2, 1, 0);
            this.myCalendar1.Controls.Add(this.htHeaderLabel3, 2, 0);
            this.myCalendar1.Controls.Add(this.htHeaderLabel4, 3, 0);
            this.myCalendar1.Controls.Add(this.htHeaderLabel5, 4, 0);
            this.myCalendar1.Controls.Add(this.htHeaderLabel6, 5, 0);
            this.myCalendar1.Controls.Add(this.htHeaderLabel7, 6, 0);
            this.myCalendar1.Location = new System.Drawing.Point(17, 15);
            this.myCalendar1.Margin = new System.Windows.Forms.Padding(1);
            this.myCalendar1.Name = "myCalendar1";
            this.myCalendar1.RowCount = 7;
            this.myCalendar1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.myCalendar1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.myCalendar1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.myCalendar1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.myCalendar1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.myCalendar1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.myCalendar1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.myCalendar1.Size = new System.Drawing.Size(695, 415);
            this.myCalendar1.TabIndex = 0;
            // 
            // myPanel1
            // 
            this.myPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.myPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.myPanel1.Location = new System.Drawing.Point(1, 26);
            this.myPanel1.Margin = new System.Windows.Forms.Padding(1);
            this.myPanel1.Name = "myPanel1";
            this.myPanel1.Padding = new System.Windows.Forms.Padding(3, 15, 3, 0);
            this.myPanel1.Size = new System.Drawing.Size(97, 63);
            this.myPanel1.TabIndex = 0;
            // 
            // myPanel2
            // 
            this.myPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.myPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.myPanel2.Location = new System.Drawing.Point(100, 91);
            this.myPanel2.Margin = new System.Windows.Forms.Padding(1);
            this.myPanel2.Name = "myPanel2";
            this.myPanel2.Padding = new System.Windows.Forms.Padding(3, 15, 3, 0);
            this.myPanel2.Size = new System.Drawing.Size(97, 63);
            this.myPanel2.TabIndex = 1;
            // 
            // myPanel3
            // 
            this.myPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.myPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.myPanel3.Location = new System.Drawing.Point(199, 156);
            this.myPanel3.Margin = new System.Windows.Forms.Padding(1);
            this.myPanel3.Name = "myPanel3";
            this.myPanel3.Padding = new System.Windows.Forms.Padding(3, 15, 3, 0);
            this.myPanel3.Size = new System.Drawing.Size(97, 63);
            this.myPanel3.TabIndex = 1;
            // 
            // myPanel4
            // 
            this.myPanel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.myPanel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.myPanel4.Location = new System.Drawing.Point(298, 221);
            this.myPanel4.Margin = new System.Windows.Forms.Padding(1);
            this.myPanel4.Name = "myPanel4";
            this.myPanel4.Padding = new System.Windows.Forms.Padding(3, 15, 3, 0);
            this.myPanel4.Size = new System.Drawing.Size(97, 63);
            this.myPanel4.TabIndex = 1;
            // 
            // myPanel5
            // 
            this.myPanel5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.myPanel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.myPanel5.Location = new System.Drawing.Point(397, 286);
            this.myPanel5.Margin = new System.Windows.Forms.Padding(1);
            this.myPanel5.Name = "myPanel5";
            this.myPanel5.Padding = new System.Windows.Forms.Padding(3, 15, 3, 0);
            this.myPanel5.Size = new System.Drawing.Size(97, 63);
            this.myPanel5.TabIndex = 1;
            // 
            // myPanel6
            // 
            this.myPanel6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.myPanel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.myPanel6.Location = new System.Drawing.Point(496, 351);
            this.myPanel6.Margin = new System.Windows.Forms.Padding(1);
            this.myPanel6.Name = "myPanel6";
            this.myPanel6.Padding = new System.Windows.Forms.Padding(3, 15, 3, 0);
            this.myPanel6.Size = new System.Drawing.Size(97, 63);
            this.myPanel6.TabIndex = 1;
            // 
            // htPanel1
            // 
            this.htPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.htPanel1.Controls.Add(this.htLabel5);
            this.htPanel1.Controls.Add(this.htLabel1);
            this.htPanel1.Day = 1;
            this.htPanel1.DayColor = System.Drawing.Color.DarkGray;
            this.htPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.htPanel1.Location = new System.Drawing.Point(298, 26);
            this.htPanel1.Margin = new System.Windows.Forms.Padding(1, 1, 0, 0);
            this.htPanel1.Name = "htPanel1";
            this.htPanel1.Padding = new System.Windows.Forms.Padding(3, 17, 3, 0);
            this.htPanel1.Size = new System.Drawing.Size(98, 64);
            this.htPanel1.TabIndex = 2;
            // 
            // htLabel5
            // 
            this.htLabel5.AutoSize = true;
            this.htLabel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.htLabel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.htLabel5.Location = new System.Drawing.Point(3, 37);
            this.htLabel5.MouseEnterColor = System.Drawing.SystemColors.HotTrack;
            this.htLabel5.MouseLeaveColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.htLabel5.Name = "htLabel5";
            this.htLabel5.Padding = new System.Windows.Forms.Padding(4);
            this.htLabel5.Size = new System.Drawing.Size(60, 20);
            this.htLabel5.TabIndex = 1;
            this.htLabel5.Text = "htLabel5";
            // 
            // htLabel1
            // 
            this.htLabel1.AutoSize = true;
            this.htLabel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.htLabel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.htLabel1.Location = new System.Drawing.Point(3, 17);
            this.htLabel1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.htLabel1.MouseEnterColor = System.Drawing.SystemColors.HotTrack;
            this.htLabel1.MouseLeaveColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.htLabel1.Name = "htLabel1";
            this.htLabel1.Padding = new System.Windows.Forms.Padding(4);
            this.htLabel1.Size = new System.Drawing.Size(60, 20);
            this.htLabel1.TabIndex = 0;
            this.htLabel1.Text = "htLabel1";
            // 
            // htPanel3
            // 
            this.htPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.htPanel3.Controls.Add(this.htLabel2);
            this.htPanel3.Day = 1;
            this.htPanel3.DayColor = System.Drawing.Color.DarkGray;
            this.htPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.htPanel3.Location = new System.Drawing.Point(397, 26);
            this.htPanel3.Margin = new System.Windows.Forms.Padding(1, 1, 0, 0);
            this.htPanel3.Name = "htPanel3";
            this.htPanel3.Padding = new System.Windows.Forms.Padding(3, 17, 3, 0);
            this.htPanel3.Size = new System.Drawing.Size(98, 64);
            this.htPanel3.TabIndex = 2;
            // 
            // htLabel2
            // 
            this.htLabel2.AutoSize = true;
            this.htLabel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.htLabel2.Location = new System.Drawing.Point(3, 17);
            this.htLabel2.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.htLabel2.MouseEnterColor = System.Drawing.SystemColors.HotTrack;
            this.htLabel2.MouseLeaveColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.htLabel2.Name = "htLabel2";
            this.htLabel2.Padding = new System.Windows.Forms.Padding(4);
            this.htLabel2.Size = new System.Drawing.Size(113, 20);
            this.htLabel2.TabIndex = 0;
            this.htLabel2.Text = "모스티소프트 방문";
            // 
            // htPanel4
            // 
            this.htPanel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.htPanel4.Controls.Add(this.htLabel3);
            this.htPanel4.Day = 1;
            this.htPanel4.DayColor = System.Drawing.Color.DarkGray;
            this.htPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.htPanel4.Location = new System.Drawing.Point(397, 91);
            this.htPanel4.Margin = new System.Windows.Forms.Padding(1, 1, 0, 0);
            this.htPanel4.Name = "htPanel4";
            this.htPanel4.Padding = new System.Windows.Forms.Padding(3, 17, 3, 0);
            this.htPanel4.Size = new System.Drawing.Size(98, 64);
            this.htPanel4.TabIndex = 2;
            // 
            // htLabel3
            // 
            this.htLabel3.AutoSize = true;
            this.htLabel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.htLabel3.Location = new System.Drawing.Point(3, 17);
            this.htLabel3.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.htLabel3.MouseEnterColor = System.Drawing.SystemColors.HotTrack;
            this.htLabel3.MouseLeaveColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.htLabel3.Name = "htLabel3";
            this.htLabel3.Padding = new System.Windows.Forms.Padding(4);
            this.htLabel3.Size = new System.Drawing.Size(60, 20);
            this.htLabel3.TabIndex = 0;
            this.htLabel3.Text = "htLabel1";
            // 
            // htPanel5
            // 
            this.htPanel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.htPanel5.Controls.Add(this.htLabel4);
            this.htPanel5.Day = 1;
            this.htPanel5.DayColor = System.Drawing.Color.DarkGray;
            this.htPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.htPanel5.Location = new System.Drawing.Point(298, 91);
            this.htPanel5.Margin = new System.Windows.Forms.Padding(1, 1, 0, 0);
            this.htPanel5.Name = "htPanel5";
            this.htPanel5.Padding = new System.Windows.Forms.Padding(3, 17, 3, 0);
            this.htPanel5.Size = new System.Drawing.Size(98, 64);
            this.htPanel5.TabIndex = 2;
            // 
            // htLabel4
            // 
            this.htLabel4.AutoSize = true;
            this.htLabel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.htLabel4.Location = new System.Drawing.Point(3, 17);
            this.htLabel4.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.htLabel4.MouseEnterColor = System.Drawing.SystemColors.HotTrack;
            this.htLabel4.MouseLeaveColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.htLabel4.Name = "htLabel4";
            this.htLabel4.Padding = new System.Windows.Forms.Padding(4);
            this.htLabel4.Size = new System.Drawing.Size(60, 20);
            this.htLabel4.TabIndex = 0;
            this.htLabel4.Text = "htLabel1";
            // 
            // htHeaderLabel1
            // 
            this.htHeaderLabel1.AutoSize = true;
            this.htHeaderLabel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.htHeaderLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.htHeaderLabel1.Location = new System.Drawing.Point(1, 1);
            this.htHeaderLabel1.Margin = new System.Windows.Forms.Padding(1, 1, 0, 0);
            this.htHeaderLabel1.Name = "htHeaderLabel1";
            this.htHeaderLabel1.Size = new System.Drawing.Size(98, 24);
            this.htHeaderLabel1.TabIndex = 3;
            this.htHeaderLabel1.Text = "월";
            this.htHeaderLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // htHeaderLabel2
            // 
            this.htHeaderLabel2.AutoSize = true;
            this.htHeaderLabel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.htHeaderLabel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.htHeaderLabel2.Location = new System.Drawing.Point(100, 1);
            this.htHeaderLabel2.Margin = new System.Windows.Forms.Padding(1, 1, 0, 0);
            this.htHeaderLabel2.Name = "htHeaderLabel2";
            this.htHeaderLabel2.Size = new System.Drawing.Size(98, 24);
            this.htHeaderLabel2.TabIndex = 4;
            this.htHeaderLabel2.Text = "화";
            this.htHeaderLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // htHeaderLabel3
            // 
            this.htHeaderLabel3.AutoSize = true;
            this.htHeaderLabel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.htHeaderLabel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.htHeaderLabel3.Location = new System.Drawing.Point(199, 1);
            this.htHeaderLabel3.Margin = new System.Windows.Forms.Padding(1, 1, 0, 0);
            this.htHeaderLabel3.Name = "htHeaderLabel3";
            this.htHeaderLabel3.Size = new System.Drawing.Size(98, 24);
            this.htHeaderLabel3.TabIndex = 5;
            this.htHeaderLabel3.Text = "수";
            this.htHeaderLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // htHeaderLabel4
            // 
            this.htHeaderLabel4.AutoSize = true;
            this.htHeaderLabel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.htHeaderLabel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.htHeaderLabel4.Location = new System.Drawing.Point(298, 1);
            this.htHeaderLabel4.Margin = new System.Windows.Forms.Padding(1, 1, 0, 0);
            this.htHeaderLabel4.Name = "htHeaderLabel4";
            this.htHeaderLabel4.Size = new System.Drawing.Size(98, 24);
            this.htHeaderLabel4.TabIndex = 6;
            this.htHeaderLabel4.Text = "목";
            this.htHeaderLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // htHeaderLabel5
            // 
            this.htHeaderLabel5.AutoSize = true;
            this.htHeaderLabel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.htHeaderLabel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.htHeaderLabel5.Location = new System.Drawing.Point(397, 1);
            this.htHeaderLabel5.Margin = new System.Windows.Forms.Padding(1, 1, 0, 0);
            this.htHeaderLabel5.Name = "htHeaderLabel5";
            this.htHeaderLabel5.Size = new System.Drawing.Size(98, 24);
            this.htHeaderLabel5.TabIndex = 7;
            this.htHeaderLabel5.Text = "금";
            this.htHeaderLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // htHeaderLabel6
            // 
            this.htHeaderLabel6.AutoSize = true;
            this.htHeaderLabel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.htHeaderLabel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.htHeaderLabel6.Location = new System.Drawing.Point(496, 1);
            this.htHeaderLabel6.Margin = new System.Windows.Forms.Padding(1, 1, 0, 0);
            this.htHeaderLabel6.Name = "htHeaderLabel6";
            this.htHeaderLabel6.Size = new System.Drawing.Size(98, 24);
            this.htHeaderLabel6.TabIndex = 8;
            this.htHeaderLabel6.Text = "토";
            this.htHeaderLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // htHeaderLabel7
            // 
            this.htHeaderLabel7.AutoSize = true;
            this.htHeaderLabel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.htHeaderLabel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.htHeaderLabel7.Location = new System.Drawing.Point(595, 1);
            this.htHeaderLabel7.Margin = new System.Windows.Forms.Padding(1, 1, 1, 0);
            this.htHeaderLabel7.Name = "htHeaderLabel7";
            this.htHeaderLabel7.Size = new System.Drawing.Size(99, 24);
            this.htHeaderLabel7.TabIndex = 9;
            this.htHeaderLabel7.Text = "일";
            this.htHeaderLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(733, 451);
            this.Controls.Add(this.myCalendar1);
            this.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.myCalendar1.ResumeLayout(false);
            this.myCalendar1.PerformLayout();
            this.htPanel1.ResumeLayout(false);
            this.htPanel1.PerformLayout();
            this.htPanel3.ResumeLayout(false);
            this.htPanel3.PerformLayout();
            this.htPanel4.ResumeLayout(false);
            this.htPanel4.PerformLayout();
            this.htPanel5.ResumeLayout(false);
            this.htPanel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private HtCalendar myCalendar1;
        private MyPanel myPanel1;
        private MyPanel myPanel2;
        private MyPanel myPanel3;
        private MyPanel myPanel4;
        private MyPanel myPanel5;
        private MyPanel myPanel6;
        private HtPanel htPanel1;
        private HtLabel htLabel1;
        private HtPanel htPanel3;
        private HtLabel htLabel2;
        private HtPanel htPanel4;
        private HtLabel htLabel3;
        private HtPanel htPanel5;
        private HtLabel htLabel4;
        private HtHeaderLabel htHeaderLabel1;
        private HtHeaderLabel htHeaderLabel2;
        private HtHeaderLabel htHeaderLabel3;
        private HtHeaderLabel htHeaderLabel4;
        private HtHeaderLabel htHeaderLabel5;
        private HtHeaderLabel htHeaderLabel6;
        private HtHeaderLabel htHeaderLabel7;
        private HtLabel htLabel5;
    }
}