﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using Test;

namespace XmlSerialize
{
    public partial class Form1 : FormBase
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "모스티소프트";
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {

            Layout layout = new Layout();
            List<Test.Form> formList = new List<Test.Form>();
            Test.Form form = new Test.Form();
            formList.Add(form);

            layout.FormList = formList;
            form.Name = "Application1.Form1";

            form.GridList = new List<Grid>();

            Grid grid1 = new Grid();
            grid1.Name = "grdSample";
            form.GridList.Add(grid1);
            grid1.ColumnList = new List<Column>();
            Column column1 = new Column();
            column1.key = "A";
            column1.order = 1;
            column1.width = 100;
            Column column2 = new Column();
            column2.key = "B";
            column2.order = 2;
            column2.width = 150;
            grid1.ColumnList.Add(column1);
            grid1.ColumnList.Add(column2);

            Grid grid2 = new Grid();
            grid2.Name = "grdSample2";
            form.GridList.Add(grid2);
            grid2.ColumnList = new List<Column>();
            Column column3 = new Column();
            column3.key = "C";
            column3.order = 3;
            column3.width = 200;
            Column column4 = new Column();
            column4.key = "D";
            column4.order = 4;
            column4.width = 250;

            grid2.ColumnList.Add(column3);
            grid2.ColumnList.Add(column4);

            /////////////////////////////////////////////////////////////

            form = new Test.Form();
            formList.Add(form);

            layout.FormList = formList;
            form.Name = "Application1.Form2";

            form.GridList = new List<Grid>();

            grid1 = new Grid();
            grid1.Name = "grdSample";
            form.GridList.Add(grid1);
            grid1.ColumnList = new List<Column>();
            column1 = new Column();
            column1.key = "A";
            column1.order = 1;
            column1.width = 100;
            column2 = new Column();
            column2.key = "B";
            column2.order = 2;
            column2.width = 150;
            grid1.ColumnList.Add(column1);
            grid1.ColumnList.Add(column2);

            grid2 = new Grid();
            grid2.Name = "grdSample2";
            form.GridList.Add(grid2);
            grid2.ColumnList = new List<Column>();
            column3 = new Column();
            column3.key = "C";
            column3.order = 3;
            column3.width = 200;
            column4 = new Column();
            column4.key = "D";
            column4.order = 4;
            column4.width = 250;

            grid2.ColumnList.Add(column3);
            grid2.ColumnList.Add(column4);

            XmlSerializer ser = new XmlSerializer(typeof(Layout));
            using (TextWriter writer = new StreamWriter("test.xml"))
            {
                ser.Serialize(writer, layout);
                writer.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Layout layout = null;
            XmlSerializer ser = new XmlSerializer(typeof(Layout));
            using (XmlReader reader = XmlReader.Create("test.xml"))
            {
                layout = (Layout)ser.Deserialize(reader);
                reader.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
        }

        public void ShowMsg(string[] args)
        {
            foreach (string item in args)
            {
                MessageBox.Show(item.ToString());
            }

        }

        public override void ReceiveFromWeb(string message)
        {
            textBox1.Text = message;
            MessageBox.Show(message);
        }

    }
}
