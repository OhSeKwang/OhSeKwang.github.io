﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Test
{
    [XmlRoot("layout", Namespace="http://amis.mostisoft.com")]
    public class Layout
    {
        [XmlElement("form")]
        public List<Form> FormList;
    }

    public class Form
    {
        [XmlAttribute("nm")]
        public String Name { get; set; }

        [XmlElement("grid")]
        public List<Grid> GridList { get; set; }
    }

    public class Grid
    {
        [XmlElement("column")]
        public List<Column> ColumnList { get; set; }

        [XmlAttribute("nm")]
        public string Name { get; set; }
    }

    public class Column
    {
        [XmlAttribute("key")]
        public string key { get; set; }

        [XmlAttribute("order")]
        public int order { get; set; }

        [XmlAttribute("width")]
        public int width { get; set; }
    }
}
