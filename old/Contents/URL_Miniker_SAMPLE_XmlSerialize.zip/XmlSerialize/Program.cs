﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace XmlSerialize
{
    static class Program
    {
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        private static readonly string APP_MUTEX_GUID = "85995180-56F9-4F19-B63D-0A705FCCC91F";
        /// <summary>
        /// 해당 응용 프로그램의 주 진입점입니다.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            bool isNew = false;
            Mutex mutex = new Mutex(true, APP_MUTEX_GUID, out isNew);

            if (isNew)
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Form1());

                mutex.ReleaseMutex();
            }
            else
            {
                IntPtr handle = FindWindow(null, "모스티소프트");
                //MessageBox.Show(handle.ToString());

                SetForegroundWindow(handle);

                if (args.Length == 0)
                    SendArgs(handle, "No Args");
                else
                {
                    
                    //NameValueCollection parameters = HttpUtility.ParseQueryString(args[0]);
                    //foreach (var item in parameters)
                    //{

                    //}
                    //nexFrame://CPP027/id=htkm&name=김희택 --> key : CPP027
                    string strKey = Regex.Match(args[0], @"(?<=://).+?(?=:|/|\Z)").Value;
                    MessageBox.Show("Key : " + strKey);
                    // string strParam = args[0].Split('?')[1];
                    SendArgs(handle, args[0]);
                }
                    
                //Form control = Control.FromHandle(handle) as Form;
                //Type [] types= new Type [1];
                //types[0] = typeof(string[]);
                //MethodInfo method = control.GetType().GetMethod("ShowMsg", types);
                //method.Invoke(control, args);

                //Process current = Process.GetCurrentProcess();
                //foreach (Process process in Process.GetProcessesByName(current.ProcessName))
                //{
                //    if (process.Id != current.Id)
                //    {
                //        //SetForegroundWindow(process.MainWindowHandle);
                //        //Form1.parameters(Environment.GetCommandLineArgs());
                //        break;
                //    }
                //}
                Application.Exit();
            }
        }

        public static bool SendArgs(IntPtr handle, string message)
        {
            Win32API.COPYDATASTRUCT data = new Win32API.COPYDATASTRUCT();
            try
            {
                data = new Win32API.COPYDATASTRUCT();
                data.dwData = (IntPtr)(1024 + 604);
                data.cbData = (uint)message.Length * sizeof(char);
                data.lpData = message;

                if(handle != IntPtr.Zero)
                    Win32API.SendMessage(handle, Win32API.WM_COPYDATA, IntPtr.Zero, ref data);
            }
            finally
            {
                
            }

            return true;
        } 
    }
}
